(ns data-analysis-hidden-user.core
  (:require [clojure.data.json :as json]) )

(defn ascii-letter? [ch]
  (or (and (>= ch 65) (<= ch 90)) (and (>= ch 97) (<= ch 122))) )

(defn bucket-finder [user-name]
  (let [ch (get user-name 0)]
    (if (ascii-letter? (int ch))
      (str "hu_bucket_" ch)
      (str "hu_bucket_OTHER"))))

;;(def file-path "/Users/me/_dev/incubator/data_analysis_hidden_user/data/blocked-users-20151218-154919.json")
(def file-path "../../data/blocked-users-20151218-154919.json")

(def hu-json (slurp file-path))

(def hu (json/read-str hu-json))
;(prn "hu:" hu)
(prn "count:" (count hu))
(newline)
(def huf (frequencies hu))
;(prn "freqs hu:" huf)
(defn hasher [n-chars, user-name]
  (subs user-name 0 n-chars))

; hidden users, hashed key is 1st char
(def buckets (map bucket-finder hu))
(def buckets-freq (frequencies buckets))
(prn "freq hidden by bucket:" (sort-by key buckets-freq) )
(newline)
(prn "freqs hidden by counts:" (sort-by val buckets-freq) )
(newline)(newline)


