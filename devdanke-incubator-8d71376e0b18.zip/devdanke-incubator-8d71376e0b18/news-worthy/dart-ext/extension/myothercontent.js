//debugger;

console.log("in my other content script");