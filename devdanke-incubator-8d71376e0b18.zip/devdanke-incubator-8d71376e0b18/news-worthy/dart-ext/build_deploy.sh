#!/bin/sh

# do build
cd dart-lib
~/_tools/dart/dart-sdk/bin/pub build  --mode=release

# tried to make it only run if no warning from pub build, but it ran even when there was a  compile error/warning.
if [ $? -eq 0 ]
then
  cd build/web

  #cp -f -R -L . ../../../chrome-ext/source
  cp -f -v -L ./*.js ../../../extension
fi




