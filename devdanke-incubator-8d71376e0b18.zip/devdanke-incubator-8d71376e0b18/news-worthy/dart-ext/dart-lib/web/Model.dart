library model;
//import 'package:quiver/collection.dart';
import "DbMgr.dart";


/* **************************************
Hold a reference to each story on a GNews page.
Recreate object anew each time page is downloaded.
Move stories to different collection whenever the user changes a news source's state.
Each collection is a map. The map key is the news source name.
The map value is a list of stories that come from a news source.
This class doesn't know anything about stories. It just holds references to stories.
 */
class Model
{
  final Map<String,Set> _worthyByNewsSource = new Map();
  final Map<String,Set> _unworthyByNewsSource = new Map();
  final Map<String,Set> _plainByNewsSource = new Map();

  Model(List worthyNewsSources, List unworthyNewsSources)
  {
    // Now we know the initial worthy and unworthy news sources.
    worthyNewsSources.forEach((newsSourceName){
      _worthyByNewsSource[newsSourceName] = new Set();
    });

    unworthyNewsSources.forEach((newsSourceName){
      _unworthyByNewsSource[newsSourceName] = new Set();
    });
  }

  bool isWorthy(String newSourceName)
  {
    return _worthyByNewsSource.containsKey(newSourceName);
  }

  bool isUnworthy(String newSourceName)
  {
    return _unworthyByNewsSource.containsKey(newSourceName);
  }

  /* **************************************************************************
  Used only once and only at initialization.
   */
  void addWorthy(String newsSourceName, Object storyElem)
  {
    _worthyByNewsSource[newsSourceName]=storyElem;
  }

  /* **************************************************************************
  Used only once and only at initialization.
   */
  void addUnworthy(String newsSourceName, Object storyElem)
  {
    _unworthyByNewsSource[newsSourceName]=storyElem;
  }

  /* **************************************************************************
  Used only once and only at initialization.
   */
  void addPlain(String newsSourceName, Object storyElem)
  {
    _plainByNewsSource[newsSourceName]=storyElem;
  }

  /* **************************************************************************
  Used to show news sources on icon_popup page.
   */
  Iterable<String> getUnworthyNewsSources()
  {
    return _unworthyByNewsSource.keys;
  }


  /* **************************************************************************
  Used to show news sources on icon_popup page.
   */
  Iterable<String> getWorthyNewsSources()
  {
    return _worthyByNewsSource.keys;
  }

}