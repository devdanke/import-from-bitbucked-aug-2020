library message_util;

import 'dart:js';

const String MSG_RESULT_IS_OK =  "MSG_RESULT_IS_OK";
const String MSG_ACTION =        "MSG_ACTION";
const String MSG_ERROR_INFO =    "MSG_ERROR_INFO";

const String MSG_ERROR_UNKNOWN_ACTION =    "MSG_ERROR_UNKNOWN_ACTION";

// get news sources for content script
const String MSG_GET_NEWS_SOURCES = "MSG_GET_NEWS_SOURCES";
const String MSG_RESULT_WORTHY =    "MSG_RESULT_WORTHY";
const String MSG_RESULT_UNWORTHY =  "MSG_RESULT_UNWORTHY";

// get news sources for popup html
const String MSG_LOAD_NEWS_SOURCES_INTO_POPUP =  "MSG_LOAD_NEWS_SOURCES_INTO_POPUP";

const String _me = "message_util:";


/* **************************
Register to listen for chrome extension message event.
Client provides a function to handle messages. Message hander looks like this:
messageHandler(request, sender, sendResponse)
 */
void registerChromeExtMessageListener(chromeMessageHandlerFunction)
{
  print("${_me} registerChromeExtMessageListener IN");

  var jsOnMessageEvent = context['chrome']['runtime']['onMessage'];

  JsObject dartOnMessageEvent =
  (jsOnMessageEvent is JsObject ? jsOnMessageEvent : new JsObject.fromBrowserObject(jsOnMessageEvent));

  dartOnMessageEvent.callMethod('addListener', [chromeMessageHandlerFunction]);

  print("${_me} registerChromeExtMessageListener OUT");
}


/* **********************
 */
void requestNewsSourceData(Function clientNewsSourcesHandler)
{
  print("${_me} requestNewsSourceData IN");

  context['chrome']['runtime'].callMethod('sendMessage',
  [
      new JsObject.jsify({MSG_ACTION: MSG_GET_NEWS_SOURCES}),
          (respObj) => checkThenPassNewsSourcesListsToClient(respObj,clientNewsSourcesHandler)
  ]);
  print("${_me} requestNewsSourceData OUT");
}


/* **********************
 */
void checkThenPassNewsSourcesListsToClient(JsObject respObj, Function clientNewsSourcesHandler)
{
  if(respObj[MSG_RESULT_IS_OK]) {

    List worthyNewsSources = respObj[MSG_RESULT_WORTHY];
    List unworthyNewsSources = respObj[MSG_RESULT_UNWORTHY];

    print("${_me} worthy: ${worthyNewsSources}");
    print("${_me} unworthy: ${unworthyNewsSources}");

    clientNewsSourcesHandler(worthyNewsSources, unworthyNewsSources);
  }
  else
  {
    print("${_me}: problem with response from background_script.js");
  }
}




