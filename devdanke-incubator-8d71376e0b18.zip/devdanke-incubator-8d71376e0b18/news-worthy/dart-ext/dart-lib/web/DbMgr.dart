library db_mgr;

class DbMgr
{
  Set<String> loadUnworthy()
  {
    Set<String> set = new Set();
    set.add("Fox News");
    set.add("seattlepi.com");
    set.add("Boston Globe");
    set.add("Washington Times");
    set.add("Bleacher Report");
    set.add("USA TODAY");
    set.add("Wall Street Journal");
    return set;
  }

  Set<String> loadWorthy()
  {
    Set<String> set = new Set();
    set.add("ABC Online");
    set.add("CNBC");
    set.add("Brisbane Times");
    set.add("The Guardian");
    set.add("Sydney Morning Herald	");
    return set;
  }

}