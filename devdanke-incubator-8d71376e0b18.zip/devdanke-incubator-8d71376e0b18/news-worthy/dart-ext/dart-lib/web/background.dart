//import 'dart:mirrors';
import 'dart:js';

import 'DbMgr.dart';
import 'message_util.dart' as msg;



DbMgr _dbMgr;


/* **************************
MAIN
 */
void main() {

  print("IN");

  _dbMgr = new DbMgr();

//  msg.registerChromeExtMessageListener(messageHandler);

  whenGnewsPageLoadsShowExtensionIcon();

  print("OUT");
}


/* **************************
 */
void whenGnewsPageLoadsShowExtensionIcon()
{
  JsObject chromeTabs = context['chrome']['tabs'];
  JsObject chromeTabsOnUpdated = chromeTabs['onUpdated'];



/*
.callMethod('addListener',[handleTabUpdateEvent]);

    (function(tabId, changeInfo, tab) {

    if (~tab.url.indexOf('.pl')) {
      chrome.pageAction.show(tabId);
    }

  }

  context['chrome']['runtime'].callMethod('sendMessage',
  [
      new JsObject.jsify({MSG_ACTION: MSG_GET_NEWS_SOURCES}),
          (respObj) => checkThenPassNewsSourcesListsToClient(respObj,clientNewsSourcesHandler)
  ]);


  context['chrome']['runtime'].callMethod('sendMessage',
  chrome.tabs.onUpdated.listen((chrome.OnUpdatedEvent event) {

    chrome.pageAction.show(event.tabId);
    print('Showing extension icon. event.changeInfo=${event.changeInfo}');
  });
*/

  print("Will show extension icon for matching pages.");
}

void handleTabUpdateEvent(tabId, changeInfo, tab)
{

  print("handleTabUpdateEvent: IN");
  print("tabId.url= ${tabId['url']}");
  print("handleTabUpdateEvent: OUT");
}


/* **************************
Handle all requests from clients, such as from content_script.js and popup_script.js.
 */
void messageHandler(request, sender, sendResponse)
{
  var action = request[msg.MSG_ACTION];
  print("messageHandler: received action = $action");

  Map respData = new Map();

  if(action == msg.MSG_GET_NEWS_SOURCES)
  {
    respData[msg.MSG_RESULT_WORTHY] = _dbMgr.loadWorthy().toList();
    respData[msg.MSG_RESULT_UNWORTHY] = _dbMgr.loadUnworthy().toList();

    respData[msg.MSG_RESULT_IS_OK] = true;
  }
  else
  {
    respData[msg.MSG_RESULT_IS_OK] = false;
    respData[msg.MSG_ERROR_INFO] = msg.MSG_ERROR_UNKNOWN_ACTION;
  }

  sendResponse.apply([new JsObject.jsify(respData)]);

  print("messageHandler: OUT");
}
/*
function checkForValidUrl(tabId, changeInfo, tab) {
  if (tab.url.indexOf('.foo.com') > -1)
    chrome.pageAction.show(tabId);
};

chrome.tabs.onUpdated.addListener(checkForValidUrl);

chrome.pageAction.onClicked.addListener(function(tab){
  var myName = tab.url.split(".")[0].slice(7);
  if (myName != "www") //ignore main site
    chrome.tabs.update(tab.id, {url: "http://foo.com/foo.html?t=" + myName});
});

 */

