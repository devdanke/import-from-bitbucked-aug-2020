import 'dart:html';

import 'Model.dart';
import 'message_util.dart' as msg;
import 'my_util.dart' as util;


const WORTHY_BTN_STYLE =   "smileFace";
const UNWORTHY_BTN_STYLE = "sadFace";
const PLAIN_BTN_STYLE =    "plainFace";

List<String> btnStyles = [WORTHY_BTN_STYLE, UNWORTHY_BTN_STYLE, PLAIN_BTN_STYLE];

const TITLE_ELEM_CLASS =   ".titletext";
const SOURCE_ELEM_CLASS =  ".al-attribution-source";
const SNIPPET_ELEM_CLASS = ".esc-lead-snippet-wrapper";


Model _model;

void main()
{
  print("IN");

  // HTML page manipulation begins after news source data arrives from background_script.js.
//  msg.requestNewsSourceData(initPage);

  print("OUT");
}

/*
//////////////////////////////////////////////
void initPage(List worthyNewsSources, List unworthyNewsSources)
{
  _model = new Model(worthyNewsSources,unworthyNewsSources);

  List<Element> stories = querySelectorAll("#main-wrapper .story").toList();
  print("Story count: ${stories.length}.");

  processStories(stories);
}


//////////////////////////////////////////////
void processStories(List<Element> stories)
{
  print("processStories IN");

  stories.forEach((Element storyElem){

    Element newsSourceElem = storyElem.querySelector(SOURCE_ELEM_CLASS);
    String newsSourceName = util.safeGetText(newsSourceElem);
    String btnStyle;

    if(_model.isWorthy(newsSourceName))
    {
      _model.addWorthy(newsSourceName, storyElem);
      btnStyle = WORTHY_BTN_STYLE;
    }
    else if(_model.isUnworthy(newsSourceName))
    {
      _model.addUnworthy(newsSourceName, storyElem);
      btnStyle = UNWORTHY_BTN_STYLE;
    }
    else
    {
      _model.addPlain(newsSourceName, storyElem);
      btnStyle = PLAIN_BTN_STYLE;
    }

    addNewsSourceToggle(btnStyle, storyElem);
  });

  print("processStories OUT");
}


//////////////////////////////////////////////
void addNewsSourceToggle(String worthinessState, Element storyElem)
{
  if(storyElem == null)
  {
    print("addNewsSourceToggle: ERROR storyElem was null");
    return;
  }

  Element newsSourceElem = storyElem.querySelector(SOURCE_ELEM_CLASS);

  if(newsSourceElem == null)
  {
    print("addNewsSourceToggle: ERROR newsSourceElem was null");
    return;
  }

  String newsSourceName = util.safeGetText(newsSourceElem);

  if(UNWORTHY_BTN_STYLE == worthinessState)
  {
    Element titleElem = storyElem.querySelector(TITLE_ELEM_CLASS);
    String title = util.safeGetText(titleElem);

    AnchorElement titleLink = titleElem.parent;
    titleLink.onClick.listen((event) => warnAboutUnworthiness(event));

    print("Unworthy: ${title} : ${newsSourceName}\n");
  }

  // Button shows current worthiness and allows state change.
  newsSourceElem.replaceWith(makeNewsWorthyToggleBtn(worthinessState, newsSourceName));
}


//////////////////////////////////////////////
ButtonElement makeNewsWorthyToggleBtn(String btnStyle, String newsSourceName)
{
  ButtonElement btnElem = new ButtonElement();

  btnElem.appendHtml("<span>${newsSourceName}</span>&nbsp;");

  ImageElement img = new ImageElement();
  img.classes.add(btnStyle);
  btnElem.append(img);

  btnElem.onClick.listen((MouseEvent me){

    String currentStyle = img.classes.first;

    img.classes.clear();
    img.classes.add(calcNextBtnStyle(currentStyle));

    me.stopPropagation();
  });
  return btnElem;
}


//////////////////////////////////////////////
String calcNextBtnStyle(String curStyle)
{
  String nextStyle = btnStyles.first;
  int index = btnStyles.indexOf(curStyle);
  if((index+1) < btnStyles.length)
  {
    nextStyle = btnStyles[index+1];
  }

  return nextStyle;
}


//////////////////////////////////////////////
void warnAboutUnworthiness(Event event)
{
  event.preventDefault();
  window.alert("Unworthy News Source.");
}
*/
