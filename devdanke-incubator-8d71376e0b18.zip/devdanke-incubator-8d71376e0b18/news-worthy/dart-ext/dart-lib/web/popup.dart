import 'dart:html';

import 'message_util.dart' as msg;
import 'my_util.dart' as util;

/*
Where does this log to?  I don't see it in Chrome dev tools log console.
 */
const String me = "page_icon_popup_script:";

/* **************************
 */
void main()
{
  print("${me} IN");

  msg.requestNewsSourceData(initPage);

  print("${me} OUT");
}


/* **********************
 */
void initPage(List worthyNewsSources, List unworthyNewsSources)
{
  print("${me} initPage IN");

  Element worthyListElem = querySelector("#worthyList");
  worthyNewsSources.forEach((String newsSourceName)=> addListItem(newsSourceName,worthyListElem,"worthyList"));

  Element unworthyListElem = querySelector("#unworthyList");
  unworthyNewsSources.forEach((String newsSourceName)=> addListItem(newsSourceName,unworthyListElem,"unworthyList"));

  print("${me} initPage OUT");
}


/* **********************
 */
void addListItem(String newsSourceName, Element listElem, String listName)
{
  print("${me} addListItem IN");

  try
  {
    if(util.isArgNull(newsSourceName,"newsSourceName")) return;
    if(util.isArgNull(listElem,"listElem-$listName")) return;

    listElem.appendHtml("<li>$newsSourceName</li>");
    print("$me added li $newsSourceName.");
  }
  catch(err)
  {
    print("${me} Problem adding list item. newsSource=$newsSourceName. listElem=${listName}");
  }

  print("${me} addListItem OUT");
}




