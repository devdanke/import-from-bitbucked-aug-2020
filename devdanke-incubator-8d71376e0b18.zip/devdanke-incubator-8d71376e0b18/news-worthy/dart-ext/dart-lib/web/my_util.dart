library my_util;

import 'dart:html';



/* ***********************
 */
String safeGetText(Element elem)
{
  return (elem != null) ? elem.text : null;
}



/* **********************
 */
bool isArgNull(var arg, String argName)
{
  if(arg == null)
  {
    print("Error: arg $argName=null");
    return true;
  }
  else
  {
    return false;
  }
}