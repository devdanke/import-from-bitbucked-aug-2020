//debugger;
"use strict";
// Currently, this script is injected into content page by background.js.

var me = "process_content.js";


var MODEL_CHANGED_MSG = "MODEL_CHANGED_MSG";

var TITLE_ELEM_CLASS =   ".titletext";
var MAIN_STORY_SOURCE_ELEM_CLASS =  ".al-attribution-source";


var LINK_TO_UNWORTHY_CLASS =  "linkToUnworthy";

var SMALL_STORY_SOURCE_ELEM_CLASS =  ".source-pref";

var MAIN_STORIES_SELECTOR = '#main-wrapper .story';
var SMALL_STORIES_GREEDY_SELECTOR = '.small-story';


// These styles choose the image to show on each news source btn.
// So, it's doing double duty as style and state record.
var WORTHY_STATE_BTN_STYLE =   "worthyState";
var UNWORTHY_STATE_BTN_STYLE = "unworthyState";
var NO_STATE_BTN_STYLE =       "noState";

var WORTHY_LIST_KEY = "WORTHY_LIST_KEY";
var UNWORTHY_LIST_KEY = "UNWORTHY_LIST_KEY";
var BTN_STYLES = [WORTHY_STATE_BTN_STYLE, UNWORTHY_STATE_BTN_STYLE, NO_STATE_BTN_STYLE];

// global data model
// a storyInfo object is: newsSourceName, storyLinkElem, and btnImgElem
// storyInfo hold both main and small stories.  They're similar enough to treat the same for updates.
// StoryInfo fields: followStoryLink, newsSourceName, newsSourceStateElem.
var gModel = {
    worthyNewsSources : [],
    unworthyNewsSources : [],
    storyInfos : []
};

var gSmallStoryConfig = {
    isProcessed : false,
    waitBeforeAttempt : 2000,
    storyCount : 0, // if < 5, then try up to 1 more time.
    //minStoryCount: 5,
    //maxProcessAttempts : 0,
    processAttempCount : 0
}

//////////////////////////////////////////////////////////////
// It all starts here! ///////////////////////////////////////
//////////////////////////////////////////////////////////////
main();



//////////////////////////////////////////////////////////////
function main()
{
    console.debug(me, "IN");

    try
    {
        chrome.runtime.onMessage.addListener(handleMessageFromPopup);

        loadNewsSourceRatings(initialProcessPage);

        processShowMoreLinks();
    }
    catch(err) {
        alert("err.msg: " + err.message);
    }

    console.debug(me, "OUT");
}


//////////////////////////////////////////////////////////////
function processShowMoreLinks()
{
    var SHOW_MORE_STORIES_CLASS = ".show-more-blended-stories";
    var showMoreNodes = document.querySelectorAll(SHOW_MORE_STORIES_CLASS);
    var showMoreNodesCount = showMoreNodes.length;

    for(var i=0; i<showMoreNodesCount; i++)
    {
        var link = showMoreNodes[i].firstChild;

        console.debug("added listener to:",link.textContent);

        link.addEventListener("click", function(event){
            console.debug("Clicked: " + event.target.textContent);

            // Wait to process small-stories, because Google's ajax loads them after main stories.
            window.setTimeout(function()
                {

                    processStories(gModel, MAIN_STORIES_SELECTOR, MAIN_STORY_SOURCE_ELEM_CLASS);

                },
                1000);


            // Ideally, just process 'raw' main stories that were just download
            // that don't have newsSource btn.

            //event.preventDefault();
            //event.stopImmediatePropagation();
        });
    }
}


//////////////////////////////////////////////////////////////
function handleMessageFromPopup(request, sender, sendResponse)
{
    console.log("Got message.");
    if(request.action == MODEL_CHANGED_MSG)
    {
        console.log("Popup says to update stories state from DB data.");
        loadNewsSourceRatings(updateStoryStateViewFromModel);
    }
    else
    {
        console.debug("Unknown message from popup: ", request.action);
    }
}


//////////////////////////////////////////////////////////////
function loadNewsSourceRatings(newsSourceRatingsConsumer)
{
    chrome.storage.local.get([WORTHY_LIST_KEY, UNWORTHY_LIST_KEY],
        function(dbData)
        {
            gModel.worthyNewsSources = getValOrEmptyArray(dbData[WORTHY_LIST_KEY]);
            gModel.unworthyNewsSources = getValOrEmptyArray(dbData[UNWORTHY_LIST_KEY]);

            try
            {
                newsSourceRatingsConsumer(gModel);
            }
            catch(err) {
                console.log("err.msg: ", err.message, err.stack );
            }
        }
    );
}


//////////////////////////////////////////////////////////////
// Initially, process each story by replacing news source name span
// with a button, containing news source name and image.
// Collect a list of StoryInfo's into the model object.
// After that initial setup, call another method that assigns worthiness based on user's prior saved choices.
function initialProcessPage(model)
{
    processStories(model, MAIN_STORIES_SELECTOR, MAIN_STORY_SOURCE_ELEM_CLASS);

    // Wait to process small-stories, because Google's ajax loads them after main stories.
    window.setTimeout(function()
        {
            var storyCount = processStories(model, SMALL_STORIES_GREEDY_SELECTOR, SMALL_STORY_SOURCE_ELEM_CLASS);

            gSmallStoryConfig.isProcessed = true;
            gSmallStoryConfig.processAttempCount += 1;
            gSmallStoryConfig.storyCount += storyCount;
        },
        gSmallStoryConfig.waitBeforeAttempt);
}


//////////////////////////////////////////////////////////////
// This does a one time add of stories to global model.
function processStories(model, storiesSelectory, newsSourceSelector)
{
    var storyInfos = initialProcessStories(storiesSelectory, newsSourceSelector);
    console.debug("found raw stories:", storyInfos.length);
    model.storyInfos = model.storyInfos.concat(storyInfos); // TODO make this a StoryInfo class method.
    updateStoryStateViewFromModel(model);
    return storyInfos.length;
}

//////////////////////////////////////////////////////////////

/*
Add news source btn to each story.
Return an array of StoryInfo ojbect that can be used to update the stories later, based on user new source choices.
 */
function initialProcessStories(storiesSelector, newsSourceSelector)
{
    var nodeList = document.querySelectorAll(storiesSelector);
    var nodeCount = nodeList.length;

    if(nodeCount < 1)
    {
        console.log("No '", storiesSelector, "' stories to process.");
        return;
    }

    var storyInfos = [];
    for (var i=0; i  < nodeCount; i++)
    {
        var storyElem = nodeList[i];

        var newsSourceElem = storyElem.querySelector(newsSourceSelector);

        if(newsSourceElem==null)
        {
            // Skip stories that don't have a news source child element.
            continue;
        }

        var newsSourceName = newsSourceElem.textContent;
        var btnElem = replaceWithButton(newsSourceName, newsSourceElem, NO_STATE_BTN_STYLE);

        var curStoryInfo = makeStoryInfo(
            newsSourceName,
            storyElem.querySelector(TITLE_ELEM_CLASS),
            btnElem.querySelector("image")
        );

        // Add story info to model so it can be updated later when user changes news source rating.
        storyInfos.push(curStoryInfo);
    }

    return storyInfos;
}


//////////////////////////////////////////////////////////////
/*
Replace new source span with toggle button.
Clicking button toggles through newSource worhiness states.

Replace target element with button that contains news source name and image showing worthiness state.

@param replacementTargetElem replace this element with a button.
@param newsSourceName use as button text.
@param newsSourceStateStyle style class of image button
 */
function replaceWithButton(newsSourceName, replacementTargetElem, newsSourceStateStyle)
{
    var imgElem = document.createElement("image");
    imgElem.className = newsSourceStateStyle;

    var spanElem = document.createElement("span");
    spanElem.textContent = newsSourceName;

    var newsSourceToggelBtn = document.createElement("button");
    newsSourceToggelBtn.className = "newsSourceBtn";
    newsSourceToggelBtn.appendChild(spanElem);
    newsSourceToggelBtn.appendChild(document.createTextNode(" "));
    newsSourceToggelBtn.appendChild(imgElem);

    newsSourceToggelBtn.onclick = function (event)
    {
        var curStateClass = imgElem.className;
        var nextStateClass = calcNextNewsSourceStateClass(curStateClass);
        imgElem.className = nextStateClass;

        updateModelAndPersist(gModel,newsSourceName,curStateClass,nextStateClass);
        updateStoryStateViewFromModel(gModel);

        event.stopPropagation();
    };

    // Replace news source text with toggle button.
    replacementTargetElem.parentNode.replaceChild(newsSourceToggelBtn,replacementTargetElem);

    return newsSourceToggelBtn;
}



//////////////////////////////////////////////////////////////
function makeStoryInfo(newsSourceName, storyTitleElem, newsSourceStateImgElem)
{
    var followStoryLink = storyTitleElem.parentElement;
    return {
        'titleText':storyTitleElem.textContent, //for debug only
        'newsSourceName': newsSourceName,
        'followStoryLink': followStoryLink,
        'newsSourceStateImgElem': newsSourceStateImgElem
    };
}


//////////////////////////////////////////////////////////////
function updateModelAndPersist(model, newsSource, oldState, newState)
{
    console.debug("updateModelAndPersist: model", model);

    // remove from previsous state
    if(oldState == WORTHY_STATE_BTN_STYLE)
    {
        removeFromSet(model.worthyNewsSources,newsSource);
    }
    else if(oldState == UNWORTHY_STATE_BTN_STYLE)
    {
        removeFromSet(model.unworthyNewsSources,newsSource);
    }

    // put into its new state
    if(newState == WORTHY_STATE_BTN_STYLE)
    {
        addToSet(model.worthyNewsSources,newsSource);
    }
    else if(newState == UNWORTHY_STATE_BTN_STYLE)
    {
        addToSet(model.unworthyNewsSources,newsSource);
    }

    // update storage
    chrome.storage.local.set({WORTHY_LIST_KEY:model.worthyNewsSources,
        UNWORTHY_LIST_KEY:model.unworthyNewsSources});
}


//////////////////////////////////////////////////////////////
// Called both at page startup as well as everytime user changes
// news source worthiness rating.
//
// ASSUME gModel.un/worthy was already changed.  Now update each
// story's button imgage with the correct style class.
// Also, disable link to new article for unworhty news sources.
function updateStoryStateViewFromModel(model)
{
    model.storyInfos.forEach(function(storyInfo) {

       // console.debug("updateStoryStateViewFromModel: storyInfo title: ", storyInfo.titleText)

        var titleTextElem = storyInfo.followStoryLink.querySelector(TITLE_ELEM_CLASS);

        var TOOLTIP_DATA_ATTR = "data-tip";

        if(model.worthyNewsSources.indexOf(storyInfo.newsSourceName) > -1)
        {
            storyInfo.newsSourceStateImgElem.className = WORTHY_STATE_BTN_STYLE;
            storyInfo.followStoryLink.onclick = null;
            storyInfo.followStoryLink.classList.remove(LINK_TO_UNWORTHY_CLASS);
            storyInfo.followStoryLink.removeAttribute(TOOLTIP_DATA_ATTR);
        }
        else if(model.unworthyNewsSources.indexOf(storyInfo.newsSourceName) > -1)
        {
            storyInfo.newsSourceStateImgElem.className = UNWORTHY_STATE_BTN_STYLE;
            storyInfo.followStoryLink.onclick = handleClickUnworthyNewsSource ;
            storyInfo.followStoryLink.classList.add(LINK_TO_UNWORTHY_CLASS);
            storyInfo.followStoryLink.setAttribute(TOOLTIP_DATA_ATTR,
                storyInfo.newsSourceName + " is unworthy.");
        }
        else
        {
            storyInfo.newsSourceStateImgElem.className = NO_STATE_BTN_STYLE;
            storyInfo.followStoryLink.onclick = null ;
            storyInfo.followStoryLink.classList.remove(LINK_TO_UNWORTHY_CLASS);
            storyInfo.followStoryLink.removeAttribute(TOOLTIP_DATA_ATTR);
        }
    });
}



//////////////////////////////////////////////////////////////
function calcNextNewsSourceStateClass(curStateClass)
{
    var curPos = BTN_STYLES.indexOf(curStateClass);
    var nextPos = 1 + curPos;

    if(nextPos >= BTN_STYLES.length)
    {
        nextPos = 0;
    }
    return BTN_STYLES[nextPos];
}


//////////////////////////////////////////////////////////////
function handleClickUnworthyNewsSource(event)
{
    //alert("Unworthy news source.");
    console.debug("clicked on unworthy news source link")
    event.preventDefault();
}


/*
UTILS
 */

//////////////////////////////////////////////////////////////
function removeFromSet(newsSourcesSet, item)
{
    var index = newsSourcesSet.indexOf(item);
    if(index == -1)
    {
        console.debug("set", newsSourcesSet, "does not contain", item);
        return;
    }

    newsSourcesSet.splice(index,1);
    console.log("removed", item, "from", newsSourcesSet);
}


//////////////////////////////////////////////////////////////
// Only add if it isn't already in the list.
// News source lists are actually sets.
function addToSet(newsSourcesSet, item)
{
    if(newsSourcesSet.indexOf(item) > -1)
    {
        console.debug("set", newsSourcesSet, "already contains", item);
        return;
    }
    newsSourcesSet.push(item);
    console.log("added", item, "to set", newsSourcesSet);
}



//////////////////////////////////////////////////////////////
function getValOrEmptyArray(val)
{
    if((val == null) || (val == "") || val == undefined)
    {
        return [];
    }
    else
    {
        return val;
    }
}
