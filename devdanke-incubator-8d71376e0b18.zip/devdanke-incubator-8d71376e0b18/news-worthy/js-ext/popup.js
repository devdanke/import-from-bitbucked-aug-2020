//debugger;

"use strict";


var WORTHY_LIST_KEY = "WORTHY_LIST_KEY";
var UNWORTHY_LIST_KEY = "UNWORTHY_LIST_KEY";
var MODEL_CHANGED_MSG = "MODEL_CHANGED_MSG";

// global data model
var gModel = {
    worthyNewsSources : [],
    unworthyNewsSources : []
};

var gChanged = false;


main();

//////////////////////////////////////////////////////////////
function main()
{
    console.log("IN");

    try
    {
        loadNewsSourceData();
        document.getElementById("saveBtn").onclick = saveChanges;
        document.getElementById("cancelBtn").onclick = cancelChanges;
    }
    catch(err)
    {
        alert("err.msg: " + err.message);
    }

    console.log("OUT");
}


//////////////////////////////////////////////////////////////
function loadNewsSourceData()
{
    chrome.storage.local.get([WORTHY_LIST_KEY,UNWORTHY_LIST_KEY], function (dbData)
    {
        try
        {
            gModel.worthyNewsSources = getValOrEmptyArray(dbData[WORTHY_LIST_KEY]);
            gModel.unworthyNewsSources = getValOrEmptyArray(dbData[UNWORTHY_LIST_KEY]);

            initPage(gModel);
        }
        catch(err) {
            console.log("err.msg: ", err.message, err.stack );
        }
    });
}


//////////////////////////////////////////////////////////////
function initPage(model)
{
    fillList("worthyList", model.worthyNewsSources);
    fillList("unworthyList", model.unworthyNewsSources);
}

//////////////////////////////////////////////////////////////
function fillList(listElemId,newsSources)
{
    var listElem = document.getElementById(listElemId);

    for(var i=0; i<newsSources.length; i++)
    {
        listElem.appendChild(createCheckboxItem(newsSources[i], newsSources));
    }
}


//////////////////////////////////////////////////////////////
function createCheckboxItem(newsSource, newSourcesList)
{
    var checkBox = document.createElement("input");

    checkBox.type = "checkbox";
    checkBox.value = newsSource;
    checkBox.checked = true;
    checkBox.onclick = function(event)
    {
        if(this.checked)
        {
            // If it's checked now, then is was unchecked before.
            // So, we're adding.
            addToSet(newSourcesList,newsSource);
        }
        else
        {
            removeFromSet(newSourcesList,newsSource);
        }
        gChanged = true;
    }

    var listItem = document.createElement("li");
    listItem.appendChild(checkBox);
    listItem.appendChild(document.createTextNode(newsSource));

    return listItem;
}


//////////////////////////////////////////////////////////////
function saveChanges(event)
{
    console.log("saving changes");

    if(gChanged==true)
    {
        // update storage
        chrome.storage.local.set({WORTHY_LIST_KEY:gModel.worthyNewsSources,
            UNWORTHY_LIST_KEY:gModel.unworthyNewsSources});

        console.log("save changes",gModel);

        // 2) make content relabel stories using latest db data.
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {action: MODEL_CHANGED_MSG}, function(response) {
                console.log("response",response);
            });
        });
        console.log("told content page to refresh view with latest db data.");

        /*
            chrome.tabs.query(
                {currentWindow: true, active : true},
                function(tabArray)
                {
                    chrome.tabs.reload(tabArray[0].id);
                    console.log("post-reload current tab.");
                }
            )
            */
    }
    else
    {
        console.log("nothing changed.");
    }
    window.close();
}

//////////////////////////////////////////////////////////////
function cancelChanges()
{
    window.close();
}

/*
 UTILS
 */

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
function removeFromSet(newsSourcesSet, item)
{
    var index = newsSourcesSet.indexOf(item);

    if(index == -1)
    {
        console.debug("set", newsSourcesSet, "does not contain", item);
        return;
    }

    newsSourcesSet.splice(index,1);
    console.log("removed", item, "from", newsSourcesSet);
}


//////////////////////////////////////////////////////////////
// Only add if it isn't already in the list.
// News source lists are actually sets.
function addToSet(newSourcesSet, item)
{
    if(newSourcesSet.indexOf(item) > -1)
    {
        console.debug("set", newsSourcesSet, "already contains", item);
        return;
    }
    newSourcesSet.push(item);
    console.log("added", item, "to set", newSourcesSet);
}


//////////////////////////////////////////////////////////////
function getValOrEmptyArray(val)
{
    if((val == null) || (val == "") || val == undefined)
    {
        return [];
    }
    else
    {
        return val;
    }
}

