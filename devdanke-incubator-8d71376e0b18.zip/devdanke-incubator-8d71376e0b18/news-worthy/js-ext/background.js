//debugger;
"use strict";

var WORTHY_LIST_KEY = "WORTHY_LIST_KEY";
var UNWORTHY_LIST_KEY = "UNWORTHY_LIST_KEY";


var MODEL_CHANGED_MSG = "MODEL_CHANGED_MSG";

main();

//////////////////////////////////////////////////////////////
function main()
{
    console.log("IN");

    chrome.tabs.onUpdated.addListener(handleTabUpdateEvent);

    console.log("OUT");
}



//////////////////////////////////////////////////////////////
function handleTabUpdateEvent(tabId, changeInfo, tab)
{
    console.log("tabUpdateEvent: url:", tab.url, "state:",changeInfo.status);

    if(isReallyGoogleNews(tab.url, changeInfo.status))
    {
        chrome.pageAction.show(tabId);
        console.log("handleTabUpdateEvent: show pageAction icon.", tab.url);

        chrome.tabs.insertCSS(tabId, {file: "myext.css", runAt: "document_start"});

        chrome.tabs.executeScript(tabId, {file: "process_content.js", runAt: "document_end"},
            function() {
                if (chrome.runtime.lastError) console.error(chrome.runtime.lastError.message);
            }
        );
    }
}


//////////////////////////////////////////////////////////////
function isReallyGoogleNews(tabUrl,tabLoadState)
{
    if(tabLoadState != "loading")//"complete")
    { //loading means js & css can be ready before page fully downloads
        return false;
    }

    if(tabUrl.indexOf("news.google.com/news/url") > -1)//a news redirect
    {
        return false;
    }

    if((tabUrl.indexOf("news.google.com") > -1) || (tabUrl.indexOf("fake-gnews.html") > -1))
    {    // the real thing (or my test page).
        return true;
    }

    return false;
}


