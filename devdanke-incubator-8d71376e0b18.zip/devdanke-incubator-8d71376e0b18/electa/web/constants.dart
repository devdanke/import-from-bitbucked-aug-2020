library my_constants;

//import 'dart:convert';

/* ****************************************************************************************
 */
class Level
{
  static final String FEDERAL = "FEDERAL";
  static final String STATE = "STATE";
  static final String COUNTY = "COUNTY";
  static final String CITY = "CITY";
}

/* ****************************************************************************************
 */
class Branch
{
  static final String EXECUTIVE = "EXECUTIVE";
  static final String LEGISLATURE = "LEGISLATURE";
  static final String JUDICIAL = "JUDICIAL";
  static final String CITIZEN = "CITIZEN";
}

/* ****************************************************************************************
 */
class Field
{
  static final String ID = "ID";
  static final String LEVEL = "LEVEL";
  static final String BRANCH = "BRANCH";
  static final String OFFICE = "OFFICE";
  static final String POSITION = "POSITION";
  static final String DISTRICT = "DISTRICT";
  static final String DISPLAY_NAME = "DISPLAY_NAME";
}

