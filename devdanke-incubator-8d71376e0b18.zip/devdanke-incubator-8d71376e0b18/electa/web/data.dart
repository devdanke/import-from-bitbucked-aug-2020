library my_data;

//import 'dart:convert';
import 'constants.dart';


/* ****************************************************************************************
 */
class AbsBaseContest
{
  String id;
  String level;
  String branch;

  AbsBaseContest(this.id, this.level, this.branch);

  ///////////////////////////////////////////////////
  Map<String,String> toMap()
  {
    Map map = new Map();
    map[Field.ID] = id;
    map[Field.LEVEL] = level;
    map[Field.BRANCH] = branch;
    return map;
  }
}

/* ****************************************************************************************
 */
class Contest extends AbsBaseContest
{
  String office;

  Contest(String id, String level, String branch, this.office) : super(id,level,branch);


  ///////////////////////////////////////////////////
  Map toMap()
  {
    Map map = super.toMap();
    map[Field.OFFICE] = office;
    map[Field.DISPLAY_NAME] = "${office}";
    return map;
  }
}


/* ****************************************************************************************
 */
class CountyJudge extends Contest
{
  String electoralDistrict;
  int position;

  CountyJudge(String id, this.electoralDistrict, this.position) :
    super(id, Level.COUNTY, Branch.JUDICIAL, "Judge");

  ///////////////////////////////////////////////////
  Map toMap()
  {
    Map map = super.toMap();
    map["electoralDistrict"] = electoralDistrict;
    map[Field.DISPLAY_NAME] = "${office}, ${electoralDistrict} District, Position ${position}";
    return map;
  }
}


/* ****************************************************************************************
 */
class AbsDistrictLeg extends Contest
{
  int district;

  AbsDistrictLeg(String id, String level, String office, this.district) :
    super(id, level,Branch.LEGISLATURE,office);

  Map toMap()
  {
    Map map = super.toMap();
    map[Field.DISTRICT] = district.toString();
    return map;
  }
}


/* ****************************************************************************************
 */
class UsRep extends AbsDistrictLeg
{
  UsRep(int district) : super("us-rep-d${district}", Level.FEDERAL,"Representative", district);


  Map toMap()
  {
    Map map = super.toMap();
    map[Field.DISPLAY_NAME] = "${office}, District ${district}";
    return map;
  }
}


/* ****************************************************************************************
 */
class AbsStateLeg extends AbsDistrictLeg
{
  AbsStateLeg(String id, String office, int district) :
    super(id, Level.STATE,office,district);
}


/* ****************************************************************************************
 */
class StateSenate extends AbsStateLeg
{
  StateSenate(int district) : super("st-sen-d${district}", "Senator", district);

  Map toMap()
  {
    Map map = super.toMap();
    map[Field.DISPLAY_NAME] = "${office}, District ${district}";
    return map;
  }
}

/* ****************************************************************************************
 */
class StateRep extends AbsStateLeg
{
  int position;

  StateRep(int district, int position) :
    super("st-rep-d${district}-p${position}", "Representative",district)
  {
    this.position = position;
  }

  Map toMap()
  {
    Map map = super.toMap();
    map[Field.POSITION] = position.toString();
    map[Field.DISPLAY_NAME] = "${office}, District ${district}, Position ${position}";
    return map;
  }
}


/* ****************************************************************************************
 */
class AbsBallotMeasure extends AbsBaseContest
{
  String label;  // e.g. Property or Initiative.
  String title;
  int number;

  AbsBallotMeasure(String id, String level, this.label, this.title, this.number) :
    super(id,level, Branch.CITIZEN);

  Map toMap()
  {
    Map map = super.toMap();

    map["label"] = label;
    map["title"] = title;
    map["number"] = number.toString();

    return map;
  }
}

/* ****************************************************************************************
 */
class SeattleProp extends AbsBallotMeasure
{
  SeattleProp(String id, String title, int number) :
    super(id , Level.CITY, "Proposition", title, number);

    Map toMap()
    {
      Map map = super.toMap();

      map[Field.DISPLAY_NAME] = "${title}, ${label} ${number}";

      return map;
    }


}

