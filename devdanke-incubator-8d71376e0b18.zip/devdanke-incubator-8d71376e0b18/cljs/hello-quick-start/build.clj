(require 'cljs.build.api)

;; part 1
;;(cljs.build.api/build "src" {:output-to "out/main.js"})

;; part 2: supposedly to reduce boiler plate code else where.
(cljs.build.api/build "src"
  {:main 'hello-world.core
   :output-to "out/main.js"})