(ns rss-exp.core

  (:gen-class)

(:require
  [clojure.string :as string]
  [clojure.pprint :as pp])
(:use
  clj-xpath.core)

  )

(def rssUrl "https://seattle.craigslist.org/search/w4m?format=rss")
(def rssFilePath "/Users/me/_dev/incubator/rss-exp/target/cl-data.xml")

(defn writeUrlToFile [url filePath]
    (spit filePath (slurp url))
  )

(defn myMain []

  (println "myMain\n*** BEGIN ***")

  ;;(writeUrlToFile rssUrl rssFilePath)

  (let [ rssXml (slurp rssFilePath)
         xmlDoc (xml->doc rssXml)
         items ($x "//item" xmlDoc)
         itemTitles ($x "//item/title" xmlDoc)]

    (prn "log100 rssXml char count: " (count rssXml))

    (prn "log200 count(//item) in xmlDoc" (count items))

    (prn "log210 count li in xmlDoc" (count ($x "//li" xmlDoc)))
    (prn "log220 count li with local-name in xmlDoc" (count ($x "//*[local-name()='li']" xmlDoc)))

    ;;(prn "log300 process items in xmlDoc" (take 5 (iterate #(println "item: " %) xmlDoc)))

    (doseq [item (take 1 items)]
      (prn "*** ITEM400")
      (doseq [subitem item]
        (prn "*** *** SUB: " subitem)))


    (prn "log500 count(//item/title) in xmlDoc" (count itemTitles))

    (doseq [title (set itemTitles)]
      (prn "*** Title510: " (get title :text)
      ))

    );let

  (prn "*** END ***")

  )


(myMain)