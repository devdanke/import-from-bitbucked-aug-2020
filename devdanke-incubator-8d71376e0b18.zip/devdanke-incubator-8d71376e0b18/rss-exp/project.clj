(defproject rss-exp "0.1.0-SNAPSHOT"
  :description "practice downloading and extracting data from rss feed"

  :dependencies [   [org.clojure/clojure "1.7.0"]
                    [com.github.kyleburton/clj-xpath "1.4.5"]
                
                    
  ]
  
  :main ^:skip-aot rss-exp.core
  :target-path "target/%s"
  :profiles {:uberjar {:aot :all}})
