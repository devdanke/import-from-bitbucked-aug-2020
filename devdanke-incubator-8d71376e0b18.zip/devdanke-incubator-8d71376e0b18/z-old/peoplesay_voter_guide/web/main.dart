import 'dart:html';
import 'dart:convert';
import 'dart:async';

import 'constants.dart';
import 'data_builder.dart';


/* ****************************************************************************************
 */
void main() {

  downloadEndorsements();

}


/* ****************************************************************************************
 */
void showTableHeader(String contestsTitle, List<Map>recommendationTitles)
{
  TableRowElement headerRow = querySelector("#headerRow");

  headerRow.appendHtml(thCell(contestsTitle));

  recommendationTitles.forEach((rec){
    headerRow.appendHtml(thCell(rec[RECOMMENDER]));
  });
}

/* ****************************************************************************************
 */
String thCell(String content)
{
  return "<th>${content}</th>";
}


/* ****************************************************************************************
 */
void showRecommendations(List<Map<String,String>> recommends)
{
  TableSectionElement tbody = querySelector("#bodySec");

  tbody.rows.forEach((row){

    if(row.classes.contains(DATA_ROW))
    {
      recommends.forEach((rec){

        TableCellElement tc = new TableCellElement();
        if(rec.containsKey(row.id)) {

          tc.innerHtml = (rec[row.id]);
        }
        else{
          tc.innerHtml = "&nbsp;";
        }
        row.append(tc);
      });
    }
  });
}


/* ****************************************************************************************
 */
void showContests(Map<String,List> electionData, int dataColCount)
{
  TableSectionElement tbody = querySelector("#bodySec");

  electionData.forEach((String level,List contests){

    tbody.appendHtml("<tr class='levelHeader'><td colspan='${dataColCount+1}'>${level}</td></tr>");

      int rowCount = 0;
      contests.forEach((Map item){
        rowCount++;
        String rowClass = "";
        if((rowCount % 2)==0) rowClass = "alt";
        tbody.appendHtml("<tr id='${item[Field.ID]}' class='${rowClass} ${DATA_ROW}'><td>${item[Field.DISPLAY_NAME]}</td></tr>");
      });

  });
}


/* ****************************************************************************************
 */
List<Map> downloadEndorsements()
{
  print("download start");

  List<String> fileNames = new List();
  List<Future> futures = new List();
  fileNames.add("endorsements/times.json");
  fileNames.add("endorsements/stranger.json");
  fileNames.add("endorsements/conservation.json");

  fileNames.forEach((fileName){
    Future<String> future = HttpRequest.getString(fileName);
    futures.add(future);
  });


  Future.wait(futures)
    .then((List responses) {
        List endorsements = new List();

        process(responses,endorsements);
        Map<String,List> contests = makeElectionData();

        showTableHeader("Contests", endorsements);
        showContests(contests, endorsements.length);
        showRecommendations(endorsements);
    })
    .catchError((e) => handleErrorg(e));

  print("download end");
}

/* ****************************************************************************************
 */
void process(List jsonResponses, List results)
{
  jsonResponses.forEach((jResp){
    //print("process: json: ${jResp}.");
    results.add(JSON.decode(jResp));
  });
}

/* ****************************************************************************************
 */
void handleErrorg(e)
{
  print("ERRORG: ${e.toString()}");
}






