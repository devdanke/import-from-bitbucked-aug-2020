library data_builder;

import 'dart:convert';
import 'data.dart';
import 'constants.dart';

final String LEVEL_HEADER = "levelHeader";
final String RECOMMENDER = "recommender";
final String DATA_ROW = "dataRow";


/* ****************************************************************************************
 */
Map makeElectionData()
{
  Map data = new Map();

  data[Level.FEDERAL] = makeNationalData();
  data[Level.STATE] = makeStateData();
  //data[Level.COUNTY] = makeCountyData();
  data[Level.CITY] = makeCityData();

  return data;
}

/* ****************************************************************************************
 */
List makeCityData()
{
  List list = new List();

  list.add(new SeattleProp("ci-prop-1", "Seattle Park District", 1).toMap());

  return list;
}

/* ****************************************************************************************
 */
List makeCountyData()
{
  List list = new List();

  list.add( new CountyJudge("co-edNorthEast-p3","Northeast", 3).toMap());
  list.add( new Contest("co-pros", Level.COUNTY, Branch.EXECUTIVE, "Prosecutor").toMap() );

  return list;
}


/* ****************************************************************************************
 */
List makeNationalData()
{
  List list = new List();

  list.add(new UsRep(7).toMap());
  list.add(new UsRep(9).toMap());

  return list;
}


/* ****************************************************************************************
 */
List makeStateData()
{
  List data = new List();

  List<int> stLegDistricts = [11, 32, 33, 34, 36, 37, 43, 46];
  stLegDistricts.forEach((district){

     data.add(new StateSenate(district).toMap());
     data.add(new StateRep(district,1).toMap());
     data.add(new StateRep(district,2).toMap());

  });

  return data;
}
