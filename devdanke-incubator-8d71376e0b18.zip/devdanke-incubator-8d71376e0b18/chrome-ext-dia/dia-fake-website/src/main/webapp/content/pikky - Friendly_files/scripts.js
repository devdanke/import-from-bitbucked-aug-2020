function GetRegionLabel(n) {
    switch (n) {
        case"KH":
            return "Province (Khaet)";
        case"CN":
            return "Province (Sheng)";
        case"MY":
            return "State (Negeri)";
        case"SA":
            return "Region (Mintaqah)";
        case"SG":
            return "Region";
        case"TH":
            return "Province (Changwat)";
        case"VN":
            return "Province (Tinh)";
        case"AU":
            return "State";
        case"AT":
            return "State (Bundesland)";
        case"DK":
            return "Region";
        case"FR":
            return "Region (Departement)";
        case"DE":
            return "State (Bundesland)";
        case"IS":
            return "County (Magistrate)";
        case"IE":
            return "County";
        case"NZ":
            return "Region";
        case"NO":
            return "County (Fylke)";
        case"PT":
            return "District";
        case"SE":
            return "County (Län)";
        case"GB":
            return "Constituent Country";
        case"US":
            return "State";
        default:
            return "Province"
    }
}
function onCountryChange(n, t) {
    $("#" + t).html(GetRegionLabel(n))
}
function playNotificationSound() {
    var n, t;
    if (!/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
        if (/android/i.test(navigator.userAgent))try {
            n = new Howl({urls: [window.__NOTIFICATION_SOUND_PATH]});
            n.play();
            return
        } catch (i) {
        }
        try {
            window.__NOTIFICATION_AUDIO == null && (t = new Audio(window.__NOTIFICATION_SOUND_PATH), window.__NOTIFICATION_AUDIO = t);
            window.__NOTIFICATION_AUDIO.play()
        } catch (i) {
        }
    }
}
function updateTimestamps() {
    $(".timestamp").each(function () {
        var h = Math.round(((new Date).getTime() - window.initialTime) / 1e3), c = Number($(this).data("co"));
        c > 0 && (h = Math.round(((new Date).getTime() - c) / 1e3));
        var l = Number($(this).data("o")), r = l + h, t = r / 60, i = t / 60, u = i / 24;
        r = Math.floor(r);
        t = Math.floor(t);
        i = Math.floor(i);
        u = Math.floor(u);
        var f = u, e = u > 0 ? i - u * 24 : i, o = i > 0 ? t - i * 60 : t, s = t > 0 ? r - t * 60 : r, n = "";
        f > 0 && (n += f + "d");
        e > 0 && (n += (n.length > 0 ? ", " + e : e) + "h");
        o > 0 && f < 1 && (n += (n.length > 0 ? ", " + o : o) + "m");
        s > 0 && o < 1 && e < 1 && f < 1 && (n += (n.length > 0 ? ", " + s : s) + "s");
        r < 5 ? n = "now" : n += " ago";
        $(this).text(n)
    });
    setTimeout("updateTimestamps()", 2e4)
}
function count(n, t) {
    n.value.length > t && (n.value = n.value.substring(0, t), alert("Max length is " + t + " chars"))
}
function watermarkFocus(n, t) {
    n.value == t && (n.value = "")
}
function watermarkBlur(n, t) {
    n.value == "" && (n.value = t)
}
function mutexCheckBox(n) {
    for (var t = 0; t < n.parentNode.childNodes.length; t++)n.parentNode.childNodes[t].name != null && n.parentNode.childNodes[t].name.indexOf("CheckBox") != -1 && n.parentNode.childNodes[t] != n && (n.parentNode.childNodes[t].checked = !1)
}
function createCookie(n, t, i) {
    var u, r;
    i ? (r = new Date, r.setTime(r.getTime() + i * 864e5), u = "; expires=" + r.toGMTString()) : u = "";
    document.cookie = n + "=" + t + u + "; path=/"
}
function readCookie(n) {
    for (var r = n + "=", u = document.cookie.split(";"), t, i = 0; i < u.length; i++) {
        for (t = u[i]; t.charAt(0) == " ";)t = t.substring(1, t.length);
        if (t.indexOf(r) == 0)return t.substring(r.length, t.length)
    }
    return null
}
function eraseCookie(n) {
    createCookie(n, "", -1)
}
function addOnResizeEvent(n) {
    var t = window.onresize;
    window.onresize = function () {
        n();
        typeof t == "function" && t()
    }
}
function addOnLoadEvent(n) {
    var t = window.onload;
    window.onload = function () {
        n();
        typeof t == "function" && t()
    }
}
function simpleAjax(n, t) {
    $("#" + t).html("<img src='/Images/ajax-loader2.gif' style='vertical-align:middle' />");
    $("#" + t).load(n)
}
function setDesignCookies() {
    try {
        createCookie("screen", screen.width + "x" + screen.height, 360)
    } catch (n) {
        createCookie("screen", "error", 1)
    }
    try {
        createCookie("window", $(window).width() + "x" + $(window).height(), 360)
    } catch (n) {
        createCookie("window", "error", 1)
    }
}
function scrollToConversation() {
    $("#messages").length && $("#messages .unread-message").length && $("html, body").animate({scrollTop: $("#message-form").offset().top - 10}, 800)
}
function showMoreProfileOptions() {
    $("#button-moreprofileoptions").hide();
    $("#moreprofileoptions").show()
}
function hideAllPhotoReportPanels() {
    $("#report-panel").html("");
    $("#report-panel").hide();
    $('[id^="album-report-panel-"]').html("");
    $('[id^="album-report-panel-"]').hide();
    $('[id^="album-google-search-"]').hide();
    try {
        $(".album").masonry("layout")
    } catch (n) {
    }
}
function showPhotoReportChoices() {
    hideAllPhotoReportPanels();
    $("#report-panel").html('<div class="p text-center"><img src="/Images/ajax-loader2.gif" alt="" /><\/div>');
    $("#report-panel").show();
    $("#report-panel").load("/ReportChoices #snippet-photo-report-choices");
    $("html, body").animate({scrollTop: $("#report-panel").offset().top}, 500)
}
function showPhotoReportChoices2(n) {
    var t = "#album-report-panel-" + n, i;
    if ($(t).html().length) {
        hideAllPhotoReportPanels();
        return
    }
    $("#flagged-photo").val(n);
    hideAllPhotoReportPanels();
    i = "#album-google-search-" + n;
    $(i).show();
    $(t).html('<div class="p text-center"><img src="/Images/ajax-loader2.gif" alt="" /><\/div>');
    $(t).show();
    try {
        $(".album").masonry("layout")
    } catch (r) {
    }
    $(t).load("/ReportChoices #snippet-photo-report-choices", function () {
        try {
            $(".album").masonry("layout")
        } catch (n) {
        }
    })
}
function showMemberReportChoices() {
    $("#report-panel").html('<div class="p text-center"><img src="/Images/ajax-loader2.gif" alt="" /><\/div>');
    $("#report-panel").show();
    $("#report-panel").load("/ReportChoices #snippet-member-report-choices");
    $("html, body").animate({scrollTop: $("#report-panel").offset().top}, 500)
}
function flagPhoto(n) {
    var t = !1, i;
    switch (n) {
        case"0100":
            hideAllPhotoReportPanels();
            t = !1;
            break;
        case"0101":
            confirm('Please confirm that you want to flag this photo with reason "Not a photo of the member".') && (t = !0);
            break;
        case"0102":
            confirm('Please confirm that you want to flag this photo with reason "Nudity, Violence or otherwise Inappropriate".') && (t = !0);
            break;
        case"0103":
            confirm('Please confirm that you want to flag this photo with reason "Cannot see face clearly".') && (t = !0);
            break;
        case"0104":
            confirm('Please confirm that you want to flag this photo with reason "Child in photo".') && (t = !0);
            break;
        default:
            confirm("Please confirm that you want to flag this photo.") && (t = !0)
    }
    ($('[id^="album-google-search-"]').hide(), $("#photo-report-choices").hide(), $("html, body").scrollTop($("#moreprofileoptions").offset().top - 5), t) && ($("#photo-report-result").show(), $("#photo-report-result").html('<div class="text-center"><img src="/Images/ajax-loader2.gif" alt="" /><\/div>'), i = new Date, $("#photo-report-result").load("/FlagPhoto.aspx?uid=" + $("#profile-userid").val() + "&cb=" + i.getTime() + "&flag=" + n + "&fp=" + $("#flagged-photo").val(), function () {
        try {
            $(".album").masonry("layout")
        } catch (n) {
        }
    }))
}
function reportMember(n) {
    var t = !1, i;
    switch (n) {
        case"0200":
            t = !1;
            break;
        case"0201":
            confirm("Please confirm that you want to report this member for being rude.") && (t = !0);
            break;
        case"0202":
            confirm("Please confirm that you want to report this member for asking for or offering money.") && (t = !0);
            break;
        case"0203":
            confirm("Please confirm that you want to report this member for offering or seeking prostitution or escort services.") && (t = !0);
            break;
        case"0204":
            confirm("Please confirm that you want to report this member for being underage (too young).") && (t = !0);
            break;
        case"0205":
            confirm("Please confirm that you want to report this profile as being inappropriate.") && (t = !0);
            break;
        case"0206":
            confirm("Please confirm that you want to report this profile as fake.") && (t = !0);
            break;
        case"0207":
            confirm("Please confirm that you want to report this member for advertising.") && (t = !0);
            break;
        case"0208":
            confirm("Please confirm that you want to report this member for scam or spam.") && (t = !0);
            break;
        case"0209":
            confirm("Please confirm that you want to report this member for creating more than one profile.") && (t = !0);
            break;
        default:
            confirm("Please confirm that you want to report this member.") && (t = !0)
    }
    ($("#member-report-choices").hide(), $("html, body").scrollTop($("#moreprofileoptions").offset().top - 5), t) && ($("#member-report-result").show(), $("#member-report-result").html('<div class="text-center"><img src="/Images/ajax-loader2.gif" alt="" /><\/div>'), i = new Date, $("#member-report-result").load("/ReportMember.aspx?uid=" + $("#profile-userid").val() + "&ts=" + i.getTime() + "&reason=" + n))
}
function AddUserList(n, t) {
    if (window.__STINYBOX == 1)TINY.box.show("AddUserList?mti=" + n + "&uid=" + t, 1, 240, 130, 1); else {
        var i = window.open("AddUserList?mti=" + n + "&uid=" + t, "_blank", "height=150, width=250");
        window.focus && i.focus()
    }
}
function BlockMember(n) {
    if (window.__STINYBOX == 1)TINY.box.show("Block/" + n, 1, 240, 130, 1); else {
        var t = window.open("Block/" + n, "_blank", "height=150, width=250");
        window.focus && t.focus()
    }
}
function notifyByEmail(n) {
    document.getElementById("emailnotificationssetstatus").innerHTML = "<img src='/Images/ajax-loader2.gif' style='vertical-align:middle' />";
    var t;
    t = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
    t.onreadystatechange = function () {
        t.readyState == 4 && t.status == 200 && (document.getElementById("emailnotificationssetstatus").innerHTML = t.responseText)
    };
    t.open("GET", "/Account/" + (n ? "notifybyemail" : "unnotifybyemail"));
    t.send()
}
function hideProfile(n) {
    document.getElementById("profilehidesetstatus").innerHTML = "<img src='/Images/ajax-loader2.gif' style='vertical-align:middle' />";
    var t;
    t = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
    t.onreadystatechange = function () {
        t.readyState == 4 && t.status == 200 && (document.getElementById("profilehidesetstatus").innerHTML = t.responseText)
    };
    t.open("GET", "/Account/" + (n ? "hide" : "unhide"));
    t.send()
}
function onSearchCountryChange(n) {
    n == "US" ? $("#SearchRegion").show() : $("#SearchRegion").hide()
}
function onFilterButton() {
    $("#filter-button").hide();
    $("#search-menu").show();
    $("#IsAdvancedSearch").length && $("#mobile-header-spacer").hide()
}
function showSearch(n) {
    var r = document.getElementById("StandardSearch"), u = document.getElementById("AdvancedSearch"), f = document.getElementById("UsernameSearch"), e = document.getElementById("searchtab1"), o = document.getElementById("searchtab2"), s = document.getElementById("searchtab3"), i = document.getElementById("ContentPlaceHolder1_StandardSearchButton"), h = "#F6F5F5", t = "#DBDBDB";
    switch (n) {
        case 1:
            r.style.display = "block";
            i != null && (i.style.display = "block");
            u.style.display = "none";
            f.style.display = "none";
            e.style.backgroundColor = h;
            o.style.backgroundColor = t;
            s.style.backgroundColor = t;
            break;
        case 2:
            r.style.display = "block";
            i != null && (i.style.display = "none");
            u.style.display = "block";
            f.style.display = "none";
            e.style.backgroundColor = t;
            o.style.backgroundColor = h;
            s.style.backgroundColor = t;
            break;
        case 3:
            r.style.display = "none";
            u.style.display = "none";
            f.style.display = "block";
            e.style.backgroundColor = t;
            o.style.backgroundColor = t;
            s.style.backgroundColor = h
    }
}
function search(n) {
    n.value = "Moment..."
}
function autoResizeTextArea(n, t) {
    var i, r;
    try {
        t != null ? window.messageBoxMinHeight = t : t = window.messageBoxMinHeight;
        i = document.getElementById("__dummyTA");
        window.dummyData == null && (window.dummyData = !0, i.style.width = n.offsetWidth + "px", i.style.border = n.style.border, i.style.borderRadius = n.style.borderRadius, i.style.padding = n.style.padding, i.style.fontSize = n.style.fontSize, i.style.fontWeight = n.style.fontWeight, i.style.overflow = n.style.overflow);
        i.innerHTML = n.value;
        r = i.scrollHeight > t ? i.scrollHeight : t;
        /Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent) && (r += $("#__dummyTAR2").height() - $("#__dummyTAR1").height());
        (r < parseInt(n.style.height) || r > parseInt(n.style.height) && $("#messages-column").height() > 50) && (n.style.height = r + "px", fixHeightAndScroll())
    } catch (u) {
    }
}
function fixHeight() {
    var n = $(".mobileheader").css("display") == "none" ? $(".header").height() : $(".mobileheader").height();
    $("#ads").length && (n += $("#ads").innerHeight() + 1);
    $(".headerwrapper").css("display") == "none" && $(".mobileheader").css("display") == "none" && (n = 0);
    navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPod/i) ? ($("#messages-column").height($(window).height() - $("#inputdiv")[0].scrollHeight - 0 - n), $("#conversations-column").height($(window).height() - n)) : ($("#messages-column").height(window.innerHeight - $("#inputdiv")[0].scrollHeight - 0 - n), $("#conversations-column").height(window.innerHeight - n));
    createCookie("m-c-h", $("#messages-column").height(), 7);
    createCookie("c-c-h", $("#conversations-column").height(), 7)
}
function scroll() {
    $("#messages-column").scrollTop($("#messages-column")[0].scrollHeight)
}
function fixHeightAndScroll() {
    navigator.userAgent.match(/Android/i) && navigator.userAgent.match(/Chrome/i) ? _fixHeightAndScroll() : setTimeout(_fixHeightAndScroll, 1)
}
function _fixHeightAndScroll() {
    fixHeight();
    scroll()
}
function loadLastMessages(n, t) {
    if (Number($("#chatfromtop").val()) === 1) {
        chatHelper.loadLastMessages(t);
        return
    }
    var i = 0;
    $('#messages [id^="message_"]').each(function () {
        i = Number(this.id.substring(8))
    });
    $.get("/account/loadlastmessages/" + i + "/" + Number($("#chattingwith").val()), function (i) {
        t && playNotificationSound();
        i = i.replace('data-co="0" class="timestamp">', 'data-co="' + (new Date).getTime() + '" class="timestamp">');
        n && ($("#message").val(""), autoResizeTextArea($("#message")[0]), $("#buttonsend").show(), $("#waitstuff").hide());
        $("#messages").append(i);
        fixHeightAndScroll()
    }, "html");
    $("#unreadbutton").show()
}
function loadOlderMessages() {
    try {
        $("#loadmorebutton").hide();
        $("#loadmorewait").show();
        var n = Number($('#messages [id^="message_"]')[0].id.substring(8));
        $.get("/account/loadoldermessages/" + n, function (n) {
            n = n.replace('data-co="0" class="timestamp">', 'data-co="' + (new Date).getTime() + '" class="timestamp">');
            $("#messages").prepend(n);
            $("#loadnomore").length ? $("#loadmore").hide() : $("#loadmorebutton").show();
            $("#loadmorewait").hide()
        }, "html")
    } catch (t) {
    }
}
function waitSendMessage(n) {
    $(n).hide();
    $("#waitstuff").css("display", "inline-block")
}
function sendMessage(n) {
    if (!($("#message").val().length < 1)) {
        $(n).hide();
        $("#waitstuff").css("display", "inline-block");
        var t = $.post("", $("#message-form").serialize());
        t.done(function (t) {
            t && (t = chatHelper.fix_chrome_issue(t), $("#message").val(""), autoResizeTextArea($("#message")[0]), $(n).show(), $("#waitstuff").hide(), t.indexOf("timestamp") !== -1 ? (t = t.replace('data-co="0" class="timestamp">', 'data-co="' + (new Date).getTime() + '" class="timestamp">'), $("#message").val(""), autoResizeTextArea($("#message")[0]), $("#buttonsend").show(), $("#waitstuff").hide(), $("#messages").append(t), fixHeightAndScroll()) : alert(t))
        })
    }
}
function readMessages() {
    var n = "";
    $(".cb-list:checked").each(function () {
        n.length > 0 && (n += ",");
        n += this.id
    });
    $("#readcollection").val(n);
    $("#form1").submit()
}
function unreadMessages() {
    var n = "";
    $(".cb-list:checked").each(function () {
        n.length > 0 && (n += ",");
        n += this.id
    });
    $("#unreadcollection").val(n);
    $("#form1").submit()
}
function deleteMessages() {
    var t = $(".cb-list:checked").length > 1 ? "Are you sure you want to delete ALL the selected conversations?\n\nALL the messages in ALL these conversations will be deleted, and this action CANNOT be undone!" : "Are you sure you want to delete the selected conversation?\n\nALL the messages in this conversation will be deleted, and this action CANNOT be undone!", n;
    if (confirm(t))n = "", $(".cb-list:checked").each(function () {
        n.length > 0 && (n += ",");
        n += this.id
    }), $("#deletecollection").val(n), $("#form1").submit(); else return
}
function showSelect() {
    var n = $(".cb-column").css("display") == "none";
    $(".cb-column").css("display", n ? "table-cell" : "none");
    $("#edit-button").html(n ? "Cancel" : '<i class="fa fa-cog fa-lg"><\/i>');
    $("#select-button").css("display", n ? "inline-block" : "none");
    $("#action-button-group").css("display", n ? "inline-block" : "none");
    n || ($(".cb-list").prop("checked", !1), updateSelect())
}
function selectAll() {
    var n = $(".cb-list").length, t = $(".cb-list:checked").length;
    t < n ? $(".cb-list").prop("checked", !0) : $(".cb-list").prop("checked", !1);
    updateSelect()
}
function updateSelectButtonText() {
    var n = $(".cb-list").length, t = $(".cb-list:checked").length;
    t < n ? $("#select-button").text("Select All") : $("#select-button").text("Select None")
}
function updateSelect() {
    var n = $(".cb-list:checked").length;
    $("#delete-button").css("display", n ? "inline-block" : "none");
    $("#read-button").css("display", n ? "inline-block" : "none");
    $("#unread-button").css("display", n ? "inline-block" : "none");
    $("#outbox").val() == "true" && ($("#read-button").hide(), $("#unread-button").hide());
    $("#delete-button").text("Delete");
    $("#read-button").text("Read");
    $("#unread-button").text("Unread");
    updateSelectButtonText()
}
function toggleMSound() {
    var n = $("#msound").data("on") == "1";
    $.get(n ? "/account/msoundoff" : "/account/msoundon");
    $("#msound > i").toggleClass("fontcolorpale");
    $("#msound > i").toggleClass("fa-volume-up");
    $("#msound > i").toggleClass("fa-volume-off");
    $("#msound").data("on", !n);
    n || playNotificationSound();
    alertify.log(n ? "Sound Notifications when receiving messages switched OFF" : "Sound Notifications when receiving messages switched ON", "", 6e3)
}
function T$(n) {
    return document.getElementById(n)
}
var alertifyEx, ajaxForm, chatHelper, TINY;
!function (n, t) {
    "object" == typeof module && "object" == typeof module.exports ? module.exports = n.document ? t(n, !0) : function (n) {
        if (!n.document)throw new Error("jQuery requires a window with a document");
        return t(n)
    } : t(n)
}("undefined" != typeof window ? window : this, function (n, t) {
    function ri(n) {
        var t = n.length, r = i.type(n);
        return "function" === r || i.isWindow(n) ? !1 : 1 === n.nodeType && t ? !0 : "array" === r || 0 === t || "number" == typeof t && t > 0 && t - 1 in n
    }

    function ui(n, t, r) {
        if (i.isFunction(t))return i.grep(n, function (n, i) {
            return !!t.call(n, i, n) !== r
        });
        if (t.nodeType)return i.grep(n, function (n) {
            return n === t !== r
        });
        if ("string" == typeof t) {
            if (ue.test(t))return i.filter(t, n, r);
            t = i.filter(t, n)
        }
        return i.grep(n, function (n) {
            return i.inArray(n, t) >= 0 !== r
        })
    }

    function hr(n, t) {
        do n = n[t]; while (n && 1 !== n.nodeType);
        return n
    }

    function oe(n) {
        var t = fi[n] = {};
        return i.each(n.match(h) || [], function (n, i) {
            t[i] = !0
        }), t
    }

    function cr() {
        u.addEventListener ? (u.removeEventListener("DOMContentLoaded", a, !1), n.removeEventListener("load", a, !1)) : (u.detachEvent("onreadystatechange", a), n.detachEvent("onload", a))
    }

    function a() {
        (u.addEventListener || "load" === event.type || "complete" === u.readyState) && (cr(), i.ready())
    }

    function yr(n, t, r) {
        if (void 0 === r && 1 === n.nodeType) {
            var u = "data-" + t.replace(vr, "-$1").toLowerCase();
            if (r = n.getAttribute(u), "string" == typeof r) {
                try {
                    r = "true" === r ? !0 : "false" === r ? !1 : "null" === r ? null : +r + "" === r ? +r : ar.test(r) ? i.parseJSON(r) : r
                } catch (f) {
                }
                i.data(n, t, r)
            } else r = void 0
        }
        return r
    }

    function ei(n) {
        var t;
        for (t in n)if (("data" !== t || !i.isEmptyObject(n[t])) && "toJSON" !== t)return !1;
        return !0
    }

    function pr(n, t, r, u) {
        if (i.acceptData(n)) {
            var s, e, h = i.expando, l = n.nodeType, o = l ? i.cache : n, f = l ? n[h] : n[h] && h;
            if (f && o[f] && (u || o[f].data) || void 0 !== r || "string" != typeof t)return f || (f = l ? n[h] = c.pop() || i.guid++ : h), o[f] || (o[f] = l ? {} : {toJSON: i.noop}), ("object" == typeof t || "function" == typeof t) && (u ? o[f] = i.extend(o[f], t) : o[f].data = i.extend(o[f].data, t)), e = o[f], u || (e.data || (e.data = {}), e = e.data), void 0 !== r && (e[i.camelCase(t)] = r), "string" == typeof t ? (s = e[t], null == s && (s = e[i.camelCase(t)])) : s = e, s
        }
    }

    function wr(n, t, u) {
        if (i.acceptData(n)) {
            var o, s, h = n.nodeType, f = h ? i.cache : n, e = h ? n[i.expando] : i.expando;
            if (f[e]) {
                if (t && (o = u ? f[e] : f[e].data)) {
                    for (i.isArray(t) ? t = t.concat(i.map(t, i.camelCase)) : (t in o) ? t = [t] : (t = i.camelCase(t), t = (t in o) ? [t] : t.split(" ")), s = t.length; s--;)delete o[t[s]];
                    if (u ? !ei(o) : !i.isEmptyObject(o))return
                }
                (u || (delete f[e].data, ei(f[e]))) && (h ? i.cleanData([n], !0) : r.deleteExpando || f != f.window ? delete f[e] : f[e] = null)
            }
        }
    }

    function vt() {
        return !0
    }

    function it() {
        return !1
    }

    function dr() {
        try {
            return u.activeElement
        } catch (n) {
        }
    }

    function gr(n) {
        var i = nu.split("|"), t = n.createDocumentFragment();
        if (t.createElement)while (i.length)t.createElement(i.pop());
        return t
    }

    function f(n, t) {
        var e, u, s = 0, r = typeof n.getElementsByTagName !== o ? n.getElementsByTagName(t || "*") : typeof n.querySelectorAll !== o ? n.querySelectorAll(t || "*") : void 0;
        if (!r)for (r = [], e = n.childNodes || n; null != (u = e[s]); s++)!t || i.nodeName(u, t) ? r.push(u) : i.merge(r, f(u, t));
        return void 0 === t || t && i.nodeName(n, t) ? i.merge([n], r) : r
    }

    function be(n) {
        oi.test(n.type) && (n.defaultChecked = n.checked)
    }

    function eu(n, t) {
        return i.nodeName(n, "table") && i.nodeName(11 !== t.nodeType ? t : t.firstChild, "tr") ? n.getElementsByTagName("tbody")[0] || n.appendChild(n.ownerDocument.createElement("tbody")) : n
    }

    function ou(n) {
        return n.type = (null !== i.find.attr(n, "type")) + "/" + n.type, n
    }

    function su(n) {
        var t = ye.exec(n.type);
        return t ? n.type = t[1] : n.removeAttribute("type"), n
    }

    function li(n, t) {
        for (var u, r = 0; null != (u = n[r]); r++)i._data(u, "globalEval", !t || i._data(t[r], "globalEval"))
    }

    function hu(n, t) {
        if (1 === t.nodeType && i.hasData(n)) {
            var u, f, o, s = i._data(n), r = i._data(t, s), e = s.events;
            if (e) {
                delete r.handle;
                r.events = {};
                for (u in e)for (f = 0, o = e[u].length; o > f; f++)i.event.add(t, u, e[u][f])
            }
            r.data && (r.data = i.extend({}, r.data))
        }
    }

    function ke(n, t) {
        var u, e, f;
        if (1 === t.nodeType) {
            if (u = t.nodeName.toLowerCase(), !r.noCloneEvent && t[i.expando]) {
                f = i._data(t);
                for (e in f.events)i.removeEvent(t, e, f.handle);
                t.removeAttribute(i.expando)
            }
            "script" === u && t.text !== n.text ? (ou(t).text = n.text, su(t)) : "object" === u ? (t.parentNode && (t.outerHTML = n.outerHTML), r.html5Clone && n.innerHTML && !i.trim(t.innerHTML) && (t.innerHTML = n.innerHTML)) : "input" === u && oi.test(n.type) ? (t.defaultChecked = t.checked = n.checked, t.value !== n.value && (t.value = n.value)) : "option" === u ? t.defaultSelected = t.selected = n.defaultSelected : ("input" === u || "textarea" === u) && (t.defaultValue = n.defaultValue)
        }
    }

    function cu(t, r) {
        var u = i(r.createElement(t)).appendTo(r.body), f = n.getDefaultComputedStyle ? n.getDefaultComputedStyle(u[0]).display : i.css(u[0], "display");
        return u.detach(), f
    }

    function lu(n) {
        var r = u, t = ai[n];
        return t || (t = cu(n, r), "none" !== t && t || (ot = (ot || i("<iframe frameborder='0' width='0' height='0'/>")).appendTo(r.documentElement), r = (ot[0].contentWindow || ot[0].contentDocument).document, r.write(), r.close(), t = cu(n, r), ot.detach()), ai[n] = t), t
    }

    function vu(n, t) {
        return {
            get: function () {
                var i = n();
                if (null != i)return i ? void delete this.get : (this.get = t).apply(this, arguments)
            }
        }
    }

    function wu(n, t) {
        if (t in n)return t;
        for (var r = t.charAt(0).toUpperCase() + t.slice(1), u = t, i = pu.length; i--;)if (t = pu[i] + r, t in n)return t;
        return u
    }

    function bu(n, t) {
        for (var f, r, o, e = [], u = 0, s = n.length; s > u; u++)r = n[u], r.style && (e[u] = i._data(r, "olddisplay"), f = r.style.display, t ? (e[u] || "none" !== f || (r.style.display = ""), "" === r.style.display && et(r) && (e[u] = i._data(r, "olddisplay", lu(r.nodeName)))) : e[u] || (o = et(r), (f && "none" !== f || !o) && i._data(r, "olddisplay", o ? f : i.css(r, "display"))));
        for (u = 0; s > u; u++)r = n[u], r.style && (t && "none" !== r.style.display && "" !== r.style.display || (r.style.display = t ? e[u] || "" : "none"));
        return n
    }

    function ku(n, t, i) {
        var r = to.exec(t);
        return r ? Math.max(0, r[1] - (i || 0)) + (r[2] || "px") : t
    }

    function du(n, t, r, u, f) {
        for (var e = r === (u ? "border" : "content") ? 4 : "width" === t ? 1 : 0, o = 0; 4 > e; e += 2)"margin" === r && (o += i.css(n, r + w[e], !0, f)), u ? ("content" === r && (o -= i.css(n, "padding" + w[e], !0, f)), "margin" !== r && (o -= i.css(n, "border" + w[e] + "Width", !0, f))) : (o += i.css(n, "padding" + w[e], !0, f), "padding" !== r && (o += i.css(n, "border" + w[e] + "Width", !0, f)));
        return o
    }

    function gu(n, t, u) {
        var o = !0, f = "width" === t ? n.offsetWidth : n.offsetHeight, e = k(n), s = r.boxSizing() && "border-box" === i.css(n, "boxSizing", !1, e);
        if (0 >= f || null == f) {
            if (f = d(n, t, e), (0 > f || null == f) && (f = n.style[t]), yt.test(f))return f;
            o = s && (r.boxSizingReliable() || f === n.style[t]);
            f = parseFloat(f) || 0
        }
        return f + du(n, t, u || (s ? "border" : "content"), o, e) + "px"
    }

    function e(n, t, i, r, u) {
        return new e.prototype.init(n, t, i, r, u)
    }

    function tf() {
        return setTimeout(function () {
            rt = void 0
        }), rt = i.now()
    }

    function bt(n, t) {
        var r, i = {height: n}, u = 0;
        for (t = t ? 1 : 0; 4 > u; u += 2 - t)r = w[u], i["margin" + r] = i["padding" + r] = n;
        return t && (i.opacity = i.width = n), i
    }

    function rf(n, t, i) {
        for (var u, f = (st[t] || []).concat(st["*"]), r = 0, e = f.length; e > r; r++)if (u = f[r].call(i, t, n))return u
    }

    function eo(n, t, u) {
        var f, l, p, a, o, b, y, w, c = this, v = {}, s = n.style, h = n.nodeType && et(n), e = i._data(n, "fxshow");
        u.queue || (o = i._queueHooks(n, "fx"), null == o.unqueued && (o.unqueued = 0, b = o.empty.fire, o.empty.fire = function () {
            o.unqueued || b()
        }), o.unqueued++, c.always(function () {
            c.always(function () {
                o.unqueued--;
                i.queue(n, "fx").length || o.empty.fire()
            })
        }));
        1 === n.nodeType && ("height" in t || "width" in t) && (u.overflow = [s.overflow, s.overflowX, s.overflowY], y = i.css(n, "display"), w = lu(n.nodeName), "none" === y && (y = w), "inline" === y && "none" === i.css(n, "float") && (r.inlineBlockNeedsLayout && "inline" !== w ? s.zoom = 1 : s.display = "inline-block"));
        u.overflow && (s.overflow = "hidden", r.shrinkWrapBlocks() || c.always(function () {
            s.overflow = u.overflow[0];
            s.overflowX = u.overflow[1];
            s.overflowY = u.overflow[2]
        }));
        for (f in t)if (l = t[f], uo.exec(l)) {
            if (delete t[f], p = p || "toggle" === l, l === (h ? "hide" : "show")) {
                if ("show" !== l || !e || void 0 === e[f])continue;
                h = !0
            }
            v[f] = e && e[f] || i.style(n, f)
        }
        if (!i.isEmptyObject(v)) {
            e ? "hidden" in e && (h = e.hidden) : e = i._data(n, "fxshow", {});
            p && (e.hidden = !h);
            h ? i(n).show() : c.done(function () {
                i(n).hide()
            });
            c.done(function () {
                var t;
                i._removeData(n, "fxshow");
                for (t in v)i.style(n, t, v[t])
            });
            for (f in v)a = rf(h ? e[f] : 0, f, c), f in e || (e[f] = a.start, h && (a.end = a.start, a.start = "width" === f || "height" === f ? 1 : 0))
        }
    }

    function oo(n, t) {
        var r, f, e, u, o;
        for (r in n)if (f = i.camelCase(r), e = t[f], u = n[r], i.isArray(u) && (e = u[1], u = n[r] = u[0]), r !== f && (n[f] = u, delete n[r]), o = i.cssHooks[f], o && "expand" in o) {
            u = o.expand(u);
            delete n[f];
            for (r in u)r in n || (n[r] = u[r], t[r] = e)
        } else t[f] = e
    }

    function uf(n, t, r) {
        var h, e, o = 0, l = wt.length, f = i.Deferred().always(function () {
            delete c.elem
        }), c = function () {
            if (e)return !1;
            for (var s = rt || tf(), t = Math.max(0, u.startTime + u.duration - s), h = t / u.duration || 0, i = 1 - h, r = 0, o = u.tweens.length; o > r; r++)u.tweens[r].run(i);
            return f.notifyWith(n, [u, i, t]), 1 > i && o ? t : (f.resolveWith(n, [u]), !1)
        }, u = f.promise({
            elem: n,
            props: i.extend({}, t),
            opts: i.extend(!0, {specialEasing: {}}, r),
            originalProperties: t,
            originalOptions: r,
            startTime: rt || tf(),
            duration: r.duration,
            tweens: [],
            createTween: function (t, r) {
                var f = i.Tween(n, u.opts, t, r, u.opts.specialEasing[t] || u.opts.easing);
                return u.tweens.push(f), f
            },
            stop: function (t) {
                var i = 0, r = t ? u.tweens.length : 0;
                if (e)return this;
                for (e = !0; r > i; i++)u.tweens[i].run(1);
                return t ? f.resolveWith(n, [u, t]) : f.rejectWith(n, [u, t]), this
            }
        }), s = u.props;
        for (oo(s, u.opts.specialEasing); l > o; o++)if (h = wt[o].call(u, n, s, u.opts))return h;
        return i.map(s, rf, u), i.isFunction(u.opts.start) && u.opts.start.call(n, u), i.fx.timer(i.extend(c, {
            elem: n,
            anim: u,
            queue: u.opts.queue
        })), u.progress(u.opts.progress).done(u.opts.done, u.opts.complete).fail(u.opts.fail).always(u.opts.always)
    }

    function vf(n) {
        return function (t, r) {
            "string" != typeof t && (r = t, t = "*");
            var u, f = 0, e = t.toLowerCase().match(h) || [];
            if (i.isFunction(r))while (u = e[f++])"+" === u.charAt(0) ? (u = u.slice(1) || "*", (n[u] = n[u] || []).unshift(r)) : (n[u] = n[u] || []).push(r)
        }
    }

    function yf(n, t, r, u) {
        function e(s) {
            var h;
            return f[s] = !0, i.each(n[s] || [], function (n, i) {
                var s = i(t, r, u);
                return "string" != typeof s || o || f[s] ? o ? !(h = s) : void 0 : (t.dataTypes.unshift(s), e(s), !1)
            }), h
        }

        var f = {}, o = n === bi;
        return e(t.dataTypes[0]) || !f["*"] && e("*")
    }

    function ki(n, t) {
        var u, r, f = i.ajaxSettings.flatOptions || {};
        for (r in t)void 0 !== t[r] && ((f[r] ? n : u || (u = {}))[r] = t[r]);
        return u && i.extend(!0, n, u), n
    }

    function vo(n, t, i) {
        for (var o, e, u, f, s = n.contents, r = n.dataTypes; "*" === r[0];)r.shift(), void 0 === e && (e = n.mimeType || t.getResponseHeader("Content-Type"));
        if (e)for (f in s)if (s[f] && s[f].test(e)) {
            r.unshift(f);
            break
        }
        if (r[0] in i)u = r[0]; else {
            for (f in i) {
                if (!r[0] || n.converters[f + " " + r[0]]) {
                    u = f;
                    break
                }
                o || (o = f)
            }
            u = u || o
        }
        if (u)return (u !== r[0] && r.unshift(u), i[u])
    }

    function yo(n, t, i, r) {
        var h, u, f, s, e, o = {}, c = n.dataTypes.slice();
        if (c[1])for (f in n.converters)o[f.toLowerCase()] = n.converters[f];
        for (u = c.shift(); u;)if (n.responseFields[u] && (i[n.responseFields[u]] = t), !e && r && n.dataFilter && (t = n.dataFilter(t, n.dataType)), e = u, u = c.shift())if ("*" === u)u = e; else if ("*" !== e && e !== u) {
            if (f = o[e + " " + u] || o["* " + u], !f)for (h in o)if (s = h.split(" "), s[1] === u && (f = o[e + " " + s[0]] || o["* " + s[0]])) {
                f === !0 ? f = o[h] : o[h] !== !0 && (u = s[0], c.unshift(s[1]));
                break
            }
            if (f !== !0)if (f && n.throws)t = f(t); else try {
                t = f(t)
            } catch (l) {
                return {state: "parsererror", error: f ? l : "No conversion from " + e + " to " + u}
            }
        }
        return {state: "success", data: t}
    }

    function di(n, t, r, u) {
        var f;
        if (i.isArray(t))i.each(t, function (t, i) {
            r || wo.test(n) ? u(n, i) : di(n + "[" + ("object" == typeof i ? t : "") + "]", i, r, u)
        }); else if (r || "object" !== i.type(t))u(n, t); else for (f in t)di(n + "[" + f + "]", t[f], r, u)
    }

    function wf() {
        try {
            return new n.XMLHttpRequest
        } catch (t) {
        }
    }

    function ns() {
        try {
            return new n.ActiveXObject("Microsoft.XMLHTTP")
        } catch (t) {
        }
    }

    function bf(n) {
        return i.isWindow(n) ? n : 9 === n.nodeType ? n.defaultView || n.parentWindow : !1
    }

    var c = [], l = c.slice, ir = c.concat, ti = c.push, rr = c.indexOf, ct = {}, gf = ct.toString, tt = ct.hasOwnProperty, ii = "".trim, r = {}, ur = "1.11.0", i = function (n, t) {
        return new i.fn.init(n, t)
    }, ne = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, te = /^-ms-/, ie = /-([\da-z])/gi, re = function (n, t) {
        return t.toUpperCase()
    }, p, or, sr, h, fi, lt, o, lr, ar, vr, ot, ai, ff, of, sf, dt, gi, ni, nr, tr, kf, df;
    i.fn = i.prototype = {
        jquery: ur, constructor: i, selector: "", length: 0, toArray: function () {
            return l.call(this)
        }, get: function (n) {
            return null != n ? 0 > n ? this[n + this.length] : this[n] : l.call(this)
        }, pushStack: function (n) {
            var t = i.merge(this.constructor(), n);
            return t.prevObject = this, t.context = this.context, t
        }, each: function (n, t) {
            return i.each(this, n, t)
        }, map: function (n) {
            return this.pushStack(i.map(this, function (t, i) {
                return n.call(t, i, t)
            }))
        }, slice: function () {
            return this.pushStack(l.apply(this, arguments))
        }, first: function () {
            return this.eq(0)
        }, last: function () {
            return this.eq(-1)
        }, eq: function (n) {
            var i = this.length, t = +n + (0 > n ? i : 0);
            return this.pushStack(t >= 0 && i > t ? [this[t]] : [])
        }, end: function () {
            return this.prevObject || this.constructor(null)
        }, push: ti, sort: c.sort, splice: c.splice
    };
    i.extend = i.fn.extend = function () {
        var r, e, t, f, o, s, n = arguments[0] || {}, u = 1, c = arguments.length, h = !1;
        for ("boolean" == typeof n && (h = n, n = arguments[u] || {}, u++), "object" == typeof n || i.isFunction(n) || (n = {}), u === c && (n = this, u--); c > u; u++)if (null != (o = arguments[u]))for (f in o)r = n[f], t = o[f], n !== t && (h && t && (i.isPlainObject(t) || (e = i.isArray(t))) ? (e ? (e = !1, s = r && i.isArray(r) ? r : []) : s = r && i.isPlainObject(r) ? r : {}, n[f] = i.extend(h, s, t)) : void 0 !== t && (n[f] = t));
        return n
    };
    i.extend({
        expando: "jQuery" + (ur + Math.random()).replace(/\D/g, ""), isReady: !0, error: function (n) {
            throw new Error(n);
        }, noop: function () {
        }, isFunction: function (n) {
            return "function" === i.type(n)
        }, isArray: Array.isArray || function (n) {
            return "array" === i.type(n)
        }, isWindow: function (n) {
            return null != n && n == n.window
        }, isNumeric: function (n) {
            return n - parseFloat(n) >= 0
        }, isEmptyObject: function (n) {
            var t;
            for (t in n)return !1;
            return !0
        }, isPlainObject: function (n) {
            var t;
            if (!n || "object" !== i.type(n) || n.nodeType || i.isWindow(n))return !1;
            try {
                if (n.constructor && !tt.call(n, "constructor") && !tt.call(n.constructor.prototype, "isPrototypeOf"))return !1
            } catch (u) {
                return !1
            }
            if (r.ownLast)for (t in n)return tt.call(n, t);
            for (t in n);
            return void 0 === t || tt.call(n, t)
        }, type: function (n) {
            return null == n ? n + "" : "object" == typeof n || "function" == typeof n ? ct[gf.call(n)] || "object" : typeof n
        }, globalEval: function (t) {
            t && i.trim(t) && (n.execScript || function (t) {
                n.eval.call(n, t)
            })(t)
        }, camelCase: function (n) {
            return n.replace(te, "ms-").replace(ie, re)
        }, nodeName: function (n, t) {
            return n.nodeName && n.nodeName.toLowerCase() === t.toLowerCase()
        }, each: function (n, t, i) {
            var u, r = 0, f = n.length, e = ri(n);
            if (i) {
                if (e) {
                    for (; f > r; r++)if (u = t.apply(n[r], i), u === !1)break
                } else for (r in n)if (u = t.apply(n[r], i), u === !1)break
            } else if (e) {
                for (; f > r; r++)if (u = t.call(n[r], r, n[r]), u === !1)break
            } else for (r in n)if (u = t.call(n[r], r, n[r]), u === !1)break;
            return n
        }, trim: ii && !ii.call("﻿ ") ? function (n) {
            return null == n ? "" : ii.call(n)
        } : function (n) {
            return null == n ? "" : (n + "").replace(ne, "")
        }, makeArray: function (n, t) {
            var r = t || [];
            return null != n && (ri(Object(n)) ? i.merge(r, "string" == typeof n ? [n] : n) : ti.call(r, n)), r
        }, inArray: function (n, t, i) {
            var r;
            if (t) {
                if (rr)return rr.call(t, n, i);
                for (r = t.length, i = i ? 0 > i ? Math.max(0, r + i) : i : 0; r > i; i++)if (i in t && t[i] === n)return i
            }
            return -1
        }, merge: function (n, t) {
            for (var r = +t.length, i = 0, u = n.length; r > i;)n[u++] = t[i++];
            if (r !== r)while (void 0 !== t[i])n[u++] = t[i++];
            return n.length = u, n
        }, grep: function (n, t, i) {
            for (var u, f = [], r = 0, e = n.length, o = !i; e > r; r++)u = !t(n[r], r), u !== o && f.push(n[r]);
            return f
        }, map: function (n, t, i) {
            var u, r = 0, e = n.length, o = ri(n), f = [];
            if (o)for (; e > r; r++)u = t(n[r], r, i), null != u && f.push(u); else for (r in n)u = t(n[r], r, i), null != u && f.push(u);
            return ir.apply([], f)
        }, guid: 1, proxy: function (n, t) {
            var u, r, f;
            return "string" == typeof t && (f = n[t], t = n, n = f), i.isFunction(n) ? (u = l.call(arguments, 2), r = function () {
                return n.apply(t || this, u.concat(l.call(arguments)))
            }, r.guid = n.guid = n.guid || i.guid++, r) : void 0
        }, now: function () {
            return +new Date
        }, support: r
    });
    i.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function (n, t) {
        ct["[object " + t + "]"] = t.toLowerCase()
    });
    p = function (n) {
        function u(n, t, i, u) {
            var w, h, c, v, k, y, d, a, nt, g;
            if ((t ? t.ownerDocument || t : s) !== e && p(t), t = t || e, i = i || [], !n || "string" != typeof n)return i;
            if (1 !== (v = t.nodeType) && 9 !== v)return [];
            if (l && !u) {
                if (w = or.exec(n))if (c = w[1]) {
                    if (9 === v) {
                        if (h = t.getElementById(c), !h || !h.parentNode)return i;
                        if (h.id === c)return i.push(h), i
                    } else if (t.ownerDocument && (h = t.ownerDocument.getElementById(c)) && et(t, h) && h.id === c)return i.push(h), i
                } else {
                    if (w[2])return b.apply(i, t.getElementsByTagName(n)), i;
                    if ((c = w[3]) && r.getElementsByClassName && t.getElementsByClassName)return b.apply(i, t.getElementsByClassName(c)), i
                }
                if (r.qsa && (!o || !o.test(n))) {
                    if (a = d = f, nt = t, g = 9 === v && n, 1 === v && "object" !== t.nodeName.toLowerCase()) {
                        for (y = vt(n), (d = t.getAttribute("id")) ? a = d.replace(sr, "\\$&") : t.setAttribute("id", a), a = "[id='" + a + "'] ", k = y.length; k--;)y[k] = a + yt(y[k]);
                        nt = gt.test(n) && ii(t.parentNode) || t;
                        g = y.join(",")
                    }
                    if (g)try {
                        return b.apply(i, nt.querySelectorAll(g)), i
                    } catch (tt) {
                    } finally {
                        d || t.removeAttribute("id")
                    }
                }
            }
            return vr(n.replace(lt, "$1"), t, i, u)
        }

        function ni() {
            function n(r, u) {
                return i.push(r + " ") > t.cacheLength && delete n[i.shift()], n[r + " "] = u
            }

            var i = [];
            return n
        }

        function h(n) {
            return n[f] = !0, n
        }

        function c(n) {
            var t = e.createElement("div");
            try {
                return !!n(t)
            } catch (i) {
                return !1
            } finally {
                t.parentNode && t.parentNode.removeChild(t);
                t = null
            }
        }

        function ti(n, i) {
            for (var u = n.split("|"), r = n.length; r--;)t.attrHandle[u[r]] = i
        }

        function pi(n, t) {
            var i = t && n, r = i && 1 === n.nodeType && 1 === t.nodeType && (~t.sourceIndex || li) - (~n.sourceIndex || li);
            if (r)return r;
            if (i)while (i = i.nextSibling)if (i === t)return -1;
            return n ? 1 : -1
        }

        function hr(n) {
            return function (t) {
                var i = t.nodeName.toLowerCase();
                return "input" === i && t.type === n
            }
        }

        function cr(n) {
            return function (t) {
                var i = t.nodeName.toLowerCase();
                return ("input" === i || "button" === i) && t.type === n
            }
        }

        function tt(n) {
            return h(function (t) {
                return t = +t, h(function (i, r) {
                    for (var u, f = n([], i.length, t), e = f.length; e--;)i[u = f[e]] && (i[u] = !(r[u] = i[u]))
                })
            })
        }

        function ii(n) {
            return n && typeof n.getElementsByTagName !== ut && n
        }

        function wi() {
        }

        function vt(n, i) {
            var e, f, s, o, r, h, c, l = hi[n + " "];
            if (l)return i ? 0 : l.slice(0);
            for (r = n, h = [], c = t.preFilter; r;) {
                (!e || (f = nr.exec(r))) && (f && (r = r.slice(f[0].length) || r), h.push(s = []));
                e = !1;
                (f = tr.exec(r)) && (e = f.shift(), s.push({
                    value: e,
                    type: f[0].replace(lt, " ")
                }), r = r.slice(e.length));
                for (o in t.filter)(f = at[o].exec(r)) && (!c[o] || (f = c[o](f))) && (e = f.shift(), s.push({
                    value: e,
                    type: o,
                    matches: f
                }), r = r.slice(e.length));
                if (!e)break
            }
            return i ? r.length : r ? u.error(n) : hi(n, h).slice(0)
        }

        function yt(n) {
            for (var t = 0, r = n.length, i = ""; r > t; t++)i += n[t].value;
            return i
        }

        function ri(n, t, i) {
            var r = t.dir, u = i && "parentNode" === r, e = bi++;
            return t.first ? function (t, i, f) {
                while (t = t[r])if (1 === t.nodeType || u)return n(t, i, f)
            } : function (t, i, o) {
                var s, h, c = [a, e];
                if (o) {
                    while (t = t[r])if ((1 === t.nodeType || u) && n(t, i, o))return !0
                } else while (t = t[r])if (1 === t.nodeType || u) {
                    if (h = t[f] || (t[f] = {}), (s = h[r]) && s[0] === a && s[1] === e)return c[2] = s[2];
                    if (h[r] = c, c[2] = n(t, i, o))return !0
                }
            }
        }

        function ui(n) {
            return n.length > 1 ? function (t, i, r) {
                for (var u = n.length; u--;)if (!n[u](t, i, r))return !1;
                return !0
            } : n[0]
        }

        function pt(n, t, i, r, u) {
            for (var e, o = [], f = 0, s = n.length, h = null != t; s > f; f++)(e = n[f]) && (!i || i(e, r, u)) && (o.push(e), h && t.push(f));
            return o
        }

        function fi(n, t, i, r, u, e) {
            return r && !r[f] && (r = fi(r)), u && !u[f] && (u = fi(u, e)), h(function (f, e, o, s) {
                var l, c, a, p = [], y = [], w = e.length, k = f || ar(t || "*", o.nodeType ? [o] : o, []), v = !n || !f && t ? k : pt(k, p, n, o, s), h = i ? u || (f ? n : w || r) ? [] : e : v;
                if (i && i(v, h, o, s), r)for (l = pt(h, y), r(l, [], o, s), c = l.length; c--;)(a = l[c]) && (h[y[c]] = !(v[y[c]] = a));
                if (f) {
                    if (u || n) {
                        if (u) {
                            for (l = [], c = h.length; c--;)(a = h[c]) && l.push(v[c] = a);
                            u(null, h = [], l, s)
                        }
                        for (c = h.length; c--;)(a = h[c]) && (l = u ? nt.call(f, a) : p[c]) > -1 && (f[l] = !(e[l] = a))
                    }
                } else h = pt(h === e ? h.splice(w, h.length) : h), u ? u(null, e, h, s) : b.apply(e, h)
            })
        }

        function ei(n) {
            for (var s, u, r, o = n.length, h = t.relative[n[0].type], c = h || t.relative[" "], i = h ? 1 : 0, l = ri(function (n) {
                return n === s
            }, c, !0), a = ri(function (n) {
                return nt.call(s, n) > -1
            }, c, !0), e = [function (n, t, i) {
                return !h && (i || t !== ht) || ((s = t).nodeType ? l(n, t, i) : a(n, t, i))
            }]; o > i; i++)if (u = t.relative[n[i].type])e = [ri(ui(e), u)]; else {
                if (u = t.filter[n[i].type].apply(null, n[i].matches), u[f]) {
                    for (r = ++i; o > r; r++)if (t.relative[n[r].type])break;
                    return fi(i > 1 && ui(e), i > 1 && yt(n.slice(0, i - 1).concat({value: " " === n[i - 2].type ? "*" : ""})).replace(lt, "$1"), u, r > i && ei(n.slice(i, r)), o > r && ei(n = n.slice(r)), o > r && yt(n))
                }
                e.push(u)
            }
            return ui(e)
        }

        function lr(n, i) {
            var r = i.length > 0, f = n.length > 0, o = function (o, s, h, c, l) {
                var y, d, w, k = 0, v = "0", g = o && [], p = [], nt = ht, tt = o || f && t.find.TAG("*", l), it = a += null == nt ? 1 : Math.random() || .1, rt = tt.length;
                for (l && (ht = s !== e && s); v !== rt && null != (y = tt[v]); v++) {
                    if (f && y) {
                        for (d = 0; w = n[d++];)if (w(y, s, h)) {
                            c.push(y);
                            break
                        }
                        l && (a = it)
                    }
                    r && ((y = !w && y) && k--, o && g.push(y))
                }
                if (k += v, r && v !== k) {
                    for (d = 0; w = i[d++];)w(g, p, s, h);
                    if (o) {
                        if (k > 0)while (v--)g[v] || p[v] || (p[v] = di.call(c));
                        p = pt(p)
                    }
                    b.apply(c, p);
                    l && !o && p.length > 0 && k + i.length > 1 && u.uniqueSort(c)
                }
                return l && (a = it, ht = nt), g
            };
            return r ? h(o) : o
        }

        function ar(n, t, i) {
            for (var r = 0, f = t.length; f > r; r++)u(n, t[r], i);
            return i
        }

        function vr(n, i, u, f) {
            var s, e, o, c, a, h = vt(n);
            if (!f && 1 === h.length) {
                if (e = h[0] = h[0].slice(0), e.length > 2 && "ID" === (o = e[0]).type && r.getById && 9 === i.nodeType && l && t.relative[e[1].type]) {
                    if (i = (t.find.ID(o.matches[0].replace(k, d), i) || [])[0], !i)return u;
                    n = n.slice(e.shift().value.length)
                }
                for (s = at.needsContext.test(n) ? 0 : e.length; s--;) {
                    if (o = e[s], t.relative[c = o.type])break;
                    if ((a = t.find[c]) && (f = a(o.matches[0].replace(k, d), gt.test(e[0].type) && ii(i.parentNode) || i))) {
                        if (e.splice(s, 1), n = f.length && yt(e), !n)return b.apply(u, f), u;
                        break
                    }
                }
            }
            return wt(n, h)(f, i, !l, u, gt.test(n) && ii(i.parentNode) || i), u
        }

        var it, r, t, st, oi, wt, ht, y, rt, p, e, v, l, o, g, ct, et, f = "sizzle" + -new Date, s = n.document, a = 0, bi = 0, si = ni(), hi = ni(), ci = ni(), bt = function (n, t) {
            return n === t && (rt = !0), 0
        }, ut = "undefined", li = -2147483648, ki = {}.hasOwnProperty, w = [], di = w.pop, gi = w.push, b = w.push, ai = w.slice, nt = w.indexOf || function (n) {
                for (var t = 0, i = this.length; i > t; t++)if (this[t] === n)return t;
                return -1
            }, kt = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped", i = "[\\x20\\t\\r\\n\\f]", ft = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+", vi = ft.replace("w", "w#"), yi = "\\[" + i + "*(" + ft + ")" + i + "*(?:([*^$|!~]?=)" + i + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + vi + ")|)|)" + i + "*\\]", dt = ":(" + ft + ")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|" + yi.replace(3, 8) + ")*)|.*)\\)|)", lt = new RegExp("^" + i + "+|((?:^|[^\\\\])(?:\\\\.)*)" + i + "+$", "g"), nr = new RegExp("^" + i + "*," + i + "*"), tr = new RegExp("^" + i + "*([>+~]|" + i + ")" + i + "*"), ir = new RegExp("=" + i + "*([^\\]'\"]*?)" + i + "*\\]", "g"), rr = new RegExp(dt), ur = new RegExp("^" + vi + "$"), at = {
            ID: new RegExp("^#(" + ft + ")"),
            CLASS: new RegExp("^\\.(" + ft + ")"),
            TAG: new RegExp("^(" + ft.replace("w", "w*") + ")"),
            ATTR: new RegExp("^" + yi),
            PSEUDO: new RegExp("^" + dt),
            CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + i + "*(even|odd|(([+-]|)(\\d*)n|)" + i + "*(?:([+-]|)" + i + "*(\\d+)|))" + i + "*\\)|)", "i"),
            bool: new RegExp("^(?:" + kt + ")$", "i"),
            needsContext: new RegExp("^" + i + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + i + "*((?:-\\d)?\\d*)" + i + "*\\)|)(?=[^-]|$)", "i")
        }, fr = /^(?:input|select|textarea|button)$/i, er = /^h\d$/i, ot = /^[^{]+\{\s*\[native \w/, or = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/, gt = /[+~]/, sr = /'|\\/g, k = new RegExp("\\\\([\\da-f]{1,6}" + i + "?|(" + i + ")|.)", "ig"), d = function (n, t, i) {
            var r = "0x" + t - 65536;
            return r !== r || i ? t : 0 > r ? String.fromCharCode(r + 65536) : String.fromCharCode(r >> 10 | 55296, 1023 & r | 56320)
        };
        try {
            b.apply(w = ai.call(s.childNodes), s.childNodes);
            w[s.childNodes.length].nodeType
        } catch (yr) {
            b = {
                apply: w.length ? function (n, t) {
                    gi.apply(n, ai.call(t))
                } : function (n, t) {
                    for (var i = n.length, r = 0; n[i++] = t[r++];);
                    n.length = i - 1
                }
            }
        }
        r = u.support = {};
        oi = u.isXML = function (n) {
            var t = n && (n.ownerDocument || n).documentElement;
            return t ? "HTML" !== t.nodeName : !1
        };
        p = u.setDocument = function (n) {
            var a, u = n ? n.ownerDocument || n : s, h = u.defaultView;
            return u !== e && 9 === u.nodeType && u.documentElement ? (e = u, v = u.documentElement, l = !oi(u), h && h !== h.top && (h.addEventListener ? h.addEventListener("unload", function () {
                p()
            }, !1) : h.attachEvent && h.attachEvent("onunload", function () {
                p()
            })), r.attributes = c(function (n) {
                return n.className = "i", !n.getAttribute("className")
            }), r.getElementsByTagName = c(function (n) {
                return n.appendChild(u.createComment("")), !n.getElementsByTagName("*").length
            }), r.getElementsByClassName = ot.test(u.getElementsByClassName) && c(function (n) {
                    return n.innerHTML = "<div class='a'><\/div><div class='a i'><\/div>", n.firstChild.className = "i", 2 === n.getElementsByClassName("i").length
                }), r.getById = c(function (n) {
                return v.appendChild(n).id = f, !u.getElementsByName || !u.getElementsByName(f).length
            }), r.getById ? (t.find.ID = function (n, t) {
                if (typeof t.getElementById !== ut && l) {
                    var i = t.getElementById(n);
                    return i && i.parentNode ? [i] : []
                }
            }, t.filter.ID = function (n) {
                var t = n.replace(k, d);
                return function (n) {
                    return n.getAttribute("id") === t
                }
            }) : (delete t.find.ID, t.filter.ID = function (n) {
                var t = n.replace(k, d);
                return function (n) {
                    var i = typeof n.getAttributeNode !== ut && n.getAttributeNode("id");
                    return i && i.value === t
                }
            }), t.find.TAG = r.getElementsByTagName ? function (n, t) {
                if (typeof t.getElementsByTagName !== ut)return t.getElementsByTagName(n)
            } : function (n, t) {
                var i, r = [], f = 0, u = t.getElementsByTagName(n);
                if ("*" === n) {
                    while (i = u[f++])1 === i.nodeType && r.push(i);
                    return r
                }
                return u
            }, t.find.CLASS = r.getElementsByClassName && function (n, t) {
                    if (typeof t.getElementsByClassName !== ut && l)return t.getElementsByClassName(n)
                }, g = [], o = [], (r.qsa = ot.test(u.querySelectorAll)) && (c(function (n) {
                n.innerHTML = "<select t=''><option selected=''><\/option><\/select>";
                n.querySelectorAll("[t^='']").length && o.push("[*^$]=" + i + "*(?:''|\"\")");
                n.querySelectorAll("[selected]").length || o.push("\\[" + i + "*(?:value|" + kt + ")");
                n.querySelectorAll(":checked").length || o.push(":checked")
            }), c(function (n) {
                var t = u.createElement("input");
                t.setAttribute("type", "hidden");
                n.appendChild(t).setAttribute("name", "D");
                n.querySelectorAll("[name=d]").length && o.push("name" + i + "*[*^$|!~]?=");
                n.querySelectorAll(":enabled").length || o.push(":enabled", ":disabled");
                n.querySelectorAll("*,:x");
                o.push(",.*:")
            })), (r.matchesSelector = ot.test(ct = v.webkitMatchesSelector || v.mozMatchesSelector || v.oMatchesSelector || v.msMatchesSelector)) && c(function (n) {
                r.disconnectedMatch = ct.call(n, "div");
                ct.call(n, "[s!='']:x");
                g.push("!=", dt)
            }), o = o.length && new RegExp(o.join("|")), g = g.length && new RegExp(g.join("|")), a = ot.test(v.compareDocumentPosition), et = a || ot.test(v.contains) ? function (n, t) {
                var r = 9 === n.nodeType ? n.documentElement : n, i = t && t.parentNode;
                return n === i || !(!i || 1 !== i.nodeType || !(r.contains ? r.contains(i) : n.compareDocumentPosition && 16 & n.compareDocumentPosition(i)))
            } : function (n, t) {
                if (t)while (t = t.parentNode)if (t === n)return !0;
                return !1
            }, bt = a ? function (n, t) {
                if (n === t)return rt = !0, 0;
                var i = !n.compareDocumentPosition - !t.compareDocumentPosition;
                return i ? i : (i = (n.ownerDocument || n) === (t.ownerDocument || t) ? n.compareDocumentPosition(t) : 1, 1 & i || !r.sortDetached && t.compareDocumentPosition(n) === i ? n === u || n.ownerDocument === s && et(s, n) ? -1 : t === u || t.ownerDocument === s && et(s, t) ? 1 : y ? nt.call(y, n) - nt.call(y, t) : 0 : 4 & i ? -1 : 1)
            } : function (n, t) {
                if (n === t)return rt = !0, 0;
                var i, r = 0, o = n.parentNode, h = t.parentNode, f = [n], e = [t];
                if (!o || !h)return n === u ? -1 : t === u ? 1 : o ? -1 : h ? 1 : y ? nt.call(y, n) - nt.call(y, t) : 0;
                if (o === h)return pi(n, t);
                for (i = n; i = i.parentNode;)f.unshift(i);
                for (i = t; i = i.parentNode;)e.unshift(i);
                while (f[r] === e[r])r++;
                return r ? pi(f[r], e[r]) : f[r] === s ? -1 : e[r] === s ? 1 : 0
            }, u) : e
        };
        u.matches = function (n, t) {
            return u(n, null, null, t)
        };
        u.matchesSelector = function (n, t) {
            if ((n.ownerDocument || n) !== e && p(n), t = t.replace(ir, "='$1']"), !(!r.matchesSelector || !l || g && g.test(t) || o && o.test(t)))try {
                var i = ct.call(n, t);
                if (i || r.disconnectedMatch || n.document && 11 !== n.document.nodeType)return i
            } catch (f) {
            }
            return u(t, e, null, [n]).length > 0
        };
        u.contains = function (n, t) {
            return (n.ownerDocument || n) !== e && p(n), et(n, t)
        };
        u.attr = function (n, i) {
            (n.ownerDocument || n) !== e && p(n);
            var f = t.attrHandle[i.toLowerCase()], u = f && ki.call(t.attrHandle, i.toLowerCase()) ? f(n, i, !l) : void 0;
            return void 0 !== u ? u : r.attributes || !l ? n.getAttribute(i) : (u = n.getAttributeNode(i)) && u.specified ? u.value : null
        };
        u.error = function (n) {
            throw new Error("Syntax error, unrecognized expression: " + n);
        };
        u.uniqueSort = function (n) {
            var u, f = [], t = 0, i = 0;
            if (rt = !r.detectDuplicates, y = !r.sortStable && n.slice(0), n.sort(bt), rt) {
                while (u = n[i++])u === n[i] && (t = f.push(i));
                while (t--)n.splice(f[t], 1)
            }
            return y = null, n
        };
        st = u.getText = function (n) {
            var r, i = "", u = 0, t = n.nodeType;
            if (t) {
                if (1 === t || 9 === t || 11 === t) {
                    if ("string" == typeof n.textContent)return n.textContent;
                    for (n = n.firstChild; n; n = n.nextSibling)i += st(n)
                } else if (3 === t || 4 === t)return n.nodeValue
            } else while (r = n[u++])i += st(r);
            return i
        };
        t = u.selectors = {
            cacheLength: 50,
            createPseudo: h,
            match: at,
            attrHandle: {},
            find: {},
            relative: {
                ">": {dir: "parentNode", first: !0},
                " ": {dir: "parentNode"},
                "+": {dir: "previousSibling", first: !0},
                "~": {dir: "previousSibling"}
            },
            preFilter: {
                ATTR: function (n) {
                    return n[1] = n[1].replace(k, d), n[3] = (n[4] || n[5] || "").replace(k, d), "~=" === n[2] && (n[3] = " " + n[3] + " "), n.slice(0, 4)
                }, CHILD: function (n) {
                    return n[1] = n[1].toLowerCase(), "nth" === n[1].slice(0, 3) ? (n[3] || u.error(n[0]), n[4] = +(n[4] ? n[5] + (n[6] || 1) : 2 * ("even" === n[3] || "odd" === n[3])), n[5] = +(n[7] + n[8] || "odd" === n[3])) : n[3] && u.error(n[0]), n
                }, PSEUDO: function (n) {
                    var i, t = !n[5] && n[2];
                    return at.CHILD.test(n[0]) ? null : (n[3] && void 0 !== n[4] ? n[2] = n[4] : t && rr.test(t) && (i = vt(t, !0)) && (i = t.indexOf(")", t.length - i) - t.length) && (n[0] = n[0].slice(0, i), n[2] = t.slice(0, i)), n.slice(0, 3))
                }
            },
            filter: {
                TAG: function (n) {
                    var t = n.replace(k, d).toLowerCase();
                    return "*" === n ? function () {
                        return !0
                    } : function (n) {
                        return n.nodeName && n.nodeName.toLowerCase() === t
                    }
                }, CLASS: function (n) {
                    var t = si[n + " "];
                    return t || (t = new RegExp("(^|" + i + ")" + n + "(" + i + "|$)")) && si(n, function (n) {
                            return t.test("string" == typeof n.className && n.className || typeof n.getAttribute !== ut && n.getAttribute("class") || "")
                        })
                }, ATTR: function (n, t, i) {
                    return function (r) {
                        var f = u.attr(r, n);
                        return null == f ? "!=" === t : t ? (f += "", "=" === t ? f === i : "!=" === t ? f !== i : "^=" === t ? i && 0 === f.indexOf(i) : "*=" === t ? i && f.indexOf(i) > -1 : "$=" === t ? i && f.slice(-i.length) === i : "~=" === t ? (" " + f + " ").indexOf(i) > -1 : "|=" === t ? f === i || f.slice(0, i.length + 1) === i + "-" : !1) : !0
                    }
                }, CHILD: function (n, t, i, r, u) {
                    var s = "nth" !== n.slice(0, 3), o = "last" !== n.slice(-4), e = "of-type" === t;
                    return 1 === r && 0 === u ? function (n) {
                        return !!n.parentNode
                    } : function (t, i, h) {
                        var v, k, c, l, y, w, b = s !== o ? "nextSibling" : "previousSibling", p = t.parentNode, g = e && t.nodeName.toLowerCase(), d = !h && !e;
                        if (p) {
                            if (s) {
                                while (b) {
                                    for (c = t; c = c[b];)if (e ? c.nodeName.toLowerCase() === g : 1 === c.nodeType)return !1;
                                    w = b = "only" === n && !w && "nextSibling"
                                }
                                return !0
                            }
                            if (w = [o ? p.firstChild : p.lastChild], o && d) {
                                for (k = p[f] || (p[f] = {}), v = k[n] || [], y = v[0] === a && v[1], l = v[0] === a && v[2], c = y && p.childNodes[y]; c = ++y && c && c[b] || (l = y = 0) || w.pop();)if (1 === c.nodeType && ++l && c === t) {
                                    k[n] = [a, y, l];
                                    break
                                }
                            } else if (d && (v = (t[f] || (t[f] = {}))[n]) && v[0] === a)l = v[1]; else while (c = ++y && c && c[b] || (l = y = 0) || w.pop())if ((e ? c.nodeName.toLowerCase() === g : 1 === c.nodeType) && ++l && (d && ((c[f] || (c[f] = {}))[n] = [a, l]), c === t))break;
                            return l -= u, l === r || l % r == 0 && l / r >= 0
                        }
                    }
                }, PSEUDO: function (n, i) {
                    var e, r = t.pseudos[n] || t.setFilters[n.toLowerCase()] || u.error("unsupported pseudo: " + n);
                    return r[f] ? r(i) : r.length > 1 ? (e = [n, n, "", i], t.setFilters.hasOwnProperty(n.toLowerCase()) ? h(function (n, t) {
                        for (var u, f = r(n, i), e = f.length; e--;)u = nt.call(n, f[e]), n[u] = !(t[u] = f[e])
                    }) : function (n) {
                        return r(n, 0, e)
                    }) : r
                }
            },
            pseudos: {
                not: h(function (n) {
                    var i = [], r = [], t = wt(n.replace(lt, "$1"));
                    return t[f] ? h(function (n, i, r, u) {
                        for (var e, o = t(n, null, u, []), f = n.length; f--;)(e = o[f]) && (n[f] = !(i[f] = e))
                    }) : function (n, u, f) {
                        return i[0] = n, t(i, null, f, r), !r.pop()
                    }
                }), has: h(function (n) {
                    return function (t) {
                        return u(n, t).length > 0
                    }
                }), contains: h(function (n) {
                    return function (t) {
                        return (t.textContent || t.innerText || st(t)).indexOf(n) > -1
                    }
                }), lang: h(function (n) {
                    return ur.test(n || "") || u.error("unsupported lang: " + n), n = n.replace(k, d).toLowerCase(), function (t) {
                        var i;
                        do if (i = l ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang"))return i = i.toLowerCase(), i === n || 0 === i.indexOf(n + "-"); while ((t = t.parentNode) && 1 === t.nodeType);
                        return !1
                    }
                }), target: function (t) {
                    var i = n.location && n.location.hash;
                    return i && i.slice(1) === t.id
                }, root: function (n) {
                    return n === v
                }, focus: function (n) {
                    return n === e.activeElement && (!e.hasFocus || e.hasFocus()) && !!(n.type || n.href || ~n.tabIndex)
                }, enabled: function (n) {
                    return n.disabled === !1
                }, disabled: function (n) {
                    return n.disabled === !0
                }, checked: function (n) {
                    var t = n.nodeName.toLowerCase();
                    return "input" === t && !!n.checked || "option" === t && !!n.selected
                }, selected: function (n) {
                    return n.parentNode && n.parentNode.selectedIndex, n.selected === !0
                }, empty: function (n) {
                    for (n = n.firstChild; n; n = n.nextSibling)if (n.nodeType < 6)return !1;
                    return !0
                }, parent: function (n) {
                    return !t.pseudos.empty(n)
                }, header: function (n) {
                    return er.test(n.nodeName)
                }, input: function (n) {
                    return fr.test(n.nodeName)
                }, button: function (n) {
                    var t = n.nodeName.toLowerCase();
                    return "input" === t && "button" === n.type || "button" === t
                }, text: function (n) {
                    var t;
                    return "input" === n.nodeName.toLowerCase() && "text" === n.type && (null == (t = n.getAttribute("type")) || "text" === t.toLowerCase())
                }, first: tt(function () {
                    return [0]
                }), last: tt(function (n, t) {
                    return [t - 1]
                }), eq: tt(function (n, t, i) {
                    return [0 > i ? i + t : i]
                }), even: tt(function (n, t) {
                    for (var i = 0; t > i; i += 2)n.push(i);
                    return n
                }), odd: tt(function (n, t) {
                    for (var i = 1; t > i; i += 2)n.push(i);
                    return n
                }), lt: tt(function (n, t, i) {
                    for (var r = 0 > i ? i + t : i; --r >= 0;)n.push(r);
                    return n
                }), gt: tt(function (n, t, i) {
                    for (var r = 0 > i ? i + t : i; ++r < t;)n.push(r);
                    return n
                })
            }
        };
        t.pseudos.nth = t.pseudos.eq;
        for (it in{radio: !0, checkbox: !0, file: !0, password: !0, image: !0})t.pseudos[it] = hr(it);
        for (it in{submit: !0, reset: !0})t.pseudos[it] = cr(it);
        return wi.prototype = t.filters = t.pseudos, t.setFilters = new wi, wt = u.compile = function (n, t) {
            var r, u = [], e = [], i = ci[n + " "];
            if (!i) {
                for (t || (t = vt(n)), r = t.length; r--;)i = ei(t[r]), i[f] ? u.push(i) : e.push(i);
                i = ci(n, lr(e, u))
            }
            return i
        }, r.sortStable = f.split("").sort(bt).join("") === f, r.detectDuplicates = !!rt, p(), r.sortDetached = c(function (n) {
            return 1 & n.compareDocumentPosition(e.createElement("div"))
        }), c(function (n) {
            return n.innerHTML = "<a href='#'><\/a>", "#" === n.firstChild.getAttribute("href")
        }) || ti("type|href|height|width", function (n, t, i) {
            if (!i)return n.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
        }), r.attributes && c(function (n) {
            return n.innerHTML = "<input/>", n.firstChild.setAttribute("value", ""), "" === n.firstChild.getAttribute("value")
        }) || ti("value", function (n, t, i) {
            if (!i && "input" === n.nodeName.toLowerCase())return n.defaultValue
        }), c(function (n) {
            return null == n.getAttribute("disabled")
        }) || ti(kt, function (n, t, i) {
            var r;
            if (!i)return n[t] === !0 ? t.toLowerCase() : (r = n.getAttributeNode(t)) && r.specified ? r.value : null
        }), u
    }(n);
    i.find = p;
    i.expr = p.selectors;
    i.expr[":"] = i.expr.pseudos;
    i.unique = p.uniqueSort;
    i.text = p.getText;
    i.isXMLDoc = p.isXML;
    i.contains = p.contains;
    var fr = i.expr.match.needsContext, er = /^<(\w+)\s*\/?>(?:<\/\1>|)$/, ue = /^.[^:#\[\.,]*$/;
    i.filter = function (n, t, r) {
        var u = t[0];
        return r && (n = ":not(" + n + ")"), 1 === t.length && 1 === u.nodeType ? i.find.matchesSelector(u, n) ? [u] : [] : i.find.matches(n, i.grep(t, function (n) {
            return 1 === n.nodeType
        }))
    };
    i.fn.extend({
        find: function (n) {
            var t, r = [], u = this, f = u.length;
            if ("string" != typeof n)return this.pushStack(i(n).filter(function () {
                for (t = 0; f > t; t++)if (i.contains(u[t], this))return !0
            }));
            for (t = 0; f > t; t++)i.find(n, u[t], r);
            return r = this.pushStack(f > 1 ? i.unique(r) : r), r.selector = this.selector ? this.selector + " " + n : n, r
        }, filter: function (n) {
            return this.pushStack(ui(this, n || [], !1))
        }, not: function (n) {
            return this.pushStack(ui(this, n || [], !0))
        }, is: function (n) {
            return !!ui(this, "string" == typeof n && fr.test(n) ? i(n) : n || [], !1).length
        }
    });
    var ft, u = n.document, fe = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/, ee = i.fn.init = function (n, t) {
        var r, f;
        if (!n)return this;
        if ("string" == typeof n) {
            if (r = "<" === n.charAt(0) && ">" === n.charAt(n.length - 1) && n.length >= 3 ? [null, n, null] : fe.exec(n), !r || !r[1] && t)return !t || t.jquery ? (t || ft).find(n) : this.constructor(t).find(n);
            if (r[1]) {
                if (t = t instanceof i ? t[0] : t, i.merge(this, i.parseHTML(r[1], t && t.nodeType ? t.ownerDocument || t : u, !0)), er.test(r[1]) && i.isPlainObject(t))for (r in t)i.isFunction(this[r]) ? this[r](t[r]) : this.attr(r, t[r]);
                return this
            }
            if (f = u.getElementById(r[2]), f && f.parentNode) {
                if (f.id !== r[2])return ft.find(n);
                this.length = 1;
                this[0] = f
            }
            return this.context = u, this.selector = n, this
        }
        return n.nodeType ? (this.context = this[0] = n, this.length = 1, this) : i.isFunction(n) ? "undefined" != typeof ft.ready ? ft.ready(n) : n(i) : (void 0 !== n.selector && (this.selector = n.selector, this.context = n.context), i.makeArray(n, this))
    };
    ee.prototype = i.fn;
    ft = i(u);
    or = /^(?:parents|prev(?:Until|All))/;
    sr = {children: !0, contents: !0, next: !0, prev: !0};
    i.extend({
        dir: function (n, t, r) {
            for (var f = [], u = n[t]; u && 9 !== u.nodeType && (void 0 === r || 1 !== u.nodeType || !i(u).is(r));)1 === u.nodeType && f.push(u), u = u[t];
            return f
        }, sibling: function (n, t) {
            for (var i = []; n; n = n.nextSibling)1 === n.nodeType && n !== t && i.push(n);
            return i
        }
    });
    i.fn.extend({
        has: function (n) {
            var t, r = i(n, this), u = r.length;
            return this.filter(function () {
                for (t = 0; u > t; t++)if (i.contains(this, r[t]))return !0
            })
        }, closest: function (n, t) {
            for (var r, f = 0, o = this.length, u = [], e = fr.test(n) || "string" != typeof n ? i(n, t || this.context) : 0; o > f; f++)for (r = this[f]; r && r !== t; r = r.parentNode)if (r.nodeType < 11 && (e ? e.index(r) > -1 : 1 === r.nodeType && i.find.matchesSelector(r, n))) {
                u.push(r);
                break
            }
            return this.pushStack(u.length > 1 ? i.unique(u) : u)
        }, index: function (n) {
            return n ? "string" == typeof n ? i.inArray(this[0], i(n)) : i.inArray(n.jquery ? n[0] : n, this) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        }, add: function (n, t) {
            return this.pushStack(i.unique(i.merge(this.get(), i(n, t))))
        }, addBack: function (n) {
            return this.add(null == n ? this.prevObject : this.prevObject.filter(n))
        }
    });
    i.each({
        parent: function (n) {
            var t = n.parentNode;
            return t && 11 !== t.nodeType ? t : null
        }, parents: function (n) {
            return i.dir(n, "parentNode")
        }, parentsUntil: function (n, t, r) {
            return i.dir(n, "parentNode", r)
        }, next: function (n) {
            return hr(n, "nextSibling")
        }, prev: function (n) {
            return hr(n, "previousSibling")
        }, nextAll: function (n) {
            return i.dir(n, "nextSibling")
        }, prevAll: function (n) {
            return i.dir(n, "previousSibling")
        }, nextUntil: function (n, t, r) {
            return i.dir(n, "nextSibling", r)
        }, prevUntil: function (n, t, r) {
            return i.dir(n, "previousSibling", r)
        }, siblings: function (n) {
            return i.sibling((n.parentNode || {}).firstChild, n)
        }, children: function (n) {
            return i.sibling(n.firstChild)
        }, contents: function (n) {
            return i.nodeName(n, "iframe") ? n.contentDocument || n.contentWindow.document : i.merge([], n.childNodes)
        }
    }, function (n, t) {
        i.fn[n] = function (r, u) {
            var f = i.map(this, t, r);
            return "Until" !== n.slice(-5) && (u = r), u && "string" == typeof u && (f = i.filter(u, f)), this.length > 1 && (sr[n] || (f = i.unique(f)), or.test(n) && (f = f.reverse())), this.pushStack(f)
        }
    });
    h = /\S+/g;
    fi = {};
    i.Callbacks = function (n) {
        n = "string" == typeof n ? fi[n] || oe(n) : i.extend({}, n);
        var o, u, h, f, e, c, t = [], r = !n.once && [], l = function (i) {
            for (u = n.memory && i, h = !0, e = c || 0, c = 0, f = t.length, o = !0; t && f > e; e++)if (t[e].apply(i[0], i[1]) === !1 && n.stopOnFalse) {
                u = !1;
                break
            }
            o = !1;
            t && (r ? r.length && l(r.shift()) : u ? t = [] : s.disable())
        }, s = {
            add: function () {
                if (t) {
                    var r = t.length;
                    !function e(r) {
                        i.each(r, function (r, u) {
                            var f = i.type(u);
                            "function" === f ? n.unique && s.has(u) || t.push(u) : u && u.length && "string" !== f && e(u)
                        })
                    }(arguments);
                    o ? f = t.length : u && (c = r, l(u))
                }
                return this
            }, remove: function () {
                return t && i.each(arguments, function (n, r) {
                    for (var u; (u = i.inArray(r, t, u)) > -1;)t.splice(u, 1), o && (f >= u && f--, e >= u && e--)
                }), this
            }, has: function (n) {
                return n ? i.inArray(n, t) > -1 : !(!t || !t.length)
            }, empty: function () {
                return t = [], f = 0, this
            }, disable: function () {
                return t = r = u = void 0, this
            }, disabled: function () {
                return !t
            }, lock: function () {
                return r = void 0, u || s.disable(), this
            }, locked: function () {
                return !r
            }, fireWith: function (n, i) {
                return !t || h && !r || (i = i || [], i = [n, i.slice ? i.slice() : i], o ? r.push(i) : l(i)), this
            }, fire: function () {
                return s.fireWith(this, arguments), this
            }, fired: function () {
                return !!h
            }
        };
        return s
    };
    i.extend({
        Deferred: function (n) {
            var u = [["resolve", "done", i.Callbacks("once memory"), "resolved"], ["reject", "fail", i.Callbacks("once memory"), "rejected"], ["notify", "progress", i.Callbacks("memory")]], f = "pending", r = {
                state: function () {
                    return f
                }, always: function () {
                    return t.done(arguments).fail(arguments), this
                }, then: function () {
                    var n = arguments;
                    return i.Deferred(function (f) {
                        i.each(u, function (u, e) {
                            var o = i.isFunction(n[u]) && n[u];
                            t[e[1]](function () {
                                var n = o && o.apply(this, arguments);
                                n && i.isFunction(n.promise) ? n.promise().done(f.resolve).fail(f.reject).progress(f.notify) : f[e[0] + "With"](this === r ? f.promise() : this, o ? [n] : arguments)
                            })
                        });
                        n = null
                    }).promise()
                }, promise: function (n) {
                    return null != n ? i.extend(n, r) : r
                }
            }, t = {};
            return r.pipe = r.then, i.each(u, function (n, i) {
                var e = i[2], o = i[3];
                r[i[1]] = e.add;
                o && e.add(function () {
                    f = o
                }, u[1 ^ n][2].disable, u[2][2].lock);
                t[i[0]] = function () {
                    return t[i[0] + "With"](this === t ? r : this, arguments), this
                };
                t[i[0] + "With"] = e.fireWith
            }), r.promise(t), n && n.call(t, t), t
        }, when: function (n) {
            var t = 0, u = l.call(arguments), r = u.length, e = 1 !== r || n && i.isFunction(n.promise) ? r : 0, f = 1 === e ? n : i.Deferred(), h = function (n, t, i) {
                return function (r) {
                    t[n] = this;
                    i[n] = arguments.length > 1 ? l.call(arguments) : r;
                    i === o ? f.notifyWith(t, i) : --e || f.resolveWith(t, i)
                }
            }, o, c, s;
            if (r > 1)for (o = new Array(r), c = new Array(r), s = new Array(r); r > t; t++)u[t] && i.isFunction(u[t].promise) ? u[t].promise().done(h(t, s, u)).fail(f.reject).progress(h(t, c, o)) : --e;
            return e || f.resolveWith(s, u), f.promise()
        }
    });
    i.fn.ready = function (n) {
        return i.ready.promise().done(n), this
    };
    i.extend({
        isReady: !1, readyWait: 1, holdReady: function (n) {
            n ? i.readyWait++ : i.ready(!0)
        }, ready: function (n) {
            if (n === !0 ? !--i.readyWait : !i.isReady) {
                if (!u.body)return setTimeout(i.ready);
                i.isReady = !0;
                n !== !0 && --i.readyWait > 0 || (lt.resolveWith(u, [i]), i.fn.trigger && i(u).trigger("ready").off("ready"))
            }
        }
    });
    i.ready.promise = function (t) {
        if (!lt)if (lt = i.Deferred(), "complete" === u.readyState)setTimeout(i.ready); else if (u.addEventListener)u.addEventListener("DOMContentLoaded", a, !1), n.addEventListener("load", a, !1); else {
            u.attachEvent("onreadystatechange", a);
            n.attachEvent("onload", a);
            var r = !1;
            try {
                r = null == n.frameElement && u.documentElement
            } catch (e) {
            }
            r && r.doScroll && !function f() {
                if (!i.isReady) {
                    try {
                        r.doScroll("left")
                    } catch (n) {
                        return setTimeout(f, 50)
                    }
                    cr();
                    i.ready()
                }
            }()
        }
        return lt.promise(t)
    };
    o = "undefined";
    for (lr in i(r))break;
    r.ownLast = "0" !== lr;
    r.inlineBlockNeedsLayout = !1;
    i(function () {
        var t, n, i = u.getElementsByTagName("body")[0];
        i && (t = u.createElement("div"), t.style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px", n = u.createElement("div"), i.appendChild(t).appendChild(n), typeof n.style.zoom !== o && (n.style.cssText = "border:0;margin:0;width:1px;padding:1px;display:inline;zoom:1", (r.inlineBlockNeedsLayout = 3 === n.offsetWidth) && (i.style.zoom = 1)), i.removeChild(t), t = n = null)
    }), function () {
        var n = u.createElement("div");
        if (null == r.deleteExpando) {
            r.deleteExpando = !0;
            try {
                delete n.test
            } catch (t) {
                r.deleteExpando = !1
            }
        }
        n = null
    }();
    i.acceptData = function (n) {
        var t = i.noData[(n.nodeName + " ").toLowerCase()], r = +n.nodeType || 1;
        return 1 !== r && 9 !== r ? !1 : !t || t !== !0 && n.getAttribute("classid") === t
    };
    ar = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/;
    vr = /([A-Z])/g;
    i.extend({
        cache: {},
        noData: {"applet ": !0, "embed ": !0, "object ": "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"},
        hasData: function (n) {
            return n = n.nodeType ? i.cache[n[i.expando]] : n[i.expando], !!n && !ei(n)
        },
        data: function (n, t, i) {
            return pr(n, t, i)
        },
        removeData: function (n, t) {
            return wr(n, t)
        },
        _data: function (n, t, i) {
            return pr(n, t, i, !0)
        },
        _removeData: function (n, t) {
            return wr(n, t, !0)
        }
    });
    i.fn.extend({
        data: function (n, t) {
            var f, u, e, r = this[0], o = r && r.attributes;
            if (void 0 === n) {
                if (this.length && (e = i.data(r), 1 === r.nodeType && !i._data(r, "parsedAttrs"))) {
                    for (f = o.length; f--;)u = o[f].name, 0 === u.indexOf("data-") && (u = i.camelCase(u.slice(5)), yr(r, u, e[u]));
                    i._data(r, "parsedAttrs", !0)
                }
                return e
            }
            return "object" == typeof n ? this.each(function () {
                i.data(this, n)
            }) : arguments.length > 1 ? this.each(function () {
                i.data(this, n, t)
            }) : r ? yr(r, n, i.data(r, n)) : void 0
        }, removeData: function (n) {
            return this.each(function () {
                i.removeData(this, n)
            })
        }
    });
    i.extend({
        queue: function (n, t, r) {
            var u;
            if (n)return (t = (t || "fx") + "queue", u = i._data(n, t), r && (!u || i.isArray(r) ? u = i._data(n, t, i.makeArray(r)) : u.push(r)), u || [])
        }, dequeue: function (n, t) {
            t = t || "fx";
            var r = i.queue(n, t), e = r.length, u = r.shift(), f = i._queueHooks(n, t), o = function () {
                i.dequeue(n, t)
            };
            "inprogress" === u && (u = r.shift(), e--);
            u && ("fx" === t && r.unshift("inprogress"), delete f.stop, u.call(n, o, f));
            !e && f && f.empty.fire()
        }, _queueHooks: function (n, t) {
            var r = t + "queueHooks";
            return i._data(n, r) || i._data(n, r, {
                    empty: i.Callbacks("once memory").add(function () {
                        i._removeData(n, t + "queue");
                        i._removeData(n, r)
                    })
                })
        }
    });
    i.fn.extend({
        queue: function (n, t) {
            var r = 2;
            return "string" != typeof n && (t = n, n = "fx", r--), arguments.length < r ? i.queue(this[0], n) : void 0 === t ? this : this.each(function () {
                var r = i.queue(this, n, t);
                i._queueHooks(this, n);
                "fx" === n && "inprogress" !== r[0] && i.dequeue(this, n)
            })
        }, dequeue: function (n) {
            return this.each(function () {
                i.dequeue(this, n)
            })
        }, clearQueue: function (n) {
            return this.queue(n || "fx", [])
        }, promise: function (n, t) {
            var r, f = 1, e = i.Deferred(), u = this, o = this.length, s = function () {
                --f || e.resolveWith(u, [u])
            };
            for ("string" != typeof n && (t = n, n = void 0), n = n || "fx"; o--;)r = i._data(u[o], n + "queueHooks"), r && r.empty && (f++, r.empty.add(s));
            return s(), e.promise(t)
        }
    });
    var at = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source, w = ["Top", "Right", "Bottom", "Left"], et = function (n, t) {
        return n = t || n, "none" === i.css(n, "display") || !i.contains(n.ownerDocument, n)
    }, b = i.access = function (n, t, r, u, f, e, o) {
        var s = 0, c = n.length, h = null == r;
        if ("object" === i.type(r)) {
            f = !0;
            for (s in r)i.access(n, t, s, r[s], !0, e, o)
        } else if (void 0 !== u && (f = !0, i.isFunction(u) || (o = !0), h && (o ? (t.call(n, u), t = null) : (h = t, t = function (n, t, r) {
                return h.call(i(n), r)
            })), t))for (; c > s; s++)t(n[s], r, o ? u : u.call(n[s], s, t(n[s], r)));
        return f ? n : h ? t.call(n) : c ? t(n[0], r) : e
    }, oi = /^(?:checkbox|radio)$/i;
    !function () {
        var i = u.createDocumentFragment(), n = u.createElement("div"), t = u.createElement("input");
        if (n.setAttribute("className", "t"), n.innerHTML = "  <link/><table><\/table><a href='/a'>a<\/a>", r.leadingWhitespace = 3 === n.firstChild.nodeType, r.tbody = !n.getElementsByTagName("tbody").length, r.htmlSerialize = !!n.getElementsByTagName("link").length, r.html5Clone = "<:nav><\/:nav>" !== u.createElement("nav").cloneNode(!0).outerHTML, t.type = "checkbox", t.checked = !0, i.appendChild(t), r.appendChecked = t.checked, n.innerHTML = "<textarea>x<\/textarea>", r.noCloneChecked = !!n.cloneNode(!0).lastChild.defaultValue, i.appendChild(n), n.innerHTML = "<input type='radio' checked='checked' name='t'/>", r.checkClone = n.cloneNode(!0).cloneNode(!0).lastChild.checked, r.noCloneEvent = !0, n.attachEvent && (n.attachEvent("onclick", function () {
                r.noCloneEvent = !1
            }), n.cloneNode(!0).click()), null == r.deleteExpando) {
            r.deleteExpando = !0;
            try {
                delete n.test
            } catch (f) {
                r.deleteExpando = !1
            }
        }
        i = n = t = null
    }(), function () {
        var t, i, f = u.createElement("div");
        for (t in{
            submit: !0,
            change: !0,
            focusin: !0
        })i = "on" + t, (r[t + "Bubbles"] = i in n) || (f.setAttribute(i, "t"), r[t + "Bubbles"] = f.attributes[i].expando === !1);
        f = null
    }();
    var si = /^(?:input|select|textarea)$/i, se = /^key/, he = /^(?:mouse|contextmenu)|click/, br = /^(?:focusinfocus|focusoutblur)$/, kr = /^([^.]*)(?:\.(.+)|)$/;
    i.event = {
        global: {},
        add: function (n, t, r, u, f) {
            var w, y, b, p, s, c, l, a, e, k, d, v = i._data(n);
            if (v) {
                for (r.handler && (p = r, r = p.handler, f = p.selector), r.guid || (r.guid = i.guid++), (y = v.events) || (y = v.events = {}), (c = v.handle) || (c = v.handle = function (n) {
                    if (typeof i !== o && (!n || i.event.triggered !== n.type))return i.event.dispatch.apply(c.elem, arguments)
                }, c.elem = n), t = (t || "").match(h) || [""], b = t.length; b--;)w = kr.exec(t[b]) || [], e = d = w[1], k = (w[2] || "").split(".").sort(), e && (s = i.event.special[e] || {}, e = (f ? s.delegateType : s.bindType) || e, s = i.event.special[e] || {}, l = i.extend({
                    type: e,
                    origType: d,
                    data: u,
                    handler: r,
                    guid: r.guid,
                    selector: f,
                    needsContext: f && i.expr.match.needsContext.test(f),
                    namespace: k.join(".")
                }, p), (a = y[e]) || (a = y[e] = [], a.delegateCount = 0, s.setup && s.setup.call(n, u, k, c) !== !1 || (n.addEventListener ? n.addEventListener(e, c, !1) : n.attachEvent && n.attachEvent("on" + e, c))), s.add && (s.add.call(n, l), l.handler.guid || (l.handler.guid = r.guid)), f ? a.splice(a.delegateCount++, 0, l) : a.push(l), i.event.global[e] = !0);
                n = null
            }
        },
        remove: function (n, t, r, u, f) {
            var y, o, s, b, p, a, c, l, e, w, k, v = i.hasData(n) && i._data(n);
            if (v && (a = v.events)) {
                for (t = (t || "").match(h) || [""], p = t.length; p--;)if (s = kr.exec(t[p]) || [], e = k = s[1], w = (s[2] || "").split(".").sort(), e) {
                    for (c = i.event.special[e] || {}, e = (u ? c.delegateType : c.bindType) || e, l = a[e] || [], s = s[2] && new RegExp("(^|\\.)" + w.join("\\.(?:.*\\.|)") + "(\\.|$)"), b = y = l.length; y--;)o = l[y], !f && k !== o.origType || r && r.guid !== o.guid || s && !s.test(o.namespace) || u && u !== o.selector && ("**" !== u || !o.selector) || (l.splice(y, 1), o.selector && l.delegateCount--, c.remove && c.remove.call(n, o));
                    b && !l.length && (c.teardown && c.teardown.call(n, w, v.handle) !== !1 || i.removeEvent(n, e, v.handle), delete a[e])
                } else for (e in a)i.event.remove(n, e + t[p], r, u, !0);
                i.isEmptyObject(a) && (delete v.handle, i._removeData(n, "events"))
            }
        },
        trigger: function (t, r, f, e) {
            var l, a, o, p, c, h, w, y = [f || u], s = tt.call(t, "type") ? t.type : t, v = tt.call(t, "namespace") ? t.namespace.split(".") : [];
            if (o = h = f = f || u, 3 !== f.nodeType && 8 !== f.nodeType && !br.test(s + i.event.triggered) && (s.indexOf(".") >= 0 && (v = s.split("."), s = v.shift(), v.sort()), a = s.indexOf(":") < 0 && "on" + s, t = t[i.expando] ? t : new i.Event(s, "object" == typeof t && t), t.isTrigger = e ? 2 : 3, t.namespace = v.join("."), t.namespace_re = t.namespace ? new RegExp("(^|\\.)" + v.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, t.result = void 0, t.target || (t.target = f), r = null == r ? [t] : i.makeArray(r, [t]), c = i.event.special[s] || {}, e || !c.trigger || c.trigger.apply(f, r) !== !1)) {
                if (!e && !c.noBubble && !i.isWindow(f)) {
                    for (p = c.delegateType || s, br.test(p + s) || (o = o.parentNode); o; o = o.parentNode)y.push(o), h = o;
                    h === (f.ownerDocument || u) && y.push(h.defaultView || h.parentWindow || n)
                }
                for (w = 0; (o = y[w++]) && !t.isPropagationStopped();)t.type = w > 1 ? p : c.bindType || s, l = (i._data(o, "events") || {})[t.type] && i._data(o, "handle"), l && l.apply(o, r), l = a && o[a], l && l.apply && i.acceptData(o) && (t.result = l.apply(o, r), t.result === !1 && t.preventDefault());
                if (t.type = s, !e && !t.isDefaultPrevented() && (!c._default || c._default.apply(y.pop(), r) === !1) && i.acceptData(f) && a && f[s] && !i.isWindow(f)) {
                    h = f[a];
                    h && (f[a] = null);
                    i.event.triggered = s;
                    try {
                        f[s]()
                    } catch (b) {
                    }
                    i.event.triggered = void 0;
                    h && (f[a] = h)
                }
                return t.result
            }
        },
        dispatch: function (n) {
            n = i.event.fix(n);
            var e, f, t, r, o, s = [], h = l.call(arguments), c = (i._data(this, "events") || {})[n.type] || [], u = i.event.special[n.type] || {};
            if (h[0] = n, n.delegateTarget = this, !u.preDispatch || u.preDispatch.call(this, n) !== !1) {
                for (s = i.event.handlers.call(this, n, c), e = 0; (r = s[e++]) && !n.isPropagationStopped();)for (n.currentTarget = r.elem, o = 0; (t = r.handlers[o++]) && !n.isImmediatePropagationStopped();)(!n.namespace_re || n.namespace_re.test(t.namespace)) && (n.handleObj = t, n.data = t.data, f = ((i.event.special[t.origType] || {}).handle || t.handler).apply(r.elem, h), void 0 !== f && (n.result = f) === !1 && (n.preventDefault(), n.stopPropagation()));
                return u.postDispatch && u.postDispatch.call(this, n), n.result
            }
        },
        handlers: function (n, t) {
            var f, e, u, o, h = [], s = t.delegateCount, r = n.target;
            if (s && r.nodeType && (!n.button || "click" !== n.type))for (; r != this; r = r.parentNode || this)if (1 === r.nodeType && (r.disabled !== !0 || "click" !== n.type)) {
                for (u = [], o = 0; s > o; o++)e = t[o], f = e.selector + " ", void 0 === u[f] && (u[f] = e.needsContext ? i(f, this).index(r) >= 0 : i.find(f, this, null, [r]).length), u[f] && u.push(e);
                u.length && h.push({elem: r, handlers: u})
            }
            return s < t.length && h.push({elem: this, handlers: t.slice(s)}), h
        },
        fix: function (n) {
            if (n[i.expando])return n;
            var e, o, s, r = n.type, f = n, t = this.fixHooks[r];
            for (t || (this.fixHooks[r] = t = he.test(r) ? this.mouseHooks : se.test(r) ? this.keyHooks : {}), s = t.props ? this.props.concat(t.props) : this.props, n = new i.Event(f), e = s.length; e--;)o = s[e], n[o] = f[o];
            return n.target || (n.target = f.srcElement || u), 3 === n.target.nodeType && (n.target = n.target.parentNode), n.metaKey = !!n.metaKey, t.filter ? t.filter(n, f) : n
        },
        props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
        fixHooks: {},
        keyHooks: {
            props: "char charCode key keyCode".split(" "), filter: function (n, t) {
                return null == n.which && (n.which = null != t.charCode ? t.charCode : t.keyCode), n
            }
        },
        mouseHooks: {
            props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
            filter: function (n, t) {
                var i, e, r, f = t.button, o = t.fromElement;
                return null == n.pageX && null != t.clientX && (e = n.target.ownerDocument || u, r = e.documentElement, i = e.body, n.pageX = t.clientX + (r && r.scrollLeft || i && i.scrollLeft || 0) - (r && r.clientLeft || i && i.clientLeft || 0), n.pageY = t.clientY + (r && r.scrollTop || i && i.scrollTop || 0) - (r && r.clientTop || i && i.clientTop || 0)), !n.relatedTarget && o && (n.relatedTarget = o === n.target ? t.toElement : o), n.which || void 0 === f || (n.which = 1 & f ? 1 : 2 & f ? 3 : 4 & f ? 2 : 0), n
            }
        },
        special: {
            load: {noBubble: !0}, focus: {
                trigger: function () {
                    if (this !== dr() && this.focus)try {
                        return this.focus(), !1
                    } catch (n) {
                    }
                }, delegateType: "focusin"
            }, blur: {
                trigger: function () {
                    if (this === dr() && this.blur)return (this.blur(), !1)
                }, delegateType: "focusout"
            }, click: {
                trigger: function () {
                    if (i.nodeName(this, "input") && "checkbox" === this.type && this.click)return (this.click(), !1)
                }, _default: function (n) {
                    return i.nodeName(n.target, "a")
                }
            }, beforeunload: {
                postDispatch: function (n) {
                    void 0 !== n.result && (n.originalEvent.returnValue = n.result)
                }
            }
        },
        simulate: function (n, t, r, u) {
            var f = i.extend(new i.Event, r, {type: n, isSimulated: !0, originalEvent: {}});
            u ? i.event.trigger(f, null, t) : i.event.dispatch.call(t, f);
            f.isDefaultPrevented() && r.preventDefault()
        }
    };
    i.removeEvent = u.removeEventListener ? function (n, t, i) {
        n.removeEventListener && n.removeEventListener(t, i, !1)
    } : function (n, t, i) {
        var r = "on" + t;
        n.detachEvent && (typeof n[r] === o && (n[r] = null), n.detachEvent(r, i))
    };
    i.Event = function (n, t) {
        return this instanceof i.Event ? (n && n.type ? (this.originalEvent = n, this.type = n.type, this.isDefaultPrevented = n.defaultPrevented || void 0 === n.defaultPrevented && (n.returnValue === !1 || n.getPreventDefault && n.getPreventDefault()) ? vt : it) : this.type = n, t && i.extend(this, t), this.timeStamp = n && n.timeStamp || i.now(), void(this[i.expando] = !0)) : new i.Event(n, t)
    };
    i.Event.prototype = {
        isDefaultPrevented: it,
        isPropagationStopped: it,
        isImmediatePropagationStopped: it,
        preventDefault: function () {
            var n = this.originalEvent;
            this.isDefaultPrevented = vt;
            n && (n.preventDefault ? n.preventDefault() : n.returnValue = !1)
        },
        stopPropagation: function () {
            var n = this.originalEvent;
            this.isPropagationStopped = vt;
            n && (n.stopPropagation && n.stopPropagation(), n.cancelBubble = !0)
        },
        stopImmediatePropagation: function () {
            this.isImmediatePropagationStopped = vt;
            this.stopPropagation()
        }
    };
    i.each({mouseenter: "mouseover", mouseleave: "mouseout"}, function (n, t) {
        i.event.special[n] = {
            delegateType: t, bindType: t, handle: function (n) {
                var u, f = this, r = n.relatedTarget, e = n.handleObj;
                return (!r || r !== f && !i.contains(f, r)) && (n.type = e.origType, u = e.handler.apply(this, arguments), n.type = t), u
            }
        }
    });
    r.submitBubbles || (i.event.special.submit = {
        setup: function () {
            return i.nodeName(this, "form") ? !1 : void i.event.add(this, "click._submit keypress._submit", function (n) {
                var r = n.target, t = i.nodeName(r, "input") || i.nodeName(r, "button") ? r.form : void 0;
                t && !i._data(t, "submitBubbles") && (i.event.add(t, "submit._submit", function (n) {
                    n._submit_bubble = !0
                }), i._data(t, "submitBubbles", !0))
            })
        }, postDispatch: function (n) {
            n._submit_bubble && (delete n._submit_bubble, this.parentNode && !n.isTrigger && i.event.simulate("submit", this.parentNode, n, !0))
        }, teardown: function () {
            return i.nodeName(this, "form") ? !1 : void i.event.remove(this, "._submit")
        }
    });
    r.changeBubbles || (i.event.special.change = {
        setup: function () {
            return si.test(this.nodeName) ? (("checkbox" === this.type || "radio" === this.type) && (i.event.add(this, "propertychange._change", function (n) {
                "checked" === n.originalEvent.propertyName && (this._just_changed = !0)
            }), i.event.add(this, "click._change", function (n) {
                this._just_changed && !n.isTrigger && (this._just_changed = !1);
                i.event.simulate("change", this, n, !0)
            })), !1) : void i.event.add(this, "beforeactivate._change", function (n) {
                var t = n.target;
                si.test(t.nodeName) && !i._data(t, "changeBubbles") && (i.event.add(t, "change._change", function (n) {
                    !this.parentNode || n.isSimulated || n.isTrigger || i.event.simulate("change", this.parentNode, n, !0)
                }), i._data(t, "changeBubbles", !0))
            })
        }, handle: function (n) {
            var t = n.target;
            if (this !== t || n.isSimulated || n.isTrigger || "radio" !== t.type && "checkbox" !== t.type)return n.handleObj.handler.apply(this, arguments)
        }, teardown: function () {
            return i.event.remove(this, "._change"), !si.test(this.nodeName)
        }
    });
    r.focusinBubbles || i.each({focus: "focusin", blur: "focusout"}, function (n, t) {
        var r = function (n) {
            i.event.simulate(t, n.target, i.event.fix(n), !0)
        };
        i.event.special[t] = {
            setup: function () {
                var u = this.ownerDocument || this, f = i._data(u, t);
                f || u.addEventListener(n, r, !0);
                i._data(u, t, (f || 0) + 1)
            }, teardown: function () {
                var u = this.ownerDocument || this, f = i._data(u, t) - 1;
                f ? i._data(u, t, f) : (u.removeEventListener(n, r, !0), i._removeData(u, t))
            }
        }
    });
    i.fn.extend({
        on: function (n, t, r, u, f) {
            var o, e;
            if ("object" == typeof n) {
                "string" != typeof t && (r = r || t, t = void 0);
                for (o in n)this.on(o, t, r, n[o], f);
                return this
            }
            if (null == r && null == u ? (u = t, r = t = void 0) : null == u && ("string" == typeof t ? (u = r, r = void 0) : (u = r, r = t, t = void 0)), u === !1)u = it; else if (!u)return this;
            return 1 === f && (e = u, u = function (n) {
                return i().off(n), e.apply(this, arguments)
            }, u.guid = e.guid || (e.guid = i.guid++)), this.each(function () {
                i.event.add(this, n, u, r, t)
            })
        }, one: function (n, t, i, r) {
            return this.on(n, t, i, r, 1)
        }, off: function (n, t, r) {
            var u, f;
            if (n && n.preventDefault && n.handleObj)return u = n.handleObj, i(n.delegateTarget).off(u.namespace ? u.origType + "." + u.namespace : u.origType, u.selector, u.handler), this;
            if ("object" == typeof n) {
                for (f in n)this.off(f, t, n[f]);
                return this
            }
            return (t === !1 || "function" == typeof t) && (r = t, t = void 0), r === !1 && (r = it), this.each(function () {
                i.event.remove(this, n, r, t)
            })
        }, trigger: function (n, t) {
            return this.each(function () {
                i.event.trigger(n, t, this)
            })
        }, triggerHandler: function (n, t) {
            var r = this[0];
            if (r)return i.event.trigger(n, t, r, !0)
        }
    });
    var nu = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video", ce = / jQuery\d+="(?:null|\d+)"/g, tu = new RegExp("<(?:" + nu + ")[\\s/>]", "i"), hi = /^\s+/, iu = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi, ru = /<([\w:]+)/, uu = /<tbody/i, le = /<|&#?\w+;/, ae = /<(?:script|style|link)/i, ve = /checked\s*(?:[^=]|=\s*.checked.)/i, fu = /^$|\/(?:java|ecma)script/i, ye = /^true\/(.*)/, pe = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g, s = {
        option: [1, "<select multiple='multiple'>", "<\/select>"],
        legend: [1, "<fieldset>", "<\/fieldset>"],
        area: [1, "<map>", "<\/map>"],
        param: [1, "<object>", "<\/object>"],
        thead: [1, "<table>", "<\/table>"],
        tr: [2, "<table><tbody>", "<\/tbody><\/table>"],
        col: [2, "<table><tbody><\/tbody><colgroup>", "<\/colgroup><\/table>"],
        td: [3, "<table><tbody><tr>", "<\/tr><\/tbody><\/table>"],
        _default: r.htmlSerialize ? [0, "", ""] : [1, "X<div>", "<\/div>"]
    }, we = gr(u), ci = we.appendChild(u.createElement("div"));
    s.optgroup = s.option;
    s.tbody = s.tfoot = s.colgroup = s.caption = s.thead;
    s.th = s.td;
    i.extend({
        clone: function (n, t, u) {
            var e, c, s, o, h, l = i.contains(n.ownerDocument, n);
            if (r.html5Clone || i.isXMLDoc(n) || !tu.test("<" + n.nodeName + ">") ? s = n.cloneNode(!0) : (ci.innerHTML = n.outerHTML, ci.removeChild(s = ci.firstChild)), !(r.noCloneEvent && r.noCloneChecked || 1 !== n.nodeType && 11 !== n.nodeType || i.isXMLDoc(n)))for (e = f(s), h = f(n), o = 0; null != (c = h[o]); ++o)e[o] && ke(c, e[o]);
            if (t)if (u)for (h = h || f(n), e = e || f(s), o = 0; null != (c = h[o]); o++)hu(c, e[o]); else hu(n, s);
            return e = f(s, "script"), e.length > 0 && li(e, !l && f(n, "script")), e = h = c = null, s
        }, buildFragment: function (n, t, u, e) {
            for (var c, o, b, h, p, w, a, k = n.length, v = gr(t), l = [], y = 0; k > y; y++)if (o = n[y], o || 0 === o)if ("object" === i.type(o))i.merge(l, o.nodeType ? [o] : o); else if (le.test(o)) {
                for (h = h || v.appendChild(t.createElement("div")), p = (ru.exec(o) || ["", ""])[1].toLowerCase(), a = s[p] || s._default, h.innerHTML = a[1] + o.replace(iu, "<$1><\/$2>") + a[2], c = a[0]; c--;)h = h.lastChild;
                if (!r.leadingWhitespace && hi.test(o) && l.push(t.createTextNode(hi.exec(o)[0])), !r.tbody)for (o = "table" !== p || uu.test(o) ? "<table>" !== a[1] || uu.test(o) ? 0 : h : h.firstChild, c = o && o.childNodes.length; c--;)i.nodeName(w = o.childNodes[c], "tbody") && !w.childNodes.length && o.removeChild(w);
                for (i.merge(l, h.childNodes), h.textContent = ""; h.firstChild;)h.removeChild(h.firstChild);
                h = v.lastChild
            } else l.push(t.createTextNode(o));
            for (h && v.removeChild(h), r.appendChecked || i.grep(f(l, "input"), be), y = 0; o = l[y++];)if ((!e || -1 === i.inArray(o, e)) && (b = i.contains(o.ownerDocument, o), h = f(v.appendChild(o), "script"), b && li(h), u))for (c = 0; o = h[c++];)fu.test(o.type || "") && u.push(o);
            return h = null, v
        }, cleanData: function (n, t) {
            for (var u, e, f, s, a = 0, h = i.expando, l = i.cache, v = r.deleteExpando, y = i.event.special; null != (u = n[a]); a++)if ((t || i.acceptData(u)) && (f = u[h], s = f && l[f])) {
                if (s.events)for (e in s.events)y[e] ? i.event.remove(u, e) : i.removeEvent(u, e, s.handle);
                l[f] && (delete l[f], v ? delete u[h] : typeof u.removeAttribute !== o ? u.removeAttribute(h) : u[h] = null, c.push(f))
            }
        }
    });
    i.fn.extend({
        text: function (n) {
            return b(this, function (n) {
                return void 0 === n ? i.text(this) : this.empty().append((this[0] && this[0].ownerDocument || u).createTextNode(n))
            }, null, n, arguments.length)
        }, append: function () {
            return this.domManip(arguments, function (n) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var t = eu(this, n);
                    t.appendChild(n)
                }
            })
        }, prepend: function () {
            return this.domManip(arguments, function (n) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var t = eu(this, n);
                    t.insertBefore(n, t.firstChild)
                }
            })
        }, before: function () {
            return this.domManip(arguments, function (n) {
                this.parentNode && this.parentNode.insertBefore(n, this)
            })
        }, after: function () {
            return this.domManip(arguments, function (n) {
                this.parentNode && this.parentNode.insertBefore(n, this.nextSibling)
            })
        }, remove: function (n, t) {
            for (var r, e = n ? i.filter(n, this) : this, u = 0; null != (r = e[u]); u++)t || 1 !== r.nodeType || i.cleanData(f(r)), r.parentNode && (t && i.contains(r.ownerDocument, r) && li(f(r, "script")), r.parentNode.removeChild(r));
            return this
        }, empty: function () {
            for (var n, t = 0; null != (n = this[t]); t++) {
                for (1 === n.nodeType && i.cleanData(f(n, !1)); n.firstChild;)n.removeChild(n.firstChild);
                n.options && i.nodeName(n, "select") && (n.options.length = 0)
            }
            return this
        }, clone: function (n, t) {
            return n = null == n ? !1 : n, t = null == t ? n : t, this.map(function () {
                return i.clone(this, n, t)
            })
        }, html: function (n) {
            return b(this, function (n) {
                var t = this[0] || {}, u = 0, e = this.length;
                if (void 0 === n)return 1 === t.nodeType ? t.innerHTML.replace(ce, "") : void 0;
                if (!("string" != typeof n || ae.test(n) || !r.htmlSerialize && tu.test(n) || !r.leadingWhitespace && hi.test(n) || s[(ru.exec(n) || ["", ""])[1].toLowerCase()])) {
                    n = n.replace(iu, "<$1><\/$2>");
                    try {
                        for (; e > u; u++)t = this[u] || {}, 1 === t.nodeType && (i.cleanData(f(t, !1)), t.innerHTML = n);
                        t = 0
                    } catch (o) {
                    }
                }
                t && this.empty().append(n)
            }, null, n, arguments.length)
        }, replaceWith: function () {
            var n = arguments[0];
            return this.domManip(arguments, function (t) {
                n = this.parentNode;
                i.cleanData(f(this));
                n && n.replaceChild(t, this)
            }), n && (n.length || n.nodeType) ? this : this.remove()
        }, detach: function (n) {
            return this.remove(n, !0)
        }, domManip: function (n, t) {
            n = ir.apply([], n);
            var h, u, c, o, v, s, e = 0, l = this.length, p = this, w = l - 1, a = n[0], y = i.isFunction(a);
            if (y || l > 1 && "string" == typeof a && !r.checkClone && ve.test(a))return this.each(function (i) {
                var r = p.eq(i);
                y && (n[0] = a.call(this, i, r.html()));
                r.domManip(n, t)
            });
            if (l && (s = i.buildFragment(n, this[0].ownerDocument, !1, this), h = s.firstChild, 1 === s.childNodes.length && (s = h), h)) {
                for (o = i.map(f(s, "script"), ou), c = o.length; l > e; e++)u = s, e !== w && (u = i.clone(u, !0, !0), c && i.merge(o, f(u, "script"))), t.call(this[e], u, e);
                if (c)for (v = o[o.length - 1].ownerDocument, i.map(o, su), e = 0; c > e; e++)u = o[e], fu.test(u.type || "") && !i._data(u, "globalEval") && i.contains(v, u) && (u.src ? i._evalUrl && i._evalUrl(u.src) : i.globalEval((u.text || u.textContent || u.innerHTML || "").replace(pe, "")));
                s = h = null
            }
            return this
        }
    });
    i.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function (n, t) {
        i.fn[n] = function (n) {
            for (var u, r = 0, f = [], e = i(n), o = e.length - 1; o >= r; r++)u = r === o ? this : this.clone(!0), i(e[r])[t](u), ti.apply(f, u.get());
            return this.pushStack(f)
        }
    });
    ai = {};
    !function () {
        var t, i, n = u.createElement("div"), f = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;padding:0;margin:0;border:0";
        n.innerHTML = "  <link/><table><\/table><a href='/a'>a<\/a><input type='checkbox'/>";
        t = n.getElementsByTagName("a")[0];
        t.style.cssText = "float:left;opacity:.5";
        r.opacity = /^0.5/.test(t.style.opacity);
        r.cssFloat = !!t.style.cssFloat;
        n.style.backgroundClip = "content-box";
        n.cloneNode(!0).style.backgroundClip = "";
        r.clearCloneStyle = "content-box" === n.style.backgroundClip;
        t = n = null;
        r.shrinkWrapBlocks = function () {
            var t, r, n, e;
            if (null == i) {
                if (t = u.getElementsByTagName("body")[0], !t)return;
                e = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px";
                r = u.createElement("div");
                n = u.createElement("div");
                t.appendChild(r).appendChild(n);
                i = !1;
                typeof n.style.zoom !== o && (n.style.cssText = f + ";width:1px;padding:1px;zoom:1", n.innerHTML = "<div><\/div>", n.firstChild.style.width = "5px", i = 3 !== n.offsetWidth);
                t.removeChild(r);
                t = r = n = null
            }
            return i
        }
    }();
    var au = /^margin/, yt = new RegExp("^(" + at + ")(?!px)[a-z%]+$", "i"), k, d, de = /^(top|right|bottom|left)$/;
    n.getComputedStyle ? (k = function (n) {
        return n.ownerDocument.defaultView.getComputedStyle(n, null)
    }, d = function (n, t, r) {
        var e, o, s, u, f = n.style;
        return r = r || k(n), u = r ? r.getPropertyValue(t) || r[t] : void 0, r && ("" !== u || i.contains(n.ownerDocument, n) || (u = i.style(n, t)), yt.test(u) && au.test(t) && (e = f.width, o = f.minWidth, s = f.maxWidth, f.minWidth = f.maxWidth = f.width = u, u = r.width, f.width = e, f.minWidth = o, f.maxWidth = s)), void 0 === u ? u : u + ""
    }) : u.documentElement.currentStyle && (k = function (n) {
        return n.currentStyle
    }, d = function (n, t, i) {
        var o, f, e, r, u = n.style;
        return i = i || k(n), r = i ? i[t] : void 0, null == r && u && u[t] && (r = u[t]), yt.test(r) && !de.test(t) && (o = u.left, f = n.runtimeStyle, e = f && f.left, e && (f.left = n.currentStyle.left), u.left = "fontSize" === t ? "1em" : r, r = u.pixelLeft + "px", u.left = o, e && (f.left = e)), void 0 === r ? r : r + "" || "auto"
    });
    !function () {
        function a() {
            var f, t, r = u.getElementsByTagName("body")[0];
            r && (f = u.createElement("div"), t = u.createElement("div"), f.style.cssText = l, r.appendChild(f).appendChild(t), t.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;position:absolute;display:block;padding:1px;border:1px;width:4px;margin-top:1%;top:1%", i.swap(r, null != r.style.zoom ? {zoom: 1} : {}, function () {
                c = 4 === t.offsetWidth
            }), o = !0, s = !1, h = !0, n.getComputedStyle && (s = "1%" !== (n.getComputedStyle(t, null) || {}).top, o = "4px" === (n.getComputedStyle(t, null) || {width: "4px"}).width), r.removeChild(f), t = r = null)
        }

        var f, e, c, o, s, h, t = u.createElement("div"), l = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px", v = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;padding:0;margin:0;border:0";
        t.innerHTML = "  <link/><table><\/table><a href='/a'>a<\/a><input type='checkbox'/>";
        f = t.getElementsByTagName("a")[0];
        f.style.cssText = "float:left;opacity:.5";
        r.opacity = /^0.5/.test(f.style.opacity);
        r.cssFloat = !!f.style.cssFloat;
        t.style.backgroundClip = "content-box";
        t.cloneNode(!0).style.backgroundClip = "";
        r.clearCloneStyle = "content-box" === t.style.backgroundClip;
        f = t = null;
        i.extend(r, {
            reliableHiddenOffsets: function () {
                if (null != e)return e;
                var i, n, f, t = u.createElement("div"), r = u.getElementsByTagName("body")[0];
                if (r)return t.setAttribute("className", "t"), t.innerHTML = "  <link/><table><\/table><a href='/a'>a<\/a><input type='checkbox'/>", i = u.createElement("div"), i.style.cssText = l, r.appendChild(i).appendChild(t), t.innerHTML = "<table><tr><td><\/td><td>t<\/td><\/tr><\/table>", n = t.getElementsByTagName("td"), n[0].style.cssText = "padding:0;margin:0;border:0;display:none", f = 0 === n[0].offsetHeight, n[0].style.display = "", n[1].style.display = "none", e = f && 0 === n[0].offsetHeight, r.removeChild(i), t = r = null, e
            }, boxSizing: function () {
                return null == c && a(), c
            }, boxSizingReliable: function () {
                return null == o && a(), o
            }, pixelPosition: function () {
                return null == s && a(), s
            }, reliableMarginRight: function () {
                var r, f, t, i;
                if (null == h && n.getComputedStyle) {
                    if (r = u.getElementsByTagName("body")[0], !r)return;
                    f = u.createElement("div");
                    t = u.createElement("div");
                    f.style.cssText = l;
                    r.appendChild(f).appendChild(t);
                    i = t.appendChild(u.createElement("div"));
                    i.style.cssText = t.style.cssText = v;
                    i.style.marginRight = i.style.width = "0";
                    t.style.width = "1px";
                    h = !parseFloat((n.getComputedStyle(i, null) || {}).marginRight);
                    r.removeChild(f)
                }
                return h
            }
        })
    }();
    i.swap = function (n, t, i, r) {
        var f, u, e = {};
        for (u in t)e[u] = n.style[u], n.style[u] = t[u];
        f = i.apply(n, r || []);
        for (u in t)n.style[u] = e[u];
        return f
    };
    var vi = /alpha\([^)]*\)/i, ge = /opacity\s*=\s*([^)]*)/, no = /^(none|table(?!-c[ea]).+)/, to = new RegExp("^(" + at + ")(.*)$", "i"), io = new RegExp("^([+-])=(" + at + ")", "i"), ro = {
        position: "absolute",
        visibility: "hidden",
        display: "block"
    }, yu = {letterSpacing: 0, fontWeight: 400}, pu = ["Webkit", "O", "Moz", "ms"];
    i.extend({
        cssHooks: {
            opacity: {
                get: function (n, t) {
                    if (t) {
                        var i = d(n, "opacity");
                        return "" === i ? "1" : i
                    }
                }
            }
        },
        cssNumber: {
            columnCount: !0,
            fillOpacity: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {float: r.cssFloat ? "cssFloat" : "styleFloat"},
        style: function (n, t, u, f) {
            if (n && 3 !== n.nodeType && 8 !== n.nodeType && n.style) {
                var o, c, e, s = i.camelCase(t), h = n.style;
                if (t = i.cssProps[s] || (i.cssProps[s] = wu(h, s)), e = i.cssHooks[t] || i.cssHooks[s], void 0 === u)return e && "get" in e && void 0 !== (o = e.get(n, !1, f)) ? o : h[t];
                if (c = typeof u, "string" === c && (o = io.exec(u)) && (u = (o[1] + 1) * o[2] + parseFloat(i.css(n, t)), c = "number"), null != u && u === u && ("number" !== c || i.cssNumber[s] || (u += "px"), r.clearCloneStyle || "" !== u || 0 !== t.indexOf("background") || (h[t] = "inherit"), !(e && "set" in e && void 0 === (u = e.set(n, u, f)))))try {
                    h[t] = "";
                    h[t] = u
                } catch (l) {
                }
            }
        },
        css: function (n, t, r, u) {
            var s, f, e, o = i.camelCase(t);
            return t = i.cssProps[o] || (i.cssProps[o] = wu(n.style, o)), e = i.cssHooks[t] || i.cssHooks[o], e && "get" in e && (f = e.get(n, !0, r)), void 0 === f && (f = d(n, t, u)), "normal" === f && t in yu && (f = yu[t]), "" === r || r ? (s = parseFloat(f), r === !0 || i.isNumeric(s) ? s || 0 : f) : f
        }
    });
    i.each(["height", "width"], function (n, t) {
        i.cssHooks[t] = {
            get: function (n, r, u) {
                if (r)return 0 === n.offsetWidth && no.test(i.css(n, "display")) ? i.swap(n, ro, function () {
                    return gu(n, t, u)
                }) : gu(n, t, u)
            }, set: function (n, u, f) {
                var e = f && k(n);
                return ku(n, u, f ? du(n, t, f, r.boxSizing() && "border-box" === i.css(n, "boxSizing", !1, e), e) : 0)
            }
        }
    });
    r.opacity || (i.cssHooks.opacity = {
        get: function (n, t) {
            return ge.test((t && n.currentStyle ? n.currentStyle.filter : n.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : t ? "1" : ""
        }, set: function (n, t) {
            var r = n.style, u = n.currentStyle, e = i.isNumeric(t) ? "alpha(opacity=" + 100 * t + ")" : "", f = u && u.filter || r.filter || "";
            r.zoom = 1;
            (t >= 1 || "" === t) && "" === i.trim(f.replace(vi, "")) && r.removeAttribute && (r.removeAttribute("filter"), "" === t || u && !u.filter) || (r.filter = vi.test(f) ? f.replace(vi, e) : f + " " + e)
        }
    });
    i.cssHooks.marginRight = vu(r.reliableMarginRight, function (n, t) {
        if (t)return i.swap(n, {display: "inline-block"}, d, [n, "marginRight"])
    });
    i.each({margin: "", padding: "", border: "Width"}, function (n, t) {
        i.cssHooks[n + t] = {
            expand: function (i) {
                for (var r = 0, f = {}, u = "string" == typeof i ? i.split(" ") : [i]; 4 > r; r++)f[n + w[r] + t] = u[r] || u[r - 2] || u[0];
                return f
            }
        };
        au.test(n) || (i.cssHooks[n + t].set = ku)
    });
    i.fn.extend({
        css: function (n, t) {
            return b(this, function (n, t, r) {
                var f, e, o = {}, u = 0;
                if (i.isArray(t)) {
                    for (f = k(n), e = t.length; e > u; u++)o[t[u]] = i.css(n, t[u], !1, f);
                    return o
                }
                return void 0 !== r ? i.style(n, t, r) : i.css(n, t)
            }, n, t, arguments.length > 1)
        }, show: function () {
            return bu(this, !0)
        }, hide: function () {
            return bu(this)
        }, toggle: function (n) {
            return "boolean" == typeof n ? n ? this.show() : this.hide() : this.each(function () {
                et(this) ? i(this).show() : i(this).hide()
            })
        }
    });
    i.Tween = e;
    e.prototype = {
        constructor: e, init: function (n, t, r, u, f, e) {
            this.elem = n;
            this.prop = r;
            this.easing = f || "swing";
            this.options = t;
            this.start = this.now = this.cur();
            this.end = u;
            this.unit = e || (i.cssNumber[r] ? "" : "px")
        }, cur: function () {
            var n = e.propHooks[this.prop];
            return n && n.get ? n.get(this) : e.propHooks._default.get(this)
        }, run: function (n) {
            var r, t = e.propHooks[this.prop];
            return this.pos = r = this.options.duration ? i.easing[this.easing](n, this.options.duration * n, 0, 1, this.options.duration) : n, this.now = (this.end - this.start) * r + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), t && t.set ? t.set(this) : e.propHooks._default.set(this), this
        }
    };
    e.prototype.init.prototype = e.prototype;
    e.propHooks = {
        _default: {
            get: function (n) {
                var t;
                return null == n.elem[n.prop] || n.elem.style && null != n.elem.style[n.prop] ? (t = i.css(n.elem, n.prop, ""), t && "auto" !== t ? t : 0) : n.elem[n.prop]
            }, set: function (n) {
                i.fx.step[n.prop] ? i.fx.step[n.prop](n) : n.elem.style && (null != n.elem.style[i.cssProps[n.prop]] || i.cssHooks[n.prop]) ? i.style(n.elem, n.prop, n.now + n.unit) : n.elem[n.prop] = n.now
            }
        }
    };
    e.propHooks.scrollTop = e.propHooks.scrollLeft = {
        set: function (n) {
            n.elem.nodeType && n.elem.parentNode && (n.elem[n.prop] = n.now)
        }
    };
    i.easing = {
        linear: function (n) {
            return n
        }, swing: function (n) {
            return .5 - Math.cos(n * Math.PI) / 2
        }
    };
    i.fx = e.prototype.init;
    i.fx.step = {};
    var rt, pt, uo = /^(?:toggle|show|hide)$/, nf = new RegExp("^(?:([+-])=|)(" + at + ")([a-z%]*)$", "i"), fo = /queueHooks$/, wt = [eo], st = {
        "*": [function (n, t) {
            var f = this.createTween(n, t), s = f.cur(), r = nf.exec(t), e = r && r[3] || (i.cssNumber[n] ? "" : "px"), u = (i.cssNumber[n] || "px" !== e && +s) && nf.exec(i.css(f.elem, n)), o = 1, h = 20;
            if (u && u[3] !== e) {
                e = e || u[3];
                r = r || [];
                u = +s || 1;
                do o = o || ".5", u /= o, i.style(f.elem, n, u + e); while (o !== (o = f.cur() / s) && 1 !== o && --h)
            }
            return r && (u = f.start = +u || +s || 0, f.unit = e, f.end = r[1] ? u + (r[1] + 1) * r[2] : +r[2]), f
        }]
    };
    i.Animation = i.extend(uf, {
        tweener: function (n, t) {
            i.isFunction(n) ? (t = n, n = ["*"]) : n = n.split(" ");
            for (var r, u = 0, f = n.length; f > u; u++)r = n[u], st[r] = st[r] || [], st[r].unshift(t)
        }, prefilter: function (n, t) {
            t ? wt.unshift(n) : wt.push(n)
        }
    });
    i.speed = function (n, t, r) {
        var u = n && "object" == typeof n ? i.extend({}, n) : {
            complete: r || !r && t || i.isFunction(n) && n,
            duration: n,
            easing: r && t || t && !i.isFunction(t) && t
        };
        return u.duration = i.fx.off ? 0 : "number" == typeof u.duration ? u.duration : u.duration in i.fx.speeds ? i.fx.speeds[u.duration] : i.fx.speeds._default, (null == u.queue || u.queue === !0) && (u.queue = "fx"), u.old = u.complete, u.complete = function () {
            i.isFunction(u.old) && u.old.call(this);
            u.queue && i.dequeue(this, u.queue)
        }, u
    };
    i.fn.extend({
        fadeTo: function (n, t, i, r) {
            return this.filter(et).css("opacity", 0).show().end().animate({opacity: t}, n, i, r)
        }, animate: function (n, t, r, u) {
            var o = i.isEmptyObject(n), e = i.speed(t, r, u), f = function () {
                var t = uf(this, i.extend({}, n), e);
                (o || i._data(this, "finish")) && t.stop(!0)
            };
            return f.finish = f, o || e.queue === !1 ? this.each(f) : this.queue(e.queue, f)
        }, stop: function (n, t, r) {
            var u = function (n) {
                var t = n.stop;
                delete n.stop;
                t(r)
            };
            return "string" != typeof n && (r = t, t = n, n = void 0), t && n !== !1 && this.queue(n || "fx", []), this.each(function () {
                var o = !0, t = null != n && n + "queueHooks", e = i.timers, f = i._data(this);
                if (t)f[t] && f[t].stop && u(f[t]); else for (t in f)f[t] && f[t].stop && fo.test(t) && u(f[t]);
                for (t = e.length; t--;)e[t].elem !== this || null != n && e[t].queue !== n || (e[t].anim.stop(r), o = !1, e.splice(t, 1));
                (o || !r) && i.dequeue(this, n)
            })
        }, finish: function (n) {
            return n !== !1 && (n = n || "fx"), this.each(function () {
                var t, f = i._data(this), r = f[n + "queue"], e = f[n + "queueHooks"], u = i.timers, o = r ? r.length : 0;
                for (f.finish = !0, i.queue(this, n, []), e && e.stop && e.stop.call(this, !0), t = u.length; t--;)u[t].elem === this && u[t].queue === n && (u[t].anim.stop(!0), u.splice(t, 1));
                for (t = 0; o > t; t++)r[t] && r[t].finish && r[t].finish.call(this);
                delete f.finish
            })
        }
    });
    i.each(["toggle", "show", "hide"], function (n, t) {
        var r = i.fn[t];
        i.fn[t] = function (n, i, u) {
            return null == n || "boolean" == typeof n ? r.apply(this, arguments) : this.animate(bt(t, !0), n, i, u)
        }
    });
    i.each({
        slideDown: bt("show"),
        slideUp: bt("hide"),
        slideToggle: bt("toggle"),
        fadeIn: {opacity: "show"},
        fadeOut: {opacity: "hide"},
        fadeToggle: {opacity: "toggle"}
    }, function (n, t) {
        i.fn[n] = function (n, i, r) {
            return this.animate(t, n, i, r)
        }
    });
    i.timers = [];
    i.fx.tick = function () {
        var r, n = i.timers, t = 0;
        for (rt = i.now(); t < n.length; t++)r = n[t], r() || n[t] !== r || n.splice(t--, 1);
        n.length || i.fx.stop();
        rt = void 0
    };
    i.fx.timer = function (n) {
        i.timers.push(n);
        n() ? i.fx.start() : i.timers.pop()
    };
    i.fx.interval = 13;
    i.fx.start = function () {
        pt || (pt = setInterval(i.fx.tick, i.fx.interval))
    };
    i.fx.stop = function () {
        clearInterval(pt);
        pt = null
    };
    i.fx.speeds = {slow: 600, fast: 200, _default: 400};
    i.fn.delay = function (n, t) {
        return n = i.fx ? i.fx.speeds[n] || n : n, t = t || "fx", this.queue(t, function (t, i) {
            var r = setTimeout(t, n);
            i.stop = function () {
                clearTimeout(r)
            }
        })
    }, function () {
        var i, n, f, e, t = u.createElement("div");
        t.setAttribute("className", "t");
        t.innerHTML = "  <link/><table><\/table><a href='/a'>a<\/a><input type='checkbox'/>";
        i = t.getElementsByTagName("a")[0];
        f = u.createElement("select");
        e = f.appendChild(u.createElement("option"));
        n = t.getElementsByTagName("input")[0];
        i.style.cssText = "top:1px";
        r.getSetAttribute = "t" !== t.className;
        r.style = /top/.test(i.getAttribute("style"));
        r.hrefNormalized = "/a" === i.getAttribute("href");
        r.checkOn = !!n.value;
        r.optSelected = e.selected;
        r.enctype = !!u.createElement("form").enctype;
        f.disabled = !0;
        r.optDisabled = !e.disabled;
        n = u.createElement("input");
        n.setAttribute("value", "");
        r.input = "" === n.getAttribute("value");
        n.value = "t";
        n.setAttribute("type", "radio");
        r.radioValue = "t" === n.value;
        i = n = f = e = t = null
    }();
    ff = /\r/g;
    i.fn.extend({
        val: function (n) {
            var t, r, f, u = this[0];
            return arguments.length ? (f = i.isFunction(n), this.each(function (r) {
                var u;
                1 === this.nodeType && (u = f ? n.call(this, r, i(this).val()) : n, null == u ? u = "" : "number" == typeof u ? u += "" : i.isArray(u) && (u = i.map(u, function (n) {
                    return null == n ? "" : n + ""
                })), t = i.valHooks[this.type] || i.valHooks[this.nodeName.toLowerCase()], t && "set" in t && void 0 !== t.set(this, u, "value") || (this.value = u))
            })) : u ? (t = i.valHooks[u.type] || i.valHooks[u.nodeName.toLowerCase()], t && "get" in t && void 0 !== (r = t.get(u, "value")) ? r : (r = u.value, "string" == typeof r ? r.replace(ff, "") : null == r ? "" : r)) : void 0
        }
    });
    i.extend({
        valHooks: {
            option: {
                get: function (n) {
                    var t = i.find.attr(n, "value");
                    return null != t ? t : i.text(n)
                }
            }, select: {
                get: function (n) {
                    for (var o, t, s = n.options, u = n.selectedIndex, f = "select-one" === n.type || 0 > u, h = f ? null : [], c = f ? u + 1 : s.length, e = 0 > u ? c : f ? u : 0; c > e; e++)if (t = s[e], !(!t.selected && e !== u || (r.optDisabled ? t.disabled : null !== t.getAttribute("disabled")) || t.parentNode.disabled && i.nodeName(t.parentNode, "optgroup"))) {
                        if (o = i(t).val(), f)return o;
                        h.push(o)
                    }
                    return h
                }, set: function (n, t) {
                    for (var f, r, u = n.options, o = i.makeArray(t), e = u.length; e--;)if (r = u[e], i.inArray(i.valHooks.option.get(r), o) >= 0)try {
                        r.selected = f = !0
                    } catch (s) {
                        r.scrollHeight
                    } else r.selected = !1;
                    return f || (n.selectedIndex = -1), u
                }
            }
        }
    });
    i.each(["radio", "checkbox"], function () {
        i.valHooks[this] = {
            set: function (n, t) {
                if (i.isArray(t))return n.checked = i.inArray(i(n).val(), t) >= 0
            }
        };
        r.checkOn || (i.valHooks[this].get = function (n) {
            return null === n.getAttribute("value") ? "on" : n.value
        })
    });
    var ut, ef, v = i.expr.attrHandle, yi = /^(?:checked|selected)$/i, g = r.getSetAttribute, kt = r.input;
    i.fn.extend({
        attr: function (n, t) {
            return b(this, i.attr, n, t, arguments.length > 1)
        }, removeAttr: function (n) {
            return this.each(function () {
                i.removeAttr(this, n)
            })
        }
    });
    i.extend({
        attr: function (n, t, r) {
            var u, f, e = n.nodeType;
            if (n && 3 !== e && 8 !== e && 2 !== e)return typeof n.getAttribute === o ? i.prop(n, t, r) : (1 === e && i.isXMLDoc(n) || (t = t.toLowerCase(), u = i.attrHooks[t] || (i.expr.match.bool.test(t) ? ef : ut)), void 0 === r ? u && "get" in u && null !== (f = u.get(n, t)) ? f : (f = i.find.attr(n, t), null == f ? void 0 : f) : null !== r ? u && "set" in u && void 0 !== (f = u.set(n, r, t)) ? f : (n.setAttribute(t, r + ""), r) : void i.removeAttr(n, t))
        }, removeAttr: function (n, t) {
            var r, u, e = 0, f = t && t.match(h);
            if (f && 1 === n.nodeType)while (r = f[e++])u = i.propFix[r] || r, i.expr.match.bool.test(r) ? kt && g || !yi.test(r) ? n[u] = !1 : n[i.camelCase("default-" + r)] = n[u] = !1 : i.attr(n, r, ""), n.removeAttribute(g ? r : u)
        }, attrHooks: {
            type: {
                set: function (n, t) {
                    if (!r.radioValue && "radio" === t && i.nodeName(n, "input")) {
                        var u = n.value;
                        return n.setAttribute("type", t), u && (n.value = u), t
                    }
                }
            }
        }
    });
    ef = {
        set: function (n, t, r) {
            return t === !1 ? i.removeAttr(n, r) : kt && g || !yi.test(r) ? n.setAttribute(!g && i.propFix[r] || r, r) : n[i.camelCase("default-" + r)] = n[r] = !0, r
        }
    };
    i.each(i.expr.match.bool.source.match(/\w+/g), function (n, t) {
        var r = v[t] || i.find.attr;
        v[t] = kt && g || !yi.test(t) ? function (n, t, i) {
            var u, f;
            return i || (f = v[t], v[t] = u, u = null != r(n, t, i) ? t.toLowerCase() : null, v[t] = f), u
        } : function (n, t, r) {
            if (!r)return n[i.camelCase("default-" + t)] ? t.toLowerCase() : null
        }
    });
    kt && g || (i.attrHooks.value = {
        set: function (n, t, r) {
            return i.nodeName(n, "input") ? void(n.defaultValue = t) : ut && ut.set(n, t, r)
        }
    });
    g || (ut = {
        set: function (n, t, i) {
            var r = n.getAttributeNode(i);
            return r || n.setAttributeNode(r = n.ownerDocument.createAttribute(i)), r.value = t += "", "value" === i || t === n.getAttribute(i) ? t : void 0
        }
    }, v.id = v.name = v.coords = function (n, t, i) {
        var r;
        if (!i)return (r = n.getAttributeNode(t)) && "" !== r.value ? r.value : null
    }, i.valHooks.button = {
        get: function (n, t) {
            var i = n.getAttributeNode(t);
            if (i && i.specified)return i.value
        }, set: ut.set
    }, i.attrHooks.contenteditable = {
        set: function (n, t, i) {
            ut.set(n, "" === t ? !1 : t, i)
        }
    }, i.each(["width", "height"], function (n, t) {
        i.attrHooks[t] = {
            set: function (n, i) {
                if ("" === i)return (n.setAttribute(t, "auto"), i)
            }
        }
    }));
    r.style || (i.attrHooks.style = {
        get: function (n) {
            return n.style.cssText || void 0
        }, set: function (n, t) {
            return n.style.cssText = t + ""
        }
    });
    of = /^(?:input|select|textarea|button|object)$/i;
    sf = /^(?:a|area)$/i;
    i.fn.extend({
        prop: function (n, t) {
            return b(this, i.prop, n, t, arguments.length > 1)
        }, removeProp: function (n) {
            return n = i.propFix[n] || n, this.each(function () {
                try {
                    this[n] = void 0;
                    delete this[n]
                } catch (t) {
                }
            })
        }
    });
    i.extend({
        propFix: {"for": "htmlFor", "class": "className"}, prop: function (n, t, r) {
            var f, u, o, e = n.nodeType;
            if (n && 3 !== e && 8 !== e && 2 !== e)return o = 1 !== e || !i.isXMLDoc(n), o && (t = i.propFix[t] || t, u = i.propHooks[t]), void 0 !== r ? u && "set" in u && void 0 !== (f = u.set(n, r, t)) ? f : n[t] = r : u && "get" in u && null !== (f = u.get(n, t)) ? f : n[t]
        }, propHooks: {
            tabIndex: {
                get: function (n) {
                    var t = i.find.attr(n, "tabindex");
                    return t ? parseInt(t, 10) : of.test(n.nodeName) || sf.test(n.nodeName) && n.href ? 0 : -1
                }
            }
        }
    });
    r.hrefNormalized || i.each(["href", "src"], function (n, t) {
        i.propHooks[t] = {
            get: function (n) {
                return n.getAttribute(t, 4)
            }
        }
    });
    r.optSelected || (i.propHooks.selected = {
        get: function (n) {
            var t = n.parentNode;
            return t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex), null
        }
    });
    i.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function () {
        i.propFix[this.toLowerCase()] = this
    });
    r.enctype || (i.propFix.enctype = "encoding");
    dt = /[\t\r\n\f]/g;
    i.fn.extend({
        addClass: function (n) {
            var o, t, r, u, s, f, e = 0, c = this.length, l = "string" == typeof n && n;
            if (i.isFunction(n))return this.each(function (t) {
                i(this).addClass(n.call(this, t, this.className))
            });
            if (l)for (o = (n || "").match(h) || []; c > e; e++)if (t = this[e], r = 1 === t.nodeType && (t.className ? (" " + t.className + " ").replace(dt, " ") : " ")) {
                for (s = 0; u = o[s++];)r.indexOf(" " + u + " ") < 0 && (r += u + " ");
                f = i.trim(r);
                t.className !== f && (t.className = f)
            }
            return this
        }, removeClass: function (n) {
            var o, t, r, u, s, f, e = 0, c = this.length, l = 0 === arguments.length || "string" == typeof n && n;
            if (i.isFunction(n))return this.each(function (t) {
                i(this).removeClass(n.call(this, t, this.className))
            });
            if (l)for (o = (n || "").match(h) || []; c > e; e++)if (t = this[e], r = 1 === t.nodeType && (t.className ? (" " + t.className + " ").replace(dt, " ") : "")) {
                for (s = 0; u = o[s++];)while (r.indexOf(" " + u + " ") >= 0)r = r.replace(" " + u + " ", " ");
                f = n ? i.trim(r) : "";
                t.className !== f && (t.className = f)
            }
            return this
        }, toggleClass: function (n, t) {
            var r = typeof n;
            return "boolean" == typeof t && "string" === r ? t ? this.addClass(n) : this.removeClass(n) : this.each(i.isFunction(n) ? function (r) {
                i(this).toggleClass(n.call(this, r, this.className, t), t)
            } : function () {
                if ("string" === r)for (var t, f = 0, u = i(this), e = n.match(h) || []; t = e[f++];)u.hasClass(t) ? u.removeClass(t) : u.addClass(t); else(r === o || "boolean" === r) && (this.className && i._data(this, "__className__", this.className), this.className = this.className || n === !1 ? "" : i._data(this, "__className__") || "")
            })
        }, hasClass: function (n) {
            for (var i = " " + n + " ", t = 0, r = this.length; r > t; t++)if (1 === this[t].nodeType && (" " + this[t].className + " ").replace(dt, " ").indexOf(i) >= 0)return !0;
            return !1
        }
    });
    i.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function (n, t) {
        i.fn[t] = function (n, i) {
            return arguments.length > 0 ? this.on(t, null, n, i) : this.trigger(t)
        }
    });
    i.fn.extend({
        hover: function (n, t) {
            return this.mouseenter(n).mouseleave(t || n)
        }, bind: function (n, t, i) {
            return this.on(n, null, t, i)
        }, unbind: function (n, t) {
            return this.off(n, null, t)
        }, delegate: function (n, t, i, r) {
            return this.on(t, n, i, r)
        }, undelegate: function (n, t, i) {
            return 1 === arguments.length ? this.off(n, "**") : this.off(t, n || "**", i)
        }
    });
    var pi = i.now(), wi = /\?/, so = /(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;
    i.parseJSON = function (t) {
        if (n.JSON && n.JSON.parse)return n.JSON.parse(t + "");
        var f, r = null, u = i.trim(t + "");
        return u && !i.trim(u.replace(so, function (n, t, i, u) {
            return f && t && (r = 0), 0 === r ? n : (f = i || t, r += !u - !i, "")
        })) ? Function("return " + u)() : i.error("Invalid JSON: " + t)
    };
    i.parseXML = function (t) {
        var r, u;
        if (!t || "string" != typeof t)return null;
        try {
            n.DOMParser ? (u = new DOMParser, r = u.parseFromString(t, "text/xml")) : (r = new ActiveXObject("Microsoft.XMLDOM"), r.async = "false", r.loadXML(t))
        } catch (f) {
            r = void 0
        }
        return r && r.documentElement && !r.getElementsByTagName("parsererror").length || i.error("Invalid XML: " + t), r
    };
    var nt, y, ho = /#.*$/, hf = /([?&])_=[^&]*/, co = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm, lo = /^(?:GET|HEAD)$/, ao = /^\/\//, cf = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/, lf = {}, bi = {}, af = "*/".concat("*");
    try {
        y = location.href
    } catch (ts) {
        y = u.createElement("a");
        y.href = "";
        y = y.href
    }
    nt = cf.exec(y.toLowerCase()) || [];
    i.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: y,
            type: "GET",
            isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(nt[1]),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": af,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {xml: /xml/, html: /html/, json: /json/},
            responseFields: {xml: "responseXML", text: "responseText", json: "responseJSON"},
            converters: {"* text": String, "text html": !0, "text json": i.parseJSON, "text xml": i.parseXML},
            flatOptions: {url: !0, context: !0}
        },
        ajaxSetup: function (n, t) {
            return t ? ki(ki(n, i.ajaxSettings), t) : ki(i.ajaxSettings, n)
        },
        ajaxPrefilter: vf(lf),
        ajaxTransport: vf(bi),
        ajax: function (n, t) {
            function w(n, t, s, h) {
                var v, it, nt, y, w, c = t;
                2 !== e && (e = 2, k && clearTimeout(k), a = void 0, b = h || "", u.readyState = n > 0 ? 4 : 0, v = n >= 200 && 300 > n || 304 === n, s && (y = vo(r, u, s)), y = yo(r, y, u, v), v ? (r.ifModified && (w = u.getResponseHeader("Last-Modified"), w && (i.lastModified[f] = w), w = u.getResponseHeader("etag"), w && (i.etag[f] = w)), 204 === n || "HEAD" === r.type ? c = "nocontent" : 304 === n ? c = "notmodified" : (c = y.state, it = y.data, nt = y.error, v = !nt)) : (nt = c, (n || !c) && (c = "error", 0 > n && (n = 0))), u.status = n, u.statusText = (t || c) + "", v ? g.resolveWith(o, [it, c, u]) : g.rejectWith(o, [u, c, nt]), u.statusCode(p), p = void 0, l && d.trigger(v ? "ajaxSuccess" : "ajaxError", [u, r, v ? it : nt]), tt.fireWith(o, [u, c]), l && (d.trigger("ajaxComplete", [u, r]), --i.active || i.event.trigger("ajaxStop")))
            }

            "object" == typeof n && (t = n, n = void 0);
            t = t || {};
            var s, c, f, b, k, l, a, v, r = i.ajaxSetup({}, t), o = r.context || r, d = r.context && (o.nodeType || o.jquery) ? i(o) : i.event, g = i.Deferred(), tt = i.Callbacks("once memory"), p = r.statusCode || {}, it = {}, rt = {}, e = 0, ut = "canceled", u = {
                readyState: 0,
                getResponseHeader: function (n) {
                    var t;
                    if (2 === e) {
                        if (!v)for (v = {}; t = co.exec(b);)v[t[1].toLowerCase()] = t[2];
                        t = v[n.toLowerCase()]
                    }
                    return null == t ? null : t
                },
                getAllResponseHeaders: function () {
                    return 2 === e ? b : null
                },
                setRequestHeader: function (n, t) {
                    var i = n.toLowerCase();
                    return e || (n = rt[i] = rt[i] || n, it[n] = t), this
                },
                overrideMimeType: function (n) {
                    return e || (r.mimeType = n), this
                },
                statusCode: function (n) {
                    var t;
                    if (n)if (2 > e)for (t in n)p[t] = [p[t], n[t]]; else u.always(n[u.status]);
                    return this
                },
                abort: function (n) {
                    var t = n || ut;
                    return a && a.abort(t), w(0, t), this
                }
            };
            if (g.promise(u).complete = tt.add, u.success = u.done, u.error = u.fail, r.url = ((n || r.url || y) + "").replace(ho, "").replace(ao, nt[1] + "//"), r.type = t.method || t.type || r.method || r.type, r.dataTypes = i.trim(r.dataType || "*").toLowerCase().match(h) || [""], null == r.crossDomain && (s = cf.exec(r.url.toLowerCase()), r.crossDomain = !(!s || s[1] === nt[1] && s[2] === nt[2] && (s[3] || ("http:" === s[1] ? "80" : "443")) === (nt[3] || ("http:" === nt[1] ? "80" : "443")))), r.data && r.processData && "string" != typeof r.data && (r.data = i.param(r.data, r.traditional)), yf(lf, r, t, u), 2 === e)return u;
            l = r.global;
            l && 0 == i.active++ && i.event.trigger("ajaxStart");
            r.type = r.type.toUpperCase();
            r.hasContent = !lo.test(r.type);
            f = r.url;
            r.hasContent || (r.data && (f = r.url += (wi.test(f) ? "&" : "?") + r.data, delete r.data), r.cache === !1 && (r.url = hf.test(f) ? f.replace(hf, "$1_=" + pi++) : f + (wi.test(f) ? "&" : "?") + "_=" + pi++));
            r.ifModified && (i.lastModified[f] && u.setRequestHeader("If-Modified-Since", i.lastModified[f]), i.etag[f] && u.setRequestHeader("If-None-Match", i.etag[f]));
            (r.data && r.hasContent && r.contentType !== !1 || t.contentType) && u.setRequestHeader("Content-Type", r.contentType);
            u.setRequestHeader("Accept", r.dataTypes[0] && r.accepts[r.dataTypes[0]] ? r.accepts[r.dataTypes[0]] + ("*" !== r.dataTypes[0] ? ", " + af + "; q=0.01" : "") : r.accepts["*"]);
            for (c in r.headers)u.setRequestHeader(c, r.headers[c]);
            if (r.beforeSend && (r.beforeSend.call(o, u, r) === !1 || 2 === e))return u.abort();
            ut = "abort";
            for (c in{success: 1, error: 1, complete: 1})u[c](r[c]);
            if (a = yf(bi, r, t, u)) {
                u.readyState = 1;
                l && d.trigger("ajaxSend", [u, r]);
                r.async && r.timeout > 0 && (k = setTimeout(function () {
                    u.abort("timeout")
                }, r.timeout));
                try {
                    e = 1;
                    a.send(it, w)
                } catch (ft) {
                    if (!(2 > e))throw ft;
                    w(-1, ft)
                }
            } else w(-1, "No Transport");
            return u
        },
        getJSON: function (n, t, r) {
            return i.get(n, t, r, "json")
        },
        getScript: function (n, t) {
            return i.get(n, void 0, t, "script")
        }
    });
    i.each(["get", "post"], function (n, t) {
        i[t] = function (n, r, u, f) {
            return i.isFunction(r) && (f = f || u, u = r, r = void 0), i.ajax({
                url: n,
                type: t,
                dataType: f,
                data: r,
                success: u
            })
        }
    });
    i.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function (n, t) {
        i.fn[t] = function (n) {
            return this.on(t, n)
        }
    });
    i._evalUrl = function (n) {
        return i.ajax({url: n, type: "GET", dataType: "script", async: !1, global: !1, throws: !0})
    };
    i.fn.extend({
        wrapAll: function (n) {
            if (i.isFunction(n))return this.each(function (t) {
                i(this).wrapAll(n.call(this, t))
            });
            if (this[0]) {
                var t = i(n, this[0].ownerDocument).eq(0).clone(!0);
                this[0].parentNode && t.insertBefore(this[0]);
                t.map(function () {
                    for (var n = this; n.firstChild && 1 === n.firstChild.nodeType;)n = n.firstChild;
                    return n
                }).append(this)
            }
            return this
        }, wrapInner: function (n) {
            return this.each(i.isFunction(n) ? function (t) {
                i(this).wrapInner(n.call(this, t))
            } : function () {
                var t = i(this), r = t.contents();
                r.length ? r.wrapAll(n) : t.append(n)
            })
        }, wrap: function (n) {
            var t = i.isFunction(n);
            return this.each(function (r) {
                i(this).wrapAll(t ? n.call(this, r) : n)
            })
        }, unwrap: function () {
            return this.parent().each(function () {
                i.nodeName(this, "body") || i(this).replaceWith(this.childNodes)
            }).end()
        }
    });
    i.expr.filters.hidden = function (n) {
        return n.offsetWidth <= 0 && n.offsetHeight <= 0 || !r.reliableHiddenOffsets() && "none" === (n.style && n.style.display || i.css(n, "display"))
    };
    i.expr.filters.visible = function (n) {
        return !i.expr.filters.hidden(n)
    };
    var po = /%20/g, wo = /\[\]$/, pf = /\r?\n/g, bo = /^(?:submit|button|image|reset|file)$/i, ko = /^(?:input|select|textarea|keygen)/i;
    i.param = function (n, t) {
        var r, u = [], f = function (n, t) {
            t = i.isFunction(t) ? t() : null == t ? "" : t;
            u[u.length] = encodeURIComponent(n) + "=" + encodeURIComponent(t)
        };
        if (void 0 === t && (t = i.ajaxSettings && i.ajaxSettings.traditional), i.isArray(n) || n.jquery && !i.isPlainObject(n))i.each(n, function () {
            f(this.name, this.value)
        }); else for (r in n)di(r, n[r], t, f);
        return u.join("&").replace(po, "+")
    };
    i.fn.extend({
        serialize: function () {
            return i.param(this.serializeArray())
        }, serializeArray: function () {
            return this.map(function () {
                var n = i.prop(this, "elements");
                return n ? i.makeArray(n) : this
            }).filter(function () {
                var n = this.type;
                return this.name && !i(this).is(":disabled") && ko.test(this.nodeName) && !bo.test(n) && (this.checked || !oi.test(n))
            }).map(function (n, t) {
                var r = i(this).val();
                return null == r ? null : i.isArray(r) ? i.map(r, function (n) {
                    return {name: t.name, value: n.replace(pf, "\r\n")}
                }) : {name: t.name, value: r.replace(pf, "\r\n")}
            }).get()
        }
    });
    i.ajaxSettings.xhr = void 0 !== n.ActiveXObject ? function () {
        return !this.isLocal && /^(get|post|head|put|delete|options)$/i.test(this.type) && wf() || ns()
    } : wf;
    var go = 0, gt = {}, ht = i.ajaxSettings.xhr();
    return n.ActiveXObject && i(n).on("unload", function () {
        for (var n in gt)gt[n](void 0, !0)
    }), r.cors = !!ht && "withCredentials" in ht, ht = r.ajax = !!ht, ht && i.ajaxTransport(function (n) {
        if (!n.crossDomain || r.cors) {
            var t;
            return {
                send: function (r, u) {
                    var e, f = n.xhr(), o = ++go;
                    if (f.open(n.type, n.url, n.async, n.username, n.password), n.xhrFields)for (e in n.xhrFields)f[e] = n.xhrFields[e];
                    n.mimeType && f.overrideMimeType && f.overrideMimeType(n.mimeType);
                    n.crossDomain || r["X-Requested-With"] || (r["X-Requested-With"] = "XMLHttpRequest");
                    for (e in r)void 0 !== r[e] && f.setRequestHeader(e, r[e] + "");
                    f.send(n.hasContent && n.data || null);
                    t = function (r, e) {
                        var s, c, h;
                        if (t && (e || 4 === f.readyState))if (delete gt[o], t = void 0, f.onreadystatechange = i.noop, e)4 !== f.readyState && f.abort(); else {
                            h = {};
                            s = f.status;
                            "string" == typeof f.responseText && (h.text = f.responseText);
                            try {
                                c = f.statusText
                            } catch (l) {
                                c = ""
                            }
                            s || !n.isLocal || n.crossDomain ? 1223 === s && (s = 204) : s = h.text ? 200 : 404
                        }
                        h && u(s, c, h, f.getAllResponseHeaders())
                    };
                    n.async ? 4 === f.readyState ? setTimeout(t) : f.onreadystatechange = gt[o] = t : t()
                }, abort: function () {
                    t && t(void 0, !0)
                }
            }
        }
    }), i.ajaxSetup({
        accepts: {script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},
        contents: {script: /(?:java|ecma)script/},
        converters: {
            "text script": function (n) {
                return i.globalEval(n), n
            }
        }
    }), i.ajaxPrefilter("script", function (n) {
        void 0 === n.cache && (n.cache = !1);
        n.crossDomain && (n.type = "GET", n.global = !1)
    }), i.ajaxTransport("script", function (n) {
        if (n.crossDomain) {
            var t, r = u.head || i("head")[0] || u.documentElement;
            return {
                send: function (i, f) {
                    t = u.createElement("script");
                    t.async = !0;
                    n.scriptCharset && (t.charset = n.scriptCharset);
                    t.src = n.url;
                    t.onload = t.onreadystatechange = function (n, i) {
                        (i || !t.readyState || /loaded|complete/.test(t.readyState)) && (t.onload = t.onreadystatechange = null, t.parentNode && t.parentNode.removeChild(t), t = null, i || f(200, "success"))
                    };
                    r.insertBefore(t, r.firstChild)
                }, abort: function () {
                    t && t.onload(void 0, !0)
                }
            }
        }
    }), gi = [], ni = /(=)\?(?=&|$)|\?\?/, i.ajaxSetup({
        jsonp: "callback", jsonpCallback: function () {
            var n = gi.pop() || i.expando + "_" + pi++;
            return this[n] = !0, n
        }
    }), i.ajaxPrefilter("json jsonp", function (t, r, u) {
        var f, o, e, s = t.jsonp !== !1 && (ni.test(t.url) ? "url" : "string" == typeof t.data && !(t.contentType || "").indexOf("application/x-www-form-urlencoded") && ni.test(t.data) && "data");
        if (s || "jsonp" === t.dataTypes[0])return (f = t.jsonpCallback = i.isFunction(t.jsonpCallback) ? t.jsonpCallback() : t.jsonpCallback, s ? t[s] = t[s].replace(ni, "$1" + f) : t.jsonp !== !1 && (t.url += (wi.test(t.url) ? "&" : "?") + t.jsonp + "=" + f), t.converters["script json"] = function () {
            return e || i.error(f + " was not called"), e[0]
        }, t.dataTypes[0] = "json", o = n[f], n[f] = function () {
            e = arguments
        }, u.always(function () {
            n[f] = o;
            t[f] && (t.jsonpCallback = r.jsonpCallback, gi.push(f));
            e && i.isFunction(o) && o(e[0]);
            e = o = void 0
        }), "script")
    }), i.parseHTML = function (n, t, r) {
        if (!n || "string" != typeof n)return null;
        "boolean" == typeof t && (r = t, t = !1);
        t = t || u;
        var f = er.exec(n), e = !r && [];
        return f ? [t.createElement(f[1])] : (f = i.buildFragment([n], t, e), e && e.length && i(e).remove(), i.merge([], f.childNodes))
    }, nr = i.fn.load, i.fn.load = function (n, t, r) {
        if ("string" != typeof n && nr)return nr.apply(this, arguments);
        var u, o, s, f = this, e = n.indexOf(" ");
        return e >= 0 && (u = n.slice(e, n.length), n = n.slice(0, e)), i.isFunction(t) ? (r = t, t = void 0) : t && "object" == typeof t && (s = "POST"), f.length > 0 && i.ajax({
            url: n,
            type: s,
            dataType: "html",
            data: t
        }).done(function (n) {
            o = arguments;
            f.html(u ? i("<div>").append(i.parseHTML(n)).find(u) : n)
        }).complete(r && function (n, t) {
                f.each(r, o || [n.responseText, t, n])
            }), this
    }, i.expr.filters.animated = function (n) {
        return i.grep(i.timers, function (t) {
            return n === t.elem
        }).length
    }, tr = n.document.documentElement, i.offset = {
        setOffset: function (n, t, r) {
            var e, o, s, h, u, c, v, l = i.css(n, "position"), a = i(n), f = {};
            "static" === l && (n.style.position = "relative");
            u = a.offset();
            s = i.css(n, "top");
            c = i.css(n, "left");
            v = ("absolute" === l || "fixed" === l) && i.inArray("auto", [s, c]) > -1;
            v ? (e = a.position(), h = e.top, o = e.left) : (h = parseFloat(s) || 0, o = parseFloat(c) || 0);
            i.isFunction(t) && (t = t.call(n, r, u));
            null != t.top && (f.top = t.top - u.top + h);
            null != t.left && (f.left = t.left - u.left + o);
            "using" in t ? t.using.call(n, f) : a.css(f)
        }
    }, i.fn.extend({
        offset: function (n) {
            if (arguments.length)return void 0 === n ? this : this.each(function (t) {
                i.offset.setOffset(this, n, t)
            });
            var t, f, u = {top: 0, left: 0}, r = this[0], e = r && r.ownerDocument;
            if (e)return t = e.documentElement, i.contains(t, r) ? (typeof r.getBoundingClientRect !== o && (u = r.getBoundingClientRect()), f = bf(e), {
                top: u.top + (f.pageYOffset || t.scrollTop) - (t.clientTop || 0),
                left: u.left + (f.pageXOffset || t.scrollLeft) - (t.clientLeft || 0)
            }) : u
        }, position: function () {
            if (this[0]) {
                var n, r, t = {top: 0, left: 0}, u = this[0];
                return "fixed" === i.css(u, "position") ? r = u.getBoundingClientRect() : (n = this.offsetParent(), r = this.offset(), i.nodeName(n[0], "html") || (t = n.offset()), t.top += i.css(n[0], "borderTopWidth", !0), t.left += i.css(n[0], "borderLeftWidth", !0)), {
                    top: r.top - t.top - i.css(u, "marginTop", !0),
                    left: r.left - t.left - i.css(u, "marginLeft", !0)
                }
            }
        }, offsetParent: function () {
            return this.map(function () {
                for (var n = this.offsetParent || tr; n && !i.nodeName(n, "html") && "static" === i.css(n, "position");)n = n.offsetParent;
                return n || tr
            })
        }
    }), i.each({scrollLeft: "pageXOffset", scrollTop: "pageYOffset"}, function (n, t) {
        var r = /Y/.test(t);
        i.fn[n] = function (u) {
            return b(this, function (n, u, f) {
                var e = bf(n);
                return void 0 === f ? e ? t in e ? e[t] : e.document.documentElement[u] : n[u] : void(e ? e.scrollTo(r ? i(e).scrollLeft() : f, r ? f : i(e).scrollTop()) : n[u] = f)
            }, n, u, arguments.length, null)
        }
    }), i.each(["top", "left"], function (n, t) {
        i.cssHooks[t] = vu(r.pixelPosition, function (n, r) {
            if (r)return (r = d(n, t), yt.test(r) ? i(n).position()[t] + "px" : r)
        })
    }), i.each({Height: "height", Width: "width"}, function (n, t) {
        i.each({padding: "inner" + n, content: t, "": "outer" + n}, function (r, u) {
            i.fn[u] = function (u, f) {
                var e = arguments.length && (r || "boolean" != typeof u), o = r || (u === !0 || f === !0 ? "margin" : "border");
                return b(this, function (t, r, u) {
                    var f;
                    return i.isWindow(t) ? t.document.documentElement["client" + n] : 9 === t.nodeType ? (f = t.documentElement, Math.max(t.body["scroll" + n], f["scroll" + n], t.body["offset" + n], f["offset" + n], f["client" + n])) : void 0 === u ? i.css(t, r, o) : i.style(t, r, u, o)
                }, t, e ? u : void 0, e, null)
            }
        })
    }), i.fn.size = function () {
        return this.length
    }, i.fn.andSelf = i.fn.addBack, "function" == typeof define && define.amd && define("jquery", [], function () {
        return i
    }), kf = n.jQuery, df = n.$, i.noConflict = function (t) {
        return n.$ === i && (n.$ = df), t && n.jQuery === i && (n.jQuery = kf), i
    }, typeof t === o && (n.jQuery = n.$ = i), i
}), function (n, t, i) {
    "use strict";
    function w(t, i) {
        var u, f;
        if (n.isArray(t)) {
            for (u = t.length - 1; u >= 0; u--)f = t[u], n.type(t) === "object" || n.type(f) === "string" && r.transports[f] || (i.log("Invalid transport: " + f + ", removing it from the transports list."), t.splice(u, 1));
            t.length === 0 && (i.log("No transports remain within the specified transport array."), t = null)
        } else if (n.type(t) === "object" || r.transports[t] || t === "auto") {
            if (t === "auto" && r._.ieVersion <= 8)return ["longPolling"]
        } else i.log("Invalid transport: " + t.toString() + "."), t = null;
        return t
    }

    function b(n) {
        return n === "http:" ? 80 : n === "https:" ? 443 : void 0
    }

    function l(n, t) {
        return t.match(/:\d+$/) ? t : t + ":" + b(n)
    }

    function k(t, i) {
        var u = this, r = [];
        u.tryBuffer = function (i) {
            return t.state === n.signalR.connectionState.connecting ? (r.push(i), !0) : !1
        };
        u.drain = function () {
            if (t.state === n.signalR.connectionState.connected)while (r.length > 0)i(r.shift())
        };
        u.clear = function () {
            r = []
        }
    }

    var f = {
        nojQuery: "jQuery was not found. Please ensure jQuery is referenced before the SignalR client JavaScript file.",
        noTransportOnInit: "No transport could be initialized successfully. Try specifying a different transport or none at all for auto initialization.",
        errorOnNegotiate: "Error during negotiation request.",
        stoppedWhileLoading: "The connection was stopped during page load.",
        stoppedWhileNegotiating: "The connection was stopped during the negotiate request.",
        errorParsingNegotiateResponse: "Error parsing negotiate response.",
        protocolIncompatible: "You are using a version of the client that isn't compatible with the server. Client version {0}, server version {1}.",
        sendFailed: "Send failed.",
        parseFailed: "Failed at parsing response: {0}",
        longPollFailed: "Long polling request failed.",
        eventSourceFailedToConnect: "EventSource failed to connect.",
        eventSourceError: "Error raised by EventSource",
        webSocketClosed: "WebSocket closed.",
        pingServerFailedInvalidResponse: "Invalid ping response when pinging server: '{0}'.",
        pingServerFailed: "Failed to ping server.",
        pingServerFailedStatusCode: "Failed to ping server.  Server responded with status code {0}, stopping the connection.",
        pingServerFailedParse: "Failed to parse ping server response, stopping the connection.",
        noConnectionTransport: "Connection is in an invalid state, there is no transport active."
    };
    if (typeof n != "function")throw new Error(f.nojQuery);
    var r, h, s = t.document.readyState === "complete", e = n(t), c = "__Negotiate Aborted__", u = {
        onStart: "onStart",
        onStarting: "onStarting",
        onReceived: "onReceived",
        onError: "onError",
        onConnectionSlow: "onConnectionSlow",
        onReconnecting: "onReconnecting",
        onReconnect: "onReconnect",
        onStateChanged: "onStateChanged",
        onDisconnect: "onDisconnect"
    }, a = function (n, i) {
        if (i !== !1) {
            var r;
            typeof t.console != "undefined" && (r = "[" + (new Date).toTimeString() + "] SignalR: " + n, t.console.debug ? t.console.debug(r) : t.console.log && t.console.log(r))
        }
    }, o = function (t, i, r) {
        return i === t.state ? (t.state = r, n(t).triggerHandler(u.onStateChanged, [{
            oldState: i,
            newState: r
        }]), !0) : !1
    }, v = function (n) {
        return n.state === r.connectionState.disconnected
    }, y = function (i) {
        var f = i._.config, e = function (t) {
            n(i).triggerHandler(u.onError, [t])
        };
        !f.pingIntervalId && f.pingInterval && (i._.pingIntervalId = t.setInterval(function () {
            r.transports._logic.pingServer(i).fail(e)
        }, f.pingInterval))
    }, p = function (n) {
        var i, u;
        n._.configuredStopReconnectingTimeout || (u = function (n) {
            n.log("Couldn't reconnect within the configured timeout (" + n.disconnectTimeout + "ms), disconnecting.");
            n.stop(!1, !1)
        }, n.reconnecting(function () {
            var n = this;
            n.state === r.connectionState.reconnecting && (i = t.setTimeout(function () {
                u(n)
            }, n.disconnectTimeout))
        }), n.stateChanged(function (n) {
            n.oldState === r.connectionState.reconnecting && t.clearTimeout(i)
        }), n._.configuredStopReconnectingTimeout = !0)
    };
    r = function (n, t, i) {
        return new r.fn.init(n, t, i)
    };
    r._ = {
        defaultContentType: "application/x-www-form-urlencoded; charset=UTF-8", ieVersion: function () {
            var i, n;
            return t.navigator.appName === "Microsoft Internet Explorer" && (n = /MSIE ([0-9]+\.[0-9]+)/.exec(t.navigator.userAgent), n && (i = t.parseFloat(n[1]))), i
        }(), error: function (n, t) {
            var i = new Error(n);
            return i.source = t, i
        }, transportError: function (n, t, r) {
            var u = this.error(n, r);
            return u.transport = t ? t.name : i, u
        }, format: function () {
            for (var t = arguments[0], n = 0; n < arguments.length - 1; n++)t = t.replace("{" + n + "}", arguments[n + 1]);
            return t
        }, firefoxMajorVersion: function (n) {
            var t = n.match(/Firefox\/(\d+)/);
            return !t || !t.length || t.length < 2 ? 0 : parseInt(t[1], 10)
        }
    };
    r.events = u;
    r.resources = f;
    r.ajaxDefaults = {processData: !0, timeout: null, async: !0, global: !1, cache: !1};
    r.changeState = o;
    r.isDisconnecting = v;
    r.connectionState = {connecting: 0, connected: 1, reconnecting: 2, disconnected: 4};
    r.hub = {
        start: function () {
            throw new Error("SignalR: Error loading hubs. Ensure your hubs reference is correct, e.g. <script src='/signalr/js'><\/script>.");
        }
    };
    e.load(function () {
        s = !0
    });
    r.fn = r.prototype = {
        init: function (t, i, r) {
            var f = n(this);
            this.url = t;
            this.qs = i;
            this._ = {
                connectingMessageBuffer: new k(this, function (n) {
                    f.triggerHandler(u.onReceived, [n])
                }), onFailedTimeoutHandle: null
            };
            typeof r == "boolean" && (this.logging = r)
        },
        _parseResponse: function (n) {
            var t = this;
            return n ? t.ajaxDataType === "text" ? t.json.parse(n) : n : n
        },
        json: t.JSON,
        isCrossDomain: function (i, r) {
            var u;
            return (i = n.trim(i), i.indexOf("http") !== 0) ? !1 : (r = r || t.location, u = t.document.createElement("a"), u.href = i, u.protocol + l(u.protocol, u.host) !== r.protocol + l(r.protocol, r.host))
        },
        ajaxDataType: "text",
        contentType: "application/json; charset=UTF-8",
        logging: !1,
        state: r.connectionState.disconnected,
        keepAliveData: {},
        clientProtocol: "1.3",
        reconnectDelay: 2e3,
        transportConnectTimeout: 0,
        disconnectTimeout: 3e4,
        keepAliveWarnAt: 2 / 3,
        start: function (i, h) {
            var l = this, a = {
                pingInterval: 3e5,
                waitForPageLoad: !0,
                transport: "auto",
                jsonp: !1
            }, d, v = l._deferral || n.Deferred(), b = t.document.createElement("a"), k, g;
            if (l._deferral = v, !l.json)throw new Error("SignalR: No JSON parser found. Please ensure json2.js is referenced before the SignalR.js file if you need to support clients without native JSON parsing support, e.g. IE<8.");
            if (n.type(i) === "function" ? h = i : n.type(i) === "object" && (n.extend(a, i), n.type(a.callback) === "function" && (h = a.callback)), a.transport = w(a.transport, l), !a.transport)throw new Error("SignalR: Invalid transport(s) specified, aborting start.");
            return (l._.config = a, !s && a.waitForPageLoad === !0) ? (l._.deferredStartHandler = function () {
                l.start(i, h)
            }, e.bind("load", l._.deferredStartHandler), v.promise()) : l.state === r.connectionState.connecting ? v.promise() : o(l, r.connectionState.disconnected, r.connectionState.connecting) === !1 ? (v.resolve(l), v.promise()) : (p(l), b.href = l.url, b.protocol && b.protocol !== ":" ? (l.protocol = b.protocol, l.host = b.host, l.baseUrl = b.protocol + "//" + b.host) : (l.protocol = t.document.location.protocol, l.host = t.document.location.host, l.baseUrl = l.protocol + "//" + l.host), l.wsProtocol = l.protocol === "https:" ? "wss://" : "ws://", a.transport === "auto" && a.jsonp === !0 && (a.transport = "longPolling"), this.isCrossDomain(l.url) && (l.log("Auto detected cross domain url."), a.transport === "auto" && (a.transport = ["webSockets", "longPolling"]), typeof a.withCredentials == "undefined" && (a.withCredentials = !0), a.jsonp || (a.jsonp = !n.support.cors, a.jsonp && l.log("Using jsonp because this browser doesn't support CORS.")), l.contentType = r._.defaultContentType), l.withCredentials = a.withCredentials, l.ajaxDataType = a.jsonp ? "jsonp" : "text", n(l).bind(u.onStart, function () {
                n.type(h) === "function" && h.call(l);
                v.resolve(l)
            }), d = function (i, s) {
                var w = r._.error(f.noTransportOnInit);
                if (s = s || 0, s >= i.length) {
                    n(l).triggerHandler(u.onError, [w]);
                    v.reject(w);
                    l.stop();
                    return
                }
                if (l.state !== r.connectionState.disconnected) {
                    var c = i[s], h = n.type(c) === "object" ? c : r.transports[c], a = !1, p = function () {
                        a || (a = !0, t.clearTimeout(l._.onFailedTimeoutHandle), h.stop(l), d(i, s + 1))
                    };
                    if (l.transport = h, c.indexOf("_") === 0) {
                        d(i, s + 1);
                        return
                    }
                    try {
                        l._.onFailedTimeoutHandle = t.setTimeout(function () {
                            l.log(h.name + " timed out when trying to connect.");
                            p()
                        }, l.transportConnectTimeout);
                        h.start(l, function () {
                            var i = r._.firefoxMajorVersion(t.navigator.userAgent) >= 11, f = !!l.withCredentials && i;
                            l.state !== r.connectionState.disconnected && (a || (a = !0, t.clearTimeout(l._.onFailedTimeoutHandle), h.supportsKeepAlive && l.keepAliveData.activated && r.transports._logic.monitorKeepAlive(l), y(l), o(l, r.connectionState.connecting, r.connectionState.connected), l._.connectingMessageBuffer.drain(), n(l).triggerHandler(u.onStart), e.bind("unload", function () {
                                l.log("Window unloading, stopping the connection.");
                                l.stop(f)
                            }), i && e.bind("beforeunload", function () {
                                t.setTimeout(function () {
                                    l.stop(f)
                                }, 0)
                            })))
                        }, p)
                    } catch (b) {
                        l.log(h.name + " transport threw '" + b.message + "' when attempting to start.");
                        p()
                    }
                }
            }, k = l.url + "/negotiate", g = function (t, i) {
                var e = r._.error(f.errorOnNegotiate, t);
                n(i).triggerHandler(u.onError, e);
                v.reject(e);
                i.stop()
            }, n(l).triggerHandler(u.onStarting), k = r.transports._logic.prepareQueryString(l, k), k = r.transports._logic.addQs(k, {clientProtocol: l.clientProtocol}), l.log("Negotiating with '" + k + "'."), l._.negotiateRequest = n.ajax(n.extend({}, n.signalR.ajaxDefaults, {
                xhrFields: {withCredentials: l.withCredentials},
                url: k,
                type: "GET",
                contentType: l.contentType,
                data: {},
                dataType: l.ajaxDataType,
                error: function (n, t) {
                    t !== c ? g(n, l) : v.reject(r._.error(f.stoppedWhileNegotiating))
                },
                success: function (t) {
                    var i, e, h, o = [], s = [];
                    try {
                        i = l._parseResponse(t)
                    } catch (c) {
                        g(r._.error(f.errorParsingNegotiateResponse, c), l);
                        return
                    }
                    if (e = l.keepAliveData, l.appRelativeUrl = i.Url, l.id = i.ConnectionId, l.token = i.ConnectionToken, l.webSocketServerUrl = i.WebSocketServerUrl, l.disconnectTimeout = i.DisconnectTimeout * 1e3, l.transportConnectTimeout = l.transportConnectTimeout + i.TransportConnectTimeout * 1e3, i.KeepAliveTimeout ? (e.activated = !0, e.timeout = i.KeepAliveTimeout * 1e3, e.timeoutWarning = e.timeout * l.keepAliveWarnAt, e.checkInterval = (e.timeout - e.timeoutWarning) / 3) : e.activated = !1, !i.ProtocolVersion || i.ProtocolVersion !== l.clientProtocol) {
                        h = r._.error(r._.format(f.protocolIncompatible, l.clientProtocol, i.ProtocolVersion));
                        n(l).triggerHandler(u.onError, [h]);
                        v.reject(h);
                        return
                    }
                    n.each(r.transports, function (n) {
                        if (n === "webSockets" && !i.TryWebSockets)return !0;
                        s.push(n)
                    });
                    n.isArray(a.transport) ? n.each(a.transport, function () {
                        var t = this;
                        (n.type(t) === "object" || n.type(t) === "string" && n.inArray("" + t, s) >= 0) && o.push(n.type(t) === "string" ? "" + t : t)
                    }) : n.type(a.transport) === "object" || n.inArray(a.transport, s) >= 0 ? o.push(a.transport) : o = s;
                    d(o)
                }
            })), v.promise())
        },
        starting: function (t) {
            var i = this;
            return n(i).bind(u.onStarting, function () {
                t.call(i)
            }), i
        },
        send: function (n) {
            var t = this;
            if (t.state === r.connectionState.disconnected)throw new Error("SignalR: Connection must be started before data can be sent. Call .start() before .send()");
            if (t.state === r.connectionState.connecting)throw new Error("SignalR: Connection has not been fully initialized. Use .start().done() or .start().fail() to run logic after the connection has started.");
            return t.transport.send(t, n), t
        },
        received: function (t) {
            var i = this;
            return n(i).bind(u.onReceived, function (n, r) {
                i._.connectingMessageBuffer.tryBuffer(r) || t.call(i, r)
            }), i
        },
        stateChanged: function (t) {
            var i = this;
            return n(i).bind(u.onStateChanged, function (n, r) {
                t.call(i, r)
            }), i
        },
        error: function (t) {
            var i = this;
            return n(i).bind(u.onError, function (n, r) {
                t.call(i, r)
            }), i
        },
        disconnected: function (t) {
            var i = this;
            return n(i).bind(u.onDisconnect, function () {
                t.call(i)
            }), i
        },
        connectionSlow: function (t) {
            var i = this;
            return n(i).bind(u.onConnectionSlow, function () {
                t.call(i)
            }), i
        },
        reconnecting: function (t) {
            var i = this;
            return n(i).bind(u.onReconnecting, function () {
                t.call(i)
            }), i
        },
        reconnected: function (t) {
            var i = this;
            return n(i).bind(u.onReconnect, function () {
                t.call(i)
            }), i
        },
        stop: function (i, h) {
            var l = this, a = l._deferral;
            if (l._.deferredStartHandler && e.unbind("load", l._.deferredStartHandler), delete l._deferral, delete l._.config, delete l._.deferredStartHandler, !s && (!l._.config || l._.config.waitForPageLoad === !0)) {
                l.log("Stopping connection prior to negotiate.");
                a && a.reject(r._.error(f.stoppedWhileLoading));
                return
            }
            if (l.state !== r.connectionState.disconnected) {
                try {
                    l.log("Stopping connection.");
                    t.clearTimeout(l._.onFailedTimeoutHandle);
                    t.clearInterval(l._.pingIntervalId);
                    l.transport && (l.transport.stop(l), h !== !1 && l.transport.abort(l, i), l.transport.supportsKeepAlive && l.keepAliveData.activated && r.transports._logic.stopMonitoringKeepAlive(l), l.transport = null);
                    l._.negotiateRequest && (l._.negotiateRequest.abort(c), delete l._.negotiateRequest);
                    n(l).triggerHandler(u.onDisconnect);
                    delete l.messageId;
                    delete l.groupsToken;
                    delete l.id;
                    delete l._.pingIntervalId;
                    l._.connectingMessageBuffer.clear()
                } finally {
                    o(l, l.state, r.connectionState.disconnected)
                }
                return l
            }
        },
        log: function (n) {
            a(n, this.logging)
        }
    };
    r.fn.init.prototype = r.fn;
    r.noConflict = function () {
        return n.connection === r && (n.connection = h), r
    };
    n.connection && (h = n.connection);
    n.connection = n.signalR = r
}(window.jQuery, window), function (n, t) {
    "use strict";
    function f(u) {
        var e = u.keepAliveData, o, s;
        u.state === i.connectionState.connected && (o = new Date, o.setTime(o - e.lastKeepAlive), s = o.getTime(), s >= e.timeout ? (u.log("Keep alive timed out.  Notifying transport that connection has been lost."), u.transport.lostConnection(u)) : s >= e.timeoutWarning ? e.userNotified || (u.log("Keep alive has been missed, connection may be dead/slow."), n(u).triggerHandler(r.onConnectionSlow), e.userNotified = !0) : e.userNotified = !1);
        e.monitoring && t.setTimeout(function () {
            f(u)
        }, e.checkInterval)
    }

    function o(n) {
        return n.state === i.connectionState.connected || n.state === i.connectionState.reconnecting
    }

    function s(n, i) {
        var r = n.indexOf("?") !== -1 ? "&" : "?";
        return i && (n += r + "connectionData=" + t.encodeURIComponent(i)), n
    }

    var i = n.signalR, r = n.signalR.events, e = n.signalR.changeState, u;
    i.transports = {};
    u = i.transports._logic = {
        pingServer: function (t) {
            var e, f, r = n.Deferred();
            return t.transport ? (e = t.transport.name === "webSockets" ? "" : t.baseUrl, f = e + t.appRelativeUrl + "/ping", f = u.prepareQueryString(t, f), n.ajax(n.extend({}, n.signalR.ajaxDefaults, {
                xhrFields: {withCredentials: t.withCredentials},
                url: f,
                type: "GET",
                contentType: t.contentType,
                data: {},
                dataType: t.ajaxDataType,
                success: function (n) {
                    var u;
                    try {
                        u = t._parseResponse(n)
                    } catch (f) {
                        r.reject(i._.transportError(i.resources.pingServerFailedParse, t.transport, f));
                        t.stop();
                        return
                    }
                    u.Response === "pong" ? r.resolve() : r.reject(i._.transportError(i._.format(i.resources.pingServerFailedInvalidResponse, n.responseText), t.transport))
                },
                error: function (n) {
                    n.status === 401 || n.status === 403 ? (r.reject(i._.transportError(i._.format(i.resources.pingServerFailedStatusCode, n.status), t.transport, n)), t.stop()) : r.reject(i._.transportError(i.resources.pingServerFailed, t.transport, n))
                }
            }))) : r.reject(i._.transportError(i.resources.noConnectionTransport, t.transport)), r.promise()
        }, prepareQueryString: function (n, t) {
            return t = u.addQs(t, n.qs), s(t, n.data)
        }, addQs: function (t, i) {
            var r = t.indexOf("?") !== -1 ? "&" : "?", u;
            if (!i)return t;
            if (typeof i == "object")return t + r + n.param(i);
            if (typeof i == "string")return u = i.charAt(0), (u === "?" || u === "&") && (r = ""), t + r + i;
            throw new Error("Query string property must be either a string or object.");
        }, getUrl: function (n, i, r, f) {
            var s = i === "webSockets" ? "" : n.baseUrl, e = s + n.appRelativeUrl, o = "transport=" + i + "&connectionToken=" + t.encodeURIComponent(n.token);
            return n.groupsToken && (o += "&groupsToken=" + t.encodeURIComponent(n.groupsToken)), r ? (e += f ? "/poll" : "/reconnect", n.messageId && (o += "&messageId=" + t.encodeURIComponent(n.messageId))) : e += "/connect", e += "?" + o, e = u.prepareQueryString(n, e), e + ("&tid=" + Math.floor(Math.random() * 11))
        }, maximizePersistentResponse: function (n) {
            return {
                MessageId: n.C,
                Messages: n.M,
                Initialized: typeof n.S != "undefined" ? !0 : !1,
                Disconnect: typeof n.D != "undefined" ? !0 : !1,
                ShouldReconnect: typeof n.T != "undefined" ? !0 : !1,
                LongPollDelay: n.L,
                GroupsToken: n.G
            }
        }, updateGroups: function (n, t) {
            t && (n.groupsToken = t)
        }, stringifySend: function (n, t) {
            return typeof t == "string" || typeof t == "undefined" || t === null ? t : n.json.stringify(t)
        }, ajaxSend: function (f, e) {
            var h = u.stringifySend(f, e), o = f.url + "/send?transport=" + f.transport.name + "&connectionToken=" + t.encodeURIComponent(f.token), s = function (t, u) {
                n(u).triggerHandler(r.onError, [i._.transportError(i.resources.sendFailed, u.transport, t), e])
            };
            return o = u.prepareQueryString(f, o), n.ajax(n.extend({}, n.signalR.ajaxDefaults, {
                xhrFields: {withCredentials: f.withCredentials},
                url: o,
                type: f.ajaxDataType === "jsonp" ? "GET" : "POST",
                contentType: i._.defaultContentType,
                dataType: f.ajaxDataType,
                data: {data: h},
                success: function (t) {
                    var i;
                    if (t) {
                        try {
                            i = f._parseResponse(t)
                        } catch (u) {
                            s(u, f);
                            f.stop();
                            return
                        }
                        n(f).triggerHandler(r.onReceived, [i])
                    }
                },
                error: function (n, t) {
                    t !== "abort" && t !== "parsererror" && s(n, f)
                }
            }))
        }, ajaxAbort: function (i, r) {
            if (typeof i.transport != "undefined") {
                r = typeof r == "undefined" ? !0 : r;
                var f = i.url + "/abort?transport=" + i.transport.name + "&connectionToken=" + t.encodeURIComponent(i.token);
                f = u.prepareQueryString(i, f);
                n.ajax(n.extend({}, n.signalR.ajaxDefaults, {
                    xhrFields: {withCredentials: i.withCredentials},
                    url: f,
                    async: r,
                    timeout: 1e3,
                    type: "POST",
                    contentType: i.contentType,
                    dataType: i.ajaxDataType,
                    data: {}
                }));
                i.log("Fired ajax abort async = " + r + ".")
            }
        }, tryInitialize: function (n, t) {
            n.Initialized && t()
        }, processMessages: function (t, i, f) {
            var e, o = n(t);
            if (t.transport && t.transport.supportsKeepAlive && t.keepAliveData.activated && this.updateKeepAlive(t), i) {
                if (e = this.maximizePersistentResponse(i), e.Disconnect) {
                    t.log("Disconnect command received from server.");
                    t.stop(!1, !1);
                    return
                }
                this.updateGroups(t, e.GroupsToken);
                e.MessageId && (t.messageId = e.MessageId);
                e.Messages && (n.each(e.Messages, function (n, t) {
                    o.triggerHandler(r.onReceived, [t])
                }), u.tryInitialize(e, f))
            }
        }, monitorKeepAlive: function (t) {
            var i = t.keepAliveData, u = this;
            i.monitoring ? t.log("Tried to monitor keep alive but it's already being monitored.") : (i.monitoring = !0, u.updateKeepAlive(t), t.keepAliveData.reconnectKeepAliveUpdate = function () {
                u.updateKeepAlive(t)
            }, n(t).bind(r.onReconnect, t.keepAliveData.reconnectKeepAliveUpdate), t.log("Now monitoring keep alive with a warning timeout of " + i.timeoutWarning + " and a connection lost timeout of " + i.timeout + "."), f(t))
        }, stopMonitoringKeepAlive: function (t) {
            var i = t.keepAliveData;
            i.monitoring && (i.monitoring = !1, n(t).unbind(r.onReconnect, t.keepAliveData.reconnectKeepAliveUpdate), t.keepAliveData = {}, t.log("Stopping the monitoring of the keep alive."))
        }, updateKeepAlive: function (n) {
            n.keepAliveData.lastKeepAlive = new Date
        }, ensureReconnectingState: function (t) {
            return e(t, i.connectionState.connected, i.connectionState.reconnecting) === !0 && n(t).triggerHandler(r.onReconnecting), t.state === i.connectionState.reconnecting
        }, clearReconnectTimeout: function (n) {
            n && n._.reconnectTimeout && (t.clearTimeout(n._.reconnectTimeout), delete n._.reconnectTimeout)
        }, reconnect: function (n, r) {
            var u = i.transports[r], f = this;
            o(n) && !n._.reconnectTimeout && (n._.reconnectTimeout = t.setTimeout(function () {
                u.stop(n);
                f.ensureReconnectingState(n) && (n.log(r + " reconnecting."), u.start(n))
            }, n.reconnectDelay))
        }, handleParseFailure: function (t, u, f, e) {
            t.state === i.connectionState.connecting ? (t.log("Failed to parse server response while attempting to connect."), e()) : (n(t).triggerHandler(r.onError, [i._.transportError(i._.format(i.resources.parseFailed, u), t.transport, f)]), t.stop())
        }, foreverFrame: {count: 0, connections: {}}
    }
}(window.jQuery, window), function (n, t) {
    "use strict";
    var r = n.signalR, u = n.signalR.events, f = n.signalR.changeState, i = r.transports._logic;
    r.transports.webSockets = {
        name: "webSockets", supportsKeepAlive: !0, send: function (n, t) {
            var r = i.stringifySend(n, t);
            n.socket.send(r)
        }, start: function (e, o, s) {
            var h, c = !1, l = this, a = !o, v = n(e);
            if (!t.WebSocket) {
                s();
                return
            }
            e.socket || (h = e.webSocketServerUrl ? e.webSocketServerUrl : e.wsProtocol + e.host, h += i.getUrl(e, this.name, a), e.log("Connecting to websocket endpoint '" + h + "'."), e.socket = new t.WebSocket(h), e.socket.onopen = function () {
                c = !0;
                e.log("Websocket opened.");
                i.clearReconnectTimeout(e);
                f(e, r.connectionState.reconnecting, r.connectionState.connected) === !0 && v.triggerHandler(u.onReconnect)
            }, e.socket.onclose = function (t) {
                if (this === e.socket) {
                    if (c)typeof t.wasClean != "undefined" && t.wasClean === !1 ? (n(e).triggerHandler(u.onError, [r._.transportError(r.resources.webSocketClosed, e.transport, t)]), e.log("Unclean disconnect from websocket: " + t.reason || "[no reason given].")) : e.log("Websocket closed."); else {
                        s ? s() : a && l.reconnect(e);
                        return
                    }
                    l.reconnect(e)
                }
            }, e.socket.onmessage = function (t) {
                var r, f = n(e);
                try {
                    r = e._parseResponse(t.data)
                } catch (h) {
                    i.handleParseFailure(e, t.data, h, s);
                    return
                }
                r && (n.isEmptyObject(r) || r.M ? i.processMessages(e, r, o) : f.triggerHandler(u.onReceived, [r]))
            })
        }, reconnect: function (n) {
            i.reconnect(n, this.name)
        }, lostConnection: function (n) {
            this.reconnect(n)
        }, stop: function (n) {
            i.clearReconnectTimeout(n);
            n.socket && (n.log("Closing the Websocket."), n.socket.close(), n.socket = null)
        }, abort: function (n, t) {
            i.ajaxAbort(n, t)
        }
    }
}(window.jQuery, window), function (n, t) {
    "use strict";
    var i = n.signalR, u = n.signalR.events, f = n.signalR.changeState, r = i.transports._logic;
    i.transports.serverSentEvents = {
        name: "serverSentEvents",
        supportsKeepAlive: !0,
        timeOut: 3e3,
        start: function (e, o, s) {
            var h = this, c = !1, l = n(e), a = !o, v, y;
            if (e.eventSource && (e.log("The connection already has an event source. Stopping it."), e.stop()), !t.EventSource) {
                s && (e.log("This browser doesn't support SSE."), s());
                return
            }
            v = r.getUrl(e, this.name, a);
            try {
                e.log("Attempting to connect to SSE endpoint '" + v + "'.");
                e.eventSource = new t.EventSource(v)
            } catch (p) {
                e.log("EventSource failed trying to connect with error " + p.Message + ".");
                s ? s() : (l.triggerHandler(u.onError, [i._.transportError(i.resources.eventSourceFailedToConnect, e.transport, p)]), a && h.reconnect(e));
                return
            }
            a && (y = t.setTimeout(function () {
                c === !1 && e.eventSource.readyState !== t.EventSource.OPEN && h.reconnect(e)
            }, h.timeOut));
            e.eventSource.addEventListener("open", function () {
                e.log("EventSource connected.");
                y && t.clearTimeout(y);
                r.clearReconnectTimeout(e);
                c === !1 && (c = !0, f(e, i.connectionState.reconnecting, i.connectionState.connected) === !0 && l.triggerHandler(u.onReconnect))
            }, !1);
            e.eventSource.addEventListener("message", function (n) {
                var t;
                if (n.data !== "initialized") {
                    try {
                        t = e._parseResponse(n.data)
                    } catch (i) {
                        r.handleParseFailure(e, n.data, i, s);
                        return
                    }
                    r.processMessages(e, t, o)
                }
            }, !1);
            e.eventSource.addEventListener("error", function (n) {
                if (this === e.eventSource) {
                    if (!c) {
                        s && s();
                        return
                    }
                    e.log("EventSource readyState: " + e.eventSource.readyState + ".");
                    n.eventPhase === t.EventSource.CLOSED ? (e.log("EventSource reconnecting due to the server connection ending."), h.reconnect(e)) : (e.log("EventSource error."), l.triggerHandler(u.onError, [i._.transportError(i.resources.eventSourceError, e.transport, n)]))
                }
            }, !1)
        },
        reconnect: function (n) {
            r.reconnect(n, this.name)
        },
        lostConnection: function (n) {
            this.reconnect(n)
        },
        send: function (n, t) {
            r.ajaxSend(n, t)
        },
        stop: function (n) {
            r.clearReconnectTimeout(n);
            n && n.eventSource && (n.log("EventSource calling close()."), n.eventSource.close(), n.eventSource = null, delete n.eventSource)
        },
        abort: function (n, t) {
            r.ajaxAbort(n, t)
        }
    }
}(window.jQuery, window), function (n, t) {
    "use strict";
    var r = n.signalR, f = n.signalR.events, e = n.signalR.changeState, i = r.transports._logic, u = function () {
        var u = null, f = 1e3, i = 0;
        return {
            prevent: function () {
                r._.ieVersion <= 8 && (i === 0 && (u = t.setInterval(function () {
                    var t = n("<iframe style='position:absolute;top:0;left:0;width:0;height:0;visibility:hidden;' src=''><\/iframe>");
                    n("body").append(t);
                    t.remove();
                    t = null
                }, f)), i++)
            }, cancel: function () {
                i === 1 && t.clearInterval(u);
                i > 0 && i--
            }
        }
    }();
    r.transports.foreverFrame = {
        name: "foreverFrame",
        supportsKeepAlive: !0,
        iframeClearThreshold: 50,
        start: function (r, f, e) {
            var c = this, s = i.foreverFrame.count += 1, h, o = n("<iframe data-signalr-connection-id='" + r.id + "' style='position:absolute;top:0;left:0;width:0;height:0;visibility:hidden;' src=''><\/iframe>");
            if (t.EventSource) {
                e && (r.log("This browser supports SSE, skipping Forever Frame."), e());
                return
            }
            u.prevent();
            h = i.getUrl(r, this.name);
            h += "&frameId=" + s;
            n("body").append(o);
            o.prop("src", h);
            i.foreverFrame.connections[s] = r;
            r.log("Binding to iframe's readystatechange event.");
            o.bind("readystatechange", function () {
                n.inArray(this.readyState, ["loaded", "complete"]) >= 0 && (r.log("Forever frame iframe readyState changed to " + this.readyState + ", reconnecting."), c.reconnect(r))
            });
            r.frame = o[0];
            r.frameId = s;
            f && (r.onSuccess = function () {
                r.log("Iframe transport started.");
                f();
                delete r.onSuccess
            })
        },
        reconnect: function (n) {
            var r = this;
            t.setTimeout(function () {
                if (n.frame && i.ensureReconnectingState(n)) {
                    var u = n.frame, t = i.getUrl(n, r.name, !0) + "&frameId=" + n.frameId;
                    n.log("Updating iframe src to '" + t + "'.");
                    u.src = t
                }
            }, n.reconnectDelay)
        },
        lostConnection: function (n) {
            this.reconnect(n)
        },
        send: function (n, t) {
            i.ajaxSend(n, t)
        },
        receive: function (t, u) {
            var f;
            i.processMessages(t, u, t.onSuccess);
            t.state === n.signalR.connectionState.connected && (t.frameMessageCount = (t.frameMessageCount || 0) + 1, t.frameMessageCount > r.transports.foreverFrame.iframeClearThreshold && (t.frameMessageCount = 0, f = t.frame.contentWindow || t.frame.contentDocument, f && f.document && n("body", f.document).empty()))
        },
        stop: function (t) {
            var r = null;
            if (u.cancel(), t.frame) {
                if (t.frame.stop)t.frame.stop(); else try {
                    r = t.frame.contentWindow || t.frame.contentDocument;
                    r.document && r.document.execCommand && r.document.execCommand("Stop")
                } catch (f) {
                    t.log("Error occured when stopping foreverFrame transport. Message = " + f.message + ".")
                }
                n(t.frame).remove();
                delete i.foreverFrame.connections[t.frameId];
                t.frame = null;
                t.frameId = null;
                delete t.frame;
                delete t.frameId;
                delete t.onSuccess;
                delete t.frameMessageCount;
                t.log("Stopping forever frame.")
            }
        },
        abort: function (n, t) {
            i.ajaxAbort(n, t)
        },
        getConnection: function (n) {
            return i.foreverFrame.connections[n]
        },
        started: function (t) {
            e(t, r.connectionState.reconnecting, r.connectionState.connected) === !0 && n(t).triggerHandler(f.onReconnect)
        }
    }
}(window.jQuery, window), function (n, t) {
    "use strict";
    var r = n.signalR, u = n.signalR.events, e = n.signalR.changeState, f = n.signalR.isDisconnecting, i = r.transports._logic;
    r.transports.longPolling = {
        name: "longPolling",
        supportsKeepAlive: !1,
        reconnectDelay: 3e3,
        start: function (o, s, h) {
            var a = this, v = function () {
                v = n.noop;
                o.log("LongPolling connected.");
                s();
                h = null
            }, y = function () {
                return h ? (h(), h = null, o.log("LongPolling failed to connect."), !0) : !1
            }, c = o._, l = 0, p = function (i) {
                t.clearTimeout(c.reconnectTimeoutId);
                c.reconnectTimeoutId = null;
                e(i, r.connectionState.reconnecting, r.connectionState.connected) === !0 && (i.log("Raising the reconnect event"), n(i).triggerHandler(u.onReconnect))
            }, w = 36e5;
            o.pollXhr && (o.log("Polling xhr requests already exists, aborting."), o.stop());
            o.messageId = null;
            c.reconnectTimeoutId = null;
            c.pollTimeoutId = t.setTimeout(function () {
                (function e(s, h) {
                    var d = s.messageId, g = d === null, b = !g, nt = !h, k = i.getUrl(s, a.name, b, nt);
                    f(s) !== !0 && (o.log("Opening long polling request to '" + k + "'."), s.pollXhr = n.ajax(n.extend({}, n.signalR.ajaxDefaults, {
                        xhrFields: {withCredentials: o.withCredentials},
                        url: k,
                        type: "GET",
                        dataType: o.ajaxDataType,
                        contentType: o.contentType,
                        success: function (r) {
                            var h, w = 0, u, a;
                            o.log("Long poll complete.");
                            l = 0;
                            try {
                                h = o._parseResponse(r)
                            } catch (b) {
                                i.handleParseFailure(s, r, b, y);
                                return
                            }
                            (c.reconnectTimeoutId !== null && p(s), h && (u = i.maximizePersistentResponse(h)), i.processMessages(s, h, v), u && n.type(u.LongPollDelay) === "number" && (w = u.LongPollDelay), u && u.Disconnect) || f(s) !== !0 && (a = u && u.ShouldReconnect, !a || i.ensureReconnectingState(s)) && (w > 0 ? c.pollTimeoutId = t.setTimeout(function () {
                                e(s, a)
                            }, w) : e(s, a))
                        },
                        error: function (f, h) {
                            if (t.clearTimeout(c.reconnectTimeoutId), c.reconnectTimeoutId = null, h === "abort") {
                                o.log("Aborted xhr request.");
                                return
                            }
                            if (!y()) {
                                if (l++, o.state !== r.connectionState.reconnecting && (o.log("An error occurred using longPolling. Status = " + h + ".  Response = " + f.responseText + "."), n(s).triggerHandler(u.onError, [r._.transportError(r.resources.longPollFailed, o.transport, f)])), !i.ensureReconnectingState(s))return;
                                c.pollTimeoutId = t.setTimeout(function () {
                                    e(s, !0)
                                }, a.reconnectDelay)
                            }
                        }
                    })), b && h === !0 && (c.reconnectTimeoutId = t.setTimeout(function () {
                        p(s)
                    }, Math.min(1e3 * (Math.pow(2, l) - 1), w))))
                })(o)
            }, 250)
        },
        lostConnection: function () {
            throw new Error("Lost Connection not handled for LongPolling");
        },
        send: function (n, t) {
            i.ajaxSend(n, t)
        },
        stop: function (n) {
            t.clearTimeout(n._.pollTimeoutId);
            t.clearTimeout(n._.reconnectTimeoutId);
            delete n._.pollTimeoutId;
            delete n._.reconnectTimeoutId;
            n.pollXhr && (n.pollXhr.abort(), n.pollXhr = null, delete n.pollXhr)
        },
        abort: function (n, t) {
            i.ajaxAbort(n, t)
        }
    }
}(window.jQuery, window), function (n, t) {
    "use strict";
    function u(n) {
        return n + o
    }

    function h(n, t, i) {
        for (var f = n.length, u = [], r = 0; r < f; r += 1)n.hasOwnProperty(r) && (u[r] = t.call(i, n[r], r, n));
        return u
    }

    function c(t) {
        return n.isFunction(t) ? null : n.type(t) === "undefined" ? null : t
    }

    function f(n) {
        for (var t in n)if (n.hasOwnProperty(t))return !0;
        return !1
    }

    function e(n, t) {
        var i = n._.invocationCallbacks, r, u;
        f(i) && n.log("Clearing hub invocation callbacks with error: " + t + ".");
        n._.invocationCallbackId = 0;
        delete n._.invocationCallbacks;
        n._.invocationCallbacks = {};
        for (u in i)r = i[u], r.method.call(r.scope, {E: t})
    }

    function r(n, t) {
        return new r.fn.init(n, t)
    }

    function i(t, r) {
        var u = {qs: null, logging: !1, useDefaultPath: !0};
        return n.extend(u, r), (!t || u.useDefaultPath) && (t = (t || "") + "/signalr"), new i.fn.init(t, u)
    }

    var o = ".hubProxy", s = n.signalR;
    r.fn = r.prototype = {
        init: function (n, t) {
            this.state = {};
            this.connection = n;
            this.hubName = t;
            this._ = {callbackMap: {}}
        }, hasSubscriptions: function () {
            return f(this._.callbackMap)
        }, on: function (t, i) {
            var r = this, f = r._.callbackMap;
            return t = t.toLowerCase(), f[t] || (f[t] = {}), f[t][i] = function (n, t) {
                i.apply(r, t)
            }, n(r).bind(u(t), f[t][i]), r
        }, off: function (t, i) {
            var e = this, o = e._.callbackMap, r;
            return t = t.toLowerCase(), r = o[t], r && (r[i] ? (n(e).unbind(u(t), r[i]), delete r[i], f(r) || delete o[t]) : i || (n(e).unbind(u(t)), delete o[t])), e
        }, invoke: function (t) {
            var i = this, r = i.connection, e = n.makeArray(arguments).slice(1), o = h(e, c), f = {
                H: i.hubName,
                M: t,
                A: o,
                I: r._.invocationCallbackId
            }, u = n.Deferred(), l = function (t) {
                var f = i._maximizeHubResponse(t), o, e;
                n.extend(i.state, f.State);
                f.Error ? (f.StackTrace && r.log(f.Error + "\n" + f.StackTrace + "."), o = f.IsHubException ? "HubException" : "Exception", e = s._.error(f.Error, o), e.data = f.ErrorData, u.rejectWith(i, [e])) : u.resolveWith(i, [f.Result])
            };
            return r._.invocationCallbacks[r._.invocationCallbackId.toString()] = {
                scope: i,
                method: l
            }, r._.invocationCallbackId += 1, n.isEmptyObject(i.state) || (f.S = i.state), r.send(f), u.promise()
        }, _maximizeHubResponse: function (n) {
            return {State: n.S, Result: n.R, Id: n.I, IsHubException: n.H, Error: n.E, StackTrace: n.T, ErrorData: n.D}
        }
    };
    r.fn.init.prototype = r.fn;
    i.fn = i.prototype = n.connection();
    i.fn.init = function (i, r) {
        var o = {qs: null, logging: !1, useDefaultPath: !0}, f = this;
        n.extend(o, r);
        n.signalR.fn.init.call(f, i, o.qs, o.logging);
        f.proxies = {};
        f._.invocationCallbackId = 0;
        f._.invocationCallbacks = {};
        f.received(function (t) {
            var i, o, r, e, s, h;
            t && (typeof t.I != "undefined" ? (r = t.I.toString(), e = f._.invocationCallbacks[r], e && (f._.invocationCallbacks[r] = null, delete f._.invocationCallbacks[r], e.method.call(e.scope, t))) : (i = this._maximizeClientHubInvocation(t), f.log("Triggering client hub event '" + i.Method + "' on hub '" + i.Hub + "'."), s = i.Hub.toLowerCase(), h = i.Method.toLowerCase(), o = this.proxies[s], n.extend(o.state, i.State), n(o).triggerHandler(u(h), [i.Args])))
        });
        f.error(function (n, i) {
            var u, r, e;
            if ((!f.transport || f.transport.name !== "webSockets") && i) {
                try {
                    if (u = t.JSON.parse(i), !u.I)return
                } catch (o) {
                    return
                }
                r = u.I;
                e = f._.invocationCallbacks[r];
                e.method.call(e.scope, {E: n});
                f._.invocationCallbacks[r] = null;
                delete f._.invocationCallbacks[r]
            }
        });
        f.reconnecting(function () {
            f.transport && f.transport.name === "webSockets" && e(f, "Connection started reconnecting before invocation result was received.")
        });
        f.disconnected(function () {
            e(f, "Connection was disconnected before invocation result was received.")
        })
    };
    i.fn._maximizeClientHubInvocation = function (n) {
        return {Hub: n.H, Method: n.M, Args: n.A, State: n.S}
    };
    i.fn._registerSubscribedHubs = function () {
        var t = this;
        t._subscribedToHubs || (t._subscribedToHubs = !0, t.starting(function () {
            var i = [];
            n.each(t.proxies, function (n) {
                this.hasSubscriptions() && (i.push({name: n}), t.log("Client subscribed to hub '" + n + "'."))
            });
            i.length === 0 && t.log("No hubs have been subscribed to.  The client will not receive data from hubs.  To fix, declare at least one client side function prior to connection start for each hub you wish to subscribe to.");
            t.data = t.json.stringify(i)
        }))
    };
    i.fn.createHubProxy = function (n) {
        n = n.toLowerCase();
        var t = this.proxies[n];
        return t || (t = r(this, n), this.proxies[n] = t), this._registerSubscribedHubs(), t
    };
    i.fn.init.prototype = i.fn;
    n.hubConnection = i
}(window.jQuery, window), function (n) {
    n.signalR.version = "2.0.1"
}(window.jQuery);
window.__AUTH == 1 && $(function () {
    var t = $.hubConnection(), n = t.createHubProxy("messageHub");
    n.on("notifyMessagesRead", function (n, t) {
        n == 0 && Number($("#chattingwith").val()) == t && $(".readornot").html("Read&nbsp;&nbsp;&middot;&nbsp;")
    });
    n.on("notifyMessagesReadSelf", function (n, t) {
        n == 0 && ($("#totalCountInBoxUnread").text(t), t > 0 ? ($("#totalCountInBoxUnread").parent().show(), $("#messages-link").attr("href", "/messages/unread")) : ($("#totalCountInBoxUnread").parent().hide(), $("#messages-link").attr("href", "/messages")), $("#totalCountInBoxUnread-mobile").text(t), t > 0 ? ($("#totalCountInBoxUnread-mobile").parent().show(), $("#messages-link-mobile").attr("href", "/messages/unread")) : ($("#totalCountInBoxUnread-mobile").parent().hide(), $("#messages-link-mobile").attr("href", "/messages")))
    });
    n.on("notifyVisitReadSelf", function (n) {
        n == 0 && ($("#visitsReceivedUnreadCount").parent().hide(), $("#visitsReceivedUnreadCount-mobile").parent().hide())
    });
    n.on("notifyInterestReadSelf", function (n) {
        n == 0 && ($("#interestsReceivedUnreadCount").parent().hide(), $("#interestsReceivedUnreadCount-mobile").parent().hide())
    });
    n.on("notifyVisit", function (n, t, i, r, u) {
        n == 0 && (alertifyEx.log(t, i, r, "just visited your profile"), $("#visitsReceivedUnreadCount").text(u), u > 0 ? $("#visitsReceivedUnreadCount").parent().show() : $("#visitsReceivedUnreadCount").parent().hide(), $("#visitsReceivedUnreadCount-mobile").text(u), u > 0 ? $("#visitsReceivedUnreadCount-mobile").parent().show() : $("#visitsReceivedUnreadCount-mobile").parent().hide())
    });
    n.on("notifyInterest", function (n, t, i, r, u) {
        n == 0 && (alertifyEx.log(t, i, r, "is interested in you"), $("#interestsReceivedUnreadCount").text(u), u > 0 ? $("#interestsReceivedUnreadCount").parent().show() : $("#interestsReceivedUnreadCount").parent().hide(), $("#interestsReceivedUnreadCount-mobile").text(u), u > 0 ? $("#interestsReceivedUnreadCount-mobile").parent().show() : $("#interestsReceivedUnreadCount-mobile").parent().hide())
    });
    n.on("notifyMessage", function (n, t, i, r, u, f, e) {
        n == 0 && (Number($("#chattingwith").val()) != t ? (e && playNotificationSound(), alertifyEx.log(i, r, u, "just sent you a new message"), $("#totalCountInBoxUnread").text(f), f > 0 ? ($("#totalCountInBoxUnread").parent().show(), $("#messages-link").attr("href", "/messages/unread")) : ($("#totalCountInBoxUnread").parent().hide(), $("#messages-link").attr("href", "/messages")), $("#totalCountInBoxUnread-mobile").text(f), f > 0 ? ($("#totalCountInBoxUnread-mobile").parent().show(), $("#messages-link-mobile").attr("href", "/messages/unread")) : ($("#totalCountInBoxUnread-mobile").parent().hide(), $("#messages-link-mobile").attr("href", "/messages"))) : typeof loadLastMessages == "function" && loadLastMessages(!1, e))
    });
    t.logging = !0;
    t.start({waitForPageLoad: !1})
});
alertifyEx = {
    log: function (n, t, i, r) {
        window.innerWidth <= 640 && window.location.href.toLocaleLowerCase().indexOf("/chat/") != -1 || alertify.log('<div class="fixed-table"><div><div><a href="/' + i + '"><div class="clearfix"><div class="left"><img class="mr" style="width: 40px" src="' + t + '"/><\/div><div class=left><b>' + n + "<\/b><br />" + r + '<\/div><\/div><\/a><\/div><div><i class="fa fa-times-circle fa-3x pointer"><\/i><\/div><\/div><\/div>', "", 7e3)
    }, whatever: function () {
    }
};
window.initialTime = (new Date).getTime();
addOnLoadEvent(setDesignCookies);
addOnResizeEvent(setDesignCookies);
ajaxForm = {
    getIframeInnerHTML: function (n) {
        var t = n.contentDocument || n.contentWindow.document;
        return t.body.innerHTML
    }, supportsFileAPI: function () {
        var n = document.createElement("INPUT");
        return n.type = "file", "files" in n
    }, supportsAjaxUploadProgressEvents: function () {
        var n = new XMLHttpRequest;
        return !!(n && "upload" in n && "onprogress" in n.upload)
    }, supportsFormData: function () {
        return !!window.FormData
    }, supportAjaxUploadWithProgress: function () {
        return supportsFileAPI() && supportsAjaxUploadProgressEvents() && supportsFormData()
    }, submit: function (n, t, i) {
        var u, f, r;
        ajaxForm.supportsFormData() ? (u = document.getElementById(n), u.target = "", f = new FormData(u), r = new XMLHttpRequest, r.upload.onprogress = t, r.onreadystatechange = function () {
            r.readyState === 4 && r.status === 200 && i(r.responseText)
        }, r.open("POST", u.action, !0), r.send(f)) : document.getElementById(n).submit();
        document.getElementById(n).reset()
    }
};
chatHelper = {
    autoResizeTextArea: function (n, t) {
        var i, u, r;
        try {
            t == null && (t = "__dummyTA");
            i = document.getElementById(t);
            window.dummyData == null && (window.dummyData = !0, i.style.width = n.offsetWidth + "px", i.style.border = n.style.border, i.style.borderRadius = n.style.borderRadius, i.style.padding = n.style.padding, i.style.fontSize = n.style.fontSize, i.style.fontWeight = n.style.fontWeight, i.style.overflow = n.style.overflow);
            i.innerHTML = n.value;
            u = 2;
            r = i.scrollHeight + u;
            (r < parseInt(n.style.height) || r > parseInt(n.style.height)) && (n.style.height = r + "px");
            n.style.height = r + "px"
        } catch (f) {
        }
    }, fix_chrome_issue: function (n) {
        try {
            var t = n.split("<\/script>");
            if (t.length === 2)return t[1]
        } catch (i) {
        }
        return n
    }, sendMessage: function (n) {
        if (!($("#message").val().length < 1)) {
            $(n).hide();
            $("#waitstuff").css("display", "inline-block");
            var t = $.post("", $("#message-form").serialize());
            t.done(function (t) {
                t && (t = chatHelper.fix_chrome_issue(t), $("#message").val(""), chatHelper.autoResizeTextArea($("#message")[0]), $(n).show(), $("#waitstuff").hide(), t.indexOf("timestamp") !== -1 ? (t = t.replace('data-co="0" class="timestamp">', 'data-co="' + (new Date).getTime() + '" class="timestamp">'), $("#messages").prepend(t)) : alert(t))
            }, "html")
        }
    }, loadOlderMessages: function () {
        try {
            $("#loadmorebutton").hide();
            $("#loadmorewait").show();
            var n = Number($('#messages [id^="message_"]').last().attr("id").substring(8));
            $.get("/account/loadoldermessages2/" + n, function (n) {
                n = n.replace('data-co="0" class="timestamp">', 'data-co="' + (new Date).getTime() + '" class="timestamp">');
                $("#messages").append(n);
                $("#loadnomore").length ? $("#loadmore").hide() : $("#loadmorebutton").show();
                $("#loadmorewait").hide()
            }, "html")
        } catch (t) {
        }
    }, loadLastMessages: function (n) {
        var t = Number($('#messages [id^="message_"]').first().attr("id").substring(8));
        $.get("/account/loadlastmessages2/" + t + "/" + Number($("#chattingwith").val()), function (t) {
            n && playNotificationSound();
            t = t.replace('data-co="0" class="timestamp">', 'data-co="' + (new Date).getTime() + '" class="timestamp">');
            $("#messages").prepend(t)
        }, "html");
        $("#unreadbutton").show()
    }, onprogressHandler: function (n) {
        var t = Math.round(n.loaded / n.total * 100);
        console.log("Upload progress: " + t + "%");
        $("#progress-info").text(t + "%")
    }, processReturnedData: function (n) {
        n = chatHelper.fix_chrome_issue(n);
        n.indexOf("timestamp") !== -1 ? (n = n.replace('data-co="0" class="timestamp">', 'data-co="' + (new Date).getTime() + '" class="timestamp">'), $("#messages").prepend(n)) : n.length && alert(n)
    }, onAjaxSubmitReady: function (n) {
        chatHelper.processReturnedData(n)
    }, onIframeSubmitReady: function (n) {
        chatHelper.processReturnedData(ajaxForm.getIframeInnerHTML(n))
    }
};
TINY = {};
TINY.box = function () {
    $("body").on("keydown", function (n) {
        switch (n.which) {
            case 27:
                n.preventDefault();
                TINY.box.hide()
        }
    });
    var n, i, t, r, u, f, e, o, s = 0;
    return {
        show: function (h, c, l, a, v, y) {
            s || (n = document.createElement("div"), n.id = "tinybox", i = document.createElement("div"), i.id = "tinymask", t = document.createElement("div"), t.id = "tinycontent", document.body.appendChild(i), document.body.appendChild(n), n.appendChild(t), i.onclick = TINY.box.hide, s = 1);
            v || c ? (t.style.display = "none", n.style.width = n.style.height = "100px") : (n.style.width = l ? l + "px" : "auto", n.style.height = a ? a + "px" : "auto", n.style.backgroundImage = "none", t.innerHTML = h);
            this.mask();
            r = h;
            u = c;
            f = l;
            e = a;
            o = v;
            this.alpha(i, 1, 90, 1);
            y && setTimeout(function () {
                TINY.box.hide()
            }, 1e3 * y)
        }, fill: function (t, i, r, u, f) {
            if (i) {
                n.style.backgroundImage = "";
                var e = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
                e.onreadystatechange = function () {
                    e.readyState == 4 && e.status == 200 && TINY.box.psh(e.responseText, r, u, f)
                };
                e.open("GET", t, 1);
                e.send(null)
            } else this.psh(t, r, u, f)
        }, psh: function (i, r, u, f) {
            if (f) {
                if (r && u)t.innerHTML = i; else {
                    var e = n.style.width, o = n.style.height;
                    t.innerHTML = i;
                    n.style.width = r ? r + "px" : "";
                    n.style.height = u ? u + "px" : "";
                    t.style.display = "";
                    r = parseInt(t.offsetWidth);
                    u = parseInt(t.offsetHeight);
                    t.style.display = "none";
                    n.style.width = e;
                    n.style.height = o
                }
                this.size(n, r, u, 1)
            } else n.style.backgroundImage = "none"
        }, hide: function () {
            TINY.box.alpha(n, -1, 0, 1)
        }, resize: function () {
            TINY.box.pos();
            TINY.box.mask()
        }, mask: function () {
            i.style.height = TINY.page.theight() + "px"
        }, pos: function () {
            var t = TINY.page.height() / 3 - n.offsetHeight / 2;
            t = t < 10 ? 10 : t;
            n.style.top = t + TINY.page.top() + "px";
            n.style.left = TINY.page.width() / 2 - n.offsetWidth / 2 + "px"
        }, alpha: function (n, t, i, r) {
            clearInterval(n.ai);
            t == 1 && (n.style.opacity = 0, n.style.filter = "alpha(opacity=0)", n.style.display = "block", this.pos());
            n.ai = setInterval(function () {
                TINY.box.twalpha(n, i, t, r)
            }, 1)
        }, twalpha: function (s, h, c, l) {
            var a = Math.round(s.style.opacity * 100), v;
            a == h ? (clearInterval(s.ai), c == -1 ? (s.style.display = "none", s == n ? TINY.box.alpha(i, -1, 0, 1) : t.innerHTML = n.style.backgroundImage = "") : s == i ? this.alpha(n, 1, 100, 1) : TINY.box.fill(r, u, f, e, o)) : (v = a + Math.ceil(Math.abs(h - a) / l) * c, s.style.opacity = v / 100, s.style.filter = "alpha(opacity=" + v + ")")
        }, size: function (n, t, i, r) {
            n = typeof n == "object" ? n : T$(n);
            clearInterval(n.si);
            var u = n.offsetWidth, f = n.offsetHeight, e = u - parseInt(n.style.width), o = f - parseInt(n.style.height), s = u - e > t ? -1 : 1, h = f - o > i ? -1 : 1;
            n.si = setInterval(function () {
                TINY.box.twsize(n, t, e, s, i, o, h, r)
            }, 1)
        }, twsize: function (i, r, u, f, e, o, s, h) {
            var c = i.offsetWidth - u, l = i.offsetHeight - o;
            c == r && l == e ? (clearInterval(i.si), n.style.backgroundImage = "none", t.style.display = "block") : (c != r && (i.style.width = c + Math.ceil(Math.abs(r - c) / h) * f + "px"), l != e && (i.style.height = l + Math.ceil(Math.abs(e - l) / h) * s + "px"), this.pos())
        }
    }
}();
TINY.page = function () {
    return {
        top: function () {
            return document.body.scrollTop || document.documentElement.scrollTop
        }, width: function () {
            return self.innerWidth || document.documentElement.clientWidth
        }, height: function () {
            return self.innerHeight || document.documentElement.clientHeight
        }, theight: function () {
            var n = document, t = n.body, i = n.documentElement;
            return Math.max(Math.max(t.scrollHeight, i.scrollHeight), Math.max(t.clientHeight, i.clientHeight))
        }, twidth: function () {
            var n = document, t = n.body, i = n.documentElement;
            return Math.max(Math.max(t.scrollWidth, i.scrollWidth), Math.max(t.clientWidth, i.clientWidth))
        }
    }
}();
!function (n, t) {
    "use strict";
    var r, i = n.document;
    r = function () {
        var e, c, l, y, w, b, k, h, f, r, g, o, d, u = {}, s = {}, v = !1, p = {ENTER: 13, ESC: 27, SPACE: 32}, a = [];
        return s = {
            buttons: {
                holder: '<nav class="alertify-buttons">{{buttons}}<\/nav>',
                submit: '<button type="submit" class="alertify-button alertify-button-ok" id="alertify-ok">{{ok}}<\/button>',
                ok: '<button class="alertify-button alertify-button-ok" id="alertify-ok">{{ok}}<\/button>',
                cancel: '<button class="alertify-button alertify-button-cancel" id="alertify-cancel">{{cancel}}<\/button>'
            },
            input: '<div class="alertify-text-wrapper"><input type="text" class="alertify-text" id="alertify-text"><\/div>',
            message: '<p class="alertify-message">{{message}}<\/p>',
            log: '<article class="alertify-log{{class}}">{{message}}<\/article>'
        }, d = function () {
            var n, r, u = !1, e = i.createElement("fakeelement"), f = {
                WebkitTransition: "webkitTransitionEnd",
                MozTransition: "transitionend",
                OTransition: "otransitionend",
                transition: "transitionend"
            };
            for (n in f)if (e.style[n] !== t) {
                r = f[n];
                u = !0;
                break
            }
            return {type: r, supported: u}
        }, e = function (n) {
            return i.getElementById(n)
        }, u = {
            labels: {ok: "OK", cancel: "Cancel"},
            delay: 5e3,
            buttonReverse: !1,
            buttonFocus: "ok",
            transition: t,
            addListeners: function (n) {
                var r, u, s, h, f, v = "undefined" != typeof l, e = "undefined" != typeof c, a = "undefined" != typeof o, b = "", t = this;
                r = function (t) {
                    return "undefined" != typeof t.preventDefault && t.preventDefault(), s(t), "undefined" != typeof o && (b = o.value), "function" == typeof n && ("undefined" != typeof o ? n(!0, b) : n(!0)), !1
                };
                u = function (t) {
                    return "undefined" != typeof t.preventDefault && t.preventDefault(), s(t), "function" == typeof n && n(!1), !1
                };
                s = function () {
                    t.hide();
                    t.unbind(i.body, "keyup", h);
                    t.unbind(y, "focus", f);
                    v && t.unbind(l, "click", r);
                    e && t.unbind(c, "click", u)
                };
                h = function (n) {
                    var t = n.keyCode;
                    (t === p.SPACE && !a || a && t === p.ENTER) && r(n);
                    t === p.ESC && e && u(n)
                };
                f = function () {
                    a ? o.focus() : !e || t.buttonReverse ? l.focus() : c.focus()
                };
                this.bind(y, "focus", f);
                this.bind(w, "focus", f);
                v && this.bind(l, "click", r);
                e && this.bind(c, "click", u);
                this.bind(i.body, "keyup", h);
                this.transition.supported || this.setFocus()
            },
            bind: function (n, t, i) {
                "function" == typeof n.addEventListener ? n.addEventListener(t, i, !1) : n.attachEvent && n.attachEvent("on" + t, i)
            },
            handleErrors: function () {
                if ("undefined" != typeof n.onerror) {
                    var t = this;
                    return n.onerror = function (n, i, r) {
                        t.error("[" + n + " on line " + r + " of " + i + "]", 0)
                    }, !0
                }
                return !1
            },
            appendButtons: function (n, t) {
                return this.buttonReverse ? t + n : n + t
            },
            build: function (n) {
                var t = "", i = n.type, r = n.message, e = n.cssClass || "";
                switch (t += '<div class="alertify-dialog">', t += '<a id="alertify-resetFocusBack" class="alertify-resetFocus" href="#">Reset Focus<\/a>', "none" === u.buttonFocus && (t += '<a href="#" id="alertify-noneFocus" class="alertify-hidden"><\/a>'), "prompt" === i && (t += '<div id="alertify-form">'), t += '<article class="alertify-inner">', t += s.message.replace("{{message}}", r), "prompt" === i && (t += s.input), t += s.buttons.holder, t += "<\/article>", "prompt" === i && (t += "<\/div>"), t += '<a id="alertify-resetFocus" class="alertify-resetFocus" href="#">Reset Focus<\/a>', t += "<\/div>", i) {
                    case"confirm":
                        t = t.replace("{{buttons}}", this.appendButtons(s.buttons.cancel, s.buttons.ok));
                        t = t.replace("{{ok}}", this.labels.ok).replace("{{cancel}}", this.labels.cancel);
                        break;
                    case"prompt":
                        t = t.replace("{{buttons}}", this.appendButtons(s.buttons.cancel, s.buttons.submit));
                        t = t.replace("{{ok}}", this.labels.ok).replace("{{cancel}}", this.labels.cancel);
                        break;
                    case"alert":
                        t = t.replace("{{buttons}}", s.buttons.ok);
                        t = t.replace("{{ok}}", this.labels.ok)
                }
                return f.className = "alertify alertify-" + i + " " + e, h.className = "alertify-cover", t
            },
            close: function (n, t) {
                var u, f, e = t && !isNaN(t) ? +t : this.delay, i = this;
                this.bind(n, "click", function () {
                    u(n)
                });
                f = function (n) {
                    n.stopPropagation();
                    i.unbind(this, i.transition.type, f);
                    r.removeChild(this);
                    r.hasChildNodes() || (r.className += " alertify-logs-hidden")
                };
                u = function (n) {
                    "undefined" != typeof n && n.parentNode === r && (i.transition.supported ? (i.bind(n, i.transition.type, f), n.className += " alertify-log-hide") : (r.removeChild(n), r.hasChildNodes() || (r.className += " alertify-logs-hidden")))
                };
                0 !== t && setTimeout(function () {
                    u(n)
                }, e)
            },
            dialog: function (n, t, u, f, e) {
                k = i.activeElement;
                var o = function () {
                    r && null !== r.scrollTop && h && null !== h.scrollTop || o()
                };
                if ("string" != typeof n)throw new Error("message must be a string");
                if ("string" != typeof t)throw new Error("type must be a string");
                if ("undefined" != typeof u && "function" != typeof u)throw new Error("fn must be a function");
                return this.init(), o(), a.push({
                    type: t,
                    message: n,
                    callback: u,
                    placeholder: f,
                    cssClass: e
                }), v || this.setup(), this
            },
            extend: function (n) {
                if ("string" != typeof n)throw new Error("extend method must have exactly one paramter");
                return function (t, i) {
                    return this.log(t, n, i), this
                }
            },
            hide: function () {
                var n, t = this;
                a.splice(0, 1);
                a.length > 0 ? this.setup(!0) : (v = !1, n = function (i) {
                    i.stopPropagation();
                    t.unbind(f, t.transition.type, n)
                }, this.transition.supported ? (this.bind(f, this.transition.type, n), f.className = "alertify alertify-hide alertify-hidden") : f.className = "alertify alertify-hide alertify-hidden alertify-isHidden", h.className = "alertify-cover alertify-cover-hidden", k.focus())
            },
            init: function () {
                i.createElement("nav");
                i.createElement("article");
                i.createElement("section");
                null == e("alertify-cover") && (h = i.createElement("div"), h.setAttribute("id", "alertify-cover"), h.className = "alertify-cover alertify-cover-hidden", i.body.appendChild(h));
                null == e("alertify") && (v = !1, a = [], f = i.createElement("section"), f.setAttribute("id", "alertify"), f.className = "alertify alertify-hidden", i.body.appendChild(f));
                null == e("alertify-logs") && (r = i.createElement("section"), r.setAttribute("id", "alertify-logs"), r.className = "alertify-logs alertify-logs-hidden", i.body.appendChild(r));
                i.body.setAttribute("tabindex", "0");
                this.transition = d()
            },
            log: function (n, t, i) {
                var u = function () {
                    r && null !== r.scrollTop || u()
                };
                return this.init(), u(), r.className = "alertify-logs", this.notify(n, t, i), this
            },
            notify: function (n, t, u) {
                var f = i.createElement("article");
                f.className = "alertify-log" + ("string" == typeof t && "" !== t ? " alertify-log-" + t : "");
                f.innerHTML = n;
                r.appendChild(f);
                setTimeout(function () {
                    f.className = f.className + " alertify-log-show"
                }, 50);
                this.close(f, u)
            },
            set: function (n) {
                var t;
                if ("object" != typeof n && n instanceof Array)throw new Error("args must be an object");
                for (t in n)n.hasOwnProperty(t) && (this[t] = n[t])
            },
            setFocus: function () {
                o ? (o.focus(), o.select()) : b.focus()
            },
            setup: function (n) {
                var r, i = a[0], s = this;
                v = !0;
                r = function (n) {
                    n.stopPropagation();
                    s.setFocus();
                    s.unbind(f, s.transition.type, r)
                };
                this.transition.supported && !n && this.bind(f, this.transition.type, r);
                f.innerHTML = this.build(i);
                y = e("alertify-resetFocus");
                w = e("alertify-resetFocusBack");
                l = e("alertify-ok") || t;
                c = e("alertify-cancel") || t;
                b = "cancel" === u.buttonFocus ? c : "none" === u.buttonFocus ? e("alertify-noneFocus") : l;
                o = e("alertify-text") || t;
                g = e("alertify-form") || t;
                "string" == typeof i.placeholder && "" !== i.placeholder && (o.value = i.placeholder);
                n && this.setFocus();
                this.addListeners(i.callback)
            },
            unbind: function (n, t, i) {
                "function" == typeof n.removeEventListener ? n.removeEventListener(t, i, !1) : n.detachEvent && n.detachEvent("on" + t, i)
            }
        }, {
            alert: function (n, t, i) {
                return u.dialog(n, "alert", t, "", i), this
            }, confirm: function (n, t, i) {
                return u.dialog(n, "confirm", t, "", i), this
            }, extend: u.extend, init: u.init, log: function (n, t, i) {
                return u.log(n, t, i), this
            }, prompt: function (n, t, i, r) {
                return u.dialog(n, "prompt", t, i, r), this
            }, success: function (n, t) {
                return u.log(n, "success", t), this
            }, error: function (n, t) {
                return u.log(n, "error", t), this
            }, set: function (n) {
                u.set(n)
            }, labels: u.labels, debug: u.handleErrors
        }
    };
    "function" == typeof define ? define([], function () {
        return new r
    }) : "undefined" == typeof n.alertify && (n.alertify = new r)
}(this), function (n) {
    function r() {
    }

    function t(n) {
        function u(t) {
            t.prototype.option || (t.prototype.option = function (t) {
                n.isPlainObject(t) && (this.options = n.extend(!0, this.options, t))
            })
        }

        function f(r, u) {
            n.fn[r] = function (f) {
                var h, o, c, l, e, s;
                if (typeof f == "string") {
                    for (h = i.call(arguments, 1), o = 0, c = this.length; o < c; o++) {
                        if (l = this[o], e = n.data(l, r), !e) {
                            t("cannot call methods on " + r + " prior to initialization; attempted to call '" + f + "'");
                            continue
                        }
                        if (!n.isFunction(e[f]) || f.charAt(0) === "_") {
                            t("no such method '" + f + "' for " + r + " instance");
                            continue
                        }
                        if (s = e[f].apply(e, h), s !== undefined)return s
                    }
                    return this
                }
                return this.each(function () {
                    var t = n.data(this, r);
                    t ? (t.option(f), t._init()) : (t = new u(this, f), n.data(this, r, t))
                })
            }
        }

        if (n) {
            var t = typeof console == "undefined" ? r : function (n) {
                console.error(n)
            };
            return n.bridget = function (n, t) {
                u(t);
                f(n, t)
            }, n.bridget
        }
    }

    var i = Array.prototype.slice;
    typeof define == "function" && define.amd ? define("jquery-bridget/jquery.bridget", ["jquery"], t) : typeof exports == "object" ? t(require("jquery")) : t(n.jQuery)
}(window), function (n) {
    function f(t) {
        var i = n.event;
        return i.target = i.target || i.srcElement || t, i
    }

    var t = document.documentElement, u = function () {
    }, i, r;
    t.addEventListener ? u = function (n, t, i) {
        n.addEventListener(t, i, !1)
    } : t.attachEvent && (u = function (n, t, i) {
        n[t + i] = i.handleEvent ? function () {
            var t = f(n);
            i.handleEvent.call(i, t)
        } : function () {
            var t = f(n);
            i.call(n, t)
        };
        n.attachEvent("on" + t, n[t + i])
    });
    i = function () {
    };
    t.removeEventListener ? i = function (n, t, i) {
        n.removeEventListener(t, i, !1)
    } : t.detachEvent && (i = function (n, t, i) {
        n.detachEvent("on" + t, n[t + i]);
        try {
            delete n[t + i]
        } catch (r) {
            n[t + i] = undefined
        }
    });
    r = {bind: u, unbind: i};
    typeof define == "function" && define.amd ? define("eventie/eventie", r) : typeof exports == "object" ? module.exports = r : n.eventie = r
}(window), function () {
    function t() {
    }

    function u(n, t) {
        for (var i = n.length; i--;)if (n[i].listener === t)return i;
        return -1
    }

    function i(n) {
        return function () {
            return this[n].apply(this, arguments)
        }
    }

    var n = t.prototype, r = this, f = r.EventEmitter;
    n.getListeners = function (n) {
        var t = this._getEvents(), r, i;
        if (n instanceof RegExp) {
            r = {};
            for (i in t)t.hasOwnProperty(i) && n.test(i) && (r[i] = t[i])
        } else r = t[n] || (t[n] = []);
        return r
    };
    n.flattenListeners = function (n) {
        for (var i = [], t = 0; t < n.length; t += 1)i.push(n[t].listener);
        return i
    };
    n.getListenersAsObject = function (n) {
        var t = this.getListeners(n), i;
        return t instanceof Array && (i = {}, i[n] = t), i || t
    };
    n.addListener = function (n, t) {
        var i = this.getListenersAsObject(n), f = typeof t == "object", r;
        for (r in i)i.hasOwnProperty(r) && u(i[r], t) === -1 && i[r].push(f ? t : {listener: t, once: !1});
        return this
    };
    n.on = i("addListener");
    n.addOnceListener = function (n, t) {
        return this.addListener(n, {listener: t, once: !0})
    };
    n.once = i("addOnceListener");
    n.defineEvent = function (n) {
        return this.getListeners(n), this
    };
    n.defineEvents = function (n) {
        for (var t = 0; t < n.length; t += 1)this.defineEvent(n[t]);
        return this
    };
    n.removeListener = function (n, t) {
        var i = this.getListenersAsObject(n), f, r;
        for (r in i)i.hasOwnProperty(r) && (f = u(i[r], t), f !== -1 && i[r].splice(f, 1));
        return this
    };
    n.off = i("removeListener");
    n.addListeners = function (n, t) {
        return this.manipulateListeners(!1, n, t)
    };
    n.removeListeners = function (n, t) {
        return this.manipulateListeners(!0, n, t)
    };
    n.manipulateListeners = function (n, t, i) {
        var r, u, f = n ? this.removeListener : this.addListener, e = n ? this.removeListeners : this.addListeners;
        if (typeof t != "object" || t instanceof RegExp)for (r = i.length; r--;)f.call(this, t, i[r]); else for (r in t)t.hasOwnProperty(r) && (u = t[r]) && (typeof u == "function" ? f.call(this, r, u) : e.call(this, r, u));
        return this
    };
    n.removeEvent = function (n) {
        var r = typeof n, t = this._getEvents(), i;
        if (r === "string")delete t[n]; else if (n instanceof RegExp)for (i in t)t.hasOwnProperty(i) && n.test(i) && delete t[i]; else delete this._events;
        return this
    };
    n.removeAllListeners = i("removeEvent");
    n.emitEvent = function (n, t) {
        var r = this.getListenersAsObject(n), i, f, u, e;
        for (u in r)if (r.hasOwnProperty(u))for (f = r[u].length; f--;)i = r[u][f], i.once === !0 && this.removeListener(n, i.listener), e = i.listener.apply(this, t || []), e === this._getOnceReturnValue() && this.removeListener(n, i.listener);
        return this
    };
    n.trigger = i("emitEvent");
    n.emit = function (n) {
        var t = Array.prototype.slice.call(arguments, 1);
        return this.emitEvent(n, t)
    };
    n.setOnceReturnValue = function (n) {
        return this._onceReturnValue = n, this
    };
    n._getOnceReturnValue = function () {
        return this.hasOwnProperty("_onceReturnValue") ? this._onceReturnValue : !0
    };
    n._getEvents = function () {
        return this._events || (this._events = {})
    };
    t.noConflict = function () {
        return r.EventEmitter = f, t
    };
    typeof define == "function" && define.amd ? define("eventEmitter/EventEmitter", [], function () {
        return t
    }) : typeof module == "object" && module.exports ? module.exports = t : r.EventEmitter = t
}.call(this), function (n) {
    function t(n) {
        var u, t, f;
        if (n) {
            if (typeof r[n] == "string")return n;
            for (n = n.charAt(0).toUpperCase() + n.slice(1), t = 0, f = i.length; t < f; t++)if (u = i[t] + n, typeof r[u] == "string")return u
        }
    }

    var i = "Webkit Moz ms Ms O".split(" "), r = document.documentElement.style;
    typeof define == "function" && define.amd ? define("get-style-property/get-style-property", [], function () {
        return t
    }) : typeof exports == "object" ? module.exports = t : n.getStyleProperty = t
}(window), function (n) {
    function i(n) {
        var t = parseFloat(n), i = n.indexOf("%") === -1 && !isNaN(t);
        return i && t
    }

    function u() {
    }

    function e() {
        for (var i = {
            width: 0,
            height: 0,
            innerWidth: 0,
            innerHeight: 0,
            outerWidth: 0,
            outerHeight: 0
        }, u, n = 0, r = t.length; n < r; n++)u = t[n], i[u] = 0;
        return i
    }

    function r(r) {
        function c() {
            var e, t, c, l;
            s || (s = !0, e = n.getComputedStyle, o = function () {
                var n = e ? function (n) {
                    return e(n, null)
                } : function (n) {
                    return n.currentStyle
                };
                return function (t) {
                    var i = n(t);
                    return i || f("Style returned " + i + ". Are you running this code in a hidden iframe on Firefox? See http://bit.ly/getsizebug1"), i
                }
            }(), u = r("boxSizing"), u && (t = document.createElement("div"), t.style.width = "200px", t.style.padding = "1px 2px 3px 4px", t.style.borderStyle = "solid", t.style.borderWidth = "1px 2px 3px 4px", t.style[u] = "border-box", c = document.body || document.documentElement, c.appendChild(t), l = o(t), h = i(l.width) === 200, c.removeChild(t)))
        }

        function l(n) {
            var f, r, w, s, b, v, l, y, p;
            if (c(), typeof n == "string" && (n = document.querySelector(n)), n && typeof n == "object" && n.nodeType) {
                if (f = o(n), f.display === "none")return e();
                for (r = {}, r.width = n.offsetWidth, r.height = n.offsetHeight, w = r.isBorderBox = !!(u && f[u] && f[u] === "border-box"), s = 0, b = t.length; s < b; s++)v = t[s], l = f[v], l = a(n, l), y = parseFloat(l), r[v] = isNaN(y) ? 0 : y;
                var k = r.paddingLeft + r.paddingRight, d = r.paddingTop + r.paddingBottom, rt = r.marginLeft + r.marginRight, ut = r.marginTop + r.marginBottom, g = r.borderLeftWidth + r.borderRightWidth, nt = r.borderTopWidth + r.borderBottomWidth, tt = w && h, it = i(f.width);
                return it !== !1 && (r.width = it + (tt ? 0 : k + g)), p = i(f.height), p !== !1 && (r.height = p + (tt ? 0 : d + nt)), r.innerWidth = r.width - (k + g), r.innerHeight = r.height - (d + nt), r.outerWidth = r.width + rt, r.outerHeight = r.height + ut, r
            }
        }

        function a(t, i) {
            if (n.getComputedStyle || i.indexOf("%") === -1)return i;
            var r = t.style, e = r.left, u = t.runtimeStyle, f = u && u.left;
            return f && (u.left = t.currentStyle.left), r.left = i, i = r.pixelLeft, r.left = e, f && (u.left = f), i
        }

        var s = !1, o, u, h;
        return l
    }

    var f = typeof console == "undefined" ? u : function (n) {
        console.error(n)
    }, t = ["paddingLeft", "paddingRight", "paddingTop", "paddingBottom", "marginLeft", "marginRight", "marginTop", "marginBottom", "borderLeftWidth", "borderRightWidth", "borderTopWidth", "borderBottomWidth"];
    typeof define == "function" && define.amd ? define("get-size/get-size", ["get-style-property/get-style-property"], r) : typeof exports == "object" ? module.exports = r(require("desandro-get-style-property")) : n.getSize = r(n.getStyleProperty)
}(window), function (n) {
    function t(n) {
        typeof n == "function" && (t.isReady ? n() : r.push(n))
    }

    function u(n) {
        var r = n.type === "readystatechange" && i.readyState !== "complete";
        t.isReady || r || e()
    }

    function e() {
        var n, i, u;
        for (t.isReady = !0, n = 0, i = r.length; n < i; n++)u = r[n], u()
    }

    function f(r) {
        return i.readyState === "complete" ? e() : (r.bind(i, "DOMContentLoaded", u), r.bind(i, "readystatechange", u), r.bind(n, "load", u)), t
    }

    var i = n.document, r = [];
    t.isReady = !1;
    typeof define == "function" && define.amd ? define("doc-ready/doc-ready", ["eventie/eventie"], f) : typeof exports == "object" ? module.exports = f(require("eventie")) : n.docReady = f(n.eventie)
}(window), function (n) {
    function i(n, t) {
        return n[r](t)
    }

    function u(n) {
        if (!n.parentNode) {
            var t = document.createDocumentFragment();
            t.appendChild(n)
        }
    }

    function o(n, t) {
        var r, i, f;
        for (u(n), r = n.parentNode.querySelectorAll(t), i = 0, f = r.length; i < f; i++)if (r[i] === n)return !0;
        return !1
    }

    function s(n, t) {
        return u(n), i(n, t)
    }

    var r = function () {
        var i, t, u, f, r;
        if (n.matches)return "matches";
        if (n.matchesSelector)return "matchesSelector";
        for (i = ["webkit", "moz", "ms", "o"], t = 0, u = i.length; t < u; t++)if (f = i[t], r = f + "MatchesSelector", n[r])return r
    }(), t, f, e;
    r ? (f = document.createElement("div"), e = i(f, "div"), t = e ? i : s) : t = o;
    typeof define == "function" && define.amd ? define("matches-selector/matches-selector", [], function () {
        return t
    }) : typeof exports == "object" ? module.exports = t : window.matchesSelector = t
}(Element.prototype), function (n, t) {
    typeof define == "function" && define.amd ? define("fizzy-ui-utils/utils", ["doc-ready/doc-ready", "matches-selector/matches-selector"], function (i, r) {
        return t(n, i, r)
    }) : typeof exports == "object" ? module.exports = t(n, require("doc-ready"), require("desandro-matches-selector")) : n.fizzyUIUtils = t(n, n.docReady, n.matchesSelector)
}(window, function (n, t, i) {
    var r = {}, f, u;
    return r.extend = function (n, t) {
        for (var i in t)n[i] = t[i];
        return n
    }, r.modulo = function (n, t) {
        return (n % t + t) % t
    }, f = Object.prototype.toString, r.isArray = function (n) {
        return f.call(n) == "[object Array]"
    }, r.makeArray = function (n) {
        var t = [], i, u;
        if (r.isArray(n))t = n; else if (n && typeof n.length == "number")for (i = 0, u = n.length; i < u; i++)t.push(n[i]); else t.push(n);
        return t
    }, r.indexOf = Array.prototype.indexOf ? function (n, t) {
        return n.indexOf(t)
    } : function (n, t) {
        for (var i = 0, r = n.length; i < r; i++)if (n[i] === t)return i;
        return -1
    }, r.removeFrom = function (n, t) {
        var i = r.indexOf(n, t);
        i != -1 && n.splice(i, 1)
    }, r.isElement = typeof HTMLElement == "function" || typeof HTMLElement == "object" ? function (n) {
        return n instanceof HTMLElement
    } : function (n) {
        return n && typeof n == "object" && n.nodeType == 1 && typeof n.nodeName == "string"
    }, r.setText = function () {
        function t(t, i) {
            n = n || (document.documentElement.textContent !== undefined ? "textContent" : "innerText");
            t[n] = i
        }

        var n;
        return t
    }(), r.getParent = function (n, t) {
        while (n != document.body)if (n = n.parentNode, i(n, t))return n
    }, r.getQueryElement = function (n) {
        return typeof n == "string" ? document.querySelector(n) : n
    }, r.handleEvent = function (n) {
        var t = "on" + n.type;
        this[t] && this[t](n)
    }, r.filterFindElements = function (n, t) {
        var f, e, h, u, s, o, c;
        for (n = r.makeArray(n), f = [], e = 0, h = n.length; e < h; e++)if (u = n[e], r.isElement(u))if (t)for (i(u, t) && f.push(u), s = u.querySelectorAll(t), o = 0, c = s.length; o < c; o++)f.push(s[o]); else f.push(u);
        return f
    }, r.debounceMethod = function (n, t, i) {
        var u = n.prototype[t], r = t + "Timeout";
        n.prototype[t] = function () {
            var t = this[r], f, n;
            t && clearTimeout(t);
            f = arguments;
            n = this;
            this[r] = setTimeout(function () {
                u.apply(n, f);
                delete n[r]
            }, i || 100)
        }
    }, r.toDashed = function (n) {
        return n.replace(/(.)([A-Z])/g, function (n, t, i) {
            return t + "-" + i
        }).toLowerCase()
    }, u = n.console, r.htmlInit = function (i, f) {
        t(function () {
            for (var h = r.toDashed(f), c = document.querySelectorAll(".js-" + h), l = "data-" + h + "-options", t, o, v, y, s, e = 0, a = c.length; e < a; e++) {
                t = c[e];
                o = t.getAttribute(l);
                try {
                    v = o && JSON.parse(o)
                } catch (p) {
                    u && u.error("Error parsing " + l + " on " + t.nodeName.toLowerCase() + (t.id ? "#" + t.id : "") + ": " + p);
                    continue
                }
                y = new i(t, v);
                s = n.jQuery;
                s && s.data(t, f, y)
            }
        })
    }, r
}), function (n, t) {
    typeof define == "function" && define.amd ? define("outlayer/item", ["eventEmitter/EventEmitter", "get-size/get-size", "get-style-property/get-style-property", "fizzy-ui-utils/utils"], function (i, r, u, f) {
        return t(n, i, r, u, f)
    }) : typeof exports == "object" ? module.exports = t(n, require("wolfy87-eventemitter"), require("get-size"), require("desandro-get-style-property"), require("fizzy-ui-utils")) : (n.Outlayer = {}, n.Outlayer.Item = t(n, n.EventEmitter, n.getSize, n.getStyleProperty, n.fizzyUIUtils))
}(window, function (n, t, i, r, u) {
    function p(n) {
        for (var t in n)return !1;
        return t = null, !0
    }

    function f(n, t) {
        n && (this.element = n, this.layout = t, this.position = {x: 0, y: 0}, this._create())
    }

    function d(n) {
        return n.replace(/([A-Z])/g, function (n) {
            return "-" + n.toLowerCase()
        })
    }

    var o = n.getComputedStyle, y = o ? function (n) {
        return o(n, null)
    } : function (n) {
        return n.currentStyle
    }, e = r("transition"), w = r("transform"), b = e && w, k = !!r("perspective"), s = {
        WebkitTransition: "webkitTransitionEnd",
        MozTransition: "transitionend",
        OTransition: "otransitionend",
        transition: "transitionend"
    }[e], h = ["transform", "transition", "transitionDuration", "transitionProperty"], c = function () {
        for (var u = {}, t, i, n = 0, f = h.length; n < f; n++)t = h[n], i = r(t), i && i !== t && (u[t] = i);
        return u
    }(), l, a, v;
    return u.extend(f.prototype, t.prototype), f.prototype._create = function () {
        this._transn = {ingProperties: {}, clean: {}, onEnd: {}};
        this.css({position: "absolute"})
    }, f.prototype.handleEvent = function (n) {
        var t = "on" + n.type;
        this[t] && this[t](n)
    }, f.prototype.getSize = function () {
        this.size = i(this.element)
    }, f.prototype.css = function (n) {
        var r = this.element.style, t, i;
        for (t in n)i = c[t] || t, r[i] = n[t]
    }, f.prototype.getPosition = function () {
        var f = y(this.element), e = this.layout.options, o = e.isOriginLeft, s = e.isOriginTop, r = f[o ? "left" : "right"], u = f[s ? "top" : "bottom"], n = this.layout.size, t = r.indexOf("%") != -1 ? parseFloat(r) / 100 * n.width : parseInt(r, 10), i = u.indexOf("%") != -1 ? parseFloat(u) / 100 * n.height : parseInt(u, 10);
        t = isNaN(t) ? 0 : t;
        i = isNaN(i) ? 0 : i;
        t -= o ? n.paddingLeft : n.paddingRight;
        i -= s ? n.paddingTop : n.paddingBottom;
        this.position.x = t;
        this.position.y = i
    }, f.prototype.layoutPosition = function () {
        var i = this.layout.size, n = this.layout.options, t = {}, r = n.isOriginLeft ? "paddingLeft" : "paddingRight", u = n.isOriginLeft ? "left" : "right", f = n.isOriginLeft ? "right" : "left", e = this.position.x + i[r];
        t[u] = this.getXValue(e);
        t[f] = "";
        var o = n.isOriginTop ? "paddingTop" : "paddingBottom", s = n.isOriginTop ? "top" : "bottom", h = n.isOriginTop ? "bottom" : "top", c = this.position.y + i[o];
        t[s] = this.getYValue(c);
        t[h] = "";
        this.css(t);
        this.emitEvent("layout", [this])
    }, f.prototype.getXValue = function (n) {
        var t = this.layout.options;
        return t.percentPosition && !t.isHorizontal ? n / this.layout.size.width * 100 + "%" : n + "px"
    }, f.prototype.getYValue = function (n) {
        var t = this.layout.options;
        return t.percentPosition && t.isHorizontal ? n / this.layout.size.height * 100 + "%" : n + "px"
    }, f.prototype._transitionTo = function (n, t) {
        this.getPosition();
        var r = this.position.x, u = this.position.y, f = parseInt(n, 10), e = parseInt(t, 10), o = f === this.position.x && e === this.position.y;
        if (this.setPosition(n, t), o && !this.isTransitioning) {
            this.layoutPosition();
            return
        }
        var s = n - r, h = t - u, i = {};
        i.transform = this.getTranslate(s, h);
        this.transition({to: i, onTransitionEnd: {transform: this.layoutPosition}, isCleaning: !0})
    }, f.prototype.getTranslate = function (n, t) {
        var i = this.layout.options;
        return (n = i.isOriginLeft ? n : -n, t = i.isOriginTop ? t : -t, k) ? "translate3d(" + n + "px, " + t + "px, 0)" : "translate(" + n + "px, " + t + "px)"
    }, f.prototype.goTo = function (n, t) {
        this.setPosition(n, t);
        this.layoutPosition()
    }, f.prototype.moveTo = b ? f.prototype._transitionTo : f.prototype.goTo, f.prototype.setPosition = function (n, t) {
        this.position.x = parseInt(n, 10);
        this.position.y = parseInt(t, 10)
    }, f.prototype._nonTransition = function (n) {
        this.css(n.to);
        n.isCleaning && this._removeStyles(n.to);
        for (var t in n.onTransitionEnd)n.onTransitionEnd[t].call(this)
    }, f.prototype._transition = function (n) {
        var i, t, r;
        if (!parseFloat(this.layout.options.transitionDuration)) {
            this._nonTransition(n);
            return
        }
        i = this._transn;
        for (t in n.onTransitionEnd)i.onEnd[t] = n.onTransitionEnd[t];
        for (t in n.to)i.ingProperties[t] = !0, n.isCleaning && (i.clean[t] = !0);
        n.from && (this.css(n.from), r = this.element.offsetHeight, r = null);
        this.enableTransition(n.to);
        this.css(n.to);
        this.isTransitioning = !0
    }, l = "opacity," + d(c.transform || "transform"), f.prototype.enableTransition = function () {
        this.isTransitioning || (this.css({
            transitionProperty: l,
            transitionDuration: this.layout.options.transitionDuration
        }), this.element.addEventListener(s, this, !1))
    }, f.prototype.transition = f.prototype[e ? "_transition" : "_nonTransition"], f.prototype.onwebkitTransitionEnd = function (n) {
        this.ontransitionend(n)
    }, f.prototype.onotransitionend = function (n) {
        this.ontransitionend(n)
    }, a = {
        "-webkit-transform": "transform",
        "-moz-transform": "transform",
        "-o-transform": "transform"
    }, f.prototype.ontransitionend = function (n) {
        var t, i, r;
        n.target === this.element && (t = this._transn, i = a[n.propertyName] || n.propertyName, delete t.ingProperties[i], p(t.ingProperties) && this.disableTransition(), i in t.clean && (this.element.style[n.propertyName] = "", delete t.clean[i]), i in t.onEnd && (r = t.onEnd[i], r.call(this), delete t.onEnd[i]), this.emitEvent("transitionEnd", [this]))
    }, f.prototype.disableTransition = function () {
        this.removeTransitionStyles();
        this.element.removeEventListener(s, this, !1);
        this.isTransitioning = !1
    }, f.prototype._removeStyles = function (n) {
        var t = {}, i;
        for (i in n)t[i] = "";
        this.css(t)
    }, v = {transitionProperty: "", transitionDuration: ""}, f.prototype.removeTransitionStyles = function () {
        this.css(v)
    }, f.prototype.removeElem = function () {
        this.element.parentNode.removeChild(this.element);
        this.css({display: ""});
        this.emitEvent("remove", [this])
    }, f.prototype.remove = function () {
        if (!e || !parseFloat(this.layout.options.transitionDuration)) {
            this.removeElem();
            return
        }
        var n = this;
        this.once("transitionEnd", function () {
            n.removeElem()
        });
        this.hide()
    }, f.prototype.reveal = function () {
        delete this.isHidden;
        this.css({display: ""});
        var n = this.layout.options, t = {}, i = this.getHideRevealTransitionEndProperty("visibleStyle");
        t[i] = this.onRevealTransitionEnd;
        this.transition({from: n.hiddenStyle, to: n.visibleStyle, isCleaning: !0, onTransitionEnd: t})
    }, f.prototype.onRevealTransitionEnd = function () {
        this.isHidden || this.emitEvent("reveal")
    }, f.prototype.getHideRevealTransitionEndProperty = function (n) {
        var t = this.layout.options[n], i;
        if (t.opacity)return "opacity";
        for (i in t)return i
    }, f.prototype.hide = function () {
        this.isHidden = !0;
        this.css({display: ""});
        var n = this.layout.options, t = {}, i = this.getHideRevealTransitionEndProperty("hiddenStyle");
        t[i] = this.onHideTransitionEnd;
        this.transition({from: n.visibleStyle, to: n.hiddenStyle, isCleaning: !0, onTransitionEnd: t})
    }, f.prototype.onHideTransitionEnd = function () {
        this.isHidden && (this.css({display: "none"}), this.emitEvent("hide"))
    }, f.prototype.destroy = function () {
        this.css({position: "", left: "", right: "", top: "", bottom: "", transition: "", transform: ""})
    }, f
}), function (n, t) {
    typeof define == "function" && define.amd ? define("outlayer/outlayer", ["eventie/eventie", "eventEmitter/EventEmitter", "get-size/get-size", "fizzy-ui-utils/utils", "./item"], function (i, r, u, f, e) {
        return t(n, i, r, u, f, e)
    }) : typeof exports == "object" ? module.exports = t(n, require("eventie"), require("wolfy87-eventemitter"), require("get-size"), require("fizzy-ui-utils"), require("./item")) : n.Outlayer = t(n, n.eventie, n.EventEmitter, n.getSize, n.fizzyUIUtils, n.Outlayer.Item)
}(window, function (n, t, i, r, u, f) {
    function e(n, t) {
        var i = u.getQueryElement(n), r;
        if (!i) {
            h && h.error("Bad element for " + this.constructor.namespace + ": " + (i || n));
            return
        }
        this.element = i;
        o && (this.$element = o(this.element));
        this.options = u.extend({}, this.constructor.defaults);
        this.option(t);
        r = ++l;
        this.element.outlayerGUID = r;
        s[r] = this;
        this._create();
        this.options.isInitLayout && this.layout()
    }

    var h = n.console, o = n.jQuery, c = function () {
    }, l = 0, s = {};
    return e.namespace = "outlayer", e.Item = f, e.defaults = {
        containerStyle: {position: "relative"},
        isInitLayout: !0,
        isOriginLeft: !0,
        isOriginTop: !0,
        isResizeBound: !0,
        isResizingContainer: !0,
        transitionDuration: "0.4s",
        hiddenStyle: {opacity: 0, transform: "scale(0.001)"},
        visibleStyle: {opacity: 1, transform: "scale(1)"}
    }, u.extend(e.prototype, i.prototype), e.prototype.option = function (n) {
        u.extend(this.options, n)
    }, e.prototype._create = function () {
        this.reloadItems();
        this.stamps = [];
        this.stamp(this.options.stamp);
        u.extend(this.element.style, this.options.containerStyle);
        this.options.isResizeBound && this.bindResize()
    }, e.prototype.reloadItems = function () {
        this.items = this._itemize(this.element.children)
    }, e.prototype._itemize = function (n) {
        for (var i = this._filterFindItemElements(n), o = this.constructor.Item, r = [], f, e, t = 0, u = i.length; t < u; t++)f = i[t], e = new o(f, this), r.push(e);
        return r
    }, e.prototype._filterFindItemElements = function (n) {
        return u.filterFindElements(n, this.options.itemSelector)
    }, e.prototype.getItemElements = function () {
        for (var t = [], n = 0, i = this.items.length; n < i; n++)t.push(this.items[n].element);
        return t
    }, e.prototype.layout = function () {
        this._resetLayout();
        this._manageStamps();
        var n = this.options.isLayoutInstant !== undefined ? this.options.isLayoutInstant : !this._isLayoutInited;
        this.layoutItems(this.items, n);
        this._isLayoutInited = !0
    }, e.prototype._init = e.prototype.layout, e.prototype._resetLayout = function () {
        this.getSize()
    }, e.prototype.getSize = function () {
        this.size = r(this.element)
    }, e.prototype._getMeasurement = function (n, t) {
        var i = this.options[n], f;
        i ? (typeof i == "string" ? f = this.element.querySelector(i) : u.isElement(i) && (f = i), this[n] = f ? r(f)[t] : i) : this[n] = 0
    }, e.prototype.layoutItems = function (n, t) {
        n = this._getItemsForLayout(n);
        this._layoutItems(n, t);
        this._postLayout()
    }, e.prototype._getItemsForLayout = function (n) {
        for (var r = [], i, t = 0, u = n.length; t < u; t++)i = n[t], i.isIgnored || r.push(i);
        return r
    }, e.prototype._layoutItems = function (n, t) {
        var f, i, e, r, u;
        if (this._emitCompleteOnItems("layout", n), n && n.length) {
            for (f = [], i = 0, e = n.length; i < e; i++)r = n[i], u = this._getItemLayoutPosition(r), u.item = r, u.isInstant = t || r.isLayoutInstant, f.push(u);
            this._processLayoutQueue(f)
        }
    }, e.prototype._getItemLayoutPosition = function () {
        return {x: 0, y: 0}
    }, e.prototype._processLayoutQueue = function (n) {
        for (var t, i = 0, r = n.length; i < r; i++)t = n[i], this._positionItem(t.item, t.x, t.y, t.isInstant)
    }, e.prototype._positionItem = function (n, t, i, r) {
        r ? n.goTo(t, i) : n.moveTo(t, i)
    }, e.prototype._postLayout = function () {
        this.resizeContainer()
    }, e.prototype.resizeContainer = function () {
        if (this.options.isResizingContainer) {
            var n = this._getContainerSize();
            n && (this._setContainerMeasure(n.width, !0), this._setContainerMeasure(n.height, !1))
        }
    }, e.prototype._getContainerSize = c, e.prototype._setContainerMeasure = function (n, t) {
        if (n !== undefined) {
            var i = this.size;
            i.isBorderBox && (n += t ? i.paddingLeft + i.paddingRight + i.borderLeftWidth + i.borderRightWidth : i.paddingBottom + i.paddingTop + i.borderTopWidth + i.borderBottomWidth);
            n = Math.max(n, 0);
            this.element.style[t ? "width" : "height"] = n + "px"
        }
    }, e.prototype._emitCompleteOnItems = function (n, t) {
        function u() {
            s.dispatchEvent(n + "Complete", null, [t])
        }

        function h() {
            r++;
            r === f && u()
        }

        var s = this, f = t.length, r, i, e, o;
        if (!t || !f) {
            u();
            return
        }
        for (r = 0, i = 0, e = t.length; i < e; i++) {
            o = t[i];
            o.once(n, h)
        }
    }, e.prototype.dispatchEvent = function (n, t, i) {
        var u = t ? [t].concat(i) : i, r;
        this.emitEvent(n, u);
        o && (this.$element = this.$element || o(this.element), t ? (r = o.Event(t), r.type = n, this.$element.trigger(r, i)) : this.$element.trigger(n, i))
    }, e.prototype.ignore = function (n) {
        var t = this.getItem(n);
        t && (t.isIgnored = !0)
    }, e.prototype.unignore = function (n) {
        var t = this.getItem(n);
        t && delete t.isIgnored
    }, e.prototype.stamp = function (n) {
        var t, i, r;
        if (n = this._find(n), n)for (this.stamps = this.stamps.concat(n), t = 0, i = n.length; t < i; t++)r = n[t], this.ignore(r)
    }, e.prototype.unstamp = function (n) {
        var t, r, i;
        if (n = this._find(n), n)for (t = 0, r = n.length; t < r; t++)i = n[t], u.removeFrom(this.stamps, i), this.unignore(i)
    }, e.prototype._find = function (n) {
        if (n)return typeof n == "string" && (n = this.element.querySelectorAll(n)), u.makeArray(n)
    }, e.prototype._manageStamps = function () {
        var n, t, i;
        if (this.stamps && this.stamps.length)for (this._getBoundingRect(), n = 0, t = this.stamps.length; n < t; n++)i = this.stamps[n], this._manageStamp(i)
    }, e.prototype._getBoundingRect = function () {
        var t = this.element.getBoundingClientRect(), n = this.size;
        this._boundingRect = {
            left: t.left + n.paddingLeft + n.borderLeftWidth,
            top: t.top + n.paddingTop + n.borderTopWidth,
            right: t.right - (n.paddingRight + n.borderRightWidth),
            bottom: t.bottom - (n.paddingBottom + n.borderBottomWidth)
        }
    }, e.prototype._manageStamp = c, e.prototype._getElementOffset = function (n) {
        var t = n.getBoundingClientRect(), i = this._boundingRect, u = r(n);
        return {
            left: t.left - i.left - u.marginLeft,
            top: t.top - i.top - u.marginTop,
            right: i.right - t.right - u.marginRight,
            bottom: i.bottom - t.bottom - u.marginBottom
        }
    }, e.prototype.handleEvent = function (n) {
        var t = "on" + n.type;
        this[t] && this[t](n)
    }, e.prototype.bindResize = function () {
        this.isResizeBound || (t.bind(n, "resize", this), this.isResizeBound = !0)
    }, e.prototype.unbindResize = function () {
        this.isResizeBound && t.unbind(n, "resize", this);
        this.isResizeBound = !1
    }, e.prototype.onresize = function () {
        function t() {
            n.resize();
            delete n.resizeTimeout
        }

        this.resizeTimeout && clearTimeout(this.resizeTimeout);
        var n = this;
        this.resizeTimeout = setTimeout(t, 100)
    }, e.prototype.resize = function () {
        this.isResizeBound && this.needsResizeLayout() && this.layout()
    }, e.prototype.needsResizeLayout = function () {
        var n = r(this.element), t = this.size && n;
        return t && n.innerWidth !== this.size.innerWidth
    }, e.prototype.addItems = function (n) {
        var t = this._itemize(n);
        return t.length && (this.items = this.items.concat(t)), t
    }, e.prototype.appended = function (n) {
        var t = this.addItems(n);
        t.length && (this.layoutItems(t, !0), this.reveal(t))
    }, e.prototype.prepended = function (n) {
        var t = this._itemize(n), i;
        t.length && (i = this.items.slice(0), this.items = t.concat(i), this._resetLayout(), this._manageStamps(), this.layoutItems(t, !0), this.reveal(t), this.layoutItems(i))
    }, e.prototype.reveal = function (n) {
        var i, t, r;
        for (this._emitCompleteOnItems("reveal", n), i = n && n.length, t = 0; i && t < i; t++)r = n[t], r.reveal()
    }, e.prototype.hide = function (n) {
        var i, t, r;
        for (this._emitCompleteOnItems("hide", n), i = n && n.length, t = 0; i && t < i; t++)r = n[t], r.hide()
    }, e.prototype.revealItemElements = function (n) {
        var t = this.getItems(n);
        this.reveal(t)
    }, e.prototype.hideItemElements = function (n) {
        var t = this.getItems(n);
        this.hide(t)
    }, e.prototype.getItem = function (n) {
        for (var i, t = 0, r = this.items.length; t < r; t++)if (i = this.items[t], i.element === n)return i
    }, e.prototype.getItems = function (n) {
        var i, t, f, e, r;
        for (n = u.makeArray(n), i = [], t = 0, f = n.length; t < f; t++)e = n[t], r = this.getItem(e), r && i.push(r);
        return i
    }, e.prototype.remove = function (n) {
        var t = this.getItems(n), i, f, r;
        if (this._emitCompleteOnItems("remove", t), t && t.length)for (i = 0, f = t.length; i < f; i++)r = t[i], r.remove(), u.removeFrom(this.items, r)
    }, e.prototype.destroy = function () {
        var t = this.element.style, n, i, r, u;
        for (t.height = "", t.position = "", t.width = "", n = 0, i = this.items.length; n < i; n++)r = this.items[n], r.destroy();
        this.unbindResize();
        u = this.element.outlayerGUID;
        delete s[u];
        delete this.element.outlayerGUID;
        o && o.removeData(this.element, this.constructor.namespace)
    }, e.data = function (n) {
        n = u.getQueryElement(n);
        var t = n && n.outlayerGUID;
        return t && s[t]
    }, e.create = function (n, t) {
        function i() {
            e.apply(this, arguments)
        }

        return Object.create ? i.prototype = Object.create(e.prototype) : u.extend(i.prototype, e.prototype), i.prototype.constructor = i, i.defaults = u.extend({}, e.defaults), u.extend(i.defaults, t), i.prototype.settings = {}, i.namespace = n, i.data = e.data, i.Item = function () {
            f.apply(this, arguments)
        }, i.Item.prototype = new f, u.htmlInit(i, n), o && o.bridget && o.bridget(n, i), i
    }, e.Item = f, e
}), function (n, t) {
    typeof define == "function" && define.amd ? define(["outlayer/outlayer", "get-size/get-size", "fizzy-ui-utils/utils"], t) : typeof exports == "object" ? module.exports = t(require("outlayer"), require("get-size"), require("fizzy-ui-utils")) : n.Masonry = t(n.Outlayer, n.getSize, n.fizzyUIUtils)
}(window, function (n, t, i) {
    var r = n.create("masonry");
    return r.prototype._resetLayout = function () {
        this.getSize();
        this._getMeasurement("columnWidth", "outerWidth");
        this._getMeasurement("gutter", "outerWidth");
        this.measureColumns();
        var n = this.cols;
        for (this.colYs = []; n--;)this.colYs.push(0);
        this.maxY = 0
    }, r.prototype.measureColumns = function () {
        var n, i;
        this.getContainerWidth();
        this.columnWidth || (n = this.items[0], i = n && n.element, this.columnWidth = i && t(i).outerWidth || this.containerWidth);
        var r = this.columnWidth += this.gutter, f = this.containerWidth + this.gutter, u = f / r, e = r - f % r, o = e && e < 1 ? "round" : "floor";
        u = Math[o](u);
        this.cols = Math.max(u, 1)
    }, r.prototype.getContainerWidth = function () {
        var i = this.options.isFitWidth ? this.element.parentNode : this.element, n = t(i);
        this.containerWidth = n && n.innerWidth
    }, r.prototype._getItemLayoutPosition = function (n) {
        var t;
        n.getSize();
        var e = n.size.outerWidth % this.columnWidth, s = e && e < 1 ? "round" : "ceil", r = Math[s](n.size.outerWidth / this.columnWidth);
        r = Math.min(r, this.cols);
        var u = this._getColGroup(r), f = Math.min.apply(Math, u), o = i.indexOf(u, f), h = {
            x: this.columnWidth * o,
            y: f
        }, c = f + n.size.outerHeight, l = this.cols + 1 - u.length;
        for (t = 0; t < l; t++)this.colYs[o + t] = c;
        return h
    }, r.prototype._getColGroup = function (n) {
        var i, r, t, u;
        if (n < 2)return this.colYs;
        for (i = [], r = this.cols + 1 - n, t = 0; t < r; t++)u = this.colYs.slice(t, t + n), i[t] = Math.max.apply(Math, u);
        return i
    }, r.prototype._manageStamp = function (n) {
        var e = t(n), u = this._getElementOffset(n), o = this.options.isOriginLeft ? u.left : u.right, s = o + e.outerWidth, f = Math.floor(o / this.columnWidth), i, h, r;
        for (f = Math.max(0, f), i = Math.floor(s / this.columnWidth), i -= s % this.columnWidth ? 0 : 1, i = Math.min(this.cols - 1, i), h = (this.options.isOriginTop ? u.top : u.bottom) + e.outerHeight, r = f; r <= i; r++)this.colYs[r] = Math.max(h, this.colYs[r])
    }, r.prototype._getContainerSize = function () {
        this.maxY = Math.max.apply(Math, this.colYs);
        var n = {height: this.maxY};
        return this.options.isFitWidth && (n.width = this._getContainerFitWidth()), n
    }, r.prototype._getContainerFitWidth = function () {
        for (var n = 0, t = this.cols; --t;) {
            if (this.colYs[t] !== 0)break;
            n++
        }
        return (this.cols - n) * this.columnWidth - this.gutter
    }, r.prototype.needsResizeLayout = function () {
        var n = this.containerWidth;
        return this.getContainerWidth(), n !== this.containerWidth
    }, r
})