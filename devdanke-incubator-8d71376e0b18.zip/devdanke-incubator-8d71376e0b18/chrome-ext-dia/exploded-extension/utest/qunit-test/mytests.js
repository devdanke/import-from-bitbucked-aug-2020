QUnit.test( "hello test", function( assert ) {
    assert.ok( 1 == "1", "Passed!" );
});

QUnit.test( "StrUti.normalizeUserName test", function( assert ) {

     assert.ok(StrUtil.normalizeUserName(' X +z1-', "x  z1"),'x  z1-','passed!!!');
});