var rewire  = require('rewire');
var fs = require('fs');

// get Page module dependencies
var strLibCode = fs.readFileSync('../common/util-str.js','utf-8') ;// depends on the file encoding
eval(strLibCode);

// get code under test via rewire, so i can inject dependencies.
var codeUnderTestFromRewire = rewire('../../content/page.js');
//console.log("codeUnderTestFromRewire", codeUnderTestFromRewire);

codeUnderTestFromRewire.__set__({
    StrUtil: StrUtil
});

var Page = codeUnderTestFromRewire.TestRef;
//console.log("Page", Page);

describe("Test Page Module", function() {

    it("detect search page", function() {
        expect(Page.getPageType('/Search.aspx?g=2&af=24&at=37&c=PH')).toBe(Page.SEARCH);
    });
});

