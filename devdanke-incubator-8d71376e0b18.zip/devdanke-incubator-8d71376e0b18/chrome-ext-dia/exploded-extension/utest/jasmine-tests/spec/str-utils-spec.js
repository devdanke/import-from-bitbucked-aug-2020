var importedRef = require('../../common/util-str.js');
//console.log("In Spec: TestRef:", TestRef);
var StrUtil = importedRef.TestRef;
//console.log("In Spec: StrUtil:", StrUtil);


describe("Test normalizeUserName()", function() {

    it("normalize ' X +z1-'", function() {
        expect(StrUtil.normalizeUserName(' X +z1-', "x  z1")).toBe('x  z1-');
    });
});



