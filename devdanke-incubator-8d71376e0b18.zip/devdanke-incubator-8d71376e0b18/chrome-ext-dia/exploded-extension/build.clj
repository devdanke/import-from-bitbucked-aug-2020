(require 'cljs.build.api)

(cljs.build.api/build
  "content-cljs"
  {
   :output-dir "target"
   :pretty-print true
   :optimizations :simple
   :output-wrapper true
   :externs ["extern-cljs/pagetype.js"]
   :output-to "target/page-cljs.js"})
