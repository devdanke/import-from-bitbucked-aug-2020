(ns MyCloExt.core
  (:require [clojure.string :as cstr]) )

;; *********************
;; I'm just gonna put all my clojure stuff in here for a while. dec20
;; *********************


; used only for bin-search. it's case sensitive.
(defn string< [s1 s2]
      (neg? (compare s1 s2)))
;; from http://gettingclojure.wikidot.com/cookbook:sequences
(defn binary-search [f v target ]
      (loop [low 0
             high (dec (count v))]
            (if (> low high)
              (- (inc low))
              (let [mid (quot (+ low high) 2)
                    mid-val (v mid)]
                   (cond (f mid-val target) (recur (inc mid) high)
                         (f target mid-val) (recur low (dec mid))
                         :else mid)))) )

(defn ^:export is-hidden [jsArray target]
      ;(.log js/console "DIA: is-hidden called")
      (let [v (js->clj jsArray)]
           (binary-search string< v target) ) )


(defn contains [s sub]
      (> (.indexOf s sub) -1))

(defn ^:export get-page-type [window-location-path]

      (.log js/console "DIA: get-page-type called")

      (let [uri-path (cstr/lower-case window-location-path)]

           ;; (.log js/console "DIA: (subs uri-path 0)" (subs uri-path 0))

           (cond
             (or (contains uri-path "/search") (contains uri-path "/dating/")) PageType.SEARCH
             (contains uri-path "/messages") PageType.MESSAGES
             (contains uri-path "/list/interested") PageType.INTERESTED
             (contains uri-path "/list/visitors") PageType.VISITORS
             (= uri-path "/") PageType.LOGIN
             (= (subs uri-path 0 1) "/") PageType.PROFILE
             :else PageType.OTHER) ) )                      ;; todo: is this unreachable? is profile the real default?

