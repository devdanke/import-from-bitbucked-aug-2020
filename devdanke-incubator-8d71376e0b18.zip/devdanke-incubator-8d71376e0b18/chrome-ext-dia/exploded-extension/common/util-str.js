/// <reference path="../typings/myGlobal.d.ts"/>
var StrUtil;
(function (StrUtil) {
    var PLUS_SIGN_REGEX = /\+/g;
    /*
    Normalization is:
    1) lower case
    2) trim
    3) if starts with '/', remove it.
    4) if contains '+', replace with ' '.
     */
    function normalizeUserName(rawUserName) {
        var lowered = rawUserName.trim().toLowerCase();
        var deslashed = S(lowered).startsWith('/') ? lowered.substr(1) : lowered;
        var deplussed = deslashed.replace(PLUS_SIGN_REGEX, ' ');
        //console.debug("DIA: normalizeUserName:", "rawUserName:", rawUserName, "str:", str, "finalStr:", finalStr);
        return deplussed;
    }
    StrUtil.normalizeUserName = normalizeUserName;
    function zeroPad(n) {
        return (n < 10) ? "0" + n : "" + n;
    }
    function nowAsYyyyMmDdHHmm() {
        var now = new Date();
        return now.getFullYear() + zeroPad(now.getMonth() + 1) + zeroPad(now.getDate()) + "-" +
            zeroPad(now.getHours()) + zeroPad(now.getMinutes()) + zeroPad(now.getSeconds());
    }
    StrUtil.nowAsYyyyMmDdHHmm = nowAsYyyyMmDdHHmm;
})(StrUtil || (StrUtil = {}));
if (typeof module !== 'undefined' && module.exports) {
    // for node/jasmine
    exports.TestRef = StrUtil;
}
//# sourceMappingURL=util-str.js.map