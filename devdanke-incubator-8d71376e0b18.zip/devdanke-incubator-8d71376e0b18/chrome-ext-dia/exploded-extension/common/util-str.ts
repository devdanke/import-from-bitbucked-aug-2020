/// <reference path="../typings/myGlobal.d.ts"/>

module StrUtil {

    let PLUS_SIGN_REGEX = /\+/g;

    /*
    Normalization is:
    1) lower case
    2) trim
    3) if starts with '/', remove it.
    4) if contains '+', replace with ' '.
     */
    export function  normalizeUserName(rawUserName : string) : string {
        let lowered = rawUserName.trim().toLowerCase();
        let deslashed = S(lowered).startsWith('/')? lowered.substr(1) : lowered;
        let deplussed = deslashed.replace(PLUS_SIGN_REGEX, ' ');
        //console.debug("DIA: normalizeUserName:", "rawUserName:", rawUserName, "str:", str, "finalStr:", finalStr);
        return deplussed;
    }

    function zeroPad(n:number):string{
        return (n<10)?"0"+n:""+n;
    }


    export function nowAsYyyyMmDdHHmm(){

        let now = new Date();
        return now.getFullYear()+zeroPad(now.getMonth()+1)+zeroPad(now.getDate())+"-"+
            zeroPad(now.getHours())+zeroPad(now.getMinutes())+zeroPad(now.getSeconds());
    }
}


if (typeof module !== 'undefined' && module.exports) {
// for node/jasmine
    exports.TestRef = StrUtil;
    //console.log("exported StrUtil as TestRef");
}