module Style  {
    export var BLOCKER_BTN_BLOCKED = "blocked-btn";
    export var IMG_BLOCKED = "blocked-img";
    export var COMPLETELY_HIDE = "hide-completely";
    export var BLOCKER_BTN_DEFAULT = "blocker-btn";
}

module PageType {
    export let SEARCH = "SEARCH_PAGE";
    export let PROFILE = "PROFILE_PAGE";
    export var MESSAGES = "MESSAGES_PAGE";
    export var OTHER = "OTHER_PAGE";
    export var LOGIN = "LOGIN_PAGE";
    export var INTERESTED = "INTERESTED_PAGE"; //both interested/in
    export var VISITORS = "VISITORS_PAGE";
}


