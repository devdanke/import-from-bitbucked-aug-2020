/// <reference path="../typings/myGlobal.d.ts"/>

/*
All methods that call this ChromeDb must pass a method that takes a array of strings result.
These callers don't know anything about the BLOCKED_LIST_KEY or other db internals
 */

/*
Public
Passed in by ChromeDb client.
Recieve and do something with blockedUsers.
 */
interface IBlockedUsersConsumer {
    (blockedUsers: string[]): void;
}

module ChromeDb {

    let _INIT_DB_DTTM_KEY : string = "INIT_DB_DTTM_KEY";
    let _BLOCKED_USERS_KEY : string = "BLOCKED_USERS_KEY";

    export function storeBlockedUsers(blockedUsers:string[]) :void{

        if(blockedUsers){

            blockedUsers.sort();

            let payload = {};
            payload[_BLOCKED_USERS_KEY]=blockedUsers;
            chrome.storage.local.set(payload);
            console.debug("DIA: stored blockedUsers. count:", payload[_BLOCKED_USERS_KEY].length);
        }
        else{
            throw "DIA: blockedUsers was null";
        }
    };

    export function loadBlockedUsersAsync(blockedUsersConsumer:IBlockedUsersConsumer):void {

        console.log("DIA: loadBlockedUsersAsync called");

        chrome.storage.local.get(_BLOCKED_USERS_KEY,
            _makeDbLoadHandlerWithConsumer(blockedUsersConsumer));
    };


    export function oneTimeInstallInit() : void {
        console.log("DIA: installInit called @ " + new Date());
        _checkDbAndMaybeInit();
    }

    export function onDbChangedListener(changes, namespace): void {
        for (let key in changes) {
            var storageChange = changes[key];
            console.log('DIA: Storage key "%s" in namespace "%s" changed. ' +
                'Old value was "%s", new value is "%s".',
                key,
                namespace,
                storageChange.oldValue,
                storageChange.newValue);
        }
    };


    function _storeInitDttm(initDttm:Date) :void{

        if(initDttm){
            let payload = {};
            payload[_INIT_DB_DTTM_KEY]=initDttm.toISOString();
            chrome.storage.local.set(payload);
            console.debug("DIA: stored init dttm:", payload[_INIT_DB_DTTM_KEY]);
        }
        else{
            throw "initDttm was null";
        }
    };


    function _makeDbLoadHandlerWithConsumer(blockedUsersConsumer:IBlockedUsersConsumer) {

        let loadHandlerWithConsumer  = function(dbLoadResult):void {

            blockedUsersConsumer(_toBlockedUsersList(dbLoadResult));
        };

        return loadHandlerWithConsumer;
    };

    // Copy items from loaded array into the current global blocked list.
    function _toBlockedUsersList(dbLoadResult) :string[] {

        if(dbLoadResult && dbLoadResult[_BLOCKED_USERS_KEY]){

            // value should be array object.
            let blockedUsers = [];
            blockedUsers.push.apply(blockedUsers, dbLoadResult[_BLOCKED_USERS_KEY]);
            console.debug("DIA: loaded data. count:", blockedUsers.length);
            return blockedUsers;
        }
        else{
            throw "either dbLoadResult or its ChromeDb._BLOCKED_USERS_KEY was null. " +
            "but db should have been initialized by background-main.js";
        }
    };

    function _checkDbAndMaybeInit(){
        chrome.storage.local.get(_INIT_DB_DTTM_KEY, _resultHandler_checkDb);
    }

    function _resultHandler_checkDb(loadResult){

        if(loadResult && loadResult[_INIT_DB_DTTM_KEY]){

            console.info("DIA: db already exists. db created:", loadResult[_INIT_DB_DTTM_KEY].toString());
        }
        else{
            console.debug("DIA: db was not initialized. Added createDate and empty blockerUsers keys.")
            ChromeDb.storeBlockedUsers([]);
            _storeInitDttm(new Date());
        }
    };

}

if (typeof module !== 'undefined' && module.exports) {
    // for node/jasmine
    exports.TestRef = ChromeDb;
}


