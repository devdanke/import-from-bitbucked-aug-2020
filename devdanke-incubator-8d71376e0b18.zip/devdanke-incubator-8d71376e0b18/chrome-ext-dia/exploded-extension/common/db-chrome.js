/// <reference path="../typings/myGlobal.d.ts"/>
var ChromeDb;
(function (ChromeDb) {
    var _INIT_DB_DTTM_KEY = "INIT_DB_DTTM_KEY";
    var _BLOCKED_USERS_KEY = "BLOCKED_USERS_KEY";
    function storeBlockedUsers(blockedUsers) {
        if (blockedUsers) {
            blockedUsers.sort();
            var payload = {};
            payload[_BLOCKED_USERS_KEY] = blockedUsers;
            chrome.storage.local.set(payload);
            console.debug("DIA: stored blockedUsers. count:", payload[_BLOCKED_USERS_KEY].length);
        }
        else {
            throw "DIA: blockedUsers was null";
        }
    }
    ChromeDb.storeBlockedUsers = storeBlockedUsers;
    ;
    function loadBlockedUsersAsync(blockedUsersConsumer) {
        console.log("DIA: loadBlockedUsersAsync called");
        chrome.storage.local.get(_BLOCKED_USERS_KEY, _makeDbLoadHandlerWithConsumer(blockedUsersConsumer));
    }
    ChromeDb.loadBlockedUsersAsync = loadBlockedUsersAsync;
    ;
    function oneTimeInstallInit() {
        console.log("DIA: installInit called @ " + new Date());
        _checkDbAndMaybeInit();
    }
    ChromeDb.oneTimeInstallInit = oneTimeInstallInit;
    function onDbChangedListener(changes, namespace) {
        for (var key in changes) {
            var storageChange = changes[key];
            console.log('DIA: Storage key "%s" in namespace "%s" changed. ' +
                'Old value was "%s", new value is "%s".', key, namespace, storageChange.oldValue, storageChange.newValue);
        }
    }
    ChromeDb.onDbChangedListener = onDbChangedListener;
    ;
    function _storeInitDttm(initDttm) {
        if (initDttm) {
            var payload = {};
            payload[_INIT_DB_DTTM_KEY] = initDttm.toISOString();
            chrome.storage.local.set(payload);
            console.debug("DIA: stored init dttm:", payload[_INIT_DB_DTTM_KEY]);
        }
        else {
            throw "initDttm was null";
        }
    }
    ;
    function _makeDbLoadHandlerWithConsumer(blockedUsersConsumer) {
        var loadHandlerWithConsumer = function (dbLoadResult) {
            blockedUsersConsumer(_toBlockedUsersList(dbLoadResult));
        };
        return loadHandlerWithConsumer;
    }
    ;
    // Copy items from loaded array into the current global blocked list.
    function _toBlockedUsersList(dbLoadResult) {
        if (dbLoadResult && dbLoadResult[_BLOCKED_USERS_KEY]) {
            // value should be array object.
            var blockedUsers = [];
            blockedUsers.push.apply(blockedUsers, dbLoadResult[_BLOCKED_USERS_KEY]);
            console.debug("DIA: loaded data. count:", blockedUsers.length);
            return blockedUsers;
        }
        else {
            throw "either dbLoadResult or its ChromeDb._BLOCKED_USERS_KEY was null. " +
                "but db should have been initialized by background-main.js";
        }
    }
    ;
    function _checkDbAndMaybeInit() {
        chrome.storage.local.get(_INIT_DB_DTTM_KEY, _resultHandler_checkDb);
    }
    function _resultHandler_checkDb(loadResult) {
        if (loadResult && loadResult[_INIT_DB_DTTM_KEY]) {
            console.info("DIA: db already exists. db created:", loadResult[_INIT_DB_DTTM_KEY].toString());
        }
        else {
            console.debug("DIA: db was not initialized. Added createDate and empty blockerUsers keys.");
            ChromeDb.storeBlockedUsers([]);
            _storeInitDttm(new Date());
        }
    }
    ;
})(ChromeDb || (ChromeDb = {}));
if (typeof module !== 'undefined' && module.exports) {
    // for node/jasmine
    exports.TestRef = ChromeDb;
}
//# sourceMappingURL=db-chrome.js.map