echo '*** clean ***'
rm -rf target

echo '*** create output dir ***'
mkdir  target

echo '*** transpile ***'
java -cp clo-lib/cljs.jar:content-cljs clojure.main build.clj

echo '*** done ***'

