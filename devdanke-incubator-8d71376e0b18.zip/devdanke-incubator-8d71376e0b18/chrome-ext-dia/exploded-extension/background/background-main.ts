/// <reference path="../common/db-chrome.ts"/>
/// <reference path="./background-lib.ts"/>
/// <reference path="../typings/myGlobal.d.ts"/>

// chromy init stuff

chrome.runtime.onInstalled.addListener(BackgroundLib.onPageChangedListener);

chrome.pageAction.onClicked.addListener(BackgroundLib.onExtIconClickedHandler);

//chrome.runtime.onMessage.addListener(onMessageReceivedListener);

chrome.storage.onChanged.addListener(ChromeDb.onDbChangedListener);

// my init stuff

ChromeDb.oneTimeInstallInit();
