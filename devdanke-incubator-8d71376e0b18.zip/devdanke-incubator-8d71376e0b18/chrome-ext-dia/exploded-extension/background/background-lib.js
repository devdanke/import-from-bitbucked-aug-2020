/// <reference path="../typings/myGlobal.d.ts"/>
var BackgroundLib;
(function (BackgroundLib) {
    var installDate = new Date();
    function onExtIconClickedHandler(tab) {
        chrome.pageAction.setTitle({ title: "installed: " + installDate, tabId: tab.id });
        chrome.pageAction.setPopup({
            tabId: tab.id,
            popup: 'popup/mypopup.html'
        });
    }
    BackgroundLib.onExtIconClickedHandler = onExtIconClickedHandler;
    /*
    // Not currently used. dec6
        export function onMessageReceivedListener(request, sender, sendResponse) {
    
            console.log(sender.tab ?
            "from a content script:" + sender.tab.url :
                "from the extension");
    
            console.log("fromContentJsMsg: ", request.myMsg)
            // if (request.greeting == "hello")
            // sendResponse({farewell: "goodbye"});
        }
    */
    /*
     Maybe this is only called on extension install.

     Verify this behavior, and if so, rename function to indicate that.

     Using Declaritive API: When extension installed/upgraded ...
     */
    function onPageChangedListener() {
        var onIsDiaPageRule = {
            // That fires when a page's URL contains a 'dateinasia.com' ...
            // NOTE: Looks like there are multiple places where url is scanned.
            conditions: [
                new chrome.declarativeContent.PageStateMatcher({
                    pageUrl: { urlContains: 'dateinasia' }
                })
            ],
            // And shows the extension's page action.
            actions: [
                new chrome.declarativeContent.ShowPageAction()
            ]
        };
        // Replace current rule(s)
        chrome.declarativeContent.onPageChanged.removeRules(undefined, function () {
            // with a new rule(s)
            chrome.declarativeContent.onPageChanged.addRules([onIsDiaPageRule]);
        });
    }
    BackgroundLib.onPageChangedListener = onPageChangedListener;
})(BackgroundLib || (BackgroundLib = {}));
//# sourceMappingURL=background-lib.js.map