/// <reference path="../common/db-chrome.ts"/>
/// <reference path="../common/util-str.ts"/>

//import React = __React;

let showHiddenUserCountHandler : IBlockedUsersConsumer;
showHiddenUserCountHandler = function (hiddenUsers: string[])
{
    console.info("DIA: showHiddenUserCountHandler called.");
    try{

        let blockedUserCountSpan : HTMLSpanElement = document.getElementById("blockedUserCountSpan");
        blockedUserCountSpan.innerText = safeArrayCountAsString(hiddenUsers);

        console.info("DIA: showHiddenUserCountHandler: set span innerText.");
    }
    catch(e){
        console.log("DIA: showHiddenUserCountHandler: CAUGHT ERROR:", e);
    }
};


let downloadAppBackupDataAsJson : IBlockedUsersConsumer;
downloadAppBackupDataAsJson = function (hiddenUsers:string[]){

    console.info("DIA: downloadAppBackupDataAsJson called.");
    if(hiddenUsers){

        var backupData = {appVer:null, dbVer:null, hiddenUsers:null};

        backupData.hiddenUsers = {hu_bucket_all:hiddenUsers};
        backupData.dbVer = 1;// todo: read from db
        backupData.appVer = chrome.runtime.getManifest().version;

        var urlWithData = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupData));

        chrome.downloads.download({
            url: urlWithData,
            filename: 'ODH-backup-'+StrUtil.nowAsYyyyMmDdHHmm()+'.json'
        });
    }
    else{
        throw "DIA: hiddenUsers was null";
    }
};

function showHiddenUsersCount():void{
    console.info("DIA: showHiddenUsersCount called", new Date());
    ChromeDb.loadBlockedUsersAsync(showHiddenUserCountHandler);
}

function importDataFileIntoDb(onChangeEvent) {
    console.log("DIA: importDataFileIntoDb called. onChangeEvent:", onChangeEvent )

    let file = onChangeEvent.target.files[0];
    console.log("file: ", file)
    var reader = new FileReader()

    reader.onload = function(e) {
        console.log("DIA: onload:", new Date());

        var backupData = JSON.parse(e.target.result);

        // todo: verify the right obj keys exist and data is non null before passing to db.
        ChromeDb.storeBlockedUsers(backupData.hiddenUsers.hu_bucket_all);

        // refresh blocked user count after import
        //console.log("DIA: importDataFileIntoDb: update popup hidden user count in 1 seconds.");
        setTimeout(showHiddenUsersCount, 500);
    }

    reader.onerror = function(stuff) {
        console.log("DIA: onerror", stuff)
        console.log ("DIA: onerror", stuff.getMessage())
    }

    reader.readAsText(file) //readAsdataURL
}

function safeArrayCountAsString(arry:any):string{
    if(arry === undefined){
        //console.log("DIA: array undefined.");
        return "undefined";
    }
    else if(arry === null){
        //console.log("DIA: array null.");
        return "null";
    }
    else{
        //console.log("DIA: array >= empty.");
        return arry.length+"";
    }
}

function exportBlockedUsersData():void {
    console.info("DIA: exportBlockedUsersData called");
    ChromeDb.loadBlockedUsersAsync(downloadAppBackupDataAsJson);
};

function tellFileChooserToPickAndReadFile():void{

    console.info("DIA: tellFileChooserToPickAndReadFile clicked");
    document.getElementById("fileChooser").click();
}

function initPopup():void{
    console.info("DIA: initPopup clicked");

    showHiddenUsersCount();

    // setup button to import data
    // note: file chooser is hidden. but its action is triggered by import button.
    let fileChooser =document.getElementById("fileChooser");
    fileChooser.onchange = importDataFileIntoDb;

    ReactDOM.render(
        React.DOM.button({onClick:exportBlockedUsersData}, "Backup Data"),
        document.getElementById('exportBtnContainer')
    );

    ReactDOM.render(
        React.DOM.button({onClick:tellFileChooserToPickAndReadFile}, "Restore Data"),
        document.getElementById('importBtnContainer')
    );

};

initPopup();
