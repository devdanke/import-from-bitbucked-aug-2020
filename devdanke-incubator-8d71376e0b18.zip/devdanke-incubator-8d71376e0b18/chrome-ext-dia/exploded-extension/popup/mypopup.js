/// <reference path="../common/db-chrome.ts"/>
/// <reference path="../common/util-str.ts"/>
//import React = __React;
var showHiddenUserCountHandler;
showHiddenUserCountHandler = function (hiddenUsers) {
    console.info("DIA: showHiddenUserCountHandler called.");
    try {
        var blockedUserCountSpan = document.getElementById("blockedUserCountSpan");
        blockedUserCountSpan.innerText = safeArrayCountAsString(hiddenUsers);
        console.info("DIA: showHiddenUserCountHandler: set span innerText.");
    }
    catch (e) {
        console.log("DIA: showHiddenUserCountHandler: CAUGHT ERROR:", e);
    }
};
var downloadAppBackupDataAsJson;
downloadAppBackupDataAsJson = function (hiddenUsers) {
    console.info("DIA: downloadAppBackupDataAsJson called.");
    if (hiddenUsers) {
        var backupData = { appVer: null, dbVer: null, hiddenUsers: null };
        backupData.hiddenUsers = { hu_bucket_all: hiddenUsers };
        backupData.dbVer = 1; // todo: read from db
        backupData.appVer = chrome.runtime.getManifest().version;
        var urlWithData = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupData));
        chrome.downloads.download({
            url: urlWithData,
            filename: 'ODH-backup-' + StrUtil.nowAsYyyyMmDdHHmm() + '.json'
        });
    }
    else {
        throw "DIA: hiddenUsers was null";
    }
};
function showHiddenUsersCount() {
    console.info("DIA: showHiddenUsersCount called", new Date());
    ChromeDb.loadBlockedUsersAsync(showHiddenUserCountHandler);
}
function importDataFileIntoDb(onChangeEvent) {
    console.log("DIA: importDataFileIntoDb called. onChangeEvent:", onChangeEvent);
    var file = onChangeEvent.target.files[0];
    console.log("file: ", file);
    var reader = new FileReader();
    reader.onload = function (e) {
        console.log("DIA: onload:", new Date());
        var backupData = JSON.parse(e.target.result);
        // todo: verify the right obj keys exist and data is non null before passing to db.
        ChromeDb.storeBlockedUsers(backupData.hiddenUsers.hu_bucket_all);
        // refresh blocked user count after import
        //console.log("DIA: importDataFileIntoDb: update popup hidden user count in 1 seconds.");
        setTimeout(showHiddenUsersCount, 500);
    };
    reader.onerror = function (stuff) {
        console.log("DIA: onerror", stuff);
        console.log("DIA: onerror", stuff.getMessage());
    };
    reader.readAsText(file); //readAsdataURL
}
function safeArrayCountAsString(arry) {
    if (arry === undefined) {
        //console.log("DIA: array undefined.");
        return "undefined";
    }
    else if (arry === null) {
        //console.log("DIA: array null.");
        return "null";
    }
    else {
        //console.log("DIA: array >= empty.");
        return arry.length + "";
    }
}
function exportBlockedUsersData() {
    console.info("DIA: exportBlockedUsersData called");
    ChromeDb.loadBlockedUsersAsync(downloadAppBackupDataAsJson);
}
;
function tellFileChooserToPickAndReadFile() {
    console.info("DIA: tellFileChooserToPickAndReadFile clicked");
    document.getElementById("fileChooser").click();
}
function initPopup() {
    console.info("DIA: initPopup clicked");
    showHiddenUsersCount();
    // setup button to import data
    // note: file chooser is hidden. but its action is triggered by import button.
    var fileChooser = document.getElementById("fileChooser");
    fileChooser.onchange = importDataFileIntoDb;
    ReactDOM.render(React.DOM.button({ onClick: exportBlockedUsersData }, "Backup Data"), document.getElementById('exportBtnContainer'));
    ReactDOM.render(React.DOM.button({ onClick: tellFileChooserToPickAndReadFile }, "Restore Data"), document.getElementById('importBtnContainer'));
}
;
initPopup();
//# sourceMappingURL=mypopup.js.map