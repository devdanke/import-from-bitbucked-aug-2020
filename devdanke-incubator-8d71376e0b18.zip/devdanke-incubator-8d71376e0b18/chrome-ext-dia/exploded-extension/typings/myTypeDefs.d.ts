declare var module: {exports:any};
declare var exports: {TestRef:any};
declare var MyCloExt: {core:any};
declare var S: any;