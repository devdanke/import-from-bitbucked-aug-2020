/// <reference path="tsd.d.ts" />
/// <reference path="myTypeDefs.d.ts" />