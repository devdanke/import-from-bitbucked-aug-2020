/// <reference path="../common/db-chrome.ts"/>
/// <reference path="../common/util-str.ts"/>
/// <reference path="./section-top-row-mini-pics.ts"/>
/// <reference path="./profile-page-hider.ts"/>
/// <reference path="./profile-page-parser.ts"/>
/// <reference path="./page-search.ts"/>
/// <reference path="./page-message.ts"/>

function contentMain(blockedUsers:string[]){
    try {

        //let pageType =  PageType.getPageType(window.location.pathname);
        let pageType =  MyCloExt.core.get_page_type(window.location.pathname);
        console.log("current url", window.location.pathname, "pageType", pageType);

        if(pageType===PageType.SEARCH){

            SearchPage.process(blockedUsers);
        }
        else if(pageType===PageType.INTERESTED) {

            MiniPics.hideBlocked(blockedUsers);
        }
        else if(pageType===PageType.PROFILE){
            // This is kind of a tricky page type.
            // It's easy for other pages to fall into this bucket.
            // If there's a problem, then it's in getPageType().

            var userName = StrUtil.normalizeUserName(window.location.pathname);

            ProfilePageHider.addHiderButton(userName, blockedUsers);
            ProfilePageParser.addCaptureDataButton(userName);
            MiniPics.hideBlocked(blockedUsers);
        }
        else if(pageType===PageType.MESSAGES) {

            MiniPics.hideBlocked(blockedUsers);
            MessagePage.process(blockedUsers);
        }
        else{
            MiniPics.hideBlocked(blockedUsers);
        }
    }
    catch (e) {
        console.error("DIA: ERROR", e);
    }
}

function main(){

    let processPageWithBlockedUsers = function (blockedUsers){ contentMain(blockedUsers);}
    ChromeDb.loadBlockedUsersAsync(processPageWithBlockedUsers);
}

main();



