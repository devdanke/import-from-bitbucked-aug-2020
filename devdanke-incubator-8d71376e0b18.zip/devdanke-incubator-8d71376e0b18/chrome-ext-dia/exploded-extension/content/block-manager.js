/// <reference path="../common/db-chrome.ts"/>
var BlockMgr;
(function (BlockMgr) {
    function toggleUserHiddenState(userName) {
        var toggleUserHiddenStateHandler = function (hiddenUsers) {
            console.info("DIA: toggleUserHiddenStateHandler called.");
            if (hiddenUsers) {
                try {
                    var idx = hiddenUsers.indexOf(userName);
                    if (idx > -1) {
                        hiddenUsers.splice(idx, 1);
                        console.debug("DIA: db hidden users removed:", userName);
                    }
                    else {
                        hiddenUsers.push(userName);
                        console.debug("DIA: db hidden users added:", userName);
                    }
                    ChromeDb.storeBlockedUsers(hiddenUsers);
                }
                catch (e) {
                    console.error("DIA: toggleUserHiddenStateHandler(", userName, ") got error:", e.toString());
                }
            }
            else {
                throw "DIA: blockedUsers was null";
            }
        };
        ChromeDb.loadBlockedUsersAsync(toggleUserHiddenStateHandler);
    }
    BlockMgr.toggleUserHiddenState = toggleUserHiddenState;
    function isHidden(userName, hiddenUsers) {
        try {
            var result = MyCloExt.core.is_hidden(hiddenUsers, userName);
            //            console.log("DIA: isHidden?", userName, result);
            return (result > -1);
        }
        catch (e) {
            console.log("DIA: isHidden ERROR", e);
        }
        ;
    }
    BlockMgr.isHidden = isHidden;
})(BlockMgr || (BlockMgr = {}));
//# sourceMappingURL=block-manager.js.map