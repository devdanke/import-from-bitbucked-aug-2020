/// <reference path="../typings/myGlobal.d.ts"/>
var MiscUtil;
(function (MiscUtil) {
    function domInsertAfter(el, referenceNode) {
        referenceNode.parentNode.insertBefore(el, referenceNode.nextSibling);
    }
    MiscUtil.domInsertAfter = domInsertAfter;
})(MiscUtil || (MiscUtil = {})); //ts module
if (typeof module !== 'undefined' && module.exports) {
    //for jasmine/node
    exports.TestRef = MiscUtil;
}
//# sourceMappingURL=util-misc.js.map