/// <reference path="../typings/myGlobal.d.ts"/>

module MiscUtil  {

    export function domInsertAfter(el:Element, referenceNode:Element):void {
        referenceNode.parentNode.insertBefore(el, referenceNode.nextSibling);
    }

    /*
    export function isJqueryLoaded(){
        if (typeof jQuery != 'undefined') {
            console.log("DIA: jquery ver:", jQuery.fn.jquery);
            return true;
        }
        else{
            console.log("sorry charley, no jquery");
            return false;
        }
    }
    */

}//ts module

if (typeof module !== 'undefined' && module.exports) {
    //for jasmine/node
    exports.TestRef = MiscUtil;
}

