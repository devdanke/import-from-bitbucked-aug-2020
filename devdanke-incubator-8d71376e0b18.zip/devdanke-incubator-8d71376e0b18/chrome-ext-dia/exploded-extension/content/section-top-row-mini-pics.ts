/// <reference path="block-manager.ts"/>
/// <reference path="../common/util-str.ts"/>
/// <reference path="../common/constants.ts"/>

module MiniPics {

    export function hideBlocked(blockedUsers:string[]):void {

        let matches: NodeList = document.querySelectorAll("img[class*='smallphoto']");

        let hideCount = 0;
        if (matches) {
            for (let i:number = 0; i < matches.length; i++) {
                //var action = "ignore";
                let targElem : HTMLElement = <HTMLElement>matches[i];
                let userName:string = StrUtil.normalizeUserName(targElem.getAttribute("alt"));

                if(BlockMgr.isHidden(userName, blockedUsers)){
                    targElem.parentElement.parentElement.parentElement.classList.toggle(
                        Style.COMPLETELY_HIDE);
                    //action = "hide";
                    hideCount += 1;
                }
                //console.debug("DIA: processTopRowMiniPics():", action , userName);
            }//for
        }//if

        console.debug("DIA: MiniPics.hideBlocked(): miniPics:", matches.length, "blockedUsers:",
            blockedUsers.length, "hide:", hideCount);
    }
}

