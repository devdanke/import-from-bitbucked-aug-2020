/// <reference path="../typings/myGlobal.d.ts"/>
/// <reference path="../common/constants.ts"/>
/// <reference path="util-misc.ts"/>
var ProfilePageParser;
(function (ProfilePageParser) {
    var LAST_ONLINE_PREFIX = "Last online:";
    var ONLINE_NOW = "Online Now!";
    var AGO_SUFFIX = " ago";
    var LAST_ONLINE_SEL = "div.text-pale:contains('" + LAST_ONLINE_PREFIX + "')";
    //let LAST_ONLINE_SEL:string =  "div:contains('"+LAST_ONLINE_PREFIX+"')"; // PROBLEM: gets too many divs (all div ancestors)
    var ONLINE_NOW_SEL = "div.text-pale:contains('" + ONLINE_NOW + "')";
    //let ONLINE_NOW_SEL:string = "div:contains('"+ONLINE_NOW+"')";
    var WHEN_LAST_ONLINE_SELECTORS = [LAST_ONLINE_SEL, ONLINE_NOW_SEL];
    var PROFILE_CREATED_PREFIX = "profile created";
    var PROFILE_CREATED_SEL = "p:contains('" + PROFILE_CREATED_PREFIX + "')";
    // NOTE: All these are inside a div.innercontent element.
    var IM_HERE_TO_SEL = "h2:contains('I\\'m here to')";
    var ABOUT_ME_SEL = "h2:contains('About me')";
    var ABOUT_YOU_SEL = "h2:contains('About you')";
    var PROFILE_SUMMARY_ROWS_SEL = "div.profilesummary > dl > dt";
    function addCaptureDataButton(userName) {
        console.log("DIA: _addCaptureDataButton called");
        var captureDateBtn = document.createElement("button");
        captureDateBtn.innerText = "Capture";
        captureDateBtn.onclick = _makeCaptureDataClickHandler(userName);
        MiscUtil.domInsertAfter(captureDateBtn, document.getElementById("blockThemBtnId"));
    }
    ProfilePageParser.addCaptureDataButton = addCaptureDataButton;
    function _makeCaptureDataClickHandler(userName) {
        function clickHandler() {
            console.debug("DIA: captureDataBtnClickHandler() called");
            _parseProfileData(userName);
            return false; //prevent form submit
        }
        return clickHandler;
    }
    function _parseProfileData(userName) {
        console.debug("DIA: _parseProfileData() called");
        var profileData = {
            USER_NAME: userName,
            AGE: null,
            LAST_ONLINE: null,
            PROFILE_CREATED: null,
            SEEKING: null,
            ABOUT_ME: null,
            ABOUT_YOU: null
        };
        try {
            var ageAndLastOnline = _parseAgeAndLastOnline();
            profileData.AGE = ageAndLastOnline.AGE;
            profileData.LAST_ONLINE = ageAndLastOnline.LAST_ONLINE;
            var profileCreated = _parseProfileCreated();
            if (profileCreated != null) {
                profileData.PROFILE_CREATED = profileCreated;
            }
            var imHereTo = _getParaTextAfterH2(IM_HERE_TO_SEL);
            if (imHereTo != null) {
                profileData.SEEKING = imHereTo;
            }
            var aboutMe = _getParaTextAfterH2(ABOUT_ME_SEL);
            if (aboutMe != null) {
                profileData.ABOUT_ME = aboutMe;
            }
            var aboutYou = _getParaTextAfterH2(ABOUT_YOU_SEL);
            if (aboutYou != null) {
                profileData.ABOUT_YOU = aboutYou;
            }
            _copyProps(_getProfileSummaryRows(), profileData);
        }
        catch (e) {
            console.log("DIA: _parseProfileData: ERROR:", e);
        }
        console.log("DIA: profileData:", profileData);
    }
    // NOTE: only available on desktop view
    function _parseAgeAndLastOnline() {
        console.debug("DIA: _parseAgeAndLastOnline() called");
        var finalResult = { AGE: null, LAST_ONLINE: null };
        var searchResult = _return1stItemFrom1stSelectorWithMatches(WHEN_LAST_ONLINE_SELECTORS);
        if (searchResult != null) {
            finalResult.AGE = searchResult.AGE;
            finalResult.LAST_ONLINE = searchResult.LAST_ONLINE;
        }
        return finalResult;
    }
    // NOTE: only available within the first few days/hours after joining.
    function _parseProfileCreated() {
        console.debug("DIA: _parseProfileCreated() called");
        var jqElem = _selectJqElemFor(PROFILE_CREATED_SEL);
        if (jqElem != null) {
            return _extractTextBetween(jqElem, PROFILE_CREATED_PREFIX, AGO_SUFFIX);
        }
        else {
            return null;
        }
    }
    // all args non null
    function _extractTextBetween(elem, start, end) {
        var s = elem.innerText.trim();
        var startPos = s.lastIndexOf(start) + start.length;
        var endPos = s.lastIndexOf(end);
        return s.substring(startPos, endPos);
    }
    // returns struct with jquery elem
    // if no matches, found is null
    function _return1stItemFrom1stSelectorWithMatches(selectors) {
        for (var i = 0; i < selectors.length; i++) {
            var jqElem = _selectJqElemFor(selectors[i]);
            if (jqElem != null) {
                return _extractAgeAndLastOnline(jqElem, selectors[i]);
            }
        }
        return null;
    }
    // return null if not found
    function _selectJqElemFor(selector) {
        //let jqMatches = jQuery( "div.text-pale:contains('"+selector+"')" );
        var jqMatches = jQuery(selector);
        if (jqMatches.length > 0) {
            return jqMatches[0];
        }
        else {
            return null;
        }
    }
    // todo: return a date minus lastOnline value
    // jqElem & selector are not null
    function _extractAgeAndLastOnline(jqElem, selector) {
        var result = { lastOnline: null, age: null };
        if (selector == ONLINE_NOW_SEL) {
            result.LAST_ONLINE = "NOW";
        }
        else {
            var temp = jqElem.innerText.trim();
            var suffixPos = temp.lastIndexOf(AGO_SUFFIX);
            if (suffixPos > -1) {
                //console.log("DIA: suffixPos", suffixPos, "temp:'", temp, "'", "LO.length", LAST_ONLINE.length);
                temp = temp.substring(LAST_ONLINE_PREFIX.length, suffixPos).trim();
            }
            result.LAST_ONLINE = temp;
        }
        var nameAndAgeStr = jqElem.parentElement.firstElementChild.innerText;
        var age = parseInt(nameAndAgeStr.substring(nameAndAgeStr.indexOf(",") + 1).trim());
        result.AGE = age;
        return result;
    }
    function _getParaTextAfterH2(selector) {
        try {
            var jqElem = _selectJqElemFor(selector);
            if (jqElem != null) {
                return jqElem.nextElementSibling.innerText;
            }
            else {
                throw "No matches!";
            }
        }
        catch (e) {
            console.log("DIA: getParaTextAfterH2: selector:", selector, "ERROR:", e);
        }
        return null;
    }
    function _getProfileSummaryRows() {
        var jqMatches = jQuery(PROFILE_SUMMARY_ROWS_SEL);
        console.log("DIA: summary row count:", jqMatches.length);
        var summaryProps = {};
        for (var i = 0; i < jqMatches.length; i++) {
            var propElem = jqMatches[i];
            var propName = propElem.innerText.trim();
            if (S(propName).endsWith(":")) {
                propName = propName.substring(0, propName.length - 1);
            }
            propName = propName.replace(/ /g, "_").toUpperCase();
            var propVal = propElem.nextElementSibling.innerText.trim().replace(/<br>/g, " ");
            //console.log("DIA: property: ", propName, "=", propVal  );
            summaryProps[propName] = propVal;
        }
        return summaryProps;
    }
    function _copyProps(fromObj, toObj) {
        for (var i in fromObj) {
            if (fromObj.hasOwnProperty(i)) {
                toObj[i] = fromObj[i];
            }
        }
    }
})(ProfilePageParser || (ProfilePageParser = {})); //ts module
//# sourceMappingURL=profile-page-parser.js.map