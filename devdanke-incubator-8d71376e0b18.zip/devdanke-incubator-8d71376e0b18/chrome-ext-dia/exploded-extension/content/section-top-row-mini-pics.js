/// <reference path="block-manager.ts"/>
/// <reference path="../common/util-str.ts"/>
/// <reference path="../common/constants.ts"/>
var MiniPics;
(function (MiniPics) {
    function hideBlocked(blockedUsers) {
        var matches = document.querySelectorAll("img[class*='smallphoto']");
        var hideCount = 0;
        if (matches) {
            for (var i = 0; i < matches.length; i++) {
                //var action = "ignore";
                var targElem = matches[i];
                var userName = StrUtil.normalizeUserName(targElem.getAttribute("alt"));
                if (BlockMgr.isHidden(userName, blockedUsers)) {
                    targElem.parentElement.parentElement.parentElement.classList.toggle(Style.COMPLETELY_HIDE);
                    //action = "hide";
                    hideCount += 1;
                }
            } //for
        } //if
        console.debug("DIA: MiniPics.hideBlocked(): miniPics:", matches.length, "blockedUsers:", blockedUsers.length, "hide:", hideCount);
    }
    MiniPics.hideBlocked = hideBlocked;
})(MiniPics || (MiniPics = {}));
//# sourceMappingURL=section-top-row-mini-pics.js.map