/// <reference path="../typings/myGlobal.d.ts"/>
/// <reference path="../common/constants.ts"/>
/// <reference path="util-misc.ts"/>

module ProfilePageParser {

    let LAST_ONLINE_PREFIX:string = "Last online:";
    let ONLINE_NOW:string = "Online Now!";
    let AGO_SUFFIX:string = " ago";

    let LAST_ONLINE_SEL:string =  "div.text-pale:contains('"+LAST_ONLINE_PREFIX+"')";
    //let LAST_ONLINE_SEL:string =  "div:contains('"+LAST_ONLINE_PREFIX+"')"; // PROBLEM: gets too many divs (all div ancestors)
    let ONLINE_NOW_SEL:string = "div.text-pale:contains('"+ONLINE_NOW+"')";
    //let ONLINE_NOW_SEL:string = "div:contains('"+ONLINE_NOW+"')";
    let WHEN_LAST_ONLINE_SELECTORS:string[] = [LAST_ONLINE_SEL,ONLINE_NOW_SEL];

    let PROFILE_CREATED_PREFIX:string = "profile created";
    let PROFILE_CREATED_SEL = "p:contains('"+PROFILE_CREATED_PREFIX+"')";

    // NOTE: All these are inside a div.innercontent element.
    let IM_HERE_TO_SEL:string =  "h2:contains('I\\'m here to')";
    let ABOUT_ME_SEL:string =  "h2:contains('About me')";
    let ABOUT_YOU_SEL:string =  "h2:contains('About you')";

    let PROFILE_SUMMARY_ROWS_SEL:string= "div.profilesummary > dl > dt";


    export function addCaptureDataButton(userName:string):void {

        console.log("DIA: _addCaptureDataButton called");

        let captureDateBtn:HTMLButtonElement = document.createElement("button");
        captureDateBtn.innerText = "Capture";
        captureDateBtn.onclick = _makeCaptureDataClickHandler(userName);

        MiscUtil.domInsertAfter(captureDateBtn, document.getElementById("blockThemBtnId"));
    }


    function _makeCaptureDataClickHandler(userName:string): ()=>void {

        function clickHandler() {
            console.debug("DIA: captureDataBtnClickHandler() called");

            _parseProfileData(userName);

            return false;//prevent form submit
        }

        return clickHandler;
    }

    function _parseProfileData(userName:string){
        console.debug("DIA: _parseProfileData() called");


        let profileData = {
            USER_NAME:userName,
            AGE:null,
            LAST_ONLINE:null,
            PROFILE_CREATED:null,
            SEEKING:null,
            ABOUT_ME:null,
            ABOUT_YOU:null,
        };

        try{
            let ageAndLastOnline = _parseAgeAndLastOnline();
            profileData.AGE = ageAndLastOnline.AGE;
            profileData.LAST_ONLINE = ageAndLastOnline.LAST_ONLINE;

            let profileCreated:string = _parseProfileCreated();
            if(profileCreated != null){
                profileData.PROFILE_CREATED = profileCreated;
            }

            let imHereTo:string = _getParaTextAfterH2(IM_HERE_TO_SEL);
            if(imHereTo != null){
                profileData.SEEKING = imHereTo;
            }

            let aboutMe:string = _getParaTextAfterH2(ABOUT_ME_SEL);
            if(aboutMe != null){
                profileData.ABOUT_ME = aboutMe;
            }

            let aboutYou:string = _getParaTextAfterH2(ABOUT_YOU_SEL);
            if(aboutYou != null){
                profileData.ABOUT_YOU = aboutYou;
            }

            _copyProps(_getProfileSummaryRows(), profileData);
        }
        catch(e){
            console.log("DIA: _parseProfileData: ERROR:", e);
        }

        console.log("DIA: profileData:", profileData);
    }

    // NOTE: only available on desktop view
    function _parseAgeAndLastOnline(){
        console.debug("DIA: _parseAgeAndLastOnline() called");
        let finalResult = {AGE:null, LAST_ONLINE:null};

        let searchResult = _return1stItemFrom1stSelectorWithMatches(WHEN_LAST_ONLINE_SELECTORS);
        if(searchResult != null){
            finalResult.AGE = searchResult.AGE;
            finalResult.LAST_ONLINE = searchResult.LAST_ONLINE;
        }

        return finalResult;
    }

    // NOTE: only available within the first few days/hours after joining.
    function _parseProfileCreated(){
        console.debug("DIA: _parseProfileCreated() called");

        let jqElem = _selectJqElemFor(PROFILE_CREATED_SEL);
        if(jqElem != null){
            return _extractTextBetween(jqElem,PROFILE_CREATED_PREFIX,AGO_SUFFIX);
        }
        else {
            return null;
        }
    }

    // all args non null
    function _extractTextBetween(elem,start,end):string{
        let s = elem.innerText.trim();
        let startPos = s.lastIndexOf(start)+start.length;
        let endPos = s.lastIndexOf(end);
        return s.substring(startPos,endPos);
    }


    // returns struct with jquery elem
    // if no matches, found is null
    function _return1stItemFrom1stSelectorWithMatches(selectors:string[]){

        for(let i=0; i<selectors.length; i++){

            let jqElem = _selectJqElemFor(selectors[i]);
            if(jqElem != null){
                return _extractAgeAndLastOnline(jqElem,selectors[i]);
            }
        }
        return null;
    }

    // return null if not found
    function _selectJqElemFor(selector:string){

        //let jqMatches = jQuery( "div.text-pale:contains('"+selector+"')" );
        let jqMatches = jQuery( selector );
        if(jqMatches.length > 0){

            return jqMatches[0];
        }
        else {
            return null;
        }
    }

    // todo: return a date minus lastOnline value
    // jqElem & selector are not null
    function _extractAgeAndLastOnline(jqElem:any, selector:string){
        let result = {lastOnline:null, age:null};

        if(selector == ONLINE_NOW_SEL) {
            result.LAST_ONLINE = "NOW";
        }
        else {
            let temp = jqElem.innerText.trim();

            let suffixPos = temp.lastIndexOf(AGO_SUFFIX);
            if( suffixPos > -1){
                //console.log("DIA: suffixPos", suffixPos, "temp:'", temp, "'", "LO.length", LAST_ONLINE.length);
                temp = temp.substring(LAST_ONLINE_PREFIX.length, suffixPos).trim();
            }
            result.LAST_ONLINE = temp;
        }

        let nameAndAgeStr = jqElem.parentElement.firstElementChild.innerText;
        let age:number = parseInt(nameAndAgeStr.substring(nameAndAgeStr.indexOf(",")+1).trim());

        result.AGE = age;

        return result;
    }


    function _getParaTextAfterH2(selector:string):string{

        try{
            let jqElem = _selectJqElemFor(selector);
            if(jqElem!=null){

                return jqElem.nextElementSibling.innerText;
            }
            else{
                throw "No matches!";
            }
        }
        catch(e){
            console.log("DIA: getParaTextAfterH2: selector:", selector, "ERROR:", e);
        }
        return null;
    }

    function _getProfileSummaryRows(){
        let jqMatches = jQuery( PROFILE_SUMMARY_ROWS_SEL );
        console.log("DIA: summary row count:", jqMatches.length);

        let summaryProps = {};

        for(let i=0; i<jqMatches.length; i++){
            let propElem = jqMatches[i];
            let propName =propElem.innerText.trim();
            if(S(propName).endsWith(":")){
                propName = propName.substring(0,propName.length-1);
            }

            propName = propName.replace(/ /g,"_").toUpperCase();

            let propVal = propElem.nextElementSibling.innerText.trim().replace(/<br>/g," ");

            //console.log("DIA: property: ", propName, "=", propVal  );
            summaryProps[propName]=propVal;
        }

        return summaryProps;
    }


    function _copyProps(fromObj, toObj):void {

        for (var i in fromObj) {
            if (fromObj.hasOwnProperty(i)) {
                toObj[i] = fromObj[i];
            }
        }
    }

}//ts module
