/// <reference path="../common/util-str.ts"/>
var SearchGridItemHelper = (function () {
    function SearchGridItemHelper(gridItemDiv) {
        this._gridItem = gridItemDiv;
    }
    /*
    There are non- search item results inside search  grid.
     */
    SearchGridItemHelper.prototype.isGridItem = function () {
        var elem = this._getPicSection();
        if (!this._isElemType(elem, "SPAN")) {
            return false;
        }
        var picSection1stChild = elem.children[0];
        if (!this._isElemType(picSection1stChild, "A")) {
            return false;
        }
        return true;
    };
    //todo: move to dom util
    SearchGridItemHelper.prototype._isElemType = function (elem, elemType) {
        return ((elem != null) && (elem.nodeName == elemType.toUpperCase()));
    };
    // Returns normalized userName, i.e. lowercase.
    SearchGridItemHelper.prototype.getUserName = function () {
        var rawRelHref = this._getPicSection().querySelector("a").getAttribute("href");
        return StrUtil.normalizeUserName(rawRelHref);
    };
    SearchGridItemHelper.prototype.replaceUserNameLinkWithBlockBtn = function (blockBtn) {
        // 1st span in infoSection contains possible 'online' elem and userName anchor.
        var targParent = this._getInfoSection().children[0];
        var targ = targParent.querySelector("a");
        targParent.replaceChild(blockBtn, targ);
    };
    SearchGridItemHelper.prototype.getPic = function () {
        return this._getPicSection().querySelector("img");
    };
    SearchGridItemHelper.prototype._getPicSection = function () {
        return this._gridItem.children[0];
    };
    SearchGridItemHelper.prototype._getInfoSection = function () {
        return this._gridItem.children[1];
    };
    return SearchGridItemHelper;
})();
//# sourceMappingURL=section-search-grid-item.js.map