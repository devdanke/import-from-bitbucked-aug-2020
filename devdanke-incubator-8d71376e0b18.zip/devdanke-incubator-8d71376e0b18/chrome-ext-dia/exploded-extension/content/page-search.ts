/// <reference path="block-manager.ts"/>
/// <reference path="section-top-row-mini-pics.ts"/>
/// <reference path="../common/constants.ts"/>
/// <reference path="section-search-grid-item.ts"/>


module SearchPage {

    /*
     TODO: maybe put this in content-lib.  just take list of elements that need to have styleClass toggle.
     use in several places in app
     */
     function _toggleSearchGirdUserBlockedUi(userName:string, blockThemBtn:HTMLButtonElement,
        imgElem:HTMLImageElement):void{

        blockThemBtn.classList.toggle(Style.BLOCKER_BTN_BLOCKED);
        imgElem.classList.toggle(Style.IMG_BLOCKED);

        var action = blockThemBtn.classList.contains(Style.BLOCKER_BTN_BLOCKED)? "blocked":"unblocked";
        console.debug("DIA: _toggleSearchGirdUserBlockedUi():", action, userName);
    }


     function _makeBlockThemClickHandlerForSearchPage(userName:string, blockThemBtn:HTMLButtonElement,
        imgElem:HTMLImageElement) {

        function blockThemClickHandler(event:MouseEvent):boolean {

            console.debug("DIA: blockThemClickHandler() called");
            _toggleSearchGirdUserBlockedUi(userName, blockThemBtn, imgElem);
            BlockMgr.toggleUserHiddenState(userName);

            return false;//prevent form submit
        }

        return blockThemClickHandler;
    }

     function _makeBlockBtn(userName:string, imgElem:HTMLImageElement):HTMLButtonElement{
        let blockThemBtn:HTMLButtonElement = document.createElement("button");

        // had to return func or else all funcs use last list item :-(
        blockThemBtn.onclick = _makeBlockThemClickHandlerForSearchPage(userName, blockThemBtn, imgElem);
        blockThemBtn.setAttribute("class", Style.BLOCKER_BTN_DEFAULT);
        blockThemBtn.innerText = userName;
        return blockThemBtn;
    }

    /*
     Add a button to un/block this user.
     return true if this user is blocked.
     This only gets called once at page load.
     */
    function _processSearchPageItem(searchGridItemDiv, blockedUsers){

        var result = {isHidden:false, action:'ignrore'};//default
        try{
            var gridItemHelper = new SearchGridItemHelper(searchGridItemDiv);
            if(!gridItemHelper.isGridItem()){
                return result;
            }

            var userName = gridItemHelper.getUserName();

            if (BlockMgr.isHidden(userName, blockedUsers)) {

                // completely hide previously blocked users
                searchGridItemDiv.classList.toggle(Style.COMPLETELY_HIDE);
                result = {isHidden:true, action:'hide'}
            }
            else{
                // otherwise, add a block button in place of their displayed username.
                var blockBtn = _makeBlockBtn(userName,gridItemHelper.getPic());
                gridItemHelper.replaceUserNameLinkWithBlockBtn(blockBtn);
                result = {isHidden:false, action:'show'};
            }

            //console.debug("DIA: _processSearchPageItem(): ", userName, result);
            return result;
        }
        catch(e){
            console.error("Cannot process searchGridItem:",searchGridItemDiv, "error", e );
        }
    }


    /*
     Only runs once when a page is loaded.  Other blocking happens one picture at a time.
     Not sure how 'going back' would be handled by this method/extension.
     May need to keep state on whether current page was processed (ie came from post load history stack)
     //  Type IBlockedUsersConsumer
     */
    export function process(blockedUsers) {
        console.log("DIA: SearchPage.process() called");
        try{
            //var searchPageImgContainerSel = ".ttip";
            var searchPageImgContainerSel = "div.searchgrid > div";
            var matchesNodeList = document.querySelectorAll(searchPageImgContainerSel);

            console.debug("DIA: selector'", searchPageImgContainerSel, "' match count", matchesNodeList.length);

            var hiddenCount = 0;
            if (matchesNodeList) {

                for (var i = 0; i < matchesNodeList.length; i++) {

                    //var searchGridItemDiv = matchesNodeList.item(i).parentElement;
                    var searchGridItemDiv = matchesNodeList.item(i);
                    //console.debug("DIA: match item:", i, "searchGridItemDiv", searchGridItemDiv);

                    if(_processSearchPageItem(searchGridItemDiv, blockedUsers).isHidden){
                        hiddenCount += 1;
                    };

                }//for
            }//if
            console.debug("DIA: hidden count:", hiddenCount);
        }
        catch(e){
            console.error("DIA: processSearchPage():", e);
        }
    }
}




