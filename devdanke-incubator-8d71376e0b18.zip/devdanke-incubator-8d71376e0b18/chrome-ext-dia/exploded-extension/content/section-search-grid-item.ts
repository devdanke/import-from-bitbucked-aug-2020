/// <reference path="../common/util-str.ts"/>

class SearchGridItemHelper {

    _gridItem: HTMLElement;

    constructor (gridItemDiv: HTMLElement) {
        this._gridItem = gridItemDiv;
    }

    /*
    There are non- search item results inside search  grid.
     */
    isGridItem(){
        let elem = this._getPicSection();
        if(!this._isElemType(elem,"SPAN")){
            return false;
        }

        let picSection1stChild = elem.children[0];
        if(!this._isElemType(picSection1stChild,"A")){
            return false;
        }

        return true;
    }

    //todo: move to dom util
    _isElemType(elem : Element, elemType:string){
        return ((elem != null) && (elem.nodeName == elemType.toUpperCase()))
    }

    // Returns normalized userName, i.e. lowercase.
    getUserName() : string {
        let rawRelHref = (<NodeSelector>this._getPicSection()).querySelector("a").getAttribute("href");
        return StrUtil.normalizeUserName(rawRelHref);
    }

    replaceUserNameLinkWithBlockBtn(blockBtn:HTMLElement) : void {
        // 1st span in infoSection contains possible 'online' elem and userName anchor.
        let targParent = this._getInfoSection().children[0];
        let targ = targParent.querySelector("a");
        targParent.replaceChild(blockBtn,targ);
    }

    getPic() : HTMLImageElement {
        return <HTMLImageElement>this._getPicSection().querySelector("img");
    }

    _getPicSection() : HTMLElement {
        return <HTMLElement>this._gridItem.children[0];
    }

    _getInfoSection() : HTMLElement {
        return <HTMLElement>this._gridItem.children[1];
    }
}
