/// <reference path="block-manager.ts"/>
/// <reference path="section-top-row-mini-pics.ts"/>
/// <reference path="../common/constants.ts"/>


module MessagePage {

    export function process(blockedUsers:string[]):void{

        console.log("DIA: MessagePage.process called");

        let checkBoxItems:NodeListOf<Element> = document.querySelectorAll(".cb-column");
        console.log("match count", checkBoxItems.length);

        _.each(checkBoxItems, addDeleteBtnBesideCheckbox);
    }

    function addDeleteBtnBesideCheckbox(item){

        let checkBox:HTMLInputElement = <HTMLInputElement>item.firstElementChild;
        let userId=checkBox.id;
        //console.log("cbox id", userId );

        let parentDiv:HTMLElement = item.parentElement;
        parentDiv.appendChild(makeBtn(userId));
    }


    function makeBtn(userId:string):HTMLButtonElement{
        let btn:HTMLButtonElement = document.createElement("button");

        // had to return func or else all funcs use last list item :-(
        btn.onclick = function(){
            console.log("delete userId", userId);
            (<HTMLInputElement>document.getElementById("deletecollection")).value =userId;
            return true;//submits form
        }

        btn.innerText = "X";
        btn.style.color = "red";
        btn.style.marginLeft = "5px";
        //btn.style.verticalAlign = "middle"; //no effect
        return btn;
    }
}


