/// <reference path="../common/db-chrome.ts"/>

module BlockMgr {

    export function toggleUserHiddenState(userName:string): void {

         var toggleUserHiddenStateHandler : IBlockedUsersConsumer = function(hiddenUsers:string[]){

             console.info("DIA: toggleUserHiddenStateHandler called.");
             if(hiddenUsers){

                 try{
                     var idx = hiddenUsers.indexOf(userName);

                     if (idx > -1) {

                         hiddenUsers.splice(idx, 1);
                         console.debug("DIA: db hidden users removed:", userName );
                     }
                     else {

                         hiddenUsers.push(userName);
                         console.debug("DIA: db hidden users added:", userName );
                     }

                     ChromeDb.storeBlockedUsers(hiddenUsers);
                 }
                 catch(e){
                     console.error("DIA: toggleUserHiddenStateHandler(", userName,") got error:", e.toString() );
                 }
             }
             else{
                 throw "DIA: blockedUsers was null";
             }
         };

        ChromeDb.loadBlockedUsersAsync(toggleUserHiddenStateHandler);
    }


    export function isHidden(userName:string, hiddenUsers:string[]):boolean {

        try{
            let result = MyCloExt.core.is_hidden(hiddenUsers,userName);
//            console.log("DIA: isHidden?", userName, result);
            return (result > -1);
            //return result;
//        return _.contains(hiddenUsers, userName)
        }
        catch(e){
            console.log("DIA: isHidden ERROR", e);
        };
    }

}


