/// <reference path="block-manager.ts"/>
/// <reference path="util-misc.ts"/>
/// <reference path="../common/constants.ts"/>
/// <reference path="../typings/myGlobal.d.ts"/>

module ProfilePageHider {

    export function addHiderButton(userName:string, blockedUsers:string[]):void {

        console.log("DIA: addHiderButton() called");

        let blockThemBtn:HTMLButtonElement = document.createElement("button");
        blockThemBtn.setAttribute("id","blockThemBtnId");

        // had to return func or else all funcs use last list item :-(
        blockThemBtn.onclick = _makeBlockBtnClickHandler(userName,blockThemBtn);

        blockThemBtn.setAttribute("class", Style.BLOCKER_BTN_DEFAULT);

        if(BlockMgr.isHidden(userName,blockedUsers)){
            blockThemBtn.innerText = "Unhide";
            blockThemBtn.classList.add(Style.BLOCKER_BTN_BLOCKED);
        }
        else{
            blockThemBtn.innerText = "Hide";
        }

        MiscUtil.domInsertAfter(blockThemBtn, document.getElementById("headline"));
    }

    function _makeBlockBtnClickHandler(userName:string, blockThemBtn:HTMLButtonElement): ()=>void {

        function blockThemClickHandler() {
            //console.debug("DIA: blockThemClickHandler() called");

            // would be nice to show fading tool tip saying 'un/blocked.
            // then page exit

            blockThemBtn.classList.toggle(Style.BLOCKER_BTN_BLOCKED);
            BlockMgr.toggleUserHiddenState(userName);

            if (blockThemBtn.classList.contains(Style.BLOCKER_BTN_BLOCKED)) {

                blockThemBtn.innerText = "Unhide";
                console.debug("DIA: profile page: blocked", userName);
                setTimeout(window.close, 800);
            }
            else {
                blockThemBtn.innerText = "Hide";
                console.debug("DIA: profile page click: unblocked", userName);
            }
            return false;//prevent form submit
        }

        return blockThemClickHandler;
    }

}//ts module
