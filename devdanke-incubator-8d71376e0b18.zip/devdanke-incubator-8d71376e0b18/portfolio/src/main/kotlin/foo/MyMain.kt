package foo

import com.fasterxml.jackson.databind.ObjectMapper
import org.skife.jdbi.v2.DBI


fun main(args: Array<String>) {
    println("--- Portfolio Visualizer ---")

    val dbi = DBI("jdbc:h2:file:~/_dev/my-portfolio-db;IFEXISTS=TRUE")
    val h = dbi.open()

    val views = listOf("GRAPH_EQUITY_V_NON_EQUITY",
            "GRAPH_SECTOR_PERCENT",
            "GRAPH_US_V_FOREIGN")

    val jackson = ObjectMapper()

    views.forEach{view ->
        val q = h.createQuery("select * from $view")

        val rows: List<Map<String,Any>> = q.list()
        val row = rows[0]

        if(rows.size > 1) {
            println("$view: ${jackson.writeValueAsString(rows)}")
        }
        else {
            println("$view: ${jackson.writeValueAsString(row)}")
        }
    }

    h.close()

}