
create or replace view graph_sector_percent as

select
  SECTOR,
  cast(round(((tot_eqty_val*1.0)/(select EQUITY_VAL from GRAPH_EQUITY_V_NON_EQUITY))*100) as int) percent_tot_eqty
from (

    select
      a.SECTOR,
      sum(v.TOT_VALUE) as tot_val,
      cast(sum(v.TOT_VALUE * (EQUITY_PERCENT/100.0)) as int) as tot_eqty_val
    from TOTAL_ASSET_VALUE v
      join asset a on v.SYMBOL = a.SYMBOL
      where SECTOR not in ('cash','bond','reit')
    GROUP BY a.SECTOR
    ORDER BY a.SECTOR
)
;


create or replace view graph_us_v_foreign as
  select
    sum(us_value) as us_val,
    sum(foreign_value) as foreign_val,
    sum(us_value) + sum(foreign_value) as tot_val,
    cast(round((sum(us_value)*1.0)/(sum(us_value) + sum(foreign_value))*100,0)as int) as us_percent,
    cast(round((sum(foreign_value)*1.0)/(sum(us_value) + sum(foreign_value))*100,0)as int) as foreign_percent
  from (
    select v.SYMBOL, v.TOT_VALUE, a.US_PERCENT,
      cast(TOT_VALUE * US_PERCENT/100.0 as int) as us_value,
      cast(TOT_VALUE * (100-US_PERCENT)/100.0 as int) as foreign_value
    from TOTAL_ASSET_VALUE v
      join asset a on v.SYMBOL = a.SYMBOL
  )
;



-- graph ready equity to non-equity percents
create or replace view graph_equity_v_non_equity as
  select
    sum(EQUITY_VAL) as equity_val,
    sum(NON_EQUITY_VAL) as non_equity_val,
    (sum(EQUITY_VAL) + sum(NON_EQUITY_VAL)) as tot_val,
    cast((sum(EQUITY_VAL)*1.0/(sum(EQUITY_VAL) + sum(NON_EQUITY_VAL)))*100 as int) as equity_percent,
    cast((sum(NON_EQUITY_VAL)*1.0/(sum(EQUITY_VAL) + sum(NON_EQUITY_VAL)))*100 as int) as non_equity_percent

  from ASSET_CLASS_PERCENT_EQUITY

-- get data to determine % equity to non-equity.
create or replace view ASSET_CLASS_PERCENT_EQUITY as

  select
    ASSET_CLASS,
    avg(EQUITY_PERCENT) as asset_class_avg_equity_percent,
    sum(v.tot_value) as val
  , cast((avg(EQUITY_PERCENT)/100.0 * sum(v.tot_value)) as int ) as equity_val
  , cast(((abs(100-avg(EQUITY_PERCENT))/100.0)*sum(v.tot_value)) as int ) as non_equity_val
  from TOTAL_ASSET_VALUE v JOIN ASSET a on v.SYMBOL = a.SYMBOL
  group by ASSET_CLASS;


create or REPLACE view total_asset_percent as
select SYMBOL, TOT_VALUE,
  round(100 * TOT_VALUE/(select sum(TOT_VALUE) from TOTAL_ASSET_VALUE),1) as percent_of_tot
from TOTAL_ASSET_VALUE
order by percent_of_tot DESC ;

-- total asset value by symbol
create or REPLACE view TOTAL_ASSET_VALUE as
  select q.SYMBOL, q.TOT_QUANT * p.UNIT_PRICE as tot_value
  from TOTAL_ASSET_QUANTITY q join LATEST_PRICE p
      on (q.SYMBOL = p.symbol)
  order by q.SYMBOL


-- view_latest_price
create or replace view view_latest_price as
select p1.SYMBOL, p1.UNIT_PRICE, p2.latest_quote
from PRICE p1
  join
  (
    select SYMBOL, max(QUOTE_DATE) as latest_quote
    from PRICE
    GROUP BY SYMBOL
  ) p2
    on (p1.SYMBOL=p2.SYMBOL and p1.QUOTE_DATE = p2.latest_quote)
order by p1.SYMBOL

-- view_total_asset_quantity
create or replace view view_total_asset_quantity as
select symbol, sum(QUANTITY) as tot_quant
from holding
group by symbol
order by symbol;


CREATE TABLE raw_data (
  broker VARCHAR(10),
  account VARCHAR(10),
  type VARCHAR(10),
  symbol VARCHAR(10),
  stock_percent VARCHAR(10),
  sector VARCHAR(15),
  usa_percent INTEGER,
  quantity INTEGER,
  share_price INTEGER
  )
AS SELECT
  broker, account, type, symbol, stock_percent, sector, usa_percent, quantity, share_price
FROM CSVREAD('~/Dropbox/Records/401k/retirement-holdings-25aug2017.csv') ;


BACKUP TO '~/Dropbox/Records/401k/h2-backup-retirement-holdings-25aug2017.zip'


~/_dev/my-portfolio-db  & EXISTS=TRUE