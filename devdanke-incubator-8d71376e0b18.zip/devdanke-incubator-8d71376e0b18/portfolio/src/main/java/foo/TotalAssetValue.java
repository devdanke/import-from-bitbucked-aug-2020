package foo;


import lombok.Data;

@Data
public class TotalAssetValue {

}
