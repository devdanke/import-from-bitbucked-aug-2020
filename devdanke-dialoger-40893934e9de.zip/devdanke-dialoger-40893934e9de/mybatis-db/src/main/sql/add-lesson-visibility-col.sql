ALTER TABLE sentence_lesson
ADD COLUMN visible VARCHAR(10);

UPDATE sentence_lesson
SET visible = 'PUBLIC';

ALTER TABLE sentence_lesson
MODIFY COLUMN visible VARCHAR(10) NOT NULL;


