package com.menlospark.dialog.model;

import com.menlospark.util.MyAssert;

/**
 * *************************************************************************************
 *
 * @Since 12/14/11
 * <p/>
 * *************************************************************************************
 */
public enum LessonType
{
    VOCAB, GRAMMER, DIALOG;

    public static LessonType calcType(String lessonTitle)
    {
        MyAssert.notNullOrEmpty("lessonTitle", lessonTitle);
        if(lessonTitle.trim().toUpperCase().startsWith("GRAMMAR"))
        {
            return GRAMMER;
        }
        else
        {
            return DIALOG;
        }
    }

}
