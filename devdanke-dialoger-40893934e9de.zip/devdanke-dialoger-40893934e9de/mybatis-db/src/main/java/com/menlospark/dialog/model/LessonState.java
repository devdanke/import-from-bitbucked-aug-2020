package com.menlospark.dialog.model;

import com.menlospark.util.MyAssert;

/**
 * *************************************************************************************
 *
 * @Since 12/14/11
 * <p/>
 * *************************************************************************************
 */
public enum LessonState
{
    LEARNABLE, OTHER;

    public static LessonState calcState(String lessonStatus)
    {
        MyAssert.notNullOrEmpty("lessonStatus", lessonStatus);
        if(lessonStatus.trim().toUpperCase().startsWith("LEARNABLE"))
        {
            return LEARNABLE;
        }
        else
        {
            return OTHER;
        }
    }

}
