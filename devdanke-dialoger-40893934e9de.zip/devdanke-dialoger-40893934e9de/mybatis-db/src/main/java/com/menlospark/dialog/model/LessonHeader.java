package com.menlospark.dialog.model;

import com.google.common.annotations.VisibleForTesting;
import com.menlospark.dialog.generated.mybatis.model.SentenceLesson;

import static com.menlospark.util.MyAssert.*;

/**
 * *************************************************************************************
 * The only reason I have lesson header is because it holds enums for lesson type and
 * state.  Otherwise, I'd just use SentenceLesson.  After these enum are stored in DB,
 * then I can get rid of this class.
 */
public class LessonHeader
{
    private String _title;
    private Long _id;
    private Long _guid;
    private LessonType _lessonType;
    private LessonState _lessonState;


    @VisibleForTesting
    public LessonHeader(String title, Long guid, Long id, LessonType lessonType, LessonState lessonState)
    {
        notNullOrEmpty("title", title);
        notNull("id", id);
        notNull("guid", guid);
        notNull("lessonType", lessonType);
        notNull("lessonState", lessonState);

        _title = title;
        _id = id;
        _guid = guid;
        _lessonType = lessonType;
        _lessonState = lessonState;
    }


    public LessonHeader(SentenceLesson lsn)
    {
        notNull("lesson", lsn);

        _title = lsn.getTitle();
        _id = lsn.getId();
        _guid = lsn.getGuid();
        _lessonType = LessonType.calcType(lsn.getTitle());
        _lessonState = LessonState.calcState(lsn.getStatus());;
    }


    public String getTitle()
    {
        return _title;
    }


    public void setTitle(String title)
    {
        _title = title;
    }

    public Long getId()
    {
        return _id;
    }

    public long getGuid()
    {
        return _guid;
    }

    public LessonType getLessonType()
    {
        return _lessonType;
    }

    public LessonState getLessonState()
    {
        return _lessonState;
    }
}
