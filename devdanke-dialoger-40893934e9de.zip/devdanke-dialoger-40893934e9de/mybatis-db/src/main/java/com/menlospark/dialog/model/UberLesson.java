package com.menlospark.dialog.model;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;
import com.menlospark.dialog.generated.mybatis.model.SentenceLesson;

import static com.menlospark.util.MyAssert.*;

import java.util.List;

/**
 * *************************************************************************************
 *
 * @Since 12/22/11
 * <p/>
 * *************************************************************************************
 */
public class UberLesson
{
    private SentenceLesson _lsn;
    private List<UberSentence> _uberSentences = Lists.newArrayList();

    public UberLesson(SentenceLesson lsn, List<UberSentence> uberSentences)
    {
        _lsn = lsn;
        if( isNotNullOrEmpty(uberSentences) )
        {
            _uberSentences.addAll(uberSentences);
        }
    }

    public UberLesson(SentenceLesson lsn)
    {
        _lsn = lsn;
    }

    public SentenceLesson getLesson()
    {
        return _lsn;
    }


    @VisibleForTesting
    public Long getId()
    {
        return _lsn.getId();
    }

    public List<UberSentence> getUberSentences()
    {
        return _uberSentences;
    }

    public boolean hasSentences(){ return _uberSentences.isEmpty() ; }

}
