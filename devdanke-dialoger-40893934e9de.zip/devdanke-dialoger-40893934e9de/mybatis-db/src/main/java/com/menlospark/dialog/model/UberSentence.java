package com.menlospark.dialog.model;

import com.google.common.collect.Lists;
import com.menlospark.dialog.generated.mybatis.model.*;

import java.util.List;

import static com.menlospark.util.MyAssert.isNotNullOrEmpty;

/**
 * *************************************************************************************
 * This is really only for learnable lessons, ie lessons that have been recorded and
 * sound files parsed.
 * 
 * @Since 12/22/11
 * <p/>
 * *************************************************************************************
 */
public class UberSentence
{
    private Sentence _sentence;
    private List<Word> _words = Lists.newArrayList();
    private List<Phrase> _phrases = Lists.newArrayList();
    private List<Reply> _replies = Lists.newArrayList();
    private SoundSession _session;
    private Contributor _speaker;

    public UberSentence( Sentence sentence, SoundSession session, Contributor speaker, List<Word> words, List<Phrase> phrases,
        List<Reply> replies)
    {
        _sentence = sentence;
        _session = session;
        _speaker = speaker;
        if( isNotNullOrEmpty(words) )_words.addAll( words);
        if( isNotNullOrEmpty(phrases) )_phrases.addAll(phrases);
        if( isNotNullOrEmpty(replies) )_replies.addAll(replies);
    }

    public UberSentence( Sentence sentence, SoundSession session, Contributor speaker, List<Word> words, List<Phrase> phrases)
    {
        this(sentence,session,speaker,words,phrases,null);
    }

    public UberSentence( Sentence sentence, SoundSession session, Contributor speaker, List<Word> words)
    {
        this(sentence,session,speaker,words,null,null);
    }

    public UberSentence( Sentence sentence, SoundSession session, Contributor speaker )
    {
        this(sentence,session,speaker,null,null,null);
    }

    public Long getId()
    {
        return _sentence.getId();
    }

    public Long getGuid()
    {
        return _sentence.getGuid();
    }


    public Sentence getSentence()
    {
        return _sentence;
    }

    public List<Word> getWords()
    {
        return _words;
    }

    public List<Phrase> getPhrases()
    {
        return _phrases;
    }

    public List<Reply> getReplies()
    {
        return _replies;
    }

    public SoundSession getSoundSession()
    {
        return _session;
    }


    public Contributor getSpeaker()
    {
        return _speaker;
    }


    public boolean hasPhrases(){ return _phrases.isEmpty() ; }
    public boolean hasReplies(){ return _replies.isEmpty() ; }
}
