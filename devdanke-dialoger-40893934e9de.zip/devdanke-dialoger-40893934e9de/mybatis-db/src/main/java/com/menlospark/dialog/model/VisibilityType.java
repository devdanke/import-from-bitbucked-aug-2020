package com.menlospark.dialog.model;

/**
 * *************************************************************************************
 *
 * Used to tag lesson visibility.  Used to control which lessons make it to public site.
 * Some lessons are for my use only.
 * <p/>
 * These enums are also used in queries.  In a query, PUBLIC means you only get
 * lessons that are labled as public.  PRIVATE means you only get lessons labeled private.
 * ALL means you get all lessons, ie pub,priv,etc.
 *
 *
 * @Since 1/1/12
 * <p/>
 * *************************************************************************************
 */
public enum VisibilityType
{
    PUBLIC,
    PRIVATE,
    ALL;
}
