package com.menlospark.dialog.db.mybatis;


import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.*;
import com.menlospark.dialog.generated.mybatis.model.*;
import com.menlospark.dialog.generated.mybatis.mapper.*;

import com.menlospark.dialog.model.*;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.beans.Visibility;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;


import static com.menlospark.util.MyAssert.*;
import static java.lang.String.format;

/** *************************************************************************************
 *
 */
public class MyBatDao
{
    private Logger _log = LoggerFactory.getLogger(MyBatDao.class);

    //NOTE: avoid direct use.  instead use getSession(), which has auto-commit=true
    private SqlSessionFactory _factory;



    /*
    @param probably easier if this file is in the root of the classpath.
     */
    public MyBatDao(String mybatisRuntimeConfResourceFile)
    {
        try
        {
            Reader reader = Resources.getResourceAsReader(mybatisRuntimeConfResourceFile);
            _factory = new SqlSessionFactoryBuilder().build(reader);
            System.out.println("MyBatDao.ctor(): environment="+
                _factory.getConfiguration().getEnvironment().getId());
            _log.info("initialized");
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    /**
     * temporary method for converting legacy vocab lessons to new fangled dialog lessons.
     * <p/>
     * get all words whose english and thai fields aren't null.  use to more fully populate
     * the newly converted vocab lessons.
     *
     * @param list of words
     */
    public List<Word> findWords()
    {
        SqlSession session=null;
        try
        {
            session = getSession();

            WordMapper wordMapper = session.getMapper(WordMapper.class);

            WordExample qbe = new WordExample();
            qbe.createCriteria().andEnglishIsNotNull().andThaiIsNotNull();
            return wordMapper.selectByExample(qbe);
        }
        finally
        {
            if(session != null) session.close();
        }

    }

    /**
     *
     * TODO: maybe get rid of LessonHeader class once SentenceLesson includes
     * LessonType and LessonStatus
     *
     * @return list of header info for all learnable lessons.
     */
    public List<LessonHeader>  findLearnableLessonHeaders(VisibilityType visibility)
    {
        List<LessonHeader> result = Lists.newArrayList();
        List<SentenceLesson> list = findLearnableLessons(visibility);

        if(list != null && !list.isEmpty())
        {
            for(SentenceLesson lsn : list)
            {
                result.add(new LessonHeader(lsn));
            }
        }
        return result;
    }


    /**
     *
     * @return list of low level lessons that have status learnable....
     */
    @VisibleForTesting
    List<SentenceLesson> findLearnableLessons(VisibilityType visibility)
    {
        notNull("visibility", visibility);

        SqlSession session=null;
        List<SentenceLesson> results = Lists.newArrayList();
        try
        {
            session = getSession();

            List<SentenceLesson> list = session.selectList("findLearnableSL");
            if(VisibilityType.ALL == visibility)
            {
                results.addAll(list);
            }
            else
            {
                for(SentenceLesson lsn : list )
                {
                    if(lsn.getVisible() == visibility)
                    {
                        results.add(lsn);
                    }
                }
            }

            return results;
        }
        finally
        {
            if(session != null) session.close();
        }
    }


    /**
     *
     * @return a multimap of lessonHeaders grouped by lessonType.  Not all lessonTypes may be
     * present.  LessonHeaders are only for "learnable" lessons (i.e. a lesson whose status value
     * starts with "learnable").
*/
    public Multimap<LessonType,LessonHeader> findLearnableLessonHeadersGroupByType(VisibilityType visibility)
    {
        Multimap<LessonType, LessonHeader> resultByType = ArrayListMultimap.create();
        List<LessonHeader> list = findLearnableLessonHeaders(visibility);
        for(LessonHeader lessonHeader : list)
        {
            resultByType.put(lessonHeader.getLessonType(), lessonHeader);
        }
        return resultByType;
    }


    /**
     * first get learnable lesson headers. next get sentence ids in those lessons.
     * finally get those sentences.
     *
     * TODO handle case where there are no lessons or sentences etc
     *
     * @return 
     */
    public List<UberLesson> findLearnableUberLessons(VisibilityType visibility)
    {
        //1 get headers
        List<SentenceLesson> senLessons = findLearnableLessons(visibility);
        List<Long> lsnIds = Lists.newArrayList();
        Map<Long,SentenceLesson> idToLessonMap = Maps.newHashMap();
        for(SentenceLesson senLsn : senLessons)
        {
            Long lessonId = senLsn.getId();
            idToLessonMap.put(lessonId, senLsn);
            lsnIds.add(lessonId);
        }

        List<UberLesson> ubLessons = Lists.newArrayList();
        if(senLessons.isEmpty())
        {
            return ubLessons;
        }

        Multimap<SentenceLesson,Sentence> lessonToSensMmap = ArrayListMultimap.create();
        SqlSession session = null;
        try
        {
            session = getSession();

            //2 get link between lesson and sentences
            SentenceLessonSentenceExample slxsExample = new SentenceLessonSentenceExample();
            slxsExample.createCriteria().andSentenceLessonSentencesIdIn(lsnIds);

            SentenceLessonSentenceMapper slxsMapper = session.getMapper(SentenceLessonSentenceMapper.class);
            List<SentenceLessonSentence> slxsList = slxsMapper.selectByExample(slxsExample);

            List<Long> senIds = Lists.newArrayList();
            Multimap<Long,Long> lessonIdToSenIdMmap = ArrayListMultimap.create();
            for(SentenceLessonSentence slxs : slxsList)
            {
                Long senId = slxs.getSentenceId();
                lessonIdToSenIdMmap.put(slxs.getSentenceLessonSentencesId(), senId);
                senIds.add(senId);
            }

            if(senIds.isEmpty())
            {
                throw new IllegalStateException(format("we have %s lessons, but 0 sentences!",
                    lsnIds.size()));
            }

            //3 get sentences
            SentenceExample sExample = new SentenceExample();
            sExample.createCriteria().andIdIn(senIds);
            SentenceMapper sMapper = session.getMapper(SentenceMapper.class);
            List<Sentence> sentences = sMapper.selectByExample(sExample);

            //4 create multimap of header -> list<sentence>
            //NOTE: may have sentence order issue because haven't explicitly dealt with it yet
            //given a senId, what is it's lesson id?
            for(Sentence sen : sentences)
            {
                SentenceLesson lesson = findParentLesson(lessonIdToSenIdMmap, idToLessonMap, sen.getId());
                lessonToSensMmap.put(lesson, sen);
            }


            //5 assemble to uber lessons from pieces
            SoundSessionMapper ssMapper = session.getMapper(SoundSessionMapper.class);
            ContributorMapper cMapper = session.getMapper(ContributorMapper.class);

            for(SentenceLesson lesson :  lessonToSensMmap.keySet() )
            {
                List<UberSentence> ubSens = Lists.newArrayList();
                for(Sentence sen : lessonToSensMmap.get(lesson) )
                {
                    List<Word> words = session.selectList("findWordsBySentenceId", sen.getId());
                    //log("senGuid="+sen.getGuid()+" wordCount="+words.size());

                    if(sen.getSoundSessionId()!=null)
                    {
                        SoundSession soundSession = ssMapper.selectByPrimaryKey(sen.getSoundSessionId());

                        if(soundSession.getSpeakerId()!=null)
                        {
                            Contributor speaker = cMapper.selectByPrimaryKey(soundSession.getSpeakerId());
                            ubSens.add(new UberSentence(sen, soundSession, speaker, words));
                        }
                        else
                        {
                            _log.warn("soundSession (id={}) has null speakerId",soundSession.getId());
                        }
                    }
                    else
                    {
                        _log.warn("sen (id={}) has null sndSesId", sen.getId());
                    }
                }

                ubLessons.add(new UberLesson(lesson, ubSens));
            }


            return ubLessons;
        }
        finally
        {
            if(session != null) session.close();
        }
    }


    /*
    NOTE: has side-effect on multi-map.  Reduces it's contents, to make future searching faster.
     */
    private SentenceLesson findParentLesson(Multimap<Long,Long> lessonIdToSenId,
        Map<Long,SentenceLesson> idToLsnMap, long senId)
    {
        for(Long lsnId : lessonIdToSenId.keySet())
        {
            if(lessonIdToSenId.containsEntry(lsnId,senId))
            {
                lessonIdToSenId.remove(lsnId,senId);
                return idToLsnMap.get(lsnId);
            }
        }
        throw new RuntimeException("senId not found. should be impossible.");
    }

    
    /**
     * Default session creator.
     * @return jdbc connection with auto-commit=true
     */
    @VisibleForTesting
    protected SqlSession getSession()
    {
        return _factory.openSession(true);
    }
}
