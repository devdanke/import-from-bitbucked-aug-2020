package com.menlospark.util;

import java.util.Collection;

/**
 * *************************************************************************************
 *
 * @Since 12/9/11
 * <p/>
 * *************************************************************************************
 */
public class MyAssert
{
    public static void notNull(String paramName, Object param)
    {
        if(param == null)
        {
            throw new RuntimeException(paramName + " cannot be null.");
        }
    }

    public static void notEmpty(String paramName, String param)
    {
        if(param.trim().isEmpty())
        {
            throw new RuntimeException(paramName + " cannot be empty.");
        }
    }

    public static void notEmpty(String paramName, Collection param)
    {
        if(param.isEmpty())
        {
            throw new RuntimeException(paramName + " cannot be empty.");
        }
    }

    public static void notNullOrEmpty(String paramName, Collection param)
    {
        notNull(paramName,param);
        notEmpty(paramName, param);
    }

    public static void notNullOrEmpty(String paramName, String param)
    {
        notNull(paramName,param);
        notEmpty(paramName,param);
    }

    public static boolean isNotNullOrEmpty(Collection param)
    {
        return ((param != null) && !param.isEmpty());
    }

    public static boolean isNotNullOrEmpty(String param)
    {
        return ((param != null) && !param.trim().isEmpty());
    }

}
