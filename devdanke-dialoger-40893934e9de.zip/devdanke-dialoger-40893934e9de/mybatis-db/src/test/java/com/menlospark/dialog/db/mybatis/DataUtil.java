package com.menlospark.dialog.db.mybatis;

import com.google.common.collect.Lists;
import com.menlospark.dialog.generated.mybatis.model.*;
import com.menlospark.dialog.model.LessonHeader;
import com.menlospark.dialog.model.UberLesson;
import com.menlospark.dialog.model.UberSentence;
import com.menlospark.dialog.model.VisibilityType;
import org.joda.time.DateTime;

import java.beans.Visibility;
import java.util.List;

import static java.lang.String.format;

/**
 * *************************************************************************************
 *
 * @Since 12/22/11
 * <p/>
 * *************************************************************************************
 */
public class DataUtil
{
    //private static final String x ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final DateTime TEST_RUN_DTTM = new DateTime();


    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Uber classes
    ////////////////////////////////////////////////////////////////////////////////////////////////

    public static UberLesson makeUberLesson(String testName, int senCount, SoundSession soundSession,
        Contributor speaker)
    {
        List<UberSentence> ubSens = Lists.newArrayList();
        for(int i=0; i<senCount;i++)
        {
            String testNameForSen = testName + "_s-" + (i+1);
            Sentence sen = makeSentence(testNameForSen);
            sen.setSoundSessionId(soundSession.getId());
            UberSentence ubSen =
                new UberSentence(sen, soundSession, speaker, makeWords(testNameForSen,senCount));
            ubSens.add(ubSen);
        }
        return new UberLesson(makeLesson(testName), ubSens);
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////
    // MyBatis generated classes
    ////////////////////////////////////////////////////////////////////////////////////////////////

    /*

     */
    public static SoundSession makeSoundSession(long speakerContribId)
    {
        SoundSession ss = new SoundSession();

        ss.setDate(TEST_RUN_DTTM.toDate());
        ss.setSpeakerId(speakerContribId);
        ss.setVersion(0L);

        return ss;
    }


    public static Contributor makeContributor(String testName)
    {
        Contributor contrib = new Contributor();

        contrib.setName(format("%s-contrib-name", testName));
        contrib.setNickName(format("%s-contrib-nick", testName));
        contrib.setVersion(0L);

        return contrib;
    }


    public static SentenceLesson makeLesson(String testName)
    {
        SentenceLesson sl = new SentenceLesson();

        sl.setNote(format("%s-note", testName));
        sl.setTitle(format("%s-title", testName));
        sl.setStatus("learnable");
        sl.setVisible(VisibilityType.PUBLIC);

        sl.setGuid(makeGuid(testName));
        sl.setVersion(0L);
        sl.setCreated(TEST_RUN_DTTM.toDate());

        return sl;
    }


    public static Sentence makeSentence(String testName)
    {
        Sentence s = new Sentence();

        s.setEnglish(format("%s-english", testName));
        s.setNote(format("%s-note", testName));
        s.setSpeakerRole(format("spkrRol", testName));

        s.setGuid(makeGuid(testName));
        s.setVersion(0L);

        return s;
    }


    private static List<Word> makeWords(String testName, int wordCount)
    {
        List<Word> words = Lists.newArrayList();
        for(int i=0; i<wordCount; i++)
        {
            words.add(makeWord(testName+"_w-"+(i+1)));
        }
        return words;
    }

    private static Word makeWord(String testName)
    {
        Word w = new Word();

        w.setEnglish(format("%s-eng", testName));
        w.setPhonetic(format("%s-phon", testName));
        w.setThai(format("%s-thai", testName));
        w.setThaiBlob(format("%s-blob", testName));

        w.setGuid(makeGuid(testName));
        w.setVersion(0L);

        return w;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // convenience & util methods
    ////////////////////////////////////////////////////////////////////////////////////////////////

    private static long makeGuid(String testName)
    {
        return (long) testName.hashCode();
    }
}
