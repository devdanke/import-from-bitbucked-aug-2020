package com.menlospark.dialog.db.mybatis;

import static org.junit.Assert.*;
import static java.lang.String.*;


import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.menlospark.dialog.generated.mybatis.model.Contributor;
import com.menlospark.dialog.generated.mybatis.model.Sentence;
import com.menlospark.dialog.generated.mybatis.model.SentenceLesson;
import com.menlospark.dialog.generated.mybatis.model.SoundSession;
import com.menlospark.dialog.model.LessonHeader;
import com.menlospark.dialog.model.UberLesson;
import com.menlospark.dialog.model.UberSentence;
import com.menlospark.dialog.model.VisibilityType;
import org.joda.time.DateTime;

import org.junit.BeforeClass;
import org.junit.Test;

import java.util.List;
import java.util.Map;

import static com.menlospark.dialog.db.mybatis.DataUtil.*;

/**
 * *************************************************************************************
 *
 * @Since 12/1/11
 * <p/>
 * *************************************************************************************
 */
public class DaoTest
{

    private static MyBatDao4Junit __dao;



    @BeforeClass
    public static void oneTimeSetup()
    {
        __dao = new MyBatDao4Junit("mybatis-runtime-conf-dialoger-test-db.xml");
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////
    // los testados
    ////////////////////////////////////////////////////////////////////////////////////////////////

    @Test
    public void lessonAddDelete()
        throws Exception
    {
        String testName = "lessonAddDelete";
        
        //check pre-condition: sentence_lesson table must be empty
        assertEmptyDb();

        __dao.insertLesson(makeLesson(testName));

        assertEquals("after inserting 1 row to sentence_lesson row count", 1, __dao.getLessonCount());
    }


    @Test
    public void lessonInsertData()
        throws Exception
    {
        String testName = "lessonInsertData";
        assertEmptyDb();

        SentenceLesson lsnA = makeLesson(testName+"-A");
        SentenceLesson lsnB = makeLesson(testName+"-B");

        __dao.insertLesson(lsnA);
        __dao.insertLesson(lsnB);

        assertNotNull("lsnA id should not be null", lsnA.getId());
        assertNotNull("lsnB id should not be null", lsnB.getId());

        assertEquals("after inserting 2 row to sentence_lesson row count", 2, __dao.getLessonCount());

        SentenceLesson lsnAfromDb = __dao.getLessonById(lsnA.getId());
        assertNotNull("lsnAfromDb", lsnAfromDb);

        assertEquals("lsnA == lsnAfromDb", lsnA.getTitle(), lsnAfromDb.getTitle());
    }

    @Test
    public void selectLessonByVisibility()
        throws Exception
    {
        String testName = "selectLessonByVisibility";

        //test setup: clear db & add test data
        assertEmptyDb();

        SentenceLesson lsnA = makeLesson(testName+"-A");//public by default
        SentenceLesson lsnB = makeLesson(testName+"-B");
        lsnB.setVisible(VisibilityType.PRIVATE);
        SentenceLesson lsnC = makeLesson(testName+"-C");
        lsnC.setVisible(VisibilityType.PRIVATE);

        __dao.insertLesson(lsnA);
        __dao.insertLesson(lsnB);
        __dao.insertLesson(lsnC);


        //query db
        int allCount = __dao.findLearnableLessons(VisibilityType.ALL).size();
        int privCount = __dao.findLearnableLessons(VisibilityType.PRIVATE).size();
        int pubCount = __dao.findLearnableLessons(VisibilityType.PUBLIC).size();

        //verify results
        assertEquals("all lesson count", 3, allCount);
        assertEquals("private lesson count", 2, privCount);
        assertEquals("public lesson count", 1, pubCount);
    }


    /**
     * put two learnable lessons in the db.  the 1st has 1 sentence.  the 2nd has two sentences.
     * verify that Dao.findLearnableUberLessons() finds both and each has correct sentence count.
     * 
     * @throws Exception
     */
    @Test
    public void findLearnableUberLessonsTest()
        throws Exception
    {
        ////////////////////////////////
        //test prep

        //prep 1) empty db
        String testName = "findLearnableUberLessonsTest";
        assertEmptyDb();
        Contributor speaker = makeContributor(testName);
        __dao.insertContributor(speaker);
        SoundSession soundSession = makeSoundSession(speaker.getId());
        __dao.insertSoundSession(soundSession);

        //prep 2) create test data
        UberLesson expectUberLesson1 = makeUberLesson(testName+"-A",1,soundSession,speaker);
        UberLesson expectUberLesson2 = makeUberLesson(testName+"-B",2,soundSession,speaker);

        //prep 3) add test data to db
        __dao.insertUberLesson(expectUberLesson1);
        __dao.insertUberLesson(expectUberLesson2);


        ////////////////////////////////
        //exercise code under test
        List<UberLesson> actualUberLessons = __dao.findLearnableUberLessons(VisibilityType.PUBLIC);

        ////////////////////////////////
        //verify results
        assertEquals("actual uberLesson count", 2, actualUberLessons.size());

        Map<Long,UberLesson> idToActualUberLessonMap = mapIdToUberLesson(actualUberLessons);

        assertUberLessonsEqual(
            expectUberLesson1, idToActualUberLessonMap.get(expectUberLesson1.getId()));
        assertUberLessonsEqual(
            expectUberLesson2, idToActualUberLessonMap.get(expectUberLesson2.getId()));


    }


    private void assertUberLessonsEqual(UberLesson expect, UberLesson actual)
    {
        assertEquals("lesson title", expect.getLesson().getTitle(), actual.getLesson().getTitle());
        assertEquals("sentence count", expect.getUberSentences().size(), actual.getUberSentences().size());
        for( int i=0; i<expect.getUberSentences().size(); i++)
        {
            UberSentence expectUbSen = expect.getUberSentences().get(i);
            UberSentence actualUbSen = actual.getUberSentences().get(i);

            assertEquals(
                format("expSen.guid=%s actSen.guid=%s word count",
                    expectUbSen.getGuid(), actualUbSen.getGuid()),
                expectUbSen.getWords().size(), actualUbSen.getWords().size());
        }
    }


    
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // private convenience methods
    ////////////////////////////////////////////////////////////////////////////////////////////////

    private Map<Long,UberLesson> mapIdToUberLesson(List<UberLesson> uberLessons)
    {
        Map<Long,UberLesson> result = Maps.newHashMap();

        for(UberLesson uberLesson : uberLessons)
        {
            result.put(uberLesson.getId(),uberLesson);
        }

        return result;
    }


    private void assertEmptyDb()
    {
        //check pre-condition: sentence_lesson table must be empty
        //__dao.deleteAllLessons();
        __dao.emptyDb();
        assertTrue("all tables empty", __dao.isDbEmpty());
        //assertEquals("empty sentence_lesson table row count", 0, __dao.getLessonCount());
    }


}
