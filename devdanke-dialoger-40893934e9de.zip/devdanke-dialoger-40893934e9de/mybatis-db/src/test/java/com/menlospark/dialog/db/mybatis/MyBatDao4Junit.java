package com.menlospark.dialog.db.mybatis;

import com.google.common.collect.Lists;
import com.menlospark.dialog.generated.mybatis.mapper.*;
import com.menlospark.dialog.generated.mybatis.model.*;
import com.menlospark.dialog.model.UberLesson;
import com.menlospark.dialog.model.UberSentence;
import com.menlospark.util.MyAssert;
import org.apache.ibatis.session.SqlSession;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import static com.menlospark.util.MyAssert.*;

/**
 * *************************************************************************************
 *
 * @Since 12/19/11
 * <p/>
 * *************************************************************************************
 */
public class MyBatDao4Junit
    extends MyBatDao
{

    private static final List<String> TABLE_NAMES = Lists.newArrayList();
    static
    {
        //join tables
        TABLE_NAMES.add("sentence_word");
        TABLE_NAMES.add("sentence_phrase");
        TABLE_NAMES.add("sentence_reply");
        TABLE_NAMES.add("sentence_lesson_sentence");

        //data tables
        TABLE_NAMES.add("phrase");
        TABLE_NAMES.add("reply");
        TABLE_NAMES.add("word");

        TABLE_NAMES.add("sentence"); //sen depends on ses
        TABLE_NAMES.add("sentence_lesson");

        TABLE_NAMES.add("sound_session");
        TABLE_NAMES.add("contributor"); //ses depends on contrib
    }

    
    public MyBatDao4Junit(String mybatisRuntimeConfResourceFile)
    {
        super(mybatisRuntimeConfResourceFile);
    }


    public void insertSoundSession(SoundSession soundSession)
    {
        SqlSession session=null;
        try
        {
            session = getSession();

            SoundSessionMapper ssMapper = session.getMapper(SoundSessionMapper.class);

            ssMapper.insert(soundSession);
        }
        finally
        {
            if(session != null) session.close();
        }
    }


    public void insertContributor(Contributor contributor)
    {
        SqlSession session=null;
        try
        {
            session = getSession();

            ContributorMapper cMapper = session.getMapper(ContributorMapper.class);

            cMapper.insert(contributor);
        }
        finally
        {
            if(session != null) session.close();
        }
    }


    public int getLessonCount()
    {
        SqlSession session=null;
        try
        {
            session = getSession();

            SentenceLessonMapper slm = session.getMapper(SentenceLessonMapper.class);

            return slm.countByExample(null);
        }
        finally
        {
            if(session != null) session.close();
        }
    }


    public void insertLesson(SentenceLesson lesson)
    {
        MyAssert.notNull("lesson", lesson);
        if(lesson.getId() != null)
        {
            throw new IllegalStateException("can not insert because incoming id not null");
        }
        
        SqlSession session=null;
        try
        {
            session = getSession();

            SentenceLessonMapper slm = session.getMapper(SentenceLessonMapper.class);

            slm.insert(lesson);
        }
        finally
        {
            if(session != null) session.close();
        }
    }


    /**
     */
    public void insertUberLesson(UberLesson ubLesson)
    {
        notNull("ubLesson", ubLesson);
        insertLesson(ubLesson.getLesson());

        for(int i=0;  i < ubLesson.getUberSentences().size(); i++)
        {
            UberSentence ubSen = ubLesson.getUberSentences().get(i);
            Sentence sen = ubSen.getSentence();
            insertSentenceForLesson(sen, ubLesson.getLesson(), i);
            //now that sen is inserted, can insert its words
            List<Word> words = ubSen.getWords();
            for(int j=0; j< words.size(); j++ )
            {
                insertWordForSentence(words.get(j), sen, j);
            }
        }
    }


    public void insertSentenceForLesson(Sentence sen, SentenceLesson lesson, int senPos)
    {
        MyAssert.notNull("sen", sen);
        if(sen.getId() != null)
        {
            throw new IllegalStateException("can not insert because incoming sen id not null");
        }

        MyAssert.notNull("lesson", lesson);
        if(lesson.getId() == null)
        {
            throw new IllegalStateException("can not insert because incoming lesson id is null");
        }

        SqlSession session=null;
        try
        {
            session = getSession();

            //1 insert sentence and get it's id
            SentenceMapper sm = session.getMapper(SentenceMapper.class);
            sm.insert(sen);

            //2 insert linkage between sen and lsn
            SentenceLessonSentenceMapper slxsm = session.getMapper(SentenceLessonSentenceMapper.class);
            SentenceLessonSentence slxs = new SentenceLessonSentence();
            slxs.setSentenceId(sen.getId());
            slxs.setSentenceLessonSentencesId(lesson.getId());
            slxs.setSentencesIdx(senPos);
            slxsm.insert(slxs);
        }
        finally
        {
            if(session != null) session.close();
        }
    }

    public void insertWordForSentence(Word word, Sentence sen, int wordPos)
    {
        MyAssert.notNull("word", word);
        if(word.getId() != null)
        {
            throw new IllegalStateException("can not insert because incoming word id not null");
        }

        MyAssert.notNull("sen", sen);
        if(sen.getId() == null)
        {
            throw new IllegalStateException("can not insert because incoming sentence id is null");
        }

        SqlSession session=null;
        try
        {
            session = getSession();

            //1 insert word and get it's id
            WordMapper wm = session.getMapper(WordMapper.class);
            wm.insert(word);

            //2 insert linkage between word and sentence
            SentenceWordMapper sxwm = session.getMapper(SentenceWordMapper.class);
            SentenceWord sxw = new SentenceWord();

            sxw.setSentenceWordsId(sen.getId());
            sxw.setWordId(word.getId());
            sxw.setWordsIdx(wordPos);
            
            sxwm.insert(sxw);
        }
        finally
        {
            if(session != null) session.close();
        }
    }


    public SentenceLesson getLessonById(long id)
    {
        SqlSession session=null;
        try
        {
            session = getSession();

            SentenceLessonMapper slm = session.getMapper(SentenceLessonMapper.class);

            return slm.selectByPrimaryKey(id);
        }
        finally
        {
            if(session != null) session.close();
        }
    }


    public boolean isDbEmpty()
    {
        SqlSession session=null;
        try
        {
            session = getSession();
            Statement stmt = session.getConnection().createStatement();
            for(String table : TABLE_NAMES)
            {
                ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS rcount FROM " + table);
                if(rs.next())
                {
                    int count = rs.getInt("rcount");
                    if(count > 0)
                    {
                        throw new Exception("expected table " + table +
                            " to be empty, but it had row count=" + count);
                    }
                }
            }
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            if(session != null) session.close();
        }
        return true;
    }


    public void emptyDb()
    {
        SqlSession session=null;
        try
        {
            session = getSession();
            Statement stmt = session.getConnection().createStatement();
            for(String table : TABLE_NAMES)
            {
                stmt.execute("delete from " + table);
            }
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            if(session != null) session.close();
        }
    }

}
