

DROP TABLE IF EXISTS `word`;
CREATE TABLE `word` (
  `id` BIGINT(20) NOT NULL auto_increment,
  `version` BIGINT(20) NOT NULL,
  `english` VARCHAR(200) DEFAULT NULL,
  `phonetic` VARCHAR(200) DEFAULT NULL,
  `thai` VARCHAR(255) NOT NULL,
  `guid` BIGINT(20) DEFAULT NULL,
  `thai_blob` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `contributor`;
CREATE TABLE `contributor` (
  `id` BIGINT(20) NOT NULL auto_increment,
  `version` BIGINT(20) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `nick_name` VARCHAR(255) NOT NULL,
  `note` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `phrase`;
CREATE TABLE `phrase` (
  `id` BIGINT(20) NOT NULL auto_increment,
  `version` BIGINT(20) NOT NULL,
  `word_count` INT(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `reply`;
CREATE TABLE `reply` (
  `id` BIGINT(20) NOT NULL auto_increment,
  `version` BIGINT(20) NOT NULL,
  `english` VARCHAR(255) NOT NULL,
  `thai` VARCHAR(255) NOT NULL,
  `guid` BIGINT(20) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `sentence_lesson`;
CREATE TABLE `sentence_lesson` (
  `id` BIGINT(20) NOT NULL auto_increment,
  `version` BIGINT(20) NOT NULL,
  `created` datetime NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `status` VARCHAR(50) NOT NULL,
  `guid` BIGINT(20) DEFAULT NULL,
  `note` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*
************************************************************
*/


DROP TABLE IF EXISTS `sentence_reply`;
CREATE TABLE `sentence_reply` (
  `sentence_replies_id` BIGINT(20) DEFAULT NULL,
  `reply_id` BIGINT(20) DEFAULT NULL,
  `replies_idx` INT(11) DEFAULT NULL,
  KEY `FK2026B60EEB17A15A` (`reply_id`),
  CONSTRAINT `FK2026B60EEB17A15A` FOREIGN KEY (`reply_id`) REFERENCES `reply` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `sentence_word`;
CREATE TABLE `sentence_word` (
  `sentence_words_id` BIGINT(20) DEFAULT NULL,
  `word_id` BIGINT(20) DEFAULT NULL,
  `words_idx` INT(11) DEFAULT NULL,
  KEY `FK22142F665B0E119A` (`word_id`),
  CONSTRAINT `FK22142F665B0E119A` FOREIGN KEY (`word_id`) REFERENCES `word` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `sound_session`;
CREATE TABLE `sound_session` (
  `id` BIGINT(20) NOT NULL auto_increment,
  `version` BIGINT(20) NOT NULL,
  `date` datetime NOT NULL,
  `speaker_id` BIGINT(20) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK6C92736650CEA616` (`speaker_id`),
  CONSTRAINT `FK6C92736650CEA616` FOREIGN KEY (`speaker_id`) REFERENCES `contributor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `sentence_phrase`;
CREATE TABLE `sentence_phrase` (
  `sentence_phrases_id` BIGINT(20) DEFAULT NULL,
  `phrase_id` BIGINT(20) DEFAULT NULL,
  `phrases_idx` INT(11) DEFAULT NULL,
  KEY `FKE1716015DA6DB73A` (`phrase_id`),
  CONSTRAINT `FKE1716015DA6DB73A` FOREIGN KEY (`phrase_id`) REFERENCES `phrase` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*
************************************************************
*/


DROP TABLE IF EXISTS `sentence`;
CREATE TABLE `sentence` (
  `id` BIGINT(20) NOT NULL auto_increment,
  `version` BIGINT(20) NOT NULL,
  `english` VARCHAR(255) NOT NULL,
  `speaker_role` VARCHAR(7) NOT NULL,
  `guid` BIGINT(20) DEFAULT NULL,
  `note` VARCHAR(255) DEFAULT NULL,
  `sound_session_id` BIGINT(20) DEFAULT NULL,
  `translator_id` BIGINT(20) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `english` (`english`),
  UNIQUE KEY `guid` (`guid`),
  KEY `FK4B43D6637CDDA33B` (`sound_session_id`),
  KEY `FK4B43D6631A5FD21B` (`translator_id`),
  CONSTRAINT `FK4B43D6631A5FD21B` FOREIGN KEY (`translator_id`) REFERENCES `contributor` (`id`),
  CONSTRAINT `FK4B43D6637CDDA33B` FOREIGN KEY (`sound_session_id`) REFERENCES `sound_session` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- must come after sentence
DROP TABLE IF EXISTS `sentence_lesson_sentence`;
CREATE TABLE `sentence_lesson_sentence` (
  `sentence_lesson_sentences_id` BIGINT(20) DEFAULT NULL,
  `sentence_id` BIGINT(20) DEFAULT NULL,
  `sentences_idx` INT(11) DEFAULT NULL,
  KEY `FKC1C5BFAEFA7116FA` (`sentence_id`),
  CONSTRAINT `FKC1C5BFAEFA7116FA` FOREIGN KEY (`sentence_id`) REFERENCES `sentence` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




