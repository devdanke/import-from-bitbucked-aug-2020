/*
LANG_PIC_TO_SND  //most common default
LANG_SND_TO_DST_TEXT
LANG_DST_TXT_TO_SND



LANG_DST_TEXT_TO_SRC_TEXT  //used for concepts where there's no good pictures.
LANG_SRC_TEXT_TO_DST_TEXT //this is really just for incomplete lesson where i don't have snd/pics yet.


LANG_DST_TEXT_TO_CUST_SND

QUIZ_FACT1_TO_FACT2

 */
var gFactDataMediaMaps =
{
    "LANG_DST_TEXT_TO_CUST_SND":
    {
        desc:"Foreign Text &rarr; Voice",
        fact1:
        {
            itemDataField:"dstText",
            mediaType:"TXT",
            textType:"DST"
        },
        fact2:
        {
            itemDataField:"finalConsonantSound",
            mediaType:"SND",
        }
    },
    "LANG_SND_TO_DST_TEXT" :
    {
        desc:"Voice &rarr; Foreign Text",
        fact1:
        {
            itemDataField:"sndBaseName",
            mediaType:"SND",
        },
        fact2:
        {
            itemDataField:"dstText",
            mediaType:"TXT",
            textType:"DST"
        }
    },
    "LANG_DST_TEXT_TO_SND" :
    {
        desc:"Foreign Text &rarr; Voice",
        fact1:
        {
            itemDataField:"dstText",
            mediaType:"TXT",
            textType:"DST"
        },
        fact2:
        {
            itemDataField:"sndBaseName",
            mediaType:"SND",
        }
    },
    "LANG_DST_TEXT_TO_SRC_TEXT" :
    {
        desc:"Foreign &rarr; Native Text",
        fact1:
        {
            itemDataField:"dstText",
            mediaType:"TXT",
            textType:"DST"
        },
        fact2:
        {
            itemDataField:"srcText",
            mediaType:"TXT",
            textType:"SRC"
        }
    },
    "LANG_SRC_TEXT_TO_DST_TEXT" :
    {
        desc:"Native &rarr; Foreign Text",
        fact1:
        {
            itemDataField:"srcText",
            mediaType:"TXT",
            textType:"SRC"
        },
        fact2:
        {
            itemDataField:"dstText",
            mediaType:"TXT",
            textType:"DST"
        }
    },
    "LANG_PIC_TO_SND" :
    {
        desc:"Pic &rarr; Voice",
        fact1:
        {
            itemDataField:"picName",
            mediaType:"PIC",
        },
        fact2:
        {
            itemDataField:"sndBaseName",
            mediaType:"SND",
        }
    },
    "QUIZ_FACT1_TO_FACT2" :
    {
        desc:"Question &rarr; Answer",
        fact1:
        {
            itemDataField:"fact1",
            mediaType:"TXT",
            textType:"SRC"
        },
        fact2:
        {
            itemDataField:"fact2",
            mediaType:"TXT",
            textType:"SRC"
        }
    }
};

