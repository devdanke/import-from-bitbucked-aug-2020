/**
 *
 * Date: 4/2/12
 */


function myDebug(event)
{
    var msg = 'evt.type="' + event.type + '", evt.targ="' + event.target + '", evt.time="' + event.timeStamp + '".';
    console.log(msg);
}


function isNullOrUndef(something)
{
    if (typeof something === "undefined")
    {
//        console.log("obj was undefined");
        return true;
    }
    else
    {
  //      console.log("obj was not undefined");
        var isNull = (something == null);
    //    console.log("obj is null? " + isNull);
        return isNull;
    }
}



function getIdOrNull(jqmUiObj)
{
    if( !isNullOrUndef(jqmUiObj) )
    {
        var val = jqmUiObj.attr("id");
        if(val=="undefined") val = null;
        return val;
    }
    else
    {
        return null;
    }
}


function getTransInfo(jqmEvent, jqmUi)
{
    var transInfo = new Object();
  //  transInfo.eventTargId = jqmEvent.target.id;
    transInfo.fromPageId = getIdOrNull(jqmUi.prevPage);
    transInfo.toPageId = getIdOrNull(jqmUi.nextPage);

    if(jqmEvent.type == "pagehide")
    {
        transInfo.fromPageId = jqmEvent.target.id;
    }
    if(jqmEvent.type == "pagebeforeshow")
    {
        transInfo.toPageId = jqmEvent.target.id;
        if(isNullOrUndef(transInfo.fromPageId)) transInfo.fromPageId = null;
    }

    return transInfo;
}
