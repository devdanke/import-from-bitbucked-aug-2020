/*
****************************************************************************************************
*** GLOBAL VARS AND CONSTANTS **********************************************************************
****************************************************************************************************
*/


//gLessonPkg must be imported before this, of course.
var gTrainer = null;
var gIsTrainPgClean = null;


/*
called in mobileinit.  Could probably be called else where too.

NOTE: G_MEIDA_HOST is defined in the individual trainer pages during FreeMarker generation.
 */
function initGlobalVars()
{

    //gLessonPkg must be imported before this, of course.
    gTrainer = new TrainingMgr(gLessonPkg, gFactDataMediaMaps);
    gIsTrainPgClean = false;

    console.log("INIT global vars: ",  "gTrainer=", gTrainer,  "gIsTrainPgClean=", gIsTrainPgClean,
        "G_MEDIA_HOST=", G_MEDIA_HOST, "gFactDataMediaMaps=", gFactDataMediaMaps)
}


/*
****************************************************************************************************
*** USED IN SEVERAL PAGES **************************************************************************
****************************************************************************************************
*/


function buildSoundUrls(lessonDir, sndBaseName, mediaHost)
{
    var sndUrls = new Object();

    var baseLessonUrl = mediaHost + "/" + lessonDir + "/";

    sndUrls.mp3 =  baseLessonUrl + "mp3/" + sndBaseName + ".mp3";
    sndUrls.ogg =  baseLessonUrl + "ogg/" + sndBaseName + ".ogg";

    console.log("soundUrls=", sndUrls);
    return sndUrls;
}



/*
****************************************************************************************************
*** SOUND ******************************************************************************************
****************************************************************************************************
*/

function playAudio(audioElemId)
{
    console.log("Play audio element id='"+audioElemId+"'");
    var audioElem = document.getElementById(audioElemId);
    if(audioElem==null)
    {
        throw "ERROR: Didn't find audio element id='"+audioElemId+"'";
    }
    audioElem.play();
}


/*
I have a couple FooNoArg() methods because I don't know how to bind a function to some event and
it's dynamic params.  Currently, I only know how to give the bind method the handler function name:-(
 */
function playItemAudioNoArg()
{
    playAudio('itemAudio');
}


function setAudioSrc(sndBaseName)
{
    var jqAudioElem = $('#itemAudio');

    var sndUrls = buildSoundUrls(gLessonPkg.lessonDir, sndBaseName, G_MEDIA_HOST)

    $("<source>").attr("src", sndUrls.ogg).attr("type", "audio/ogg").appendTo(jqAudioElem);
    $("<source>").attr("src", sndUrls.mp3).attr("type", "audio/mpeg").appendTo(jqAudioElem);

    jqAudioElem.load();
}


//This didn't work, so comment it out.
function resetAudio()
{
    console.log('resetAudio NOOP');
    //var audioElem = $('#itemAudio');
    //audioElem.currentTime = 0;
}


function enableJqmBtn(btnId)
{
    $('#' + btnId).button().button('enable');
}


function disableJqmBtn(btnId)
{
    $('#' + btnId).button().button('disable');
}



/*
****************************************************************************************************
*** INTRO PAGE *************************************************************************************
****************************************************************************************************
*/


function handleLessonChoice(lessonIndex, chunkIndex)
{
    console.log("lesson chosen:", "gTrainer=", gTrainer, "lessonIndex=", lessonIndex,
        "chunkIndex=", chunkIndex);

    //assert valid index
    gTrainer.setLesson(lessonIndex,chunkIndex);

    console.log("now that we know lesson and chunk, put correct lesson-chunk name on all pages");
    $('[name=pageTitle]').each(function(index) {
        var names = gTrainer.getNames();
        $(this).text(names.pkgName + " - " + names.chunkName);
    });

    $.mobile.changePage("#train_pg", { transition: "fade"});
}



/*
Create the menu of lessons.
 */
function loadIntroPage()
 {
     console.log('loadIntroPage()');

     $('#introPageTitle').text(gLessonPkg.name);

     prepMediaMappingSelector(gLessonPkg.supportedFactMaps);

     //if there are any lessons, then show list of lesson/subs for user to choose
     var lessonCount = gLessonPkg.lessons.length;

     if(lessonCount > 0)
     {
         var menuList = $("#menuList");
         menuList.empty();

         for(var i=0; i<lessonCount; i++)
         {
             var lesson = gLessonPkg.lessons[i];

             var curTopLevelItemId = 'lessonIndex_' + i;

             var partCount = lesson.parts.length;
             if(partCount == 1)
             {

                 //lesson has only 1 part.  go directly to that part when lesson menu item clicked.
                 //capture i value in a string. otherwise, if i pass i to func, it'll use final i value
                 // for all calls.  something about the context of the closure.
                 var iValueAsOfNow = i+'';
                 /*
                 console.log("setup topLevel lesson list: ", "lesson", lesson, "captureIValueNow=",
                     iValueAsOfNow, "curTopLevelItem=", curTopLevelItem);
                 curTopLevelItem.click( function() { handleLessonChoice(iValueAsOfNow,0); } );
                 console.log("post redefine click: ", "curTopLevelItem=", curTopLevelItem);

                 removed the above code because it was using the last click handler function instead
                 of using the one I assigned for menuItem that had only one part.
                 */
                 menuList.append('<li id="'+curTopLevelItemId+'" ' +
                     'onclick="handleLessonChoice('+iValueAsOfNow+',0)">'+lesson.name+'</li>');
             }
             else
             {
                 menuList.append('<li id="'+curTopLevelItemId+'">'+lesson.name+'</li>');
                 var curTopLevelItem = $('#'+curTopLevelItemId);
                 var botLevelListId = curTopLevelItemId+'_parts';

                 curTopLevelItem.append('<ul id="'+botLevelListId+'"></ul>');
                 var botLevelItemUL = $('#'+botLevelListId);
                 //console.log("partCount="+partCount);
                 //subLesson has many parts.  first go to nested list of parts.
                 //then jump to train_pg from there.
                 for(var j=0; j<partCount; j++)
                 {
                     var part = lesson.parts[j];
                     var botLevelItemStr = '<li onclick="handleLessonChoice('+i+','+j+')">'+
                         part.name+'</li>';
                     botLevelItemUL.append(botLevelItemStr);
                 }
             }
         }//for each subLesson
     }//if any lessons
 }


/*
set default mapping and remove unsupported mappings.
 */
function prepMediaMappingSelector(supportedFactMaps)
{
    //<option value="TXT_TO_TXT">Text &rarr; Text</option>
    for (var i = 0; i < supportedFactMaps.length; i++)
    {
        var val = supportedFactMaps[i];
        $("#factMediaSelect").append(
            '<option value="'+val+'">'+ gFactDataMediaMaps[val].desc+'</option>');
    }

    //default is first one in the list
    $('#factMediaSelect').val(supportedFactMaps[0]);
}


function handleFactsMediaTypeBtns(factDataMediaMap)
{
    console.log("factMediaMap", factDataMediaMap);
    gTrainer.setFactDataMediaMap(factDataMediaMap)
}



/*
****************************************************************************************************
*** TRAINING PAGE **********************************************************************************
****************************************************************************************************
*/

function handleTrainRightWrongBtn(isRight)
{
    gTrainer.setCurItemResult(isRight);
    console.log("answer recorded: ", "gTrainer=",gTrainer);

    $("#doneItemCount").text(gTrainer.getDoneCount());

    if (gTrainer.hasUndoneItems())
    {
        console.log("There are more items to learn.");
        loadTrainPageContent();
    }
    else
    {
        console.log("Done! Go to result page.");
        var dbMgr = new DbMgr();
        if(dbMgr.hasStorage)
        {
            dbMgr.store(Const.PKG_ID_PREFIX+gLessonPkg.guid, (new Date()).toDateString() );
        }
        $.mobile.changePage("#result_pg", { transition: "fade"});
    }

}

/*
Could also be called handleRevealFact2Btn()
 */
function handleRevealAnswerBtn()
{
    enableJqmBtn("rightBtn");
    enableJqmBtn("wrongBtn");
    disableJqmBtn("revealAnswerBtn");

    switch(gTrainer.factDataMediaMap.fact2.mediaType)
    {

        case Const.SND:


            playItemAudioNoArg();
            $('#fact1Content').click(playItemAudioNoArg);
            break;

        case Const.TXT:
        case Const.PIC:

            $('#fact1Content').hide();
            $('#fact2Content').show();

            break;
        default:
            throw "ERROR: Unknown gTrainer.factMediaMap: '" +
                gTrainer.factDataMediaMap.fact2.mediaType + "'";
    }
}


/*
Call when leaving page.
Cleanup content now, so user won't see it when return to page.
 */
function trainPageCleanup()
{
    //if contentHider already showing, then assume page is cleared and
    //skip this cleanup step
    if(gIsTrainPgClean)
    {
        console.log("skip train_pg cleanup");
        return;
    }
    else
    {
        gIsTrainPgClean = true;
        console.log("cleanup train_pg");
    }

    var fact1ContentDiv = $('#fact1Content');
    var fact2ContentDiv = $('#fact2Content');

    //cleanup any prior info on the page
    fact1ContentDiv.empty();
    fact1ContentDiv.unbind('click');//TODO: in future use jquery.on/off

    fact2ContentDiv.empty();
    fact2ContentDiv.unbind('click');

    //first hide stuff before user accidently sees it.
    //NOTE: i've got these last because, when hidden, maybe you can empty an elem
    fact1ContentDiv.hide();
    fact2ContentDiv.hide();

    var itemAudioElem = $('#itemAudio');
    itemAudioElem.empty();
}


/*
Given a string, determine a font size that allows the string to be as big
as possible without causing the fact box to expands at all.
 */
function calcFontSize(str)
{
    var fontSize = null;

    var len = str.length;
    if(len < 3)
    {
        fontSize = "1000%";
    }
    else if(len < 5)
    {
        fontSize = "600%"
    }
    else if(len < 10)
    {
        fontSize = "400%"
    }
    else
    {
        fontSize = "large"
    }
    //console.log("calcFontSize: size="+fontSize+", strLen="+len);
    return fontSize;
}


function buildImgElemStr(mediaHost, lessonDir, imgFileName, styleName)
{
    var imgSrc =  mediaHost + "/" + lessonDir + "/pic/" + imgFileName;
    var imgStr = "<img src='"+ imgSrc + "' class='"+styleName+"' alt='please wait...'/>";
    return imgStr;
}

function renderFact(factContentDivId, fact)
{
    console.log("renderFact: factContentDivId=", factContentDivId , "fact=", fact);

    var factContentDiv = $('#'+factContentDivId);
    switch(fact.mediaType)
    {
        case Const.PIC:

            //var imgSrc =  G_MEDIA_HOST + "/" + gLessonPkg.lessonDir + "/pic/" + fact.data;
            //var imgStr = "<img src='"+ imgSrc + "' class='factPic' alt='please wait...'/>";
            factContentDiv.append(
                buildImgElemStr(G_MEDIA_HOST,gLessonPkg.lessonDir,fact.data,'factPic'));
            break;

        case Const.SND:

            setAudioSrc(fact.data);//data is sndBaseName
            var imgStr = "<img src='../img/speaker.png' class='factPic'/>"
            factContentDiv.append(imgStr);
            factContentDiv.click(playItemAudioNoArg);
            break;

        case Const.TXT:

            $("<div>").css("fontSize", calcFontSize(fact.data)).text(fact.data).appendTo(factContentDiv);
            break;

        default:

          throw "ERROR: unknown factMediaType: '" +fact.mediaType+"'.";
    }
}

/*
 */
function loadTrainPageContent()
{
    trainPageCleanup();

    $("#itemCountTotal").text(gTrainer.itemStates.length);
    $("#itemCountPurgatory").text("0");
    $("#itemCountDone").text("0");

    $("#itemCountPurgatory").text(gTrainer.getPurgatoryCount());
    $("#itemCountDone").text(gTrainer.getDoneCount());

    
    var fact1ContentDiv = $('#fact1Content');
    var fact2ContentDiv = $('#fact2Content');


    var itemContent = gTrainer.getNextItemContent();
    console.log("loadTrainPageContent: itemContent", itemContent );

    $('#itemId').text("#"+itemContent.id); //temp to help fix item's with problems.

    renderFact("fact1Content", itemContent.fact1);
    renderFact("fact2Content", itemContent.fact2);

    fact1ContentDiv.show();
    fact2ContentDiv.hide();

    //change to pre-answer state
    enableJqmBtn("revealAnswerBtn");
    disableJqmBtn("rightBtn");
    disableJqmBtn("wrongBtn");

    gIsTrainPgClean = false;
}




/*
****************************************************************************************************
*** RESULT PAGE ************************************************************************************
****************************************************************************************************
*/

function handleLessonChoiceNoArg()
{
    handleLessonChoice(gTrainer.lessonIndex, gTrainer.partIndex+1);
}

function loadResultPage(mediaHost)
{
    console.log('loadResultPage()');

    $('[name=lessonName]').text(gLessonPkg.name);//TODO: move to firstVisit method?

    var resultSumDiv = $("#resultSummary");

    resultSumDiv.empty();
    resultSumDiv.removeClass();//clear styles before setting new one

    /*
    if cur lesson has more parts, show button that goes directly to next part.
     */
    var nextPartBtnPara = $("#nextPartBtnPara");
    if(gTrainer.hasNextPart())
    {
        var nextPartName = gTrainer.getNextPartName();
        $("#nextPartBtn").text(nextPartName).button('refresh');

        nextPartBtnPara.show();
    }
    else
    {
        nextPartBtnPara.hide()
    }

    /*
    if user had trouble with any items, display item's text/pic.
     */
    var troubledItemContents = gTrainer.getTroubledItemContents();
    if(troubledItemContents.length > 0)
    {
        resultSumDiv.append('<div class="resultMsg">Need More Study</div>');

        console.log("result: show user items they didn't know well.");

        for (var i = 0; i < troubledItemContents.length; i++)
        {
            var itemContent = troubledItemContents[i];
            var markup = null;
            if(itemContent.fact1.mediaType==Const.TXT)
            {
                markup = itemContent.fact1.data + "; ";
            }
            else if( itemContent.fact1.mediaType==Const.PIC )
            {
                //markup = '<img class="probPic" src="'+itemData.picUrl+'">';
                markup = buildImgElemStr(G_MEDIA_HOST, gLessonPkg.lessonDir,
                    itemContent.fact1.data,'probPic');
            }
            else
            {
                //fact1 is a sound. therefore show fact2 instead
                if(itemContent.fact2.mediaType==Const.TXT)
                {
                    markup = itemContent.fact2.data + "; ";
                }
                else
                {
                    markup = buildImgElemStr(G_MEDIA_HOST, gLessonPkg.lessonDir,
                        itemContent.fact2.data,'probPic');
                }
            }
            resultSumDiv.append(markup);
        }//for
    }
    else  //show this when there's no troubled items
    {
        console.log("result: all correct.");
        resultSumDiv.addClass('resultMsg');
        resultSumDiv.text("You know it!");
    }
}


/*
****************************************************************************************************
*** INTER-PAGE CODE ********************************************************************************
****************************************************************************************************
*/



function showTransInfo(event, ui)
{
    console.log(event.type, "event: ", event, ", ui: ", ui, "pageTransInfo", getTransInfo(event,ui) );
}



$( document ).bind( "mobileinit", function()
{
    console.log("mobileinit");

    $('div[data-role="page"]').live('pagebeforeshow',function(event, ui)
    {
        showTransInfo(event,ui);

        if(getTransInfo(event,ui).toPageId == 'train_pg')
        {
            loadTrainPageContent();
        }

        if(getTransInfo(event,ui).toPageId == 'result_pg')
        {
            loadResultPage(G_MEDIA_HOST);
        }
    });


    $('div[data-role="page"]').live('pagehide',function(event, ui)
    {
        showTransInfo(event,ui);

        if(getTransInfo(event,ui).fromPageId == 'train_pg')
        {
            trainPageCleanup();
        }
    });
});

    //latest i read is that i should use pageInit instead of ready().
    //it didn't enable initializing the TrainPage. but doc.ready did.
    $(document).ready(function()
    {
        console.log("document ready");
        //initGlobalVars();

    });


    $( document ).delegate("#intro_pg", "pagecreate", function() {
        console.log("intro pg bind to pagecreate event");
        initGlobalVars();
        loadIntroPage();
    });






