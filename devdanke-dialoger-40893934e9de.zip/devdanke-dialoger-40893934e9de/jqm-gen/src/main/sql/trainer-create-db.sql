DROP TABLE IF EXISTS part_x_item;
DROP TABLE IF EXISTS item_prop;
DROP TABLE IF EXISTS item;
DROP TABLE IF EXISTS lesson_part;
DROP TABLE IF EXISTS lesson_def;
DROP TABLE IF EXISTS lesson;



/*
 */
CREATE TABLE lesson_package
(
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    locale_src TEXT NOT NULL,
    locale_dst TEXT NOT NULL,
    cms_path TEXT NOT NULL,
    default_fact_map TEXT NOT NULL,
    unsupported_fact_maps TEXT,
    access TEXT NOT NULL DEFAULT 'PRIVATE'
);


/*
 */
CREATE TABLE item
(
    id INTEGER PRIMARY KEY,
    lesson_pkg_id INTEGER,
    sound_base_name TEXT,
    pic_name TEXT,
    src_text TEXT,
    dst_text TEXT,
    props TEXT,
    notes TEXT,
    pos INTEGER,
    access TEXT NOT NULL DEFAULT 'PRIVATE',
    CONSTRAINT item_to_lsn_pkg_fk FOREIGN KEY (lesson_pkg_id) REFERENCES lesson_package(id),
    CONSTRAINT item_uk UNIQUE(lesson_pkg_id, sound_base_name,pic_name,src_text,dst_text)
);


/*
Holds additional non-standard facts/facets about an item.
  */
CREATE TABLE item_prop
(
    id INTEGER PRIMARY KEY,
    item_id INTEGER,
    name TEXT,
    value TEXT,
    type TEXT,
    CONSTRAINT prop_to_item_fk FOREIGN KEY (item_id) REFERENCES item(id)
    --, CONSTRAINT item_prop_uk UNIQUE(item_id, name)  //no because finalSound is same
);

CREATE TABLE lesson
(
    id INTEGER PRIMARY KEY,
    lesson_pkg_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    CONSTRAINT lsn_to_lsn_pkg_fk FOREIGN KEY (lesson_pkg_id) REFERENCES lesson_package(id),
    CONSTRAINT lsn_name_uk UNIQUE(name)
);

CREATE TABLE lesson_chunk
(
    id INTEGER PRIMARY KEY,
    lesson_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    CONSTRAINT chunk_to_lsn_fk FOREIGN KEY (lesson_id) REFERENCES lesson(id),
    CONSTRAINT chunk_name_uk UNIQUE(name)
);

CREATE TABLE chunk_x_item
(
    id INTEGER PRIMARY KEY,
    chunk_id INTEGER NOT NULL,
    item_id INTEGER NOT NULL,
    CONSTRAINT cxi_to_chunk_fk FOREIGN KEY (chunk_id) REFERENCES lesson_chunk(id),
    CONSTRAINT cxi_to_item_fk FOREIGN KEY (item_id) REFERENCES item(id),
    CONSTRAINT cid_iid_uk UNIQUE(chunk_id, item_id)
);
