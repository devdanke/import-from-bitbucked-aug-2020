DROP TABLE IF EXISTS formal_concept;
DROP TABLE IF EXISTS native_concept;
DROP TABLE IF EXISTS concept_map;
DROP TABLE IF EXISTS vocab_lesson;

CREATE TABLE formal_concept
(
    id INTEGER PRIMARY KEY ,
    name TEXT NOT NULL UNIQUE,
    part_of_speech TEXT NOT NULL,
    descrip TEXT,
    rel_pic_url TEXT
);

/*
NOTE:
- phonetic  is temporary.  eventaully code will gen any of many possible transliterations.
- rel_pic_url is optional.  it enables override of formal concept pic.
- locale: 2 char country code, e.g. us, th, etc
 */
CREATE TABLE native_concept
(
    id INTEGER PRIMARY KEY,
    parent_id INTEGER NOT NULL,
    locale TEXT NOT NULL,
    name TEXT NOT NULL,
    phonetic TEXT,
    descrip TEXT,
    rel_pic_url TEXT,
    rel_sound_url TEXT
);

/*
- completion state:
- visibility state: public or private (just for me)
- notes: public is for display on page.  private is just for me. mostly dev purposes.  maybe should have another table for this.
 */
CREATE TABLE lesson
(
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    descrip TEXT,
    completion_state TEXT NOT NULL,
    visibility_state TEXT NOT NULL,
    fact_map_type TEXT NOT NULL,
    notes_pub TEXT,
    notes_priv TEXT
);


CREATE TABLE concept_map
(
    lesson_id INTEGER NOT NULL,
    formal_concept_guid INTEGER NOT NULL,
    src_native_concept_guid INTEGER NOT NULL,
    dst_native_concept_guid INTEGER NOT NULL
);




