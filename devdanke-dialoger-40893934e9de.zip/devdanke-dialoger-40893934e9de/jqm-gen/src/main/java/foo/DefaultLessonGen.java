package foo;

import foo.model.Item;
import foo.model.Lesson;
import foo.model.LessonChunk;
import foo.model.LessonPackage;

import java.util.Collection;
import java.util.List;

/**
 * *************************************************************************************
 *
 * @Since 5/31/12
 * <p/>
 * *************************************************************************************
 */
public class DefaultLessonGen
{

    public static void addDefaultLessons(Collection<LessonPackage> lessonPkgs)
    {
        //Add lesson standard lesson defs, e.g. 'all', 'halves', etc.
        for (LessonPackage pkg : lessonPkgs)
        {
            List<Item> items = pkg.items;

            pkg._lessons.add(makeDefaultLessonChunks("All", items, 1));
            if (items.size() > 10) pkg._lessons.add(makeDefaultLessonChunks("Halves", items, 2));
            if (items.size() > 20) pkg._lessons.add(makeDefaultLessonChunks("Quarters", items, 4));
            if (items.size() > 6) pkg._lessons.add(makeDefaultLessonChunks("Six Packs", items,
                calcPartSize(items.size(), 6)));
        }
    }


    private static Lesson makeDefaultLessonChunks(String name, List<Item> items, int partCount)
    {
        Lesson def = new Lesson();
        def.name = name;

        for (int partIndex = 0; partIndex < partCount; partIndex++)
        {
            LessonChunk part = new LessonChunk();
            int[] chunkStartEnd = calcStartIndex(items.size(), partCount, partIndex);

            part.name = "Items " + (chunkStartEnd[0] + 1) + " - " + chunkStartEnd[1];
            def._chunks.add(part);

            for (int itemIndex = chunkStartEnd[0]; itemIndex < chunkStartEnd[1]; itemIndex++)
            {
                part.addItemIndex(itemIndex);
            }
        }

        return def;
    }


    /*
   totItemCnt | partCnt | partIdx -> startIndex | endIndexPlus1  | itemsInChunk
   10             4         0          0               2+1=3           3
   10             4         1          3               5+1=6           3
   10             4         2          6               8+1=9           3
   10             4         3          9               9+1=10          1
    */
    private static int[] calcStartIndex(int totalItemCount, int partCount, int partIndex)
    {

        int partSize = calcPartSize(totalItemCount, partCount);

        int startIndex = (partSize * partIndex);

        int endIndexPlus1 = startIndex + partSize;
        if (endIndexPlus1 > totalItemCount) endIndexPlus1 = totalItemCount;

        int[] starEndIndices = new int[2];
        starEndIndices[0] = startIndex;
        starEndIndices[1] = endIndexPlus1;

        return starEndIndices;
    }


    private static int calcPartSize(int totalItemCount, int partCount)
    {
        int partSize = totalItemCount / partCount;
        if (totalItemCount % partCount > 0) partSize++;
        return partSize;
    }


}
