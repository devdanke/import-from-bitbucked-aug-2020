package foo;

import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import foo.db.Dao;
import foo.model.LessonPackage;
import foo.model.Visibility;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;



/**
 * *************************************************************************************
 *
 * *************************************************************************************
 */
public class WebsiteGen
{
    public static final String VIS = "VIS";
    public static final String CDN_BASE_URL = "CDN_BASE_URL";
    public static final String MEDIA_BASE_URL = "MEDIA_BASE_URL";
    public static final String LSN_PKGS = "LSN_PKGS";
    public static final String DEPLOY_ENV = "DEPLOY_ENV";
    public static final String LOCAL_ENV = "local";
    public static final String REMOTE_ENV = "remote";


    public static void generate(String devRoot, String relDbPath)
        throws Exception
    {
        if(devRoot==null)
        {
            throw new RuntimeException("devRoot null");
        }
        if(relDbPath==null)
        {
            throw new RuntimeException("relDbPath null");
        }

        String dateStamp = new SimpleDateFormat("MM.dd.HH.mm").format(new Date());


        String localCdnBaseUrl =  "http://localhost/my/cdn/jquery";
        String remoteCdnBaseUrl = "http://code.jquery.com";

        String localMediaBaseUrl =  "http://localhost/my/media/flashdeck";
        String remoteMediaBaseUrl =
            "http://menlospark.s3-website-us-west-2.amazonaws.com/media/pub/lessons/vocab";
        //String remoteMediaBaseUrl = "http://dl.dropbox.com/u/46318541/media";

        String sqliteDbPath = devRoot + relDbPath;
        Dao sqliteDao = new Dao(sqliteDbPath);

        List<LessonPackage> pubLsnPkgs = sqliteDao.loadLessonData(Visibility.PUBLIC);
        List<LessonPackage> allLsnPkgs = sqliteDao.loadLessonData(Visibility.ALL);

        //need to add default lessons, such as All, Halves, etc to the packages.
        DefaultLessonGen.addDefaultLessons(pubLsnPkgs);
        DefaultLessonGen.addDefaultLessons(allLsnPkgs);


        //local pub
        Map localPub = Maps.newHashMap();
        localPub.put(VIS, Visibility.PUBLIC );
        localPub.put(CDN_BASE_URL, localCdnBaseUrl);
        localPub.put(MEDIA_BASE_URL, localMediaBaseUrl);
        localPub.put(LSN_PKGS, pubLsnPkgs);
        localPub.put(DEPLOY_ENV, LOCAL_ENV);

        //local all
        Map localAll = Maps.newHashMap();
        localAll.put(VIS, Visibility.ALL );
        localAll.put(CDN_BASE_URL, localCdnBaseUrl);
        localAll.put(MEDIA_BASE_URL,localMediaBaseUrl);
        localAll.put(LSN_PKGS, allLsnPkgs);
        localAll.put(DEPLOY_ENV, LOCAL_ENV);

        //remote pub
        Map remotePub = Maps.newHashMap();
        remotePub.put(VIS, Visibility.PUBLIC );
        remotePub.put(CDN_BASE_URL, remoteCdnBaseUrl);
        remotePub.put(MEDIA_BASE_URL, remoteMediaBaseUrl);
        remotePub.put(LSN_PKGS, pubLsnPkgs);
        remotePub.put(DEPLOY_ENV, REMOTE_ENV);

        /*
        //remote all
        Map remoteAll = Maps.newHashMap();
        remoteAll.put(VIS, Visibility.ALL );
        remoteAll.put(CDN_BASE_URL, remoteCdnBaseUrl);
        remoteAll.put(MEDIA_BASE_URL, remoteMediaBaseUrl);
        remoteAll.put(LSN_PKGS, allLsnPkgs);
        remoteAll.put(DEPLOY_ENV, REMOTE_ENV);
*/

        List<Map<String,Object>> envParams = Lists.newArrayList();
        envParams.add(localPub);
        envParams.add(localAll);
        envParams.add(remotePub);
  //      envParams.add(remoteAll);


        for(Map map : envParams)
        {
            //extract params needed for generation
            List<LessonPackage> lessonPkgs = (List<LessonPackage>) map.get(LSN_PKGS);
            Visibility visibility = (Visibility) map.get(VIS);
            String cdnBaseUrl = (String) map.get(CDN_BASE_URL);
            String mediaBaseUrl = (String) map.get(MEDIA_BASE_URL);
            String deployEnv = (String) map.get(DEPLOY_ENV);

            //create custom vars for each env
            List extCssLibs = Lists.newArrayList(cdnBaseUrl +
                "/mobile/1.1.0/jquery.mobile-1.1.0.min.css");

            List allExtJsLibsExceptJqm = Lists.newArrayList();
            allExtJsLibsExceptJqm.add(cdnBaseUrl + "/jquery-1.7.1.min.js");

            String jqmLib = cdnBaseUrl + "/mobile/1.1.0/jquery.mobile-1.1.0.min.js";

            List allExtJsLibs = Lists.newArrayList();
            allExtJsLibs.addAll(allExtJsLibsExceptJqm);
            allExtJsLibs.add(jqmLib);


            String rootOutputPath = "./target/generated-website/" +
                "/" + deployEnv + "-" + visibility.name().toLowerCase();

            //make dirs if they don't already exist
            String dataOutputPath = rootOutputPath + "/data";
            new File(dataOutputPath).mkdirs();

            //generate
            FreeMarkGen.genLessonToc(rootOutputPath, lessonPkgs, allExtJsLibs, extCssLibs);

            FreeMarkGen.genInfoHtml(rootOutputPath, dateStamp, visibility, allExtJsLibs, extCssLibs);

            FreeMarkGen.genLessonData(dataOutputPath, dateStamp, lessonPkgs);

            FreeMarkGen.genLessonSpecificTrainerHtml(lessonPkgs, rootOutputPath, allExtJsLibsExceptJqm,
                jqmLib, extCssLibs, mediaBaseUrl);
        }

    }

    public static void main(String[] args)
        throws Exception
    {
        generate(System.getenv("DEV_ROOT"), Const.DB_PATH_REL);
    }


}
