package foo;

import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;
import org.apache.commons.lang3.CharEncoding;

import java.io.File;
import java.io.PrintWriter;
import java.util.Map;

/**
 * *************************************************************************************
 *
 * @Since 3/19/12
 * <p/>
 * *************************************************************************************
 */
public class FreeMarkUtil
{
    //used by FreeMarkGen
    public static final String DEFAULT_FM_TMPL_DIR = "./src/main/freemarker";

    private Configuration _fmConf;
    private File _outDir;

    
    /*
    Used just once when class is created.
     */
    public FreeMarkUtil(File tmplDir, File outDir)
    {
        try
        {
            _outDir = outDir;
            _fmConf = new Configuration();

            _fmConf.setNumberFormat("0.######");
            _fmConf.setDirectoryForTemplateLoading(tmplDir);
            _fmConf.setObjectWrapper(new DefaultObjectWrapper());
            _fmConf.setDefaultEncoding(CharEncoding.UTF_8);
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    public void render(String templateName, Map<String, Object> model)
    {
        render(templateName, model, null);
    }

     /**
     * Where the rubber meets the road.
     * By default, the fmt (freemarker template file extension is removed.)
     *
     * @param fileSuffix insert into file name just before ".html"
     */
    public void render(String templateName, Map<String, Object> model, String outFileName)
    {
        try
        {
            Template template = _fmConf.getTemplate(templateName);

            if(outFileName == null)
            {
                outFileName = templateName;
                outFileName = outFileName.replace(".fmt","");
            }

            PrintWriter writer = new PrintWriter(new File(_outDir, outFileName));
            template.process(model, writer);

            writer.flush();
            writer.close();
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }

}
