package foo.model;

import foo.Const;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.ArrayList;
import java.util.List;

/**
 * *************************************************************************************
 * <p/>
 * <p/>
 * CREATE TABLE lesson
 * (
 * id INTEGER PRIMARY KEY,
 * name TEXT NOT NULL,
 * locale_src TEXT NOT NULL,
 * locale_dst TEXT NOT NULL,
 * cms_path TEXT NOT NULL,
 * default_fact_map TEXT NOT NULL,
 * unsupported_fact_maps TEXT
 * );
 * *************************************************************************************
 */
public class LessonPackage
{
    public Long id;
    public String name;
    public String srcLocale;
    public String dstLocale;
    public String cmsPath;
    public String access;
    public String defaultFactMap;
    public String unsupportedFactMaps;

    public List<Item> items = new ArrayList<Item>();
    public List<Lesson> _lessons = new ArrayList<Lesson>();

    public int getItemCount()
    {
        return items.size();
    }

    public Long getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public String getSrcLocale()
    {
        return srcLocale;
    }

    public String getDstLocale()
    {
        return dstLocale;
    }

    public String getCmsPath()
    {
        return cmsPath;
    }

    public boolean isPublic()
    {
        return Const.PUBLIC.equals(access);
    }
    
    public String getDefaultFactMap()
    {
        return defaultFactMap;
    }

    public String getUnsupportedFactMaps()
    {
        return unsupportedFactMaps;
    }

    public List<Item> getItems()
    {
        return items;
    }

    public List<Lesson> getLessons()
    {
        return _lessons;
    }

    @Override
    public String toString()
    {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
