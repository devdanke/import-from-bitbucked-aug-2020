package foo.model;

import foo.Const;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Map;
import java.util.TreeMap;

/**
 * *************************************************************************************
 *
 * @Since 3/18/12
 * <p/>
 * *************************************************************************************
 */
public class Item
{
    
    public Long id;
    public Long lessonPkgId;
    public String soundBaseName;
    public String picName;
    public String srcText;
    public String dstText;
    public Map<String,String> props = new TreeMap<String, String>();
    public String notes;
    public Long pos;
    public String access;

    public Long getId()
    {
        return id;
    }

    public Long getLessonPkgId()
    {
        return lessonPkgId;
    }

    public String getSoundBaseName()
    {
        return soundBaseName;
    }

    public String getPicName()
    {
        return picName;
    }

    public String getSrcText()
    {
        return srcText;
    }

    public String getDstText()
    {
        return dstText;
    }

    public Map<String,String> getProps()
    {
        return props;
    }

    public String getNotes()
    {
        return notes;
    }

    public Long getPos()
    {
        return pos;
    }

    public boolean isPublic()
    {
        return Const.PUBLIC.equals(access);
    }

    @Override
    public  String toString()
    {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
