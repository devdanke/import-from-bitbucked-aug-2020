package foo.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.ArrayList;
import java.util.List;

/**
 * *************************************************************************************

 * *************************************************************************************
 */
public class Lesson
{
    public Long id;
    public String name;
    public String factMap;
    public List<LessonChunk> _chunks = new ArrayList<LessonChunk>();

    public Long getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public String getFactMap()
    {
        return factMap;
    }


    public List<LessonChunk> getChunks()
    {
        return _chunks;
    }

    @Override
    public String toString()
    {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
