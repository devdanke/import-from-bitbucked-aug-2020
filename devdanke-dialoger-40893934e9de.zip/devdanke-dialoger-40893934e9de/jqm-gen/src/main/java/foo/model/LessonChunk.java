package foo.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.ArrayList;
import java.util.List;

/**
 * *************************************************************************************

 * *************************************************************************************
 */
public class LessonChunk
{
    public Long id;
    public String name;
    private List<Integer> itemIndices = new ArrayList<Integer>();

    public Long getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public List<Integer> getItemIndices()
    {
        return itemIndices;
    }

    public void addItemIndex(Integer index)
    {
        if(index==null) throw new RuntimeException("index cannot be null");
        itemIndices.add(index);
    }

    @Override
    public String toString()
    {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
