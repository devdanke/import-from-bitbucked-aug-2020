package foo.db;

import foo.model.*;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

/**
 * *************************************************************************************
 * <p/>
 * *************************************************************************************
 */
public class Dao
{
    private String _dbPath;

    /**
     * @param dbPath Fully qualified path to db, e.g.
     *               file: '/Users/me/_dev/dialoger/jqm-gen/database/first_try.sqlite'
     */
    public Dao(String dbPath)
    {
        if ((new File(dbPath).exists()))
        {
            _dbPath = dbPath;
        }
        else
        {
            throw new RuntimeException("File '" + dbPath + "' does not exist.");
        }

        try
        {
            Class.forName("org.sqlite.JDBC");

        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    /*
    NOTE: package private for use by DbUtil for DB manipulation.
     */
    Connection getCon()
        throws
        Exception
    {
        try
        {
            return DriverManager.getConnection("jdbc:sqlite:" + _dbPath);

        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    /**
      * *************************************************************************
      * NOTE: returns Only PUBLIC lessons/items
      */
     public List<LessonPackage> loadLessonData(Visibility visible)
         throws
         Exception
     {
         if(visible == null)
         {
             throw new IllegalArgumentException("Visible arg (enum) cannot be null.");
         }

         List<LessonPackage> lessonPkgs = loadLessonDataAll();

         switch(visible)
         {
             case ALL:
                 break;
             case PUBLIC:
                 removeNonPublicLessonsAndItemsData(lessonPkgs);
                 break;
             default:
                 throw new RuntimeException("Unknown Visibility enum");
         }

         return lessonPkgs;
     }
 

    /**
     * *************************************************************************
     * NOTE: alters the lessons list passed in.
     */
    public void removeNonPublicLessonsAndItemsData(List<LessonPackage> lessonPkgs)
        throws
        Exception
    {
        //remove any lesson/item whose access is not public
        ListIterator<LessonPackage> lessonIter = lessonPkgs.listIterator();
        while (lessonIter.hasNext())
        {
            LessonPackage lessonPkg = lessonIter.next();
            //remve private lessons
            if (!lessonPkg.isPublic())
            {
                lessonIter.remove();
                continue;
            }

            //remove private items from public lessons
            ListIterator<Item> itemIter = lessonPkg.items.listIterator();
            while (itemIter.hasNext())
            {
                Item item = itemIter.next();
                if (!item.isPublic())
                {
                    itemIter.remove();
                    continue;
                }
            }//each item in lesson
        }//each lesson
    }


    /**
     * *************************************************************************
     * I'm loading lessons in a way that lets me use the same resultset.
     * Finish processing the resultset before using it for another query.
     * I don't have a good reason for this.  It seems easy and simple.
     * <p/>
     * NOTE: returns PUBLIC & PRIVATE lessons/items
     */
    private List<LessonPackage> loadLessonDataAll()
        throws
        Exception
    {
        Connection con = null;
        try
        {
            // create a database connection
            con = getCon();
            Statement statement = con.createStatement();
            statement.setQueryTimeout(30);  // seconds

            List<LessonPackage> lessonPkgs = new ArrayList<LessonPackage>();
            ResultSet rs = statement.executeQuery("SELECT * FROM lesson_package " +
                "WHERE access <> 'NONE'");
            while (rs.next())
            {
                LessonPackage lsn = loadLessonPkg(rs);
                lessonPkgs.add(lsn);
            }
            rs.close();

            for (LessonPackage pkg : lessonPkgs)
            {
                //load lesson's items
                Map<Long, Integer> itemIdToListIndexMap = new HashMap<Long, Integer>();//used when loading lesson_def_parts
                rs = statement.executeQuery(
                    "SELECT * FROM item " +
                        "WHERE lesson_pkg_id = " + pkg.id + " AND access <> 'NONE' " +
                        "ORDER BY pos");
                int itemListIndex = 0;
                while (rs.next())
                {
                    Item item = loadItem(rs);
                    itemIdToListIndexMap.put(item.id, itemListIndex++);
                    pkg.items.add(item);
                }
                rs.close();
                //out("temIdToListIndexMap=" + itemIdToListIndexMap.toString());

                //load item props
                for (Item item : pkg.items)
                {
                    rs = statement.executeQuery(
                        "SELECT * FROM item_prop WHERE item_id = " + item.id + " ORDER BY name");
                    Map<String, String> map = new TreeMap<String, String>();
                    while (rs.next())
                    {
                        String key = rs.getString("name").trim();
                        if (key.equals("old_props") || key.equals("translit"))
                        {
                            continue;
                        }
                        map.put(key, rs.getString("value"));
                    }
                    rs.close();
                    item.props.putAll(map);
                }


                //load lesson's custom lesson defs
                rs = statement.executeQuery("SELECT * FROM lesson WHERE lesson_pkg_id = " + pkg.id);
                while (rs.next())
                {
                    Lesson lsn = loadLesson(rs);
                    pkg._lessons.add(lsn);
                }
                rs.close();

                //for each def, load its parts
                for (Lesson lsn : pkg._lessons)
                {
                    rs = statement.executeQuery(
                        "SELECT * FROM lesson_chunk WHERE lesson_id = " + lsn.id);
                    while (rs.next())
                    {
                        LessonChunk part = loadLessonChunk(rs);
                        lsn._chunks.add(part);
                    }
                    rs.close();

                    //for each part, load its item indices
                    for (LessonChunk chunk : lsn._chunks)
                    {
                        rs = statement.executeQuery(
                            "SELECT item_id FROM chunk_x_item WHERE chunk_id = " + chunk.id);
                        while (rs.next())
                        {
                            Long itemId = rs.getLong("item_id");
                            //out("item_id=" + itemId);
                            Integer itemIndex = itemIdToListIndexMap.get(itemId);
                            chunk.addItemIndex(itemIndex);
                        }
                        rs.close();
                    }
                }
            }//each lesson
            return lessonPkgs;
        }
        finally
        {
            if (con != null) con.close();
        }
    }


    private void out(String msg)
    {
        System.out.println("### " + msg);
    }


    /*
     */
    private Lesson loadLesson(ResultSet rs)
    {
        try
        {
            Lesson lsn = new Lesson();

            lsn.id = rs.getLong("id");
            lsn.name = rs.getString("name");
            lsn.factMap = rs.getString("fact_map");


            return lsn;
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    private LessonChunk loadLessonChunk(ResultSet rs)
    {
        try
        {
            LessonChunk chunk = new LessonChunk();

            chunk.id = rs.getLong("id");
            chunk.name = rs.getString("name");

            return chunk;
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    private Item loadItem(ResultSet rs)
    {
        try
        {
            Item item = new Item();

            item.id = rs.getLong("id");
            item.lessonPkgId = rs.getLong("lesson_pkg_id");
            item.soundBaseName = rs.getString("sound_base_name");
            item.picName = rs.getString("pic_name");
            item.srcText = rs.getString("src_text");
            item.dstText = rs.getString("dst_text");
            item.notes = rs.getString("notes");
            item.pos = rs.getLong("pos");
            item.access = rs.getString("access");

            return item;
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    private LessonPackage loadLessonPkg(ResultSet rs)
    {
        try
        {
            LessonPackage pkg = new LessonPackage();

            pkg.id = rs.getLong("id");
            pkg.name = rs.getString("name");
            pkg.srcLocale = rs.getString("locale_src");
            pkg.dstLocale = rs.getString("locale_dst");
            pkg.cmsPath = rs.getString("cms_path");
            pkg.access = rs.getString("access");
            pkg.defaultFactMap = rs.getString("default_fact_map");
            pkg.unsupportedFactMaps = rs.getString("unsupported_fact_maps");

            return pkg;
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


}
