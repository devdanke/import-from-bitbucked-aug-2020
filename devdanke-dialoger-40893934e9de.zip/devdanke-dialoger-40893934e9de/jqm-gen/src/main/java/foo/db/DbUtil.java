package foo.db;

import java.util.*;

/**
 * *************************************************************************************
 *
 * @Since 3/20/12
 * <p/>
 * *************************************************************************************
 */
public class DbUtil
    extends  Dao
{
    public DbUtil(String dbPath)
    {
        super(dbPath);
    }


    
    public void doIt()
        throws Exception
    {
        //insertConsProps();
    }

/*
    private void insertConsProps()
        throws Exception
    {
        List<Lesson> lessons = loadLessonData();

        Lesson targLsn = null;
        for(Lesson lsn : lessons)
        {
            if(lsn.name.trim().toLowerCase().startsWith("consonants"))
            {
                targLsn = lsn;
                break;
            }
        }

        Connection con = getCon();
        PreparedStatement pstmt = con.prepareStatement("INSERT INTO item_prop (item_id,name,value) VALUES(?,?,?)");

        for(Item item : targLsn.items)
        {
            for(Map.Entry<String,String> entry : parseOldConsProps(item.getProps()).entrySet() )
            {
                pstmt.setLong(  1, item.getId());
                pstmt.setString(2, entry.getKey());
                pstmt.setString(3, entry.getValue());

                pstmt.executeUpdate();
            }
        }
        pstmt.close();
        con.close();
    }
*/

    private Map<String,String> parseOldConsProps(String propStr)
    {
        if(propStr == null) throw new RuntimeException("propsStr null");
        propStr = propStr.trim();
        if(propStr.isEmpty()) throw new RuntimeException("propsStr empty");

        StringTokenizer st = new StringTokenizer(propStr, "|");

        Map<String,String> vals = new TreeMap<String,String>();
        //ว แหวน | wo waen | ring |w w | low
        vals.put("thNumonic", getLastPart( st.nextToken().trim()) );
        vals.put("translit",  st.nextToken().trim());
        vals.put("enNumonic", st.nextToken().trim());
        vals.put("finalSound", getLastPart( st.nextToken().trim() ));
        vals.put("toneClass", calcToneClassCode(st.nextToken().trim()) );

        return vals;
    }


    private String calcToneClassCode(String str)
    {
        str = str.toLowerCase();
        if(str.equals("mid")) return "M";
        if(str.equals("high")) return "H";
        else return "L";
    }
    

    private String getFirstPart(String str)
    {
        str = str.trim();
        int spacePos = str.trim().indexOf(" ");
        return str.substring(0,spacePos);
    }


    private String getLastPart(String str)
    {
        str = str.trim();
        int spacePos = str.trim().indexOf(" ");
        return str.substring(spacePos);
    }


/*
    private void movePropsToOldProps()
        throws Exception
    {
        List<Lesson> lessons = loadLessonData();
        
        List<Item> allItems = new ArrayList<Item>();
        for(Lesson lsn : lessons)
        {
            allItems.addAll(lsn.getItems());
        }
        
        Connection con = getCon();
        PreparedStatement pstmt = con.prepareStatement("INSERT INTO item_prop (item_id,name,value) VALUES(?,?,?)");

        for(Item item : allItems)
        {
            String props = item.getProps();
            if(props == null) continue;
            props = props.trim();
            if(props.isEmpty()) continue;

            if(props.endsWith("|")) props = props.substring(0, props.length()-1);

            pstmt.setLong(1,item.getId());
            pstmt.setString(2,"old_props");
            pstmt.setString(3,props);
            pstmt.executeUpdate();
        }
        pstmt.close();
        con.close();
    }
*/
}
