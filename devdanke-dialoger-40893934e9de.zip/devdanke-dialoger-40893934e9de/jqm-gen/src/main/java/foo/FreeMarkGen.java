package foo;

import java.io.File;
import java.util.*;

import foo.model.*;

/**
 * *************************************************************************************
 *
 */
public class FreeMarkGen
{


    /**
     * NOTE: This method changes the lessonPkgs object by adding default lessons!!!
     *
     * @param dataOutputPath
     * @param dateStamp
     * @param lessonPkgs
     * @throws Exception
     */
    public static void genLessonData(String dataOutputPath, String dateStamp,
        List<LessonPackage> lessonPkgs)
        throws Exception
    {
        //generate a json data file for each lesson
        for(LessonPackage pkg : lessonPkgs)
        {
            Map<String,Object> model = new HashMap<String, Object>();
            model.put("pkg", pkg);
            model.put("dateStamp", dateStamp);

            FreeMarkUtil fm = new FreeMarkUtil(new File(FreeMarkUtil.DEFAULT_FM_TMPL_DIR),
                new File(dataOutputPath));
            fm.render("lesson-pkg.js.fmt", model,
                pkg.name.trim().toLowerCase() + "-lesson-pkg.js");
        }
    }


    public static void genLessonToc(String rootOutputPath, List<LessonPackage> lessonPkgs,
        List extJsLibs, List extCss)
    {
        Map<String,Object> model = new HashMap<String, Object>();
        model.put("lessonPkgs", lessonPkgs);
        model.put("extCssFiles", extCss);
        model.put("extJsLibs", extJsLibs);

        FreeMarkUtil fmu = new FreeMarkUtil(new File(FreeMarkUtil.DEFAULT_FM_TMPL_DIR),
            new File(rootOutputPath));
        fmu.render("lessons.html.fmt", model);
    }


    public static void genInfoHtml(String rootOutputPath,
        String dateStamp, Visibility visibility, List extJsLibs, List extCss)
        throws RuntimeException
    {
        try
        {
            Map<String,Object> model = new HashMap<String, Object>();
            model.put("dttm", dateStamp);
            model.put("visibility", visibility.name());
            model.put("extCssFiles", extCss);
            model.put("extJsLibs", extJsLibs);

            FreeMarkUtil fmu = new FreeMarkUtil(new File(FreeMarkUtil.DEFAULT_FM_TMPL_DIR),
                new File(rootOutputPath));
            fmu.render("info.html.fmt", model);
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    /*
    The trainer.html file is essentiallly the same for each lesson.
    The only difference is that, because trainer runs without a server, it
    needs to know the name of its lesson data file.  So embed that name into the trainer file.
    Also, rename the trainer file to its specific lesson so it can be referenced in the lesson
    list.

    NOTE: this method doesn't use freemarker.
     */

    /**
     *
     * @param lessonPkgs
     * @param rootOutputPath
     * @param extJsLibsExceptJqm
     * @param jqmLib separated from other js libs because it must come after any redef/rebind of
     *               html page create events.
     * @param extCss  JQM and other css files.
     * @param mediaBaseUrl host of sound and pic files
     */
    public static void genLessonSpecificTrainerHtml(List<LessonPackage> lessonPkgs,
        String rootOutputPath, List extJsLibsExceptJqm, String jqmLib, List extCss,
        String mediaBaseUrl)
    {
        try
        {
            for(LessonPackage lessonPkg : lessonPkgs)
            {
                String safeLsnPkgName = makeFsSafeName(lessonPkg.getName());

                Map<String,Object> model = new HashMap<String, Object>();
                model.put("safeLsnPkgName", safeLsnPkgName );
                model.put("extCssFiles", extCss);
                model.put("allExtJsLibsExceptJqm", extJsLibsExceptJqm);
                model.put("jqmLib", jqmLib);
                model.put("mediaBaseUrl", mediaBaseUrl);

                FreeMarkUtil fmu = new FreeMarkUtil(new File(FreeMarkUtil.DEFAULT_FM_TMPL_DIR),
                    new File(rootOutputPath));
                fmu.render("trainer.html.fmt", model, safeLsnPkgName+"-trainer.html" );
            }
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }



    /**
     * Use to make str a safe name for file system. i.e. can be used as file name.
     *
     * @param str
     * @return
     */
    private static String makeFsSafeName(String str)
    {
        String tmp = str.trim();
        StringBuffer sb = new StringBuffer();
        for(char ch : tmp.toCharArray())
        {
            if( Character.isLetter(ch) )
            {
                sb.append(Character.toLowerCase(ch));
            }
            else if( Character.isDigit(ch) || (ch == '-') || (ch == '_'))
            {
                sb.append(ch);
            }
            else
            {
                sb.append("-");
            }
        }
        return sb.toString();
    }



}
