package foo;

/**
 * *************************************************************************************
 *
 * @Since 3/24/12
 * <p/>
 * *************************************************************************************
 */
public class Const
{

    public static final String DB_PATH_REL = "/dialoger/jqm-gen/database/trainer.sqlite";
    //public static final String DB_FILEx = "/Users/me/_dev/dialoger/jqm-gen/database/first_try.sqlite";
    public static final String PUBLIC = "PUBLIC";
}
