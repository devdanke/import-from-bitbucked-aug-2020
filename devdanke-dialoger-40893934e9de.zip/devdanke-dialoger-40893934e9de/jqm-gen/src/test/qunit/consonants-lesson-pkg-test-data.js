/*
Generated from Freemarker template 'lesson-data.js.fmt' and data from sqlite db.
Created: 06.10.15.16
 */
var gTestLessonPkg =
{
    "guid":"110",
    "name":"Consonants",
    "srcLang":"EN",
    "dstLang":"TH",
    "lessonDir":"flashdeck/consonants",
    "supportedFactMaps":["LANG_DST_TEXT_TO_SND","LANG_PIC_TO_SND", "LANG_SND_TO_DST_TEXT"],
    lessons:
    [
        {
            name:"Final Consonants",
            supportedFactMapsOverride:["LANG_DST_TEXT_TO_CUST_SND"],
            parts:
            [
                {
                    name:"Items 1 - 6",
                    itemIndices:[ 0,1,2,3,4,5 ]
                }
            ]
        } ,
        {
            name:"All",
            parts:
            [
                {
                    name:"Items 1 - 6",
                    itemIndices:[ 0,1,2,3,4,5 ]
                }
            ]
        } ,
        {
            name:"Halves",
            parts:
            [
                {
                    name:"Items 1 - 3",
                    itemIndices:[ 0,1,2 ]
                } ,
                {
                    name:"Items 4 - 6",
                    itemIndices:[ 3,4,5 ]
                }
            ]
        }

    ],


    "items":
    [
        {
            id:"35",
            srcText:"01_k__kai",
            dstText:"ก",
            sndBaseName:"01_k__kai",
            picName:"bpic01.jpg" ,
            enNumonic:"chicken",
            finalSound:"ก",
            thNumonic:" ไก่",
            toneClass:"M"
        } ,
        {
            id:"36",
            srcText:"02_kh_khai",
            dstText:"ข",
            sndBaseName:"02_kh_khai",
            picName:"bpic02.jpg" ,
            enNumonic:"egg",
            finalSound:"ก",
            thNumonic:" ไข่",
            toneClass:"H"
        } ,
        {
            id:"38",
            srcText:"04_kh_khwai",
            dstText:"ค",
            sndBaseName:"04_kh_khwai",
            picName:"bpic04.jpg" ,
            enNumonic:"water buffalo",
            finalSound:"ก",
            thNumonic:" ควาย",
            toneClass:"L"
        } ,
        {
            id:"40",
            srcText:"06_kh_rkng",
            dstText:"ฆ",
            sndBaseName:"06_kh_rkng",
            picName:"bpic06.jpg" ,
            enNumonic:"bell",
            finalSound:"ก",
            thNumonic:" ระฆัง",
            toneClass:"L"
        } ,
        {
            id:"41",
            srcText:"07_ng_ngu",
            dstText:"ง",
            sndBaseName:"07_ng_ngu",
            picName:"bpic07.jpg" ,
            enNumonic:"snake",
            finalSound:"ง",
            thNumonic:" งู",
            toneClass:"L"
        } ,
        {
            id:"42",
            srcText:"08_j__jan",
            dstText:"จ",
            sndBaseName:"08_j__jan",
            picName:"bpic08.jpg" ,
            enNumonic:"plate",
            finalSound:"ด",
            thNumonic:" จาน",
            toneClass:"M"
        }
    ]
};

