package com.menlospark.jqm;

import foo.Const;
import foo.WebsiteGen;
import org.junit.Test;

/**
 * *************************************************************************************
 *
 * @Since 5/31/12
 * <p/>
 * *************************************************************************************
 */
public class WebsiteGenTest
{
    /*
    NOTE: using prod db.
    */
    @Test
    public void testWebsiteGen()
        throws Exception
    {
        String devRoot = System.getenv("DEV_ROOT");
        if(devRoot==null) devRoot = "/home/me/_dev";
        WebsiteGen.generate(devRoot, Const.DB_PATH_REL);
    }
}
