package com.menlospark.jqm;

import foo.db.Dao;
import foo.model.LessonPackage;
import foo.model.Visibility;
import junit.framework.Assert;
import org.junit.Test;

import java.util.List;

/**
 * *************************************************************************************
 *
 * @Since 3/16/12
 * <p/>
 * *************************************************************************************
 */
public class DaoTest
{
    
    private static final String TEST_DB_URL =
        "./src/test/resources/DaoTest/2012-05-13_first_try.sqlite";
    
    
    /*
    dao.loadLessonData() must only return PUBLIC lessons
    */
    @Test
    public void daoReturnsCorrectPublicAccessLessonsCount()
        throws Exception
    {
        Dao dao = new Dao(TEST_DB_URL);

        int expect = 6;
        int actual = dao.loadLessonData(Visibility.PUBLIC).size(); //public lesson count

        Assert.assertEquals("PUBLIC lesson count", expect, actual);
    }


    /*
    dao.loadLessonDataAll() must only return all lessons (PUB and PRI)
    */
    @Test
    public void daoReturnsCorrectAllAccessLessonsCount()
        throws Exception
    {
        Dao dao = new Dao(TEST_DB_URL);

        int expect = 8;
        int actual = dao.loadLessonData(Visibility.ALL).size(); //public lesson count

        Assert.assertEquals("ALL (pub & pri) lesson count", expect, actual);
    }


    /*
    Must EXCLUDE private item "breast".
    */
    @Test
    public void daoReturnsCorrectPublicBodyLessonItemCount()
        throws Exception
    {
        Dao dao = new Dao(TEST_DB_URL);

        int expect = 35;
        int actual = getItemCount("Body", dao.loadLessonData(Visibility.PUBLIC)); //public lesson count

        Assert.assertEquals("body lesson PUBLIC item count", expect, actual);
    }


    /*
    Must include the private item too.
    */
    @Test
    public void daoReturnsCorrectAllBodyLessonItemCount()
        throws Exception
    {
        Dao dao = new Dao(TEST_DB_URL);

        int expect = 38;
        int actual = getItemCount("Body", dao.loadLessonData(Visibility.ALL)); //public lesson count

        Assert.assertEquals("body lesson ALL item count", expect, actual);
    }


    private int getItemCount(String lessonName, List<LessonPackage> lessonPkgs)
    {
        for(LessonPackage lessonPkg : lessonPkgs)
        {
            if(lessonPkg.getName().equals(lessonName))
            {
                return lessonPkg.getItemCount();
            }
        }
        throw new RuntimeException("Didn't find lesson with name: '" + lessonName+ "'");
    }
}



