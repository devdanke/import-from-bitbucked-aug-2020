package com.menlospark.jqm;

import foo.Const;
import foo.db.DbUtil;
import org.junit.Test;

/**
 * *************************************************************************************
 *
 * @Since 3/16/12
 * <p/>
 * *************************************************************************************
 */
public class DaoDoer
{

    @Test
    public void doIt()
        throws Exception
    {
        new DbUtil(Const.DB_PATH_REL).doIt();
    }
}


