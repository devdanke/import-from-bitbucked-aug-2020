package com.menlospark.dialog.data;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

import java.util.List;

/**
 * *************************************************************************************
 *
 * @Since 7/15/12
 * <p/>
 * *************************************************************************************
 */
public class MyTest
{

    @Test
    public void testSqlQuery()
    {
        DataMgr dataMrg = new DataMgr();
        Session session = dataMrg.getSession();

        Query query = session.createSQLQuery("SELECT * FROM contributor");
        List list = query.list();
        for( Object obj : list)
        {
            Object[] objArr = (Object[]) obj;
            String str = "";
            for(int i=0; i<objArr.length; i++)
            {
                Object val = objArr[i];
                if(val != null) str += val.toString();
                else str += "null";
                str +=  ", ";
            }
            System.out.println("row vals = " + str);
        }
        session.close();
    }
}
