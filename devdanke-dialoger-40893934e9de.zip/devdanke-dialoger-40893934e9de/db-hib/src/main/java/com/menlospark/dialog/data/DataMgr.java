package com.menlospark.dialog.data;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * *************************************************************************************
 *
 * @Since 7/15/12
 * <p/>
 * *************************************************************************************
 */
public class DataMgr
{
    private SessionFactory _factory;

    public DataMgr()
    {
        _factory = new Configuration()
            .configure() // configures settings from hibernate.cfg.xml
            .buildSessionFactory();

    }

    public Session getSession()
    {
        return _factory.openSession();
    }
}
