package com.menlospark.dialog.data;


import javax.persistence.*;

/**

 CREATE TABLE `contributor` (
   `id` bigint(20) NOT NULL AUTO_INCREMENT,
   `version` bigint(20) NOT NULL,
   `name` varchar(255) NOT NULL,
   `nick_name` varchar(255) NOT NULL,
   `note` varchar(255) DEFAULT NULL,
   PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

 */
@Entity
@Table( name = "contributor" )
public class Contributor
{
    @Id
    @GeneratedValue
    @Column(name = "id")
    private Long _id;
    @Column(name = "version")
    private Long _version;
    @Column(name = "name")
    private String _name;
    @Column(name = "nick_name")
    private String _nickName;
    @Column(name = "note")
    private String _note;


    public Long getId()
    {
        return _id;
    }

    public void setId(Long id)
    {
        _id = id;
    }

    public Long getVersion()
    {
        return _version;
    }

    public void setVersion(Long version)
    {
        _version = version;
    }

    public String getName()
    {
        return _name;
    }

    public void setName(String name)
    {
        _name = name;
    }

    public String getNickName()
    {
        return _nickName;
    }

    public void setNickName(String nickName)
    {
        _nickName = nickName;
    }

    public String getNote()
    {
        return _note;
    }

    public void setNote(String note)
    {
        _note = note;
    }
}
