var gLesson =

{
  "id" : 661623184,
  "name" : "jsonizeMyLesson-lesson",
  "sentences" : [ {
    "concept" : "jsonizeMyLesson-A-concept",
    "guid" : "jsonizeMyLesson-A-senGuid",
    "phrases" : [ {
      "guid" : "jsonizeMyLesson-A-phraseGuid-w1-w2",
      "sound" : "media/jsonizeMyLesson-A-phraseSound-w1-w2.mp3",
      "wordCount" : 2
    }, {
      "guid" : "jsonizeMyLesson-A-phraseGuid-w3",
      "sound" : "media/jsonizeMyLesson-A-phraseSound-w3.mp3",
      "wordCount" : 1
    } ],
    "sound" : "media/jsonizeMyLesson-A-senSound.mp3",
    "words" : [ {
      "concept" : "jsonizeMyLesson-A-concept-0",
      "guid" : "jsonizeMyLesson-A-wordGuid-0",
      "phonetic" : "jsonizeMyLesson-A-phonetic-0",
      "sound" : "media/jsonizeMyLesson-A-wordSound-0.mp3",
      "thai" : "jsonizeMyLesson-A-thai-0"
    }, {
      "concept" : "jsonizeMyLesson-A-concept-1",
      "guid" : "jsonizeMyLesson-A-wordGuid-1",
      "phonetic" : "jsonizeMyLesson-A-phonetic-1",
      "sound" : "media/jsonizeMyLesson-A-wordSound-1.mp3",
      "thai" : "jsonizeMyLesson-A-thai-1"
    }, {
      "concept" : "jsonizeMyLesson-A-concept-2",
      "guid" : "jsonizeMyLesson-A-wordGuid-2",
      "phonetic" : "jsonizeMyLesson-A-phonetic-2",
      "sound" : "media/jsonizeMyLesson-A-wordSound-2.mp3",
      "thai" : "jsonizeMyLesson-A-thai-2"
    } ]
  }, {
    "concept" : "jsonizeMyLesson-B-concept",
    "guid" : "jsonizeMyLesson-B-senGuid",
    "phrases" : [ {
      "guid" : "jsonizeMyLesson-B-phraseGuid-w1-w2",
      "sound" : "media/jsonizeMyLesson-B-phraseSound-w1-w2.mp3",
      "wordCount" : 2
    }, {
      "guid" : "jsonizeMyLesson-B-phraseGuid-w3",
      "sound" : "media/jsonizeMyLesson-B-phraseSound-w3.mp3",
      "wordCount" : 1
    } ],
    "sound" : "media/jsonizeMyLesson-B-senSound.mp3",
    "words" : [ {
      "concept" : "jsonizeMyLesson-B-concept-0",
      "guid" : "jsonizeMyLesson-B-wordGuid-0",
      "phonetic" : "jsonizeMyLesson-B-phonetic-0",
      "sound" : "media/jsonizeMyLesson-B-wordSound-0.mp3",
      "thai" : "jsonizeMyLesson-B-thai-0"
    }, {
      "concept" : "jsonizeMyLesson-B-concept-1",
      "guid" : "jsonizeMyLesson-B-wordGuid-1",
      "phonetic" : "jsonizeMyLesson-B-phonetic-1",
      "sound" : "media/jsonizeMyLesson-B-wordSound-1.mp3",
      "thai" : "jsonizeMyLesson-B-thai-1"
    }, {
      "concept" : "jsonizeMyLesson-B-concept-2",
      "guid" : "jsonizeMyLesson-B-wordGuid-2",
      "phonetic" : "jsonizeMyLesson-B-phonetic-2",
      "sound" : "media/jsonizeMyLesson-B-wordSound-2.mp3",
      "thai" : "jsonizeMyLesson-B-thai-2"
    } ]
  } ]
}

;