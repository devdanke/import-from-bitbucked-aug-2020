package com.menlospark.dialog.webgen.vocab;

/**
 * *************************************************************************************
 *
 * @Since 1/15/12
 * <p/>
 * *************************************************************************************
 */
public enum ConceptType
{
    LETTER(false,true),
    DIGIT(false,true),

    //just need this to distinguish between two words with same spelling but different meaning.
    NOUN(true,false),
    PRONOUN(true,false),
    VERB(true,false),
    ADJECTIVE(true,false),
    ADVERB(true,false),
    WORD(true,false), //some kind of word that is not a type i care about, such as particle

    PHRASE
    ;


    private final boolean _isWord;
    private final boolean _isChar;

    private ConceptType(boolean isWord, boolean isChar)
    {
        _isWord = isWord;
        _isChar = isChar;
    }

    private ConceptType()
    {
        this(false,false);
    }

    public boolean isWord()
    {
        return _isWord;
    }

    public boolean isChar()
    {
        return _isChar;
    }

    public boolean isPhrase()
    {
        return !(_isWord && _isChar);
    }
}
