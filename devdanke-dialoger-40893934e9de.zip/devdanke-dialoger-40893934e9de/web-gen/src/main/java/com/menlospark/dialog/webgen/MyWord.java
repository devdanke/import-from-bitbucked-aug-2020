package com.menlospark.dialog.webgen;

import static java.lang.String.format;


/**
 * *************************************************************************************
 *
 * @Since 12/1/11
 * <p/>
 * *************************************************************************************
 */
public class MyWord
{
    private String _guid;
    private String _concept;
    private String _thai;
    private String _phonetic;
    private String _baseSoundFileName;


    public MyWord( String guid, String concept, String thai, String phonetic, String baseSoundFileName)
    {
        _guid = guid;


        _concept = concept;
        if(_concept.contains(";"))
        {
            _concept = concept.split(";")[0].trim();
        }

        _thai = thai;
        _phonetic = phonetic;
        _baseSoundFileName = baseSoundFileName;
    }


    public String getGuid()
    {
        return _guid;
    }

    public String getConcept()
    {
        return _concept;
    }

    public String getThai()
    {
        return _thai;
    }

    public String getPhonetic()
    {
        return _phonetic;
    }

    public String getBaseSoundFileName()
    {
        return _baseSoundFileName;
    }

}
