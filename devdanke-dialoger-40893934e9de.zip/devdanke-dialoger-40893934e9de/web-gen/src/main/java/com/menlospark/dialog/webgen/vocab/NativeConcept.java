package com.menlospark.dialog.webgen.vocab;

import java.util.Locale;

/**
 * *************************************************************************************
 *
 * @Since 1/13/12
 * <p/>
 * *************************************************************************************
 */
public class NativeConcept
    extends FormalConcept
{
    public static final Locale LOCALE_TH = new Locale("th");

    private String _soundRelUrl;
    private Locale _locale;
    private String _phonetic;
    private Long _parentGuid;


    public NativeConcept(String nativeScript, String phonetic,
        String soundRelUrl, Locale locale)
    {
        super(nativeScript, null, null);
        
        _locale = locale;
        _soundRelUrl = soundRelUrl;
        _phonetic = phonetic;
    }

    public NativeConcept(){ }//for jackson


    public String getSoundRelUrl()
    {
        return _soundRelUrl;
    }

    public void setSoundRelUrl(String soundRelUrl)
    {
        _soundRelUrl = soundRelUrl;
    }

    public Locale getLocale()
    {
        return _locale;
    }

    public void setLocale(Locale locale)
    {
        _locale = locale;
    }

    public String getPhonetic()
    {
        return _phonetic;
    }

    public void setPhonetic(String phonetic)
    {
        _phonetic = phonetic;
    }

    public Long getParentGuid()
    {
        return _parentGuid;
    }

    public void setParentGuid(Long parentGuid)
    {
        _parentGuid = parentGuid;
    }
}
