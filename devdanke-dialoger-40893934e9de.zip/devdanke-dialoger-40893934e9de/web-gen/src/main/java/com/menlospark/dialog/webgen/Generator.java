package com.menlospark.dialog.webgen;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.menlospark.dialog.db.mybatis.MyBatDao;
import com.menlospark.dialog.generated.mybatis.model.Sentence;
import com.menlospark.dialog.generated.mybatis.model.SentenceLesson;
import com.menlospark.dialog.generated.mybatis.model.Word;
import com.menlospark.dialog.model.*;
import com.menlospark.dialog.webgen.vocab.VocabDao;
import com.menlospark.dialog.webgen.vocab.VocabLesson;
import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;
import org.apache.commons.lang3.CharEncoding;


import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.PrintWriter;

import java.text.SimpleDateFormat;
import java.util.*;

import static com.menlospark.util.MyAssert.*;
import static java.lang.String.format;

/**
 * *************************************************************************************
 *
 * @Since 12/13/11
 * <p/>
 * *************************************************************************************
 */
public class Generator
{
    private Logger _log = LoggerFactory.getLogger(Generator.class);



    /**
     * conf for generate time (not runtime)
     */
    public static final String DEFAULT_FM_TMPL_DIR = "./src/main/freemarker";
    public static final String DEFAULT_DB_CONF_FILE = "mybatis-runtime-conf-dialoger-prod-db.xml";


    private static final String FM_LIST_TMPL = "lessons.html.fmt";
    private static final String FM_INFO_TMPL = "info.html.fmt";
    private static final String FM_LESSON_DIALOG_TMPL = "lesson-dialog.html.fmt";
    private static final String FM_LESSON_VOCAB_TMPL = "lesson-vocab-browse.html.fmt";

    private static final String FM_PARAM_CREATED = "createDate";
    private static final String FM_PARAM_TARG_ENV = "targEnv";
    private static final String FM_PARAM_HEADERS_BY_LSN_TYPE_MAP =  "lsnHeadersByLsnTypeMap";

    
    private static final String FM_PARAM_MY_LESSON = "myLsn";
    private static final String FM_PARAM_VOCAB_LESSON = "vocLsn";
    private static final String FM_PARAM_SOUND_ROOT = "baseSoundRoot";
    private static final String FM_PARAM_BASE_MEDIA_URL = "baseMediaUrl";

    private static final String FM_PARAM_JS_LIBS = "jsLibs";
    private static final String FM_PARAM_CSS_FILES = "cssFiles";
    private static final String FM_PARAM_LESSON_FILE_FINAL_NAME = "lesson-TYPE-GUID.html";


    private File _outDir;
    private Configuration _fmConf;
    private MyBatDao _dao;
    private String _targEnv;//name of target run-time environment for app info dialog


    private final String _baseSoundDirOrUrl;
    
    private final Set<String> _jsLibs = Sets.newTreeSet();//avoids dupes, but maintains input order
    private final Set<String> _cssFiles = Sets.newTreeSet();

    private final VocabDao _vocabDao;





    /**
     * @param outputDirPath root dir where generated output is written.  if the directory doesn't
     *                      exist, it is created.
     */
   // public Generator(String outputDirPath, String mybatisDbConf, String fmTemplateDirPath,
    public Generator(String targEnv, String outputDirPath, String baseSoundDirOrUrl,
        Collection<String> jsLibs, Collection<String> cssFiles)
    {
        notNullOrEmpty("jsLibs",jsLibs);
        _jsLibs.addAll(jsLibs);

        notNullOrEmpty("cssFiles", cssFiles);
        _cssFiles.addAll(cssFiles);

        notNullOrEmpty("targEnv", targEnv);
        _targEnv = targEnv;

        notNullOrEmpty("outputDirPath", outputDirPath);
        _outDir = new File(outputDirPath);
        if (!_outDir.exists())
        {
            if (!_outDir.mkdirs())
            {
                throw new RuntimeException("unable to create " + outputDirPath);
            }
        }

        //notNullOrEmpty("mybatisDbConf", mybatisDbConf);
        _dao = new MyBatDao(DEFAULT_DB_CONF_FILE);

        //notNullOrEmpty("fmTemplateDirPath", fmTemplateDirPath);
        _fmConf = freeMarkerInit(DEFAULT_FM_TMPL_DIR);

        notNullOrEmpty("baseSoundDirOrUrl", baseSoundDirOrUrl);
        _baseSoundDirOrUrl = baseSoundDirOrUrl;


        //temp until dao has vocab data
        _vocabDao = new VocabDao();

        _log.info("created!");
    }


    public void genLessonsPage(VisibilityType visibility)
    {
        try
        {
            //get lessons from db
            Multimap<LessonType,LessonHeader> lessonHeaders =
                _dao.findLearnableLessonHeadersGroupByType(visibility);
            fixLessonHeaderTitles(lessonHeaders.get(LessonType.DIALOG));
            fixLessonHeaderTitles(lessonHeaders.get(LessonType.GRAMMER));
            
            //convert map with enum keys to string keys
            Map<String,Collection<LessonHeader>> lsnHeadersByStr = Maps.newHashMap();
            for(LessonType lsnType : lessonHeaders.keySet())
            {
                lsnHeadersByStr.put(lsnType.name(), lessonHeaders.get(lsnType));
            }
            lsnHeadersByStr.put("Vocab", _vocabDao.getHeaders());


            //create data model for fm
            Map<String, Object> pageModel = Maps.newHashMap();
            addCommonParams(pageModel);

            pageModel.put(FM_PARAM_HEADERS_BY_LSN_TYPE_MAP, lsnHeadersByStr );

            render(FM_LIST_TMPL, pageModel);
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    public void genInfoPage()
    {
        try
        {
            Map<String, Object> pageModel = Maps.newHashMap();
            addCommonParams(pageModel);

            String dttmStamp = DateTimeFormat.forPattern("d-MMM h:mm a").print(new DateTime());
            pageModel.put(FM_PARAM_CREATED, dttmStamp);
            pageModel.put(FM_PARAM_TARG_ENV, _targEnv);

            render(FM_INFO_TMPL, pageModel);
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    public void genDialogLessonPages(VisibilityType visibility)
    {
        try
        {
            //get lessons from db
            List<UberLesson> uberLessons = _dao.findLearnableUberLessons(visibility);

            //must to before changing titles
            Map<Long,LessonType> lessonTypesByLessonGuid = calcLessonTypes(uberLessons);


            fixUberLessonTitles(uberLessons);

            for(UberLesson ubLsn : uberLessons)
            {
                //create data model for fm
                Map<String, Object> pageModel = Maps.newHashMap();
                addCommonParams(pageModel);
                
                pageModel.put(FM_PARAM_MY_LESSON, convert(ubLsn));
                pageModel.put(FM_PARAM_SOUND_ROOT, _baseSoundDirOrUrl);

                //String outputFileName = FM_LESSON_DIALOG_TMPL.replace("GUID", ubLsn.getLesson().getGuid().toString());
                String outputFileName = makeLessonFileFinalName( ubLsn.getLesson().getGuid(),
                    lessonTypesByLessonGuid.get( ubLsn.getLesson().getGuid()) );
                render(FM_LESSON_DIALOG_TMPL, pageModel, outputFileName);
            }
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }



    public void genVocabLessonBrowsePages()
    {
        try
        {
            //get lessons from db
            List<VocabLesson> lessons = _vocabDao.findLessons();

            for(VocabLesson vocLsn : lessons)
            {
                //create data model for fm
                Map<String, Object> pageModel = Maps.newHashMap();
                addCommonParams(pageModel);

                pageModel.put(FM_PARAM_VOCAB_LESSON, vocLsn);
                pageModel.put(FM_PARAM_BASE_MEDIA_URL, "http://localhost/flashdeck");

                // FM_PARAM_BASE_MEDIA_URL = "baseMediaUrl";
                //String outputFileName = FM_LESSON_VOCAB_TMPL.replace("GUID", lsn.getGuid().toString());
                String outputFileName = makeLessonFileFinalName(
                    vocLsn.getGuid(), vocLsn.getLessonType());
                render(FM_LESSON_VOCAB_TMPL, pageModel, outputFileName);
            }
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    public void genAll(VisibilityType visibility)
    {
        genLessonsPage(visibility);
        genInfoPage();
        genDialogLessonPages(visibility);
        genVocabLessonBrowsePages();
    }



    /////////////////////


    private String makeLessonFileFinalName(Long guid, LessonType lsnType)
    {
        String finalName = FM_PARAM_LESSON_FILE_FINAL_NAME.replace("GUID", guid.toString());
        return finalName.replace("TYPE", lsnType.name());
    }
    private void addCommonParams(Map<String,Object> pageModel)
    {
        pageModel.put(FM_PARAM_JS_LIBS, _jsLibs);
        pageModel.put(FM_PARAM_CSS_FILES, _cssFiles);
    }


    private void fixLessonHeaderTitles(Collection<LessonHeader> headers)
    {
        for(LessonHeader header : headers)
        {
            header.setTitle(stripTitleGrammarPrefix(header.getTitle()));
        }
    }


    private void fixUberLessonTitles(List<UberLesson> ubLessons)
    {
        for(UberLesson ubLesson : ubLessons)
        {
            SentenceLesson senLsn = ubLesson.getLesson();
            senLsn.setTitle( stripTitleGrammarPrefix(senLsn.getTitle()) );
        }
    }

    private Map<Long,LessonType> calcLessonTypes(List<UberLesson> uberLessons)
    {
        Map<Long,LessonType> dialogLessonTypesByGuid = Maps.newHashMap();
        for(UberLesson ulsn : uberLessons)
        {
            LessonType type = LessonType.DIALOG;
            if(ulsn.getLesson().getTitle().toLowerCase().trim().startsWith("grammar-"))
            {
                type=LessonType.GRAMMER;
            }

            dialogLessonTypesByGuid.put(ulsn.getLesson().getGuid(), type);
        }
        return dialogLessonTypesByGuid;
    }

    private String stripTitleGrammarPrefix(String lessonTitle)
    {
        String result = lessonTitle;

        String targStr = "grammar-";
        int targLen = targStr.length();
        if(lessonTitle.toLowerCase().startsWith(targStr))
        {
            result = lessonTitle.substring(targLen);
        }
        return result;
    }


    private MyLesson convert(UberLesson uberLesson)
    {
        List<MySentence> mySentences = Lists.newArrayList();

        SentenceLesson senLsn = uberLesson.getLesson();

        for(UberSentence ubSen : uberLesson.getUberSentences())
        {
            mySentences.add( convert(ubSen, senLsn.getGuid(), ubSen.getSpeaker().getNickName()) );
        }

        return new MyLesson(senLsn.getTitle(), senLsn.getGuid(), mySentences);
    }

    
    private MySentence convert(UberSentence ubSen, Long lessonGuid, String speakerNickName)
    {
        Sentence sen = ubSen.getSentence();

        String senBaseSoundName = makeSentenceBaseSoundFileName(
            ubSen.getSpeaker().getNickName(), ubSen.getSoundSession().getDate(),
            lessonGuid, sen.getGuid() );

        List<MyWord> myWords = Lists.newArrayList();
        for(Word word : ubSen.getWords())
        {
            MyWord myWord = new MyWord(
                word.getGuid().toString(),
                word.getEnglish(),
                word.getThai(),
                word.getPhonetic(),
                makeWordBaseSoundFileName(speakerNickName,word.getGuid()) );
            myWords.add(myWord);
        }

        return new MySentence(
            sen.getGuid().toString(),
            sen.getEnglish(),
            senBaseSoundName,
            myWords,
            null);
    }


    private String makeSentenceBaseSoundFileName(String speakerNickName, Date soundSessionDate,
        Long lessonGuid, Long senGuid)
    {
        return format("%s_%s_%s_s_%s", speakerNickName, toYYMMDD(soundSessionDate), lessonGuid, senGuid);
    }


    private String makeWordBaseSoundFileName(String speakerNickName, Long wordGuid)
    {
        return format("%s_w_%s", speakerNickName, wordGuid);
    }


    private String toYYMMDD(Date date)
    {
        SimpleDateFormat YYYYMMDD = new SimpleDateFormat("yyyyMMdd", Locale.US);
        return YYYYMMDD.format(date);
    }


    /*
    Used just once when class is created.
     */
    private Configuration freeMarkerInit(String fmTemplateDirPath)
    {
        try
        {
            Configuration cfg = new Configuration();

            cfg.setNumberFormat("0.######");
            cfg.setDirectoryForTemplateLoading(new File(fmTemplateDirPath));
            cfg.setObjectWrapper(new DefaultObjectWrapper());
            cfg.setDefaultEncoding(CharEncoding.UTF_8);

            return cfg;
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    /**
     * Where the rubber meets the road.
     * By default, the fmt (freemarker template file extension is removed.)
     * 
     * @param fileSuffix insert into file name just before ".html"
     */
    private void render(String templateName, Map<String, Object> model, String outFileName)
    {
        try
        {
            Template template = _fmConf.getTemplate(templateName);

            if(outFileName == null)
            {
                outFileName = templateName;
            }
            outFileName = outFileName.replace(".fmt","");

            PrintWriter writer = new PrintWriter(new File(_outDir, outFileName));
            template.process(model, writer);
            
            writer.flush();
            writer.close();
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    
    private void render(String templateName, Map<String, Object> model)
    {
        render(templateName, model, null);
    }


}
