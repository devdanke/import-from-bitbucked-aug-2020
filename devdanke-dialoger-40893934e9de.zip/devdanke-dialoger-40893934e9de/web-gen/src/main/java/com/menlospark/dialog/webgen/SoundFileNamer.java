package com.menlospark.dialog.webgen;

import com.menlospark.dialog.generated.mybatis.model.*;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

import static java.lang.String.format;

/**
 * *************************************************************************************
 *
 * @Since 12/23/11
 * <p/>
 * *************************************************************************************
 */
public class SoundFileNamer
{
    private static final String ME = "snu.";

    private String _baseSoundDirOrUrl;
    private Long _lessonGuid;

    public SoundFileNamer(String baseSoundDirOrUrl, Long lessonGuid)
    {
        String me = ME + "ctor():";

        log("%s baseSoundDirOrUrl=%s", me, baseSoundDirOrUrl);
        log("%s lessonGuid=%s", me, lessonGuid);

        _lessonGuid = lessonGuid;
        _baseSoundDirOrUrl = baseSoundDirOrUrl;
    }



    /*
   The following genSoundName() methods create names with the object's guid(s) and the name(s) of
   any words it contains.  These are meant to be human readable.  They're used in two places:
   1) As the sound name used by SoundManager2 in the bar.Sentence Learner web page
   2) As the dummy sound wav file created in the web-app temp dir. These files make sound parsing
      easier.

   NOTE: As part of the workflow to move sounds to their final destination web dir, they'll be
   stripped of the human readable helper words.  Pretty much only guids will remain.  They're more
   stable than the human helper words.
    */
    public String genSoundName(Word w)
    {
        return format("w_%s_%s", FileNamer.toFileSafeName(w.getEnglish()), w.getGuid());
    }

    public  String genSoundName(Reply r)
    {
        return format("r_%s_%s", FileNamer.toFileSafeName(r.getEnglish()), r.getGuid() );
    }

    public  String genSoundName(Sentence s)
    {
        return format("s_%s_%s", FileNamer.toFileSafeName(s.getEnglish()), s.getGuid());
    }

    public  String genSoundName(List<Word> words)
    {
        if (words.size() == 1)
        {
            return genSoundName(words.get(0));
        }
        else
        {
            String namePart = FileNamer.toFileSafeName(FileNamer.toEnglishStr(words));
            String guidPart = FileNamer.toFileSafeName(FileNamer.toGuidStr(words));
            return format("p_%s_%s", namePart, guidPart);
        }
    }

    /*
   The following genSoundFilePath() methods are used to generate the actual mp3 sound file name,
   relative to the web app root.  The name of each file must be the same as the file name created
   by the .../mybin/lameWav2mp3.rb script.

   These file names don't include the actual word english, unlike the genSoundName() versions.
   Instead, they use only the object guids.  The protects against brittleness when the english
   in a word or sentence changes, it won't break the sound file name.

   The generated file name format is:
    parentDir/hyphenSeparatedGuid(s).mp3
    */

    public String genSoundFilePath(Reply r, SoundSession ses, Contributor speaker)
    {
        return format("%s_r_%s.mp3", genSoundFilePathBase(ses, speaker), r.getGuid());
    }


    public String genSoundFilePath(Sentence sen, SoundSession soundSession, Contributor speaker)
    {
        return format("%s_s_%s.mp3", genSoundFilePathBase(soundSession, speaker), sen.getGuid());
    }

    /*
   Differs slightly from similar named methods above.  File path base name only includes
   sound dir and speaker name.  It doesn't include session date or lesson guid.
    */
    public String genSoundFilePath(Word w, Contributor speaker)
    {
        return format("%s/%s_w_%s.mp3", _baseSoundDirOrUrl, speaker.getNickName(), w.getGuid() );
    }

    /*
     NOTE: if the phrase has only 1 word, then treat it like a word.
    */
    public String genSoundFilePath(List<Word> phraseWordList, SoundSession session, Contributor speaker)
    {
        if (phraseWordList.size() == 1)
        {
            return genSoundFilePath(phraseWordList.get(0), speaker);
        }
        else
        {
            return format("%s_p_%s.mp3", genSoundFilePathBase(session, speaker),
                FileNamer.toGuidStr(phraseWordList) );
        }
    }

    private String genSoundFilePathBase(SoundSession session, Contributor speaker)
    {
        //NOTE: all data from session must already be a file safe name.
        return format("%s/%s_%s_%s", _baseSoundDirOrUrl, speaker.getNickName(),
            genYmdStr(session.getDate()), _lessonGuid);
    }


    /*
    For recordGuide
     */
    public SortedMap sortPhrasesByEnglish(List<List<Word>> wordLists)
    {
        SortedMap smap = new TreeMap();

        for(List<Word> wordList : wordLists)
        {
            smap.put(FileNamer.toEnglishStr(wordList), FileNamer.toThaiStr(wordList));
        }

        return smap;
    }


    /*
    Given a list of words, remove from the list any word already in webapp's sound dir.

    For recordGuide
     */
    public Collection<Word> filterOutRecordedWords(Collection<Word> words,
        Contributor speaker)
    {
        if(words == null)
        {
            return null;
        }

        List<Word> targetWords = new ArrayList<Word>();

        for(Word word : words)
        {
            String soundFilePath = genSoundFilePath(word, speaker);

            File soundFile = new File(soundFilePath);

            if(soundFile.exists())
            {
                targetWords.add(word);
            }
        }

        if (!targetWords.isEmpty())
        {
            words.removeAll(targetWords);
        }

        return words;
    }


////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * TODO: use joda
     * 
     * @param date
     * @return
     */
    private String genYmdStr(Date date)
    {
        //specify us locale because macosx sometimes inexplicibly use thai calendard, ie 2555.
        SimpleDateFormat YYYYMMDD = new SimpleDateFormat("yyyyMMdd", Locale.US);
        return YYYYMMDD.format(date);
    }




////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////


    protected final void log(String msg, Object... args)
    {
        System.out.printf(msg, args);
        System.out.println();
    }


}
