package com.menlospark.dialog.webgen;

import com.google.common.collect.Lists;

import static com.menlospark.util.MyAssert.*;

import java.util.List;

/**
 * *************************************************************************************
 * This class is used in creating student UI for dialog.
 * <p/>
 * Only learnable lessons.
 * Only learnable sentences
 *
 * @Since 12/1/11
 *
 * *************************************************************************************
 */
public class MyLesson
{
    private String _title;
    private long _guid;
    private List<MySentence> _sentences = Lists.newArrayList();

    public MyLesson(String title, Long guid, List<MySentence> sentences)
    {
        notNull("title", title);
        notNull("guid",guid);
        notNullOrEmpty("sentences",sentences);

        _title = title;
        _guid = guid;
        _sentences.addAll(sentences);
    }


    public String getTitle()
    {
        return _title;
    }


    public long getGuid()
    {
        return _guid;
    }

    
    public List<MySentence> getSentences()
    {
        return _sentences;
    }
}
