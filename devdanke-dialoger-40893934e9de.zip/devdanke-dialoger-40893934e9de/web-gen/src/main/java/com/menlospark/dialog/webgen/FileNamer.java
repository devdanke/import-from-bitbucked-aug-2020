package com.menlospark.dialog.webgen;

import com.menlospark.dialog.generated.mybatis.model.Word;

import java.util.List;

/**
 * *************************************************************************************
 *
 * @Since 12/23/11
 * <p/>
 * *************************************************************************************
 */
class FileNamer
{

    public static String toGuidStr(List<Word> words)
    {
        StringBuilder sb = new StringBuilder();
        for(int i=0; i<words.size(); i++)
        {
            if (i != 0) sb.append("-");
            sb.append(words.get(i).getGuid());
        }
        return sb.toString();
    }

    public static String toEnglishStr(List<Word> words)
    {
        StringBuilder sb = new StringBuilder();
        for(Word word : words)
        {
            sb.append(word.getEnglish()).append(" ");
        }
        return sb.toString().trim();
    }

    public static String toThaiStr(List<Word> words)
    {
        StringBuilder sb = new StringBuilder();
        for(Word word : words)
        {
            sb.append(word.getThai()).append(" ");
        }
        return sb.toString().trim();
    }


    //remove excessive white space
    //replace any non alphanumeric with a hyphen
    //to lower case
    public static String toFileSafeName(String s)
    {
        if (s == null || s.trim().isEmpty())
        {
            throw new RuntimeException("input str null or empty. " +
                "happens when any of sen title, sen eng, word eng, reply eng are empty.");
        }

        s = s.trim();
        s = s.replaceAll("  ", "-");
        s = s.toLowerCase();
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray())
        {
            if (Character.isLetterOrDigit(ch) || ch == '-')
            {
                sb.append(ch);
            }
            else if (ch == '\'')
            {
                //don't replace apostrophy with anything. this makes result str easier to read
                sb.append("");
            }
            else
            {
                sb.append("-");
            }
        }

        //trim leading and trailing hyphens
        while (sb.charAt(0) == '-')
        {
            sb.deleteCharAt(0);
        }
        while (sb.charAt(sb.length() - 1) == '-')
        {
            sb.deleteCharAt(sb.length() - 1);
        }

        //remove multiple hyphens with single
        //TODO: there are probably nice regex's to do all these hyphen control operations.
        String s2 = sb.toString();
        s2 = s2.replaceAll("---", "-");
        s2 = s2.replaceAll("--", "-");

        return s2;
    }

}
