package com.menlospark.dialog.webgen.vocab;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.menlospark.dialog.model.LessonHeader;
import com.menlospark.dialog.model.LessonState;
import com.menlospark.dialog.model.LessonType;
import com.menlospark.dialog.webgen.Json;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.List;
import java.util.Map;

/**
 * *************************************************************************************
 *
 * @Since 1/13/12
 * <p/>
 * *************************************************************************************
 */
public class VocabDao
{
    private Logger _log = LoggerFactory.getLogger(VocabDao.class);

    public static final String baseVocabJsonDir = "src/test/data/vocab";
    public static final String FORMAL_CONCEPT_JSON_PATH = baseVocabJsonDir+"/formal_concept.json";
    public static final String NAVTIVE_CONCEPT_JSON_PATH = baseVocabJsonDir+"/native_concept.json";
    public static final String VOCAB_LESSON_JSON_PATH = baseVocabJsonDir+"/vocab_lesson.json";

    
    //temp fake data for testing
    private List<VocabLesson> _lessons;


    public VocabDao()
    {
         _lessons = loadLessons();
    }


    public List<LessonHeader> getHeaders()
    {
        List<LessonHeader> vocabHeaders = Lists.newArrayList();
        for(VocabLesson lsn : _lessons)
        {
            vocabHeaders.add( makeHeader(lsn) );
        }

        return vocabHeaders;
    }


    public List<VocabLesson> findLessons()
    {
        return _lessons;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////


    private LessonHeader makeHeader(VocabLesson vocLsn)
    {
        return new LessonHeader( vocLsn.getTitle(), vocLsn.getGuid(), vocLsn.getId(),
            vocLsn.getLessonType(), vocLsn.getLessonState() );
    }


    private List<VocabLesson> loadLessons()
        throws RuntimeException
    {
        try
        {
            //create objects from json files
            ObjectMapper json = Json.getMapper();

            //load all concepts & lessons
            List<FormalConcept> formalConcepts = json.readValue(
                new File(FORMAL_CONCEPT_JSON_PATH),
                new TypeReference<List<FormalConcept>>() { });
            Map<Long,FormalConcept> formalConceptsByGuid = indexByGuid(formalConcepts);

            List<NativeConcept> nativeConcepts =  json.readValue(
                new File(NAVTIVE_CONCEPT_JSON_PATH),
                new TypeReference<List<NativeConcept>>() { });

            Map<Long,NativeConcept> nativeConceptsByGuid = indexByGuid(nativeConcepts);

            List<VocabLesson> vocabLessons = json.readValue(
                new File(VOCAB_LESSON_JSON_PATH),
                new TypeReference<List<VocabLesson>>() { });


            //fully populate conceptMaps inside each vocLesson
            for(VocabLesson vocLsn : vocabLessons)
            {
                for(ConceptMap cmap : vocLsn.getConceptMaps())
                {

                    FormalConcept fCon = formalConceptsByGuid.get(cmap.getFormalConceptGuid());
                    cmap.setFormalConcept( fCon );
                    assertValidCmap(vocLsn.getTitle(),"formal",cmap.getFormalConcept().getGuid(),fCon);

                    NativeConcept sCon = nativeConceptsByGuid.get(cmap.getSrcConceptGuid());
                    cmap.setSrcConcept(sCon);
                    assertValidCmap(vocLsn.getTitle(),"src",cmap.getSrcConcept().getGuid(),sCon);

                    NativeConcept dCon = nativeConceptsByGuid.get( cmap.getDstConceptGuid() );
                    cmap.setDstConcept(dCon);
                    assertValidCmap(vocLsn.getTitle(),"dst",cmap.getDstConcept().getGuid(),dCon);
                }
            }
            return vocabLessons;
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    
    /**
     * return map of conceptMaps.  key is FormalConcept.name
     *
     * @return
     * @throws Exception
     */
    //pkg private for testing temp testing scenario. 19-jan-2012
    Map<String,ConceptMap> getConceptMaps()
        throws Exception
    {
        Map<String,ConceptMap> thCmapsByFname = Maps.newHashMap();
        for(VocabLesson vocLsn : _lessons)
        {
            List<ConceptMap> cmaps = vocLsn.getConceptMaps();
            if(cmaps.get(0).getDstConcept().getLocale().equals(NativeConcept.LOCALE_TH))
            {
                for(ConceptMap cmap : cmaps)
                {
                    String formalName = cmap.getFormalConcept().getName();
                    if(!thCmapsByFname.containsKey(formalName))
                    {
                        thCmapsByFname.put(formalName,cmap);
                    }
                    else
                    {
                        _log.warn("duplicate key in thCmapsByFname={}. Will IGNORE!", formalName );
                    }
                }
            }
        }
        return thCmapsByFname;
    }


    private void assertValidCmap(String lsnName, String cType, Long guid, Object xConcept)
    {
        if(guid == null)
        {
            _log.error("Lsn: '{}' has null {} conept guid", new Object[]{lsnName,cType});
        }

        if(xConcept == null)
        {
            _log.error("Lsn: '{}' has null {} conept for guid={}", new Object[]{lsnName,cType, guid});
        }
    }

    private <T extends FormalConcept> Map<Long,T> indexByGuid(List<T> list)
    {
        Map<Long,T> map = Maps.newHashMap();

        for(T concept : list)
        {
            map.put(concept.getGuid(),concept);
        }

        return map;
    }
}
