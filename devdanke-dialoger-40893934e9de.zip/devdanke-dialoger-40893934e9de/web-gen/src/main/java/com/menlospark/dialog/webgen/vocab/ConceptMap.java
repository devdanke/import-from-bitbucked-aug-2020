package com.menlospark.dialog.webgen.vocab;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * *************************************************************************************
 * Map one native concept to another, e.g. english to thai.
 *
 *
 * @Since 1/13/12
 * <p/>
 * *************************************************************************************
 */
@JsonIgnoreProperties({ "formalConcept", "srcConcept", "dstConcept" })
public class ConceptMap
{
    private FormalConcept _formalConcept;
    private NativeConcept _srcConcept;
    private NativeConcept _dstConcept;

    private Long _formalConceptGuid;
    private Long _srcConceptGuid;
    private Long _dstConceptGuid;


    public ConceptMap( FormalConcept formalConcept, NativeConcept srcConcept,
        NativeConcept dstConcept)
    {
        setFormalConcept(formalConcept);
        setSrcConcept( srcConcept );
        setDstConcept( dstConcept );
    }

    public ConceptMap(){} //for jackson

    public FormalConcept getFormalConcept()
    {
        return _formalConcept;

    }

    public void setFormalConcept(FormalConcept formalConcept)
    {
        _formalConcept = formalConcept;
        _formalConceptGuid = formalConcept.getGuid();
    }

    public NativeConcept getSrcConcept()
    {
        return _srcConcept;
    }

    public void setSrcConcept(NativeConcept srcConcept)
    {
        _srcConcept = srcConcept;
        _srcConceptGuid = srcConcept.getGuid();
    }

    public NativeConcept getDstConcept()
    {
        return _dstConcept;
    }

    public void setDstConcept(NativeConcept dstConcept)
    {
        _dstConcept = dstConcept;
        _dstConceptGuid = dstConcept.getGuid();
    }


    public Long getFormalConceptGuid()//for jackson
    {
        return _formalConceptGuid;
    }

    public void setFormalConceptGuid(Long formalConceptGuid)//for jackson
    {
        _formalConceptGuid = formalConceptGuid;
    }

    public Long getSrcConceptGuid()//for jackson
    {
        return _srcConceptGuid;
    }

    public void setSrcConceptGuid(Long srcConceptGuid)//for jackson
    {
        _srcConceptGuid = srcConceptGuid;
    }

    public Long getDstConceptGuid()//for jackson
    {
        return _dstConceptGuid;
    }

    public void setDstConceptGuid(Long dstConceptGuid)//for jackson
    {
        _dstConceptGuid = dstConceptGuid;
    }

    @Override
    public String toString()
    {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
