package com.menlospark.dialog.webgen;

/**
 * *************************************************************************************
 *
 * @Since 12/1/11
 * <p/>
 * *************************************************************************************
 */
public class MyPhrase
{
    private String _guid;
    private int _wordCount;
    private String _sound;


    public MyPhrase(String guid, int wordCount, String sound)
    {
        _guid = guid;
        _wordCount = wordCount;
        _sound = sound;
    }

    public String getGuid()
    {
        return _guid;
    }

    public int getWordCount()
    {
        return _wordCount;
    }

    public String getSound()
    {
        return _sound;
    }
}
