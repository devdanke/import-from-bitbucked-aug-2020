package com.menlospark.dialog.webgen.vocab;

import com.google.common.collect.Lists;
import com.menlospark.dialog.model.LessonHeader;
import com.menlospark.dialog.model.LessonState;
import com.menlospark.dialog.model.LessonType;
import com.menlospark.dialog.model.VisibilityType;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import static com.menlospark.util.MyAssert.*;

import java.beans.Visibility;
import java.util.List;

/**
 * *************************************************************************************
 *
 * @Since 1/13/12
 * <p/>
 * *************************************************************************************
 */
public class VocabLesson
{
    private LessonType _lessonType = LessonType.VOCAB;
    private LessonState _lessonState = LessonState.LEARNABLE;
    private VisibilityType _visibility = VisibilityType.PUBLIC;

    private Long _id;
    private Long _guid;
    private String _title;
    private MappingType _mappingType;
    private String _descrip;
    private String _publicNotes;
    private String _privateNotes;

    private List<ConceptMap> _conceptMaps = Lists.newArrayList();

    public VocabLesson(String title, MappingType mappingType, List<ConceptMap> conceptMaps)
    {
        _title = title;
        if(isNotNullOrEmpty(conceptMaps)) _conceptMaps.addAll(conceptMaps);
        _mappingType = mappingType;
    }

    public VocabLesson(){}//for jackson

    public LessonType getLessonType()
    {
        return _lessonType;
    }

    public void setLessonType(LessonType lessonType)
    {
        _lessonType = lessonType;
    }

    public LessonState getLessonState()
    {
        return _lessonState;
    }

    public void setLessonState(LessonState lessonState)
    {
        _lessonState = lessonState;
    }

    public VisibilityType getVisibility()
    {
        return _visibility;
    }

    public void setVisibility(VisibilityType visibility)
    {
        _visibility = visibility;
    }

    public Long getId()
    {
        return _id;
    }

    public void setId(Long id)
    {
        _id = id;
    }

    public Long getGuid()
    {
        return _guid;
    }

    public void setGuid(Long guid)
    {
        _guid = guid;
    }

    public String getTitle()
    {
        return _title;
    }

    public void setTitle(String title)
    {
        _title = title;
    }

    public MappingType getMappingType()
    {
        return _mappingType;
    }

    public void setMappingType(MappingType mappingType)
    {
        _mappingType = mappingType;
    }

    public String getDescrip()
    {
        return _descrip;
    }

    public void setDescrip(String descrip)
    {
        _descrip = descrip;
    }

    public String getPublicNotes()
    {
        return _publicNotes;
    }

    public void setPublicNotes(String publicNotes)
    {
        _publicNotes = publicNotes;
    }

    public String getPrivateNotes()
    {
        return _privateNotes;
    }

    public void setPrivateNotes(String privateNotes)
    {
        _privateNotes = privateNotes;
    }

    public List<ConceptMap> getConceptMaps()
    {
        return _conceptMaps;
    }

    public void setConceptMaps(List<ConceptMap> conceptMaps)
    {
        _conceptMaps = conceptMaps;
    }


    @Override
    public String toString()
    {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
