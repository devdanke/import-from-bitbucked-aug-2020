package com.menlospark.dialog.webgen;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;

import java.io.File;
import java.io.StringWriter;

/**
 * *************************************************************************************
 *
 * @Since 12/13/11
 * <p/>
 * *************************************************************************************
 */
public class Json
{
    private static final ObjectMapper MAPPER = new ObjectMapper();
    static
    {
        MAPPER.configure( SerializationConfig.Feature.INDENT_OUTPUT, true );
        MAPPER.configure( SerializationConfig.Feature.SORT_PROPERTIES_ALPHABETICALLY, true );
    }

    
    public static String ize(Object obj)
    {
        try
        {
            StringWriter writer = new StringWriter();

            MAPPER.writeValue(writer, obj);

            return writer.toString();

        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    /**
     */
    public static void store(Object obj, String filePath)
    {
        try
        {
            MAPPER.writeValue(new File(filePath), obj);
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    public static ObjectMapper getMapper()
    {
        return MAPPER;
    }



}
