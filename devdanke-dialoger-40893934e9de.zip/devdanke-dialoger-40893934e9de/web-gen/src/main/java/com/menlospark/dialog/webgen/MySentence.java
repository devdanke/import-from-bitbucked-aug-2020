package com.menlospark.dialog.webgen;

import com.google.common.collect.Lists;

import java.util.List;
import static com.menlospark.util.MyAssert.*;

/**
 * *************************************************************************************
 *
 * @Since 12/1/11
 * <p/>
 * *************************************************************************************
 */
public class MySentence
{
    private String _guid;
    private String _concept;
    private String _baseSoundFileName;
    private List<MyWord> _words = Lists.newArrayList();
    private List<MyPhrase> _phrases = Lists.newArrayList();

    
    public MySentence( String guid, String concept, String baseSoundFileName,
        List<MyWord> words, List<MyPhrase> phrases)
    {
         _guid = guid;
         _concept = concept;
         _baseSoundFileName = baseSoundFileName;
         if(isNotNullOrEmpty(words))_words.addAll(words);
         if(isNotNullOrEmpty(phrases))_phrases.addAll(phrases);
    }

    public String getGuid()
    {
        return _guid;
    }

    public String getConcept()
    {
        return _concept;
    }

    public String getBaseSoundFileName()
    {
        return _baseSoundFileName;
    }

    public List<MyWord> getWords()
    {
        return _words;
    }

    public int getWordCount()
    {
        return _words.size();
    }

    public List<MyPhrase> getPhrases()
    {
        return _phrases;
    }
}
