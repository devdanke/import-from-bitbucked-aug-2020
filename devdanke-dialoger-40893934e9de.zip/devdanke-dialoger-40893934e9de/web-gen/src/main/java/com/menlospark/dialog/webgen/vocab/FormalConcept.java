package com.menlospark.dialog.webgen.vocab;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * *************************************************************************************
 *
 * @Since 1/13/12
 * <p/>
 * *************************************************************************************
 */
public class FormalConcept
{
    private Long _guid;
    private String _name;
    private String _descrip;
    private String _picRelUrl;

    public FormalConcept(){}//for jackson

    public FormalConcept(String name, String descrip, String picRelUrl)
    {
        _name = name;
        _descrip = descrip;
        _picRelUrl = picRelUrl;
    }

    public FormalConcept(String name, String picRelUrl)
    {
        this(name,null,picRelUrl);
    }


    public Long getGuid()
    {
        return _guid;
    }

    public void setGuid(Long guid)
    {
        _guid = guid;
    }

    public String getName()
    {
        return _name;
    }

    public void setName(String name)
    {
        _name = name;
    }

    public String getDescrip()
    {
        return _descrip;
    }

    public void setDescrip(String descrip)
    {
        _descrip = descrip;
    }

    public String getPicRelUrl()
    {
        return _picRelUrl;
    }

    public void setPicRelUrl(String picRelUrl)
    {
        _picRelUrl = picRelUrl;
    }

    @Override
    public String toString()
    {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
