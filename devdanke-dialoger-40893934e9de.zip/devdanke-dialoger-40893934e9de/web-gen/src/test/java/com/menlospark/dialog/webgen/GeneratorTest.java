package com.menlospark.dialog.webgen;

import com.google.common.collect.Lists;
import com.menlospark.dialog.model.VisibilityType;
import org.junit.Test;

import java.util.List;


/**
 * *************************************************************************************
 *
 * *************************************************************************************
 */
public class GeneratorTest
{
    @Test
    public void genForLocalDev()
    {
        List<String> jsLibs = Lists.newArrayList(
            "../js/jquery-1.6.4.min.js",
            "../js/jquery.mobile-1.0.min.js"
        );
        jsLibs.add("../js/scroll/jquery.easing.1.3.js");
        jsLibs.add("../js/scroll/jquery.mobile.scrollview.js");
        jsLibs.add("../js/scroll/scrollview.js");

        List<String> cssFiles = Lists.newArrayList(
            "../js/jquery.mobile-1.0.min.css"
        );
        cssFiles.add("../js/scroll/jquery.mobile.scrollview.css");


        Generator generator = new Generator(
            "Local FS",
            "./target/gen-local-fs/html",
            "http://localhost/dialog-sound",
            jsLibs, cssFiles);

        generator.genAll(VisibilityType.ALL);
        //generator.genLessonsPage();
        //generator.genInfoPage();
        //generator.genDialogLessonPages();
        //generator.genVocabLessonBrowsePages();
    }


    @Test
    public void genForLocalApache()
    {
        List<String> jsLibs = Lists.newArrayList(
            "../js/jquery-1.6.4.min.js",
            "../js/jquery.mobile-1.0.min.js"
        );
        jsLibs.add("../js/scroll/jquery.easing.1.3.js");
        jsLibs.add("../js/scroll/jquery.mobile.scrollview.js");
        jsLibs.add("../js/scroll/scrollview.js");

        List<String> cssFiles = Lists.newArrayList(
            "../js/jquery.mobile-1.0.min.css"
        );
        cssFiles.add("../js/scroll/jquery.mobile.scrollview.css");

        Generator generator = new Generator(
            "Local Apache",
            "./target/gen-local-apache/html",
            "http://localhost/dialog-sound",
            jsLibs, cssFiles);

        generator.genAll(VisibilityType.ALL);
    }


    /**
     * gen only public lessons
     */
    @Test
    public void genForDropboxPublic()
    {
        List<String> jsLibs = Lists.newArrayList(
            "http://code.jquery.com/jquery-1.6.4.min.js",
            "http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.js"
        );
        jsLibs.add("../js/scroll/jquery.easing.1.3.js");
        jsLibs.add("../js/scroll/jquery.mobile.scrollview.js");
        jsLibs.add("../js/scroll/scrollview.js");

        List<String> cssFiles = Lists.newArrayList(
            "http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.css"
        );
        cssFiles.add("../js/scroll/jquery.mobile.scrollview.css");

        Generator generator = new Generator(
            "Dropbox Public",
            "./target/gen-remote-dropbox/html",
            "../sound",
            jsLibs, cssFiles);

        generator.genAll(VisibilityType.PUBLIC);
    }

    /**
     * gen all lessons, public and private.
     */
    @Test
    public void genForDropboxAll()
    {
        List<String> jsLibs = Lists.newArrayList(
            "http://code.jquery.com/jquery-1.6.4.min.js",
            "http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.js"
        );
        jsLibs.add("../js/scroll/jquery.easing.1.3.js");
        jsLibs.add("../js/scroll/jquery.mobile.scrollview.js");
        jsLibs.add("../js/scroll/scrollview.js");

        List<String> cssFiles = Lists.newArrayList(
            "http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.css"
        );
        cssFiles.add("../js/scroll/jquery.mobile.scrollview.css");

        Generator generator = new Generator(
            "Dropbox All",
            "./target/gen-remote-dropbox/html-all",
            "../sound",
            jsLibs, cssFiles);

        generator.genAll(VisibilityType.ALL);
    }


}
