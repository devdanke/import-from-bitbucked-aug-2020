package com.menlospark.dialog.webgen;

import com.google.common.collect.Lists;
import com.menlospark.dialog.model.VisibilityType;
import org.junit.Ignore;
import org.junit.Test;

import java.text.BreakIterator;
import java.util.List;


/**
 * *************************************************************************************
 *
 * *************************************************************************************
 */
@Ignore
public class GenLocalFsDev
{
    @Test
    public void genForLocalDev()
    {
        List<String> jsLibs = Lists.newArrayList(
            "../js/jquery-1.6.4.min.js",
            "../js/jquery.mobile-1.0.min.js"
        );
        jsLibs.add("../js/scroll/jquery.easing.1.3.js");
        jsLibs.add("../js/scroll/jquery.mobile.scrollview.js");
        jsLibs.add("../js/scroll/scrollview.js");

        List<String> cssFiles = Lists.newArrayList(
            "../js/jquery.mobile-1.0.min.css"
        );
        cssFiles.add("../js/scroll/jquery.mobile.scrollview.css");


        Generator generator = new Generator(
            "Local FS",
            "./target/gen-local-fs/html",
            "http://localhost/dialog-sound",
            jsLibs, cssFiles);

        VisibilityType vis = VisibilityType.PUBLIC;
        //generator.genAll(VisibilityType.ALL);
        generator.genLessonsPage(vis);
        generator.genInfoPage();
        generator.genDialogLessonPages(vis);
        generator.genVocabLessonBrowsePages();
    }

    
    private void foo()
    {
        java.text.BreakIterator bi = BreakIterator.getWordInstance();
    }

}
