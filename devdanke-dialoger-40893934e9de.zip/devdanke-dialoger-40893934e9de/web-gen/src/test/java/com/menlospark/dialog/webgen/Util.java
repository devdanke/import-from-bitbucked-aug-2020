package com.menlospark.dialog.webgen;

import com.google.common.base.Charsets;
import com.google.common.io.Files;
import junit.framework.Assert;

import java.io.File;

/**
 * *************************************************************************************
 *
 * @Since 12/9/11
 * <p/>
 * *************************************************************************************
 */
public class Util
{


    public static void assertExpectedJson(Class clazz, String testName, Object jsonizeMe)
        throws Exception
    {
        try
        {
            String expect = readExpectedOutputFile( clazz,testName );
            String actual = Json.ize(jsonizeMe);
            Assert.assertEquals(testName + "-json content", expect, actual);
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }

    }


    public static String readExpectedOutputFile(Class clazz, String testName)
        throws Exception
    {
        try
        {
            File inputDir = new File("src/test/data/"+clazz.getSimpleName());
            return Files.toString(new File(inputDir, testName + ".txt"), Charsets.UTF_8);

        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }

}
