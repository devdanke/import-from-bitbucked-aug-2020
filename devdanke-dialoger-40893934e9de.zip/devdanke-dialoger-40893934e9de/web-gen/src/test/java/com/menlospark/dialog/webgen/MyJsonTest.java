package com.menlospark.dialog.webgen;

import com.google.common.collect.Lists;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import java.io.File;
import java.util.List;


/**
 * *************************************************************************************
 *
 * NOTE: The My* objects are all supposed to be "learnable".  This means they have
 * enough info to be show to a student who wants to read/hear them.
 *
 * MyLesson & MySentence objects that are not ready to learn should not be constructed.
 *
 *
 * @Since 12/1/11
 * <p/>
 * *************************************************************************************
 */
@Ignore
public class MyJsonTest
{
    private static final String CLASS_NAME = MyJsonTest.class.getSimpleName();
    //private static final File inputDir = new File("src/test/data/"+ CLASS_NAME);

    @BeforeClass
    public static void setup()
    {
        File outDir = new File("target", CLASS_NAME);

        if (!(outDir.exists() || outDir.mkdir()))
        {
            throw new RuntimeException("couldn't create test output dir.");
        }
    }

    
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // los testados
    ////////////////////////////////////////////////////////////////////////////////////////////////

    
    @Test
    public void jsonizeMyLesson()
        throws
        Exception
    {
        String testName = "jsonizeMyLesson";
        long baseNum = testName.hashCode();

        List<MySentence> sentences = Lists.newArrayList();
        sentences.add( makeSentence(testName+"-A") );
        sentences.add( makeSentence(testName+"-B") );

        MyLesson lesson = new MyLesson(testName+"-lesson", baseNum, sentences);

        Util.assertExpectedJson(getClass(), testName, lesson);
    }



    
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // convenience & support methods
    ////////////////////////////////////////////////////////////////////////////////////////////////

    private MySentence makeSentence(String testName)
    {
        List<MyWord> words = Lists.newArrayList();

        for(int i=0; i<3; i++)
        {
            words.add( new MyWord(testName+"-wordGuid-"+i, testName+"-concept-"+i, testName+"-thai-"+i,
                testName+"-phonetic-"+i, "media/"+testName+"-wordSound-"+i + ".mp3") );
        }

        List<MyPhrase> phrases = Lists.newArrayList();
        phrases.add( new MyPhrase(testName+"-phraseGuid-w1-w2",2, "media/"+testName+"-phraseSound-w1-w2.mp3") );
        phrases.add( new MyPhrase(testName+"-phraseGuid-w3",   1, "media/"+testName+"-phraseSound-w3.mp3") );

        return new MySentence( testName + "-senGuid" , testName + "-concept",
            "media/"+testName + "-senSound.mp3", words, phrases );
    }

}
