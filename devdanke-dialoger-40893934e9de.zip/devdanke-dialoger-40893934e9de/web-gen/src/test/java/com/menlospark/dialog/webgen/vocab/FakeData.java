package com.menlospark.dialog.webgen.vocab;

import com.google.common.collect.Lists;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * *************************************************************************************
 *
 * @Since 1/13/12
 * <p/>
 * *************************************************************************************
 */
public class FakeData
{
    public static List<VocabLesson> makeLessons(MappingType mappingType, int count)
    {
        List<VocabLesson> list = Lists.newArrayList();

        for(int i=0; i<count; i++)
        {
            list.add( makeLesson("FakeVocabLsn-" + (i+1), mappingType, (i+1)) );
        }
        return list;
    }


    private static VocabLesson makeLesson(String baseName, MappingType mappingType, int count)
    {
        return new VocabLesson(baseName, mappingType, makeConceptMaps(baseName,count));
    }

    private static List<ConceptMap> makeConceptMaps(String baseName, int count)
    {
        List<ConceptMap> list = Lists.newArrayList();

        for(int i=0; i<count; i++)
        {
            list.add( makeConceptMap(baseName+"-"+(i+1)) );
        }

        return list;
    }

    private static ConceptMap makeConceptMap(String baseName)
    {
        return new ConceptMap(
            //new FormalConcept(baseName+"-fc-name", baseName+"-fc-desc", baseName+"-fc-picUrl"),
            new FormalConcept(baseName+"-frm-name", baseName+"-frm-desc",
                "flashdeck/animals/pic/rabbit.jpg"),

            new NativeConcept(baseName+"-src-script", baseName+"-src-phonetic",
                baseName+"src-nc-sndUrl", Locale.ENGLISH),

            //new NativeConcept(baseName+"-dst-nc-script",baseName+"dst-nc-sndUrl", new Locale("th"))
            new NativeConcept(baseName+"-กี่-คนกี่",
                baseName+"-dst-phonetic",
                "dialog-sound/chutima_20080524_20080520104109738_s_20080520104200906.ogg",
                new Locale("th"))
        );
    }


}


