mvn archetype:generate \
  -DarchetypeGroupId=org.apache.maven.archetypes \
  -DgroupId=com.menlospark.dialog \
  -DartifactId=db-hib \
  -DarchetypeArtifactId=maven-archetype-quickstart
