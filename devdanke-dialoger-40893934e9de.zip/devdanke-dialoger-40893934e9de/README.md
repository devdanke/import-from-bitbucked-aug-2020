# README #

Very similar to lingo.  Lots of duplication.