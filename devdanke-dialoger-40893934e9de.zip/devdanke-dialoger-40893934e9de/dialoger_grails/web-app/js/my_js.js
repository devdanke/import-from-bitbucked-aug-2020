/* *************************************************************************************************
 MOVED TO ITS OWN FILE TO ENABLE DEBUG IN CHROME
 */

/*
 Put red line around any form whose content changed.
 Reminds user to save changes.
 */
iAmChanged = function(inputElem)
{
    var myform = inputElem.form;
    var formInfo = getFormInfo(myform);
   // alert("form info: " + formInfo);
    var formChildInfo = getFormChildInfo(myform)
   // alert("form Child info: " + formChildInfo);

    var senFormIsChangedElem = get_senForm_isChanged_elem(myform);
    if(senFormIsChangedElem != null)
    {
        senFormIsChangedElem.value = true;
    }


    inputElem.form.className = "formInputChangedSaveMe";
}


function getFormInfo(f)
{
    var info;

    info = "f.elements: " + f.elements + "\n"
        + "f.length: " + f.length + "\n"
        + "f.name: " + f.name + "\n"
        + "f.acceptCharset: " + f.acceptCharset + "\n"
        + "f.action: " + f.action + "\n"
        + "f.enctype: " + f.enctype + "\n"
        + "f.encoding: " + f.encoding + "\n"
        + "f.method: " + f.method + "\n"
        + "f.target: " + f.target;
    // document.forms["formA"].elements['tex'].value = info;
    return info;
}


function getFormChildInfo(f)
{
    var info;

    for (i = 0; i < f.length; i++)
    {
        info = info + ", " + f.elements[i].name;
    }
    return info;
}

function get_senForm_isChanged_elem(f)
{
    var anElem;

    for (i = 0; i < f.length; i++)
    {
        var anElem = f.elements[i];
        var elemName = anElem.name;
        if ("senForm_isChanged" == anElem.name)
        {
            return anElem;
        }
        return null;
    }
}


