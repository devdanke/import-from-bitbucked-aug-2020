package bar
class SentenceLesson {

    String title
    String status
    Long guid
    String note

    Date created

    List sentences
    static hasMany = [ sentences : Sentence ]

    static constraints = {
        //col order? form order?
        title(unique: true)
        status( inList:[ "begun",
            "has concepts (need replies)", "has concepts", "has concepts (high priority)",
            "translated", "translated (partly)", "translated (needs review)",
            "recorded", "sound parsed",
            "learnable", "learnable (needs fix)", "learnable (added more)", "learnable (record new)",
                "learnable (record changes)",
            "hold"] );
        sentences(nullable:true)
        guid(nullable:true, unique:true)
        note(nullable:true,blank:true)
        created()
    }

    public static SentenceLesson myFindById(Long id)
    {
        return SentenceLesson.get(id);
    }

    public static List<SentenceLesson> myFindAllByQuery(String query, int maxCount)
    {
        return SentenceLesson.findAll(query,[maxCount:maxCount]);
    }


    /*
    Calls genPhraseWordLists() on all sentences.
    Eliminate duplicate phrase word lists.
    Resulting list is not grouped by sentence.
    Each List<bar.Word> in the list represents a phrase.
    Each List<bar.Word> in the list has 1 or more words, unless they've been filtered out.

    The filter param lets you exclude phrases that only have single word.
    This feature is used on the record guide web page so that words don't show up
    in the phrases list the speaker will read.
     */
    public List<List<Word>> listUniquePhraseWordLists(Boolean doFilterOutOneWordPhrases){
        List<List<Word>> lsnWordLists = []
        sentences?.each{ sen ->

            //each sentence generates an unordered phrase list.
            //those phrases may contains phrases with only 1 word.
            List<List<Word>> senWordLists = sen.genPhraseWordLists()
            senWordLists.each{ wordList ->

                Boolean isAllowed = !((wordList.size() == 1) &&  doFilterOutOneWordPhrases)
                if(  isAllowed  ){
                    if( !lsnWordLists.contains( wordList ) ) lsnWordLists.add(wordList)                    
                }
            }
        }
        return lsnWordLists
    }


    /*
      By default, don't allow single word phrases.
      I think this method is only called in the rec guide page and when creating dummy files.
    */
    public List<List<Word>> listUniqueMultiWordPhraseWordLists(){
        return listUniquePhraseWordLists(true)
    }

    public Collection<Sentence> listSortedSentences(){
        SortedMap<String,Sentence> smap = new TreeMap()

        sentences?.each{ sen ->
            smap.put(sen.english, sen)
        }
        return smap.values()
    }

    /*
    Return list of all unique words in lesson.
    List is in alpha order of word.english.
    Used by record guide page and by learner page (for soundmgr2 sound loading).

    According to JavaDoc for SortedMap, the collection returned by map.values() should be in key
     order.
     */
    public Collection<Word> listUniqueSortedWords(){

        SortedMap<String,Word> smap = new TreeMap()
        def key
        sentences?.each{ sen ->
            sen?.words?.each{ w ->

                key = "${w.english}_${w.id}"
                if(!smap.containsKey(key)) smap.put(key, w) }
        }
        return smap.values()
    }

    
    public Collection<Reply> listUniqueSortedReplies(){

        SortedMap<String,Reply> smap = new TreeMap<String,Reply>()

        sentences?.each{ sen ->
            sen?.replies?.each{ r ->
                if(!smap.containsKey(r.english)) smap.put(r.english, r)
            }
        }
        return smap.values()
    }

    /*
    swap position of two sentences.
    used to move a sentence up or down in its display order.
     */
    private void moveSen(Integer senIndex, Integer offset){

        println "************ srcIdx=${senIndex}, dstIdx=${senIndex+offset}"
        def srcSen = sentences[senIndex]
        def dstSen = sentences[senIndex + offset]

        sentences[senIndex]=dstSen;
        sentences[senIndex + offset]=srcSen;
    }

    /*
    swap position of two sentences.
    used to move a sentence up or down in its display order.
     */
    public void moveUp(Integer senIndex){

        println "************ UP srcIdx=${senIndex}, dstIdx=${senIndex+ -1}"
        moveSen(senIndex, -1)
    }
    public void moveDown(Integer senIndex){

        println "************ DOWN srcIdx=${senIndex}, dstIdx=${senIndex+1}"
        moveSen(senIndex, 1)
    }

    public String toString(){
        return title
    }
}
