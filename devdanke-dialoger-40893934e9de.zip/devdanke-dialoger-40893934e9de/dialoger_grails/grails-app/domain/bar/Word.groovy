package bar

import foo.MyUtil

class Word {

    String thai
    /*
    This is used to accurately compare thai words to each other, without the differences of
    hyphens.

    TODO: change name thaiBlob to thai_normalized
    */
    String thaiBlob
    String english
    String phonetic
    Long guid

    static belongsTo = Sentence   //enables bar.Sentence to save words

    static constraints = {
        //thai(nullable: false, blank: false, unique:'english')
        thai(nullable: false, blank: false)
        thaiBlob(nullable: false, blank: false, unique:true)
        english(nullable: true, blank: true)
        phonetic(nullable: true, blank: true)
        guid(nullable:true, unique:true)
    }

    def void setThaiBlob(someThai)
    {
        thaiBlob = MyUtil.stripDashes(someThai)
    }

    /*
    TODO: after i started using these getters, no english or phonetics would appear in the
    TODO  individual word input boxes on showTranslator page
    WTF!


    //Extract all hyphens and spaces from the thai.
    def void setThaiBlob(someThai){

    }


    creating setters that'll always give "" instead of null
    def getEnglish(){
        if(english==null)return ""
        else return english
    }

    def getPhonetic(){
        if(phonetic==null)return ""
        else return phonetic
    }
*/
}
