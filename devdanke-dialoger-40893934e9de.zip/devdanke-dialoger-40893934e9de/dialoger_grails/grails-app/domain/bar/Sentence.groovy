package bar

import foo.NameUtil
import org.springframework.validation.ObjectError

class Sentence {

    public static Sentence myFindById(Long id)
    {
        return Sentence.get(id);
    }


    public static List<ObjectError> myValidate(Sentence sen)
    {

        if( !sen.validate() )
        {
            return sen.errors.allErrors;
        }
        else
        {
            return new ArrayList<ObjectError>();
        }

    }

    String english //Are you open everyday?
    SoundSession soundSession
    Contributor translator
    Long guid
    String note
    String speakerRole


    List words  //words available by index.  allows dupes
    List phrases
    List replies
    static hasMany = [ words : Word, phrases : Phrase, replies: Reply ]

    static belongsTo = SentenceLesson   //makes SentLsn rela owner.  enables SentLsn to save Sentences

    String genThai(){
        if(words?.size() > 0){
            return NameUtil.toThaiStr(words)
        }
        else {
            return ""
        }
    }
    
    static constraints = {
        english(nullable: false, blank: false, unique: true)
        soundSession(nullable:true)
        translator(nullable:true)        
        guid(nullable:true, unique:true)
        note(nullable:true,blank:true)
        speakerRole(nullable:false,blank:false)

        words(nullable: true)
        phrases(nullable: true)
        replies(nullable: true)
    }

    def boolean isPhraseEnd(int wordIndex){

        int cumWordCount = 0
        boolean retVal = false
        phrases?.each{

            cumWordCount += it.wordCount

            if(wordIndex==(cumWordCount-1))
            {
                retVal = true
                return //exits the closure, but not the method
            }
        }
        return retVal
    }

    
    def clearPhrases()
    {
        //TODO: find a way so that when i call removeFromPhrases, grails does a cascade del on phrase.
        def tempPhrases = []
        phrases?.each{ tempPhrases.add(it) }
        tempPhrases.each {
            removeFromPhrases(it)//delete from assoc with this sentence
            it.delete() //delete from db
        }
    }


    /*
    returns immediately if newPhrases list is null or empty

    ASSUMES THAT IF THIS IS BEING CALLED BY THE APP, THEN THE CALLER ALREADY CLEARED THE
    EXISTING PHRASES.  I can't put clearPhrases() in the setter because it make hibernate
    blowup. may17

    july 1, 2008

    still having trouble with this method during grails startup in prod mode.  the error says phrases
    are found but no words.  i think it's a race condition, where hib loads the phrases before the words.
    i guess this setter may be doing too much or needs to be separated from the one hib uses.

    therefore, i'm renaming it from setPhrases() to setPossiblyChangedPhrases(), which is used in
    AddEditController only (i think!).
     */
    def setPossiblyChangedPhrases(List<Phrase> newPhrases){

        if (newPhrases?.size()==0)  return

        phrases = newPhrases

        def int cumWordCount=0
        phrases.each{ it ->
            cumWordCount += it.wordCount
        }

        if( (cumWordCount>0) &&
            ((words==null) || (words.size()==0)) )
        {
            throw new RuntimeException(
                "Have phrases but no words!  sid=${id}, cumWordCount=${cumWordCount}, wordCount=${words?.size()}")
        }


        def wcDif = words?.size() - cumWordCount
        if( (wcDif != null) && (cumWordCount > 0) && (wcDif > 0) ){

            //need to add a final phrase so all words will be in a phrase
            addToPhrases(new Phrase(wordCount:wcDif))
        }
    }


    /*
    return a list of word lists.  each word list has the words of one phrase.
    NOTE: includes duplicates
     */
    public List<List<Word>> genPhraseWordLists(){

        List<Word> list
        List<List<Word>> wordLists = []

        int startPos=0
        int endPos=0
        phrases?.each{ it ->

            list = []
            endPos += it.wordCount
            for(i in startPos..<endPos) list.add(words[i])
            wordLists.add(list)
            startPos = endPos
        }

        return wordLists
    }


    public List<Word> genPhraseWords(int phraseIndex){
        return genPhraseWordLists()[phraseIndex]
    }

}
