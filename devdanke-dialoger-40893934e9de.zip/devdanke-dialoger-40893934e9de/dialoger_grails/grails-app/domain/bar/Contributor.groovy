package bar
class Contributor {

    String nickName
    String name
    String note


    static belongsTo = [Sentence,SoundSession]

    static constraints = {
        nickName(nullable:false)
        name(nullable:false)
        note(nullable:true,blank:true)        
    }


    public String toString(){
        return "${nickName}"
    }

    public boolean equals(Object obj)
    {
        if(obj==null) return false;

        if(obj instanceof Contributor){
            Contributor that = (Contributor)obj;

            return (this.name?.equals(that?.name)); 
        }
        else return false;
    }

}
