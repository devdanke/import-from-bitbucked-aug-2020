package bar

import java.text.SimpleDateFormat

class SoundSession {


    
    //specify us locale because macosx sometimes decides to put dates in thai calendard, ie 2555.
    private static final SimpleDateFormat YYYYMMDD = new SimpleDateFormat("yyyyMMdd", Locale.US)

    def Contributor speaker
    def Date date

    def String genYmdStr(){
        return YYYYMMDD.format(date)
    }

    static constraints = {
        speaker(nullable:false)
        date(nullable:false)
    }

    public String toString(){
        return "${speaker.nickName}: ${genYmdStr()}"
    }

}
