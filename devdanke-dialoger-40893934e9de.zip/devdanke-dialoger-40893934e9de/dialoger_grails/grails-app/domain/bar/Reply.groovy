package bar
/*
a reply to a sentence.  probably brief.  used as sound file slot so tourist can learn to recognize
possible replies to sentences they say.
 */
class Reply {

    String english
    String thai
    Long guid

    static belongsTo = Sentence

    static constraints = {
        english(nullable:false)
        thai()
        guid(nullable:true, unique:true)
    }
}
