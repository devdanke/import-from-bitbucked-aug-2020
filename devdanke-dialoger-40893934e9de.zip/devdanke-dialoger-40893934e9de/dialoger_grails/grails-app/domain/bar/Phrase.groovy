package bar
class Phrase {

    Integer wordCount

    static belongsTo = Sentence


    static constraints = {
        wordCount(min:1)
    }
}
