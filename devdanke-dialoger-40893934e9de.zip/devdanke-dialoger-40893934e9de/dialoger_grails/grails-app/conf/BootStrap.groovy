import bar.Contributor
import bar.Sentence
import bar.Word
import bar.Phrase
import bar.Reply
import bar.SoundSession
import bar.SentenceLesson

class BootStrap {

    def init = { servletContext ->

        servletContext.getProperties().each { k, v ->
            println("* BootStrap.init():   ${k}=${v}")}
        
        servletContext.getProperty("initParameterNames").each { name ->
            println("* initParameterNames: ${name}=${servletContext.getProperty(name)}")}

        servletContext.getProperty("attributeNames").each { name ->
            println("* attributeNames:     ${name}=${servletContext.getProperty(name)}")}

        def String grailsEnv = System.getProperty(org.codehaus.groovy.grails.commons.GrailsApplication.ENVIRONMENT)
        if(grailsEnv==null)grailsEnv="NONE"
        else grailsEnv = grailsEnv.trim()
        println("** GRAILS ENV: ${grailsEnv}")
        
        println("*****************************************************************")

        if(grailsEnv == "development"){

            println("** Adding Dev Mode Test Data")
            addContributors()
            addSoundSessions()
            addGasStationLesson()
            addDevTestLesson()            
        }
        else{
            println("** NOT Adding Test Data")
        }

        println("*****************************************************************")
    }


    def destroy = {
    }

    /* ************************************************************************* */

    def addContributors(){

        def me = "addContributors()"

        Contributor c = new Contributor( nickName:"chutima", name:"chutima indhra")
        DbUtil.save(c, "${me} Contrib: chutima")

        c = new Contributor( nickName:"pen", name:"phensri")
        DbUtil.save(c, "${me} Contrib: pen")
    }

    def addSoundSessions(){

        def me = "addSoundSessions()"

        SoundSession ss = new SoundSession( speaker:Contributor.get(1), date:new Date((2008-1900),(4-1),9))
        DbUtil.save(ss, "${me} soundSession 4/9")

        ss = new SoundSession( speaker:Contributor.get(1), date:new Date((2008-1900),(4-1),24))
        DbUtil.save(ss, "${me} soundSession 4/24")
        
        ss = new SoundSession( speaker:Contributor.get(1), date:new Date((2008-1900),(4-1),26))
        DbUtil.save(ss, "${me} soundSession 4/26")
    }


    def addGasStationLesson(){

        def me = "addGasStationLesson()"

        SentenceLesson lsn
        Sentence sen
        Word nine, one

        lsn = new SentenceLesson(title:"Gas Station",
            created:new Date(),status:"begun",
            guid:20080520104109735L);

        //sentence 1 of 2
        sen = new Sentence(english:"Give me 50 baht of regular.",speakerRole:"tourist",
            translator:Contributor.get(2), guid:20080520104200891L)
        lsn.addToSentences(sen)

        nine = new Word(thai:"เก้า",thaiBlob:"เก้า",phonetic:"gâo ",english:"nine",guid:20080520103753438L)
        one = new Word(thai:"หนึ่ง",thaiBlob:"หนึ่ง",phonetic:"nèung",english:"one",guid:20080520103753439L)
        sen.addToWords( nine )
        sen.addToWords( one )
        sen.addToWords( new Word(thai:"ห้า-สิบ",thaiBlob:"ห้าสิบ",phonetic:"hâa-sìp",english:"fifty",guid:20080520103753440L) )
        sen.addToWords( new Word(thai:"บาท",thaiBlob:"บาท",phonetic:"bàat",english:"baht",guid:20080520103753441L) )

        sen.addToPhrases(new Phrase(wordCount:2))
        sen.addToPhrases(new Phrase(wordCount:2))

        DbUtil.save(lsn, "${me} lsn sen #1")

        //sentence 2 of 2
        sen = new Sentence(english:"Fill it up with regular.",speakerRole:"tourist",
            translator:Contributor.get(2), guid:20080520104200948L)
        lsn.addToSentences(sen)

        sen.addToWords( nine )
        sen.addToWords( one )
        sen.addToWords( new Word(thai:"เต็ม-ถัง",thaiBlob:"เต็มถัง",phonetic:"dtem-tăng",english:"fill-tank",guid:20080520103753479L) )

        sen.addToPhrases(new Phrase(wordCount:2))
        sen.addToPhrases(new Phrase(wordCount:1))

        DbUtil.save(lsn, "${me} lsn sen #2")
    }


    def addDevTestLesson(){

        def String me = "addDevTestLesson()"
        
        SentenceLesson lsn

        lsn = new SentenceLesson(title:"TEST LESSON ADDED BY INIT",
            contributor:"chutima",created:new Date(),status:"begun",guid:GuidUtil.instance.nextGuid());

        Sentence sen1 = new Sentence(english:"SENTENCE #1 HAS 0 WORDS",speakerRole:"thai",
            translator:Contributor.get(2), guid:GuidUtil.instance.nextGuid())
        lsn.addToSentences(sen1)

        Sentence sen2 = new Sentence(english:"SENTENCE #2 HAS 2 WORDS",speakerRole:"tourist",
            translator:Contributor.get(2), guid:GuidUtil.instance.nextGuid())
        sen2.addToWords( new Word(thai:"s2w1-th-foo",thaiBlob:"s2w1thfoo",phonetic:"ph-foo",english:"en-foo",guid:GuidUtil.instance.nextGuid()) )
        sen2.addToWords( new Word(thai:"s2w2-th-bar",thaiBlob:"s2w2thbar",phonetic:"ph-bar",english:"en-bar",guid:GuidUtil.instance.nextGuid()) )
        lsn.addToSentences(sen2)

        Sentence sen3 = new Sentence(english:"SENTENCE #3 HAS 3 WORDS AND NO PHRASES",
            speakerRole:"either",guid:GuidUtil.instance.nextGuid())
        lsn.addToSentences( sen3 )
        sen3.addToWords( new Word(thai:"s3w1-th-hey",thaiBlob:"s3w1thhey",phonetic:"ph-hey",english:"en-hey",guid:GuidUtil.instance.nextGuid()) )
        sen3.addToWords( new Word(thai:"s3w2-th-you",thaiBlob:"s3w2thyou",phonetic:"ph-you",english:"en-you",guid:GuidUtil.instance.nextGuid()) )
        sen3.addToWords( new Word(thai:"s3w3-th-silly",thaiBlob:"s3w3thsilly",phonetic:"ph-silly",english:"en-silly",guid:GuidUtil.instance.nextGuid()) )

        Sentence sen4 = new Sentence(english:"SENTENCE #4 HAS 3 WORDS AND 1 PHRASE AT WORD #2",
            speakerRole:"either",guid:GuidUtil.instance.nextGuid())
        lsn.addToSentences( sen4 )
        sen4.addToWords( new Word(thai:"s4w1-th-hey",thaiBlob:"s4w1thhey",phonetic:"ph-hey",english:"en-hey",guid:GuidUtil.instance.nextGuid()) )
        sen4.addToWords( new Word(thai:"s4w2-th-you",thaiBlob:"s4w2thyou",phonetic:"ph-you",english:"en-you",guid:GuidUtil.instance.nextGuid()) )
        sen4.addToWords( new Word(thai:"s4w3-th-silly",thaiBlob:"s4w3thsilly",phonetic:"ph-silly",english:"en-silly",guid:GuidUtil.instance.nextGuid()) )
        sen4.addToPhrases(new Phrase(wordCount:2))

        Sentence sen5 = new Sentence(english:"SENTENCE #5 HAS 0 WORDS, 0 PHRASEs, & 1 REPLY",
            speakerRole:"either",guid:GuidUtil.instance.nextGuid())
        lsn.addToSentences( sen5 )
        sen5.addToReplies( new Reply(thai:"s5r1-th-hey",thaiBlob:"s5r1thhey", english:"en-hey",guid:GuidUtil.instance.nextGuid()) )

        Sentence sen6 = new Sentence(english:"SENTENCE #6 HAS 0 WORDS, 0 PHRASEs, & 2 REPLIES",
            speakerRole:"either",guid:GuidUtil.instance.nextGuid())
        lsn.addToSentences( sen6 )
        sen6.addToReplies( new Reply(thai:"s6r1-th-tiger", thaiBlob:"s6r1thtiger",english:"en-tiger",guid:GuidUtil.instance.nextGuid()) )
        sen6.addToReplies( new Reply(thai:"s6r2-th-zoo", thaiBlob:"s6r2thzoo",english:"en-zoo",guid:GuidUtil.instance.nextGuid()) )

        DbUtil.save(lsn, "${me} 6 sentences")
    }



}