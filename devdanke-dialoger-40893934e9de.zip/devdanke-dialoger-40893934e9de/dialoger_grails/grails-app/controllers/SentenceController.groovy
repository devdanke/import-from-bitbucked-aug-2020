import bar.Sentence

class SentenceController {
    
    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 10
        [ sentenceList: Sentence.list( params ) ]
    }

    def show = {
        def sentence = Sentence.get( params.id )

        if(!sentence) {
            flash.message = "bar.Sentence not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ sentence : sentence ] }
    }

    def delete = {
        def sentence = Sentence.get( params.id )
        if(sentence) {
            sentence.delete()
            flash.message = "bar.Sentence ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "bar.Sentence not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def sentence = Sentence.get( params.id )

        if(!sentence) {
            flash.message = "bar.Sentence not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ sentence : sentence ]
        }
    }

    def update = {
        def sentence = Sentence.get( params.id )
        if(sentence) {
            sentence.properties = params
            if(!sentence.hasErrors() && sentence.save()) {
                flash.message = "bar.Sentence ${params.id} updated"
                redirect(action:show,id:sentence.id)
            }
            else {
                render(view:'edit',model:[sentence:sentence])
            }
        }
        else {
            flash.message = "bar.Sentence not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def sentence = new Sentence()
        sentence.properties = params
        return ['sentence':sentence]
    }

    def save = {
        def sentence = new Sentence(params)
        if(!sentence.hasErrors() && sentence.save()) {
            flash.message = "bar.Sentence ${sentence.id} created"
            redirect(action:show,id:sentence.id)
        }
        else {
            render(view:'create',model:[sentence:sentence])
        }
    }
}
