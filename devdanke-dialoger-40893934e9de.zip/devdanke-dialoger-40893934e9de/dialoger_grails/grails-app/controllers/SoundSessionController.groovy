import bar.SoundSession

class SoundSessionController {
    
    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 10
        [ soundSessionList: SoundSession.list( params ) ]
    }

    def show = {
        def soundSession = SoundSession.get( params.id )

        if(!soundSession) {
            flash.message = "bar.SoundSession not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ soundSession : soundSession ] }
    }

    def delete = {
        def soundSession = SoundSession.get( params.id )
        if(soundSession) {
            soundSession.delete()
            flash.message = "bar.SoundSession ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "bar.SoundSession not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def soundSession = SoundSession.get( params.id )

        if(!soundSession) {
            flash.message = "bar.SoundSession not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ soundSession : soundSession ]
        }
    }

    def update = {
        def soundSession = SoundSession.get( params.id )
        if(soundSession) {
            soundSession.properties = params
            if(!soundSession.hasErrors() && soundSession.save()) {
                flash.message = "bar.SoundSession ${params.id} updated"
                redirect(action:show,id:soundSession.id)
            }
            else {
                render(view:'edit',model:[soundSession:soundSession])
            }
        }
        else {
            flash.message = "bar.SoundSession not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def soundSession = new SoundSession()
        soundSession.properties = params
        return ['soundSession':soundSession]
    }

    def save = {
        def soundSession = new SoundSession(params)
        if(!soundSession.hasErrors() && soundSession.save()) {
            flash.message = "bar.SoundSession ${soundSession.id} created"
            redirect(action:show,id:soundSession.id)
        }
        else {
            render(view:'create',model:[soundSession:soundSession])
        }
    }
}
