import bar.SentenceLesson
import bar.Sentence

class SentenceMoverController {

    def index = {
        render(view:'sentenceMover',model:[msg:"no msg yet"])
    }

    def procForm = {

        SentenceLesson srcLesson = null
        SentenceLesson destLesson = null
        String className = this.class.getSimpleName()

        if(params.srcLessonId != null) srcLesson = SentenceLesson.get(params.srcLessonId)
        if(params.destLessonId != null) destLesson = SentenceLesson.get(params.destLessonId)

        List<Long> targSenIds = new ArrayList<Long>()

        params.keySet().sort().each { String key ->
            String value = params[key]
            if( key.indexOf("srcSenId")==0 ){
                targSenIds.add(new Long(key.substring(9)))
            }
            println "${className}: ${actionName} - param: ${key} -> ${value}"
        }

        String msg =
            "srcLsnId: ${params.srcLessonId}, destLsnId: ${params.destLessonId}, srcSenIds: ${targSenIds}";

        if(targSenIds.size() > 0) moveSentences(srcLesson,destLesson,targSenIds)
        render(view:'sentenceMover',model:[msg:msg, srcLesson:srcLesson, destLesson:destLesson])
    }

    void moveSentences(SentenceLesson src, SentenceLesson dest, List<Long> senIds)
    {
        List<Sentence> targets = new ArrayList<Sentence>()

        //gather target sentences from src lesson
        src.sentences.each { Sentence sen ->
            if( senIds.contains(sen.id) ) targets.add(sen)
        }
        //remove them from src lesson
        src.sentences.removeAll(targets)
        DbUtil.save(src,"srcLesson")

        //add to dest lesson
        if(dest.sentences != null)
        {
            dest.sentences.addAll(targets)
        }
        else
        {
            dest.sentences = targets
        }
        DbUtil.save(dest, "destLesson")  
    }

}


