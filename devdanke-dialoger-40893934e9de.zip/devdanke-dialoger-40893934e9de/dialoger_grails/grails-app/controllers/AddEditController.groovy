import foo.MyUtil
import foo.AddEditUtil
import foo.SentenceAction
import bar.SentenceLesson
import bar.SoundSession
import bar.Word
import bar.Sentence
import bar.Contributor
import bar.Phrase
import bar.Reply
import foo.SoundNameUtil
import foo.Conf
import foo.MyParams

class AddEditController
{
    private static final String LAST_EDIT_ANCHOR = "lastEditAnchor"
    private static final String NEW_SENTENCE = "NEW_SENTENCE"

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [ procAddEdit:'POST', procLesson:'POST']



    /* ************************************************************************
     */
    def index = { redirect(action:list,params:params) }

    

    /* ************************************************************************
     */
    def list = {

        //findAll was only way i found to use multi-col order by clause
        def queryStr = "FROM bar.SentenceLesson AS sl WHERE 1=1 ORDER BY sl.status, sl.title"
        [ sentenceLessonList:SentenceLesson.findAll(queryStr,[max:200]) ]
    }



    /* **************************************************************************
    Generate a bar.Sentence Learner web page for this lesson.  Then redirect to that page.
     */
    def showLearner = {

        String me = "${actionName}: "
        String lsnId = params.id;

        println("${me} lesson id={lsnId}")

        SentenceLesson lsn = SentenceLesson.get(lsnId)

        SoundNameUtil sndUtil = new SoundNameUtil(Conf.EXT_SOUND_BASE_URL , lsn.guid);

        render(view:"showLearner",model:[lsn:lsn, sndUtil:sndUtil])
    }

  

    /* **************************************************************************
        show the myAddLesson page.  use to create or edit the skeleton of a sentence-lesson.
        by skeleton i mean the english part, ie the lesson title and the english part of each
        sentence.  
     */
    def showTranslator = {

        String me = "${actionName}: ";
        //TODO: how LAST_EDIT_ANCHOR from params/model so it's not in rendered pg URL as kv pair
        String lastEdAnchor = AddEditUtil.retNullOrNonEmptyStr(params.get(LAST_EDIT_ANCHOR))
        params.remove(LAST_EDIT_ANCHOR)

params.keySet().sort().each { println "${me} - param: ${it} -> ${params[it]}" }

        SentenceLesson lsn;
        String btnTxt;
        if(params.id)
        {
            lsn = SentenceLesson.get(params.id)
            btnTxt = "Update";
            if(lastEdAnchor==NEW_SENTENCE)
            {
                lastEdAnchor = "anchor_senId_${lsn.sentences[lsn.sentences.size()-1].id}"
            }
        }
        else
        {
            lsn = new SentenceLesson()
            btnTxt = "Create"
        }

        String viewPage = "showTranslator"

        render(view:viewPage, model:[lsn:lsn, lsnAction:btnTxt, senAction:btnTxt,
            lastEditAnchor:lastEdAnchor,wordUtil:new WordInputUtil()])
    }


    /* **************************************************************************
    */
    def addSenOnly = {
        if( params.lsnAction == "addSentence" )
        {
            SentenceLesson lsn = SentenceLesson.get(params.id)
            def newSen = new Sentence(english:"?",speakerRole:"tourist",guid:GuidUtil.instance.nextGuid())
            lsn.addToSentences(newSen)

            redirect(action:showTranslator,id:lsn.id, params:[lastEditAnchor:NEW_SENTENCE])  //worked            
        }
        else
        {
            throw new RuntimeException("unknonwn lesson action=${params.lsnAction}")
        }
    }


    /* **************************************************************************
    */
    def procLesson = {

        String me = "${actionName}: ";

        params.keySet().sort().each { println "${me} - param: ${it} -> ${params[it]}" }

        SentenceLesson lsn;
        String lastEdAnchor = null;
        Sentence newSen = null;

        if( params.lsnAction == "Update" )
        {
            //Update  mode
            lsn = SentenceLesson.get(params.id)
        }
        else if( params.lsnAction == "Create" )
        {
            //Create mode
            lsn = new SentenceLesson(params) //TODO: use proper ctor
            lsn.guid = GuidUtil.instance.nextGuid()
            lsn.created = new Date();
            //lsn.contributor = bar.SentenceLesson.constraints.contributor.inList[0]
        }
        else if( params.lsnAction == "addSentence" )
        {
            //Treat this as an update too
            //Update  mode
            lsn = SentenceLesson.get(params.id)
            newSen = new Sentence(english:"?",speakerRole:"tourist",guid:GuidUtil.instance.nextGuid()) //TODO: use proper ctor
            lsn.addToSentences(newSen)
        }

        //for all actions - start

        //Handle soundsession bulk select
        Integer soundSessionId = MyUtil.getIntOrNull(params.soundSessionId, "Bulk Select...")
        if(soundSessionId != null)
        {
            //Assign sound session to any sentence in this lesson that has been translated
            //but doesn't yet a sound session
            lsn.sentences?.each { sen ->
                if( (sen?.words?.size() > 0) && (sen.soundSession == null) )
                {
                    sen.soundSession = SoundSession.get(soundSessionId)
                }
            }
        }

        //Handle translator bulk select
        Integer translatorId = MyUtil.getIntOrNull(params.translatorId, "Bulk Select...")
        if(translatorId != null)
        {
            //Assign translator to any sentence in this lesson that doesn't yet have one
            Contributor con = Contributor.get(translatorId)
            lsn.sentences?.each { sen ->
                if( sen.translator == null )
                {
                    sen.translator = con;
                }
            }
        }

        lsn.title = params.title
        lsn.status = params.status
        lsn.note = params.note
        //lsn.contributor = params.contributor
        //for all actions - end

        if(DbUtil.save(lsn, "sen lesson")) {
            println( "${me} ${params.lsnAction}  id=" + lsn.id)

            if(newSen != null)
            {
                lastEdAnchor = NEW_SENTENCE
            }
            
            redirect(action:showTranslator,id:lsn.id, params:[lastEditAnchor:lastEdAnchor])  //worked
        }
    }//procLesson


    public void handleStructuralChange(SentenceAction action, SentenceLesson lsn, Integer senIndex,
        Long senId)
    {
        String me = "handleStructuralChange: ";

        def outParams = [lastEditAnchor:"anchor_senId_${senId}"];

        switch(action)
        {
            case SentenceAction.ADD_REPLY:

                println("${me} add reply to sen")
                Sentence sen = Sentence.get(senId);
                sen.addToReplies( new Reply(thai:"", english:"",guid:GuidUtil.instance.nextGuid()) )
                DbUtil.save(sen, "${me} sen");
                break;

            case SentenceAction.MOVE_UP:

                println("${me} move sen up")
                lsn.moveUp( senIndex );
                DbUtil.save(lsn, "${me} lsn");
                break;

            case SentenceAction.MOVE_DOWN:

                println("${me} move sen down")

                lsn.moveDown( senIndex);
                DbUtil.save(lsn, "${me} lsn");
                break;

            case SentenceAction.DELETE:

                println("${me} delete sen")

                Sentence targSen = Sentence.get(senId);
                lsn.removeFromSentences(targSen);
                DbUtil.save(lsn, "${me} lsn");
                DbUtil.deleteSen(targSen);
                outParams = [:];

                break;
            default:
                throw new RuntimeException("unknown actionType: " + action.getName())
        }
        redirect(action:showTranslator, id:lsn.id, params:outParams);
    }


    private void handleDataChange(SentenceLesson lsn, Integer senIndex,
        Long senId, MyParams myParams)
    {
        String me = "handleDataChange: ";

        Sentence sen = Sentence.get(senId);

        sen.note = myParams.note?.trim()

        sen.english = AddEditUtil.retNullOrNonEmptyStr( myParams.english )

        String origSenThai = sen.genThai()?.trim()
        String newSenThai = AddEditUtil.retNullOrNonEmptyStr( myParams.thai )

        boolean isSenThaiChanged = false

        if( !AddEditUtil.areSame(origSenThai, newSenThai ) )
        {
            //user changed thai script in a significant way.
            //get rid of old words.  regenerate words
            println("${me} non-trivial thai sen change found. senId=${senId}")
            sen.words = genWordsFromThaiScript( newSenThai )
            isSenThaiChanged = true
        }

        if( !isSenThaiChanged && !sen.words?.isEmpty() )
        {
            //if sentence thai script didn't change AND sentence has words, then
            // a) grab potential eng def changes, and
            // b) grab potential phrase boundary changes
            String val;
            int cumWordCount = 0
            List<Phrase> phrases = new ArrayList<Phrase>();

            //NOTE: wordEnglish/wordPhontic could end up being an array.
            //Happens when same word appears more than once in a sentence. -dec2011
            sen.words?.eachWithIndex{ word, i ->

                //for each word, save literal meaning & phonetic.  hib should be able to tell
                // whether or not anything actually changed

                val = myParams.get("wordEnglish_${word.id}");
                //val = AddEditUtil.retNullOrValOrFirstValInList(val)
                if(val != null ) word.english = val.trim().toLowerCase()
                else word.english = ""

                val = myParams["wordPhonetic_${word.id}"]
                //val = AddEditUtil.retNullOrValOrFirstValInList(val)
                if(val != null ) word.phonetic = val.trim()
                else word.phonetic = ""

                val = AddEditUtil.retNullOrNonEmptyStr( myParams["phraseEnd_${i}"] )
                if( val != null )
                {
                    Phrase p = new Phrase();
                    p.wordCount = (i+1) - cumWordCount;
                    phrases.add(p);
                    cumWordCount = (i + 1);
                }
            }//for each word

            //Must delete all phrases from sentence, because user may have unchecked them all.
            sen.clearPhrases()
            if (!phrases.isEmpty())
            {
                sen.setPossiblyChangedPhrases( phrases )
            }

        }//if thai part of sen change and sen has words

        //Capture bar.Reply lines
        for(Reply reply : sen.replies)
        {
            reply.english = myParams["replyEnglish_${reply.id}"]
            reply.thai =    myParams["replyThai_${reply.id}"]
        }

        //find replies having empty english field.
        List<Reply> targDelReplies = sen.replies?.findAll { reply ->
            reply.english?.trim().isEmpty();
        }
        targDelReplies?.each{ reply ->
            sen.removeFromReplies(reply);
        }


        //Save soundsession id
        Integer soundSessionId = MyUtil.getIntOrNull(myParams.soundSessionId, "Select One...")
        if(soundSessionId != null) sen.soundSession = SoundSession.get(soundSessionId)
        else sen.soundSession = null

        //Save translator id
        Integer translatorId = MyUtil.getIntOrNull(myParams.translatorId, "Select One...")
        if(translatorId != null) sen.translator = Contributor.get(translatorId)
        else sen.translator = null

        if(DbUtil.save(sen, "${me} sen"))
        {
            //if there were any replies that had an empty english field, del the reply itself.
            targDelReplies?.each{ reply ->
                DbUtil.delete( reply, "${me} reply")
            }

            redirect(action:showTranslator, id:lsn.id, params:[lastEditAnchor:"anchor_senId_${senId}"])
        }
    }


    /* **************************************************************************
    */
    def procSentence = {

        String me = "procSen: ";
        println("${me} called");
        MyParams myParams = new MyParams();
        params.keySet().sort().each {
            println "${me} - param: ${it} -> ${params[it]}";
            myParams.add(it,params[it]);
        }

        SentenceLesson lsn = SentenceLesson.get(Long.parseLong(params.lsnId));
        Long senId = MyUtil.getLongOrNull(params.id);
        Integer senIndex = MyUtil.getIntOrNull(params?.senIndex);
        SentenceAction reqAction = SentenceAction.toEnum(params.senAction);

        if(reqAction.isStructuralChange())
        {
            println("${me} structural change request");

            //structural change
            handleStructuralChange(reqAction, lsn, senIndex, senId);
        }
        else
        {
            println("${me} data change request")
            //data change
            if( !Boolean.parseBoolean(params.senForm_isChanged) )
            {
                println("${me} No change to sentence. Ignore update request\n\n");
                redirect(action:showTranslator, id:lsn.id, params:[lastEditAnchor:"anchor_senId_${senId}"]);
                return;
            }
            println("${me} Process data changed. senId=${senId}");

            handleDataChange(lsn, senIndex, senId, myParams);
        }
    }


    ////////////////////////////////////////////////////////////
    // MISC TOOLS
    ////////////////////////////////////////////////////////////


    def showMiscTools = {

        render(view:"showMiscTools")
    }


    def listPhoneticallyChallengedWords = {

        throw new RuntimeException("what is this for? listPhoneticallyChallengedWords ")
        /*
        def baseDir = "${OUTPUT_DIR}/phonetically_challenged_words"

        StringBuffer sb = new StringBuffer();

        Word.list()?.each{ word ->

            def phon = word.phonetic
            if( ( (phon==null) || phon.trim().isEmpty() || !phon.contains("HMMMM") ||
                !phon.contains("?") || !phon.contains("[") ) && !word.english?.empty() )
            {
                sb.append("# thai=").append(word.thai)
                sb.append(" , thai_blob= ").append(word.thaiBlob).append(" \n")
                sb.append( URLEncoder.encode(word.english,"UTF-8") ).append("\n")
            }
        }

        createFile(baseDir,"harvest_words.txt", sb.toString())
        redirect(action:showMiscTools)
        */
    }

    

    ////////////////////////////////////////////////////////////
    // utils
    ////////////////////////////////////////////////////////////


    /* *****************************************************************
    ASSUMES senThai not null or empty.
     */
    private List<Word> genWordsFromThaiScript(String senThai)
    {
        //TODO try return empty list instead of null
        if(senThai==null) return null

        List<Word> words = new ArrayList<Word>();

        //use to avoid accidently creating duplicate words,
        //since GORM doesn't allow me to prevent this with their ORM DSL
        Map<String,Word> normizedThaiToWordMap = new HashMap<String,Word>();

        for(String thaiSenToken: AddEditUtil.splitLine(senThai))
        {
            String normalizedThaiWord = AddEditUtil.normalizeThaiWord(thaiSenToken)

            //case 1: this word is already in the database.
            Word word = Word.findByThaiBlob( normalizedThaiWord )

            //case 2: new word
            if(word == null)
            {
                if( normizedThaiToWordMap.containsKey(thaiSenToken) )
                {
                    //case 2a: word not in db, but i t was already parsed in this sentecne
                    word = normizedThaiToWordMap.get(thaiSenToken)
                }
                else
                {
                    //case 3: entirely new
                    word = new Word();
                    word.setThai(thaiSenToken);
                    word.setThaiBlob(normalizedThaiWord);
                    word.setEnglish("");
                    word.setPhonetic("");
                    word.setGuid(GuidUtil.instance.nextGuid());

                    normizedThaiToWordMap.put(normalizedThaiWord,word)
                }
            }
            words.add(word)
        }

        return words
    }

}