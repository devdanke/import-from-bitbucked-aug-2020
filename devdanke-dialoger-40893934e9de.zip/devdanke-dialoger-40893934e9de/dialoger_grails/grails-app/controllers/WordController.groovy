import bar.Word

class WordController {
    
    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 100
        [ wordList: Word.list( params ) ]
    }

    def show = {
        def word = Word.get( params.id )

        if(!word) {
            flash.message = "bar.Word not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ word : word ] }
    }

    def delete = {
        def word = Word.get( params.id )
        if(word) {
            word.delete()
            flash.message = "bar.Word ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "bar.Word not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def word = Word.get( params.id )

        if(!word) {
            flash.message = "bar.Word not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ word : word ]
        }
    }

    def update = {
        def word = Word.get( params.id )
        if(word) {
            word.properties = params
            if(!word.hasErrors() && word.save()) {
                flash.message = "bar.Word ${params.id} updated"
                redirect(action:show,id:word.id)
            }
            else {
                render(view:'edit',model:[word:word])
            }
        }
        else {
            flash.message = "bar.Word not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def word = new Word()
        word.properties = params
        return ['word':word]
    }

    def save = {
        def word = new Word(params)
        if(!word.hasErrors() && word.save()) {
            flash.message = "bar.Word ${word.id} created"
            redirect(action:show,id:word.id)
        }
        else {
            render(view:'create',model:[word:word])
        }
    }
}