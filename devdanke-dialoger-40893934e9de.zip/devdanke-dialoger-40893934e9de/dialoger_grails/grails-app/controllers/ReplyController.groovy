import bar.Reply

class ReplyController {
    
    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 10
        [ replyList: Reply.list( params ) ]
    }

    def show = {
        def reply = Reply.get( params.id )

        if(!reply) {
            flash.message = "bar.Reply not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ reply : reply ] }
    }

    def delete = {
        def reply = Reply.get( params.id )
        if(reply) {
            reply.delete()
            flash.message = "bar.Reply ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "bar.Reply not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def reply = Reply.get( params.id )

        if(!reply) {
            flash.message = "bar.Reply not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ reply : reply ]
        }
    }

    def update = {
        def reply = Reply.get( params.id )
        if(reply) {
            reply.properties = params
            if(!reply.hasErrors() && reply.save()) {
                flash.message = "bar.Reply ${params.id} updated"
                redirect(action:show,id:reply.id)
            }
            else {
                render(view:'edit',model:[reply:reply])
            }
        }
        else {
            flash.message = "bar.Reply not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def reply = new Reply()
        reply.properties = params
        return ['reply':reply]
    }

    def save = {
        def reply = new Reply(params)
        if(!reply.hasErrors() && reply.save()) {
            flash.message = "bar.Reply ${reply.id} created"
            redirect(action:show,id:reply.id)
        }
        else {
            render(view:'create',model:[reply:reply])
        }
    }
}