import bar.SentenceLesson

class SentenceLessonController {
    
    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 10
        [ sentenceLessonList: SentenceLesson.list( params ) ]
    }

    def show = {
        def sentenceLesson = SentenceLesson.get( params.id )

        if(!sentenceLesson) {
            flash.message = "bar.SentenceLesson not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ sentenceLesson : sentenceLesson ] }
    }

    def delete = {
        def sentenceLesson = SentenceLesson.get( params.id )
        if(sentenceLesson) {
            sentenceLesson.delete()
            flash.message = "bar.SentenceLesson ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "bar.SentenceLesson not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def sentenceLesson = SentenceLesson.get( params.id )

        if(!sentenceLesson) {
            flash.message = "bar.SentenceLesson not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ sentenceLesson : sentenceLesson ]
        }
    }

    def update = {
        def sentenceLesson = SentenceLesson.get( params.id )
        if(sentenceLesson) {
            sentenceLesson.properties = params
            if(!sentenceLesson.hasErrors() && sentenceLesson.save()) {
                flash.message = "bar.SentenceLesson ${params.id} updated"
                redirect(action:show,id:sentenceLesson.id)
            }
            else {
                render(view:'edit',model:[sentenceLesson:sentenceLesson])
            }
        }
        else {
            flash.message = "bar.SentenceLesson not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def sentenceLesson = new SentenceLesson()
        sentenceLesson.properties = params
        return ['sentenceLesson':sentenceLesson]
    }

    def save = {
        def sentenceLesson = new SentenceLesson(params)
        if(!sentenceLesson.hasErrors() && sentenceLesson.save()) {
            flash.message = "bar.SentenceLesson ${sentenceLesson.id} created"
            redirect(action:show,id:sentenceLesson.id)
        }
        else {
            render(view:'create',model:[sentenceLesson:sentenceLesson])
        }
    }
}
