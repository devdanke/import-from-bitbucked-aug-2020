import foo.MyUtil

import bar.SentenceLesson
import bar.Contributor

import foo.Conf
import foo.SoundNameUtil;

class RecordGuideController {

    def Contributor speaker
    

    def index = {

        redirect(action:showRecGuide,params:params)
    }

    /* **************************************************************************
        show the myAddLesson page.  use to create or edit the skeleton of a sentence-lesson.
        by skeleton i mean the english part, ie the lesson title and the english part of each
        sentence.
     */
    def showRecGuide = {

        println "${actionName} - IN"
        params.keySet().sort().each { println "${actionName} - param: ${it} -> ${params[it]}" }

        SentenceLesson lsn = SentenceLesson.get(params.id)

        println "${actionName} - lsn=${lsn}"

        Integer speakerId = MyUtil.getIntOrNull(params.speakerId, "Select One...")
        Map defaultSpeakerVal
        if(speakerId != null)
        {
            speaker = Contributor.get(speakerId)
        }
        else
        {
            speaker = null
        }

        render(view:"showRecGuide", model:[lsn:lsn, soundNameUtil:makeSoundNameUtil(lsn.guid),
            speaker:speaker])
    }


    /* ************************************************************************
     */
    def genDummySoundFiles = {

throw new RuntimeException("genDummySoundFiles not working now.  Please fix it:-)")
        /*
println "${actionName} - --------------------------- "        
println("${actionName} lesson id="+params.id)

        SentenceLesson lsn = SentenceLesson.get(params.id)

        def fileSafeName = NameUtil.toFileSafeName(lsn.title)
        def baseDir = "${_outputDir}/${fileSafeName}_${lsn.guid}/dummies"

        lsn.sentences?.each{ sen ->
            createEmptyFile(baseDir, "${snu.genSoundName(sen)}.wav")
        }

        //NOTE: Assume all sentences in lesson spoken by same speaker, therefore
        //it's ok to use first sentence speaker for whole lesson.
        Contributor speaker = lsn.sentences.getAt(0).soundSession.speaker;


        snu.filterOutRecordedWords(lsn.listUniqueSortedWords(), speaker)?.each{ w ->
            createEmptyFile(baseDir, "${snu.genSoundName(w)}.wav")
        }


        lsn.listUniqueMultiWordPhraseWordLists()?.each{ phraseWords ->
            createEmptyFile(baseDir, "${snu.genSoundName(phraseWords)}.wav")
        }

        lsn.listUniqueSortedReplies()?.each{ reply ->
            createEmptyFile(baseDir, "${snu.genSoundName(reply)}.wav")
        }

        render(view:"showRecGuide",model:[lsn:lsn,soundNameUtil:makeSoundNameUtil(lsn.guid)])
        */
    }


    SoundNameUtil makeSoundNameUtil(Long lessonGuid)
    {
        return new SoundNameUtil(Conf.LOCAL_FS_ROOT_SOUND_DIR, lessonGuid);
    }


    def createEmptyFile(parentPath, fileName){

        def dir = new File(parentPath)
        if( !dir.exists()) {
            if(!dir.mkdirs()) println "* failed to create parent dir(s): ${dir.absoluteFile}"
        }

        def file = new File(dir, fileName)
        if(file.exists()) return;
        else {
            if (!file.createNewFile() ) println "* failed to create file: ${file.absoluteFile}"
        }
    }


    def createFile(parentPath, fileName, content){

        createEmptyFile(parentPath, fileName)

        def filePath = parentPath + "/" + fileName

        PrintWriter pw = new PrintWriter(new File(filePath),"UTF-8")
        pw.println(content)
        pw.close()
    }


}
