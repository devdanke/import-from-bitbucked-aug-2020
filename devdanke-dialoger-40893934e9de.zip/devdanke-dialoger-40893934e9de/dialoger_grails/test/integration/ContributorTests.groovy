class ContributorTests extends GroovyTestCase {

    void testSomething() {

    }
}
