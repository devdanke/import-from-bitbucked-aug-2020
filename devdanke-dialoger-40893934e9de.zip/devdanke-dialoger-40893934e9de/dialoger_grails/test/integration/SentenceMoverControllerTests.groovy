class SentenceMoverControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
