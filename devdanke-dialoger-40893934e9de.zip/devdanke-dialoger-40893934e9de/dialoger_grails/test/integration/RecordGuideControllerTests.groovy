class RecordGuideControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
