class MyTest extends GroovyTestCase {

    void testSomething() {

        SortedMap sm = new TreeMap()
        sm.put("b","2")
        sm.put("a","1")
        sm.put("d","4")
        sm.put("c","3")

        def col = sm.values()
        col.each{
            println("val=${it}")
        }

    }
}