package foo;

/**
 */
public class MyUtil
{
    public static final Integer getIntOrNull(String val, String nothingChosenLabel)
    {
        if ( (val==null) || val.trim().isEmpty() ) return null;

        if(val==nothingChosenLabel) return null;
        else return Integer.parseInt(val);
    }


    public static String stripDashes(String str)
    {
        if(str != null)
        {
            return str.replaceAll("-", "").trim();
        }
        else
        {
            return str;
        }
    }


    public static Integer getIntOrNull(String numStr)
    {
        if( (numStr != null) && !numStr.trim().isEmpty() )
        {
            return Integer.parseInt(numStr);
        }
        else
        {
            return null;
        }
    }


    public static Integer getLongOrNull(String numStr)
    {
        if( (numStr != null) && !numStr.trim().isEmpty() )
        {
            return Integer.parseInt(numStr);
        }
        else
        {
            return null;
        }
    }

}
