package foo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * *************************************************************************************
 *
 * This class is intended to enabled better debugging Groovy params object.
 *
 * Currently, IDEA debugger can't show me when params object returns a map or single object.
 * This is important when a sentence has the same word more than once.
 *
 * So, I'll just put all these vars into a list(string) and handle then less elegantly but
 * also less ambiguity.
 *
 * @Since 12/3/11
 * <p/>
 * *************************************************************************************
 */
public class MyParams
{
    private Map<String,String> _params = new HashMap<String,String>();

    public MyParams(){}

    public void add(String key, String val)
    {
        _params.put(key,val);
    }

    /*
    throw if all vals in array not same.
     */
    public void add(String key, String[] vals)
    {
        String val1 = vals[0];
        for(String val: vals)
        {
            if(!val1.equals(val))
            {
                throw new RuntimeException("expected all same vals in array. but val1="+val1+", val="+val);
            }
        }
        _params.put(key,val1);
    }

    public String get(String key){return _params.get(key);}
}
