package foo;

import bar.Contributor;
import bar.SoundSession;
import bar.Word;
import bar.Reply;
import bar.Sentence;


import java.io.File;
import java.util.*;
import static java.lang.String.format;

/**
 */
public class SoundNameUtil
{
    private static final String ME = "snu.";

    private String _baseSoundDirOrUrl;
    private Long _lessonGuid;

    public SoundNameUtil(String baseSoundDirOrUrl, Long lessonGuid)
    {
        String me = ME + "ctor():";
        
        log("%s baseSoundDirOrUrl=%s", me, baseSoundDirOrUrl);
        log("%s lessonGuid=%s", me, lessonGuid);

        _lessonGuid = lessonGuid;
        _baseSoundDirOrUrl = baseSoundDirOrUrl;
    }



    /*
   The following genSoundName() methods create names with the object's guid(s) and the name(s) of
   any words it contains.  These are meant to be human readable.  They're used in two places:
   1) As the sound name used by SoundManager2 in the bar.Sentence Learner web page
   2) As the dummy sound wav file created in the web-app temp dir. These files make sound parsing
      easier.

   NOTE: As part of the workflow to move sounds to their final destination web dir, they'll be
   stripped of the human readable helper words.  Pretty much only guids will remain.  They're more
   stable than the human helper words.
    */
    public String genSoundName(Word w)
    {
        return format("w_%s_%s", NameUtil.toFileSafeName(w.getEnglish()), w.getGuid());
    }

    public  String genSoundName(Reply r)
    {
        return format("r_%s_%s", NameUtil.toFileSafeName(r.getEnglish()), r.getGuid() );
    }

    public  String genSoundName(Sentence s)
    {
        //return "s_${foo.NameUtil.toFileSafeName(s.english)}_${s.guid}";
        return format("s_%s_%s", NameUtil.toFileSafeName(s.getEnglish()), s.getGuid());
    }

    public  String genSoundName(List<Word> words)
    {
        if (words.size() == 1)
        {
            return genSoundName(words.get(0));
        }
        else
        {
            String namePart = NameUtil.toFileSafeName(NameUtil.toEnglishStr(words));
            String guidPart = NameUtil.toFileSafeName(NameUtil.toGuidStr(words));
            //return "p_${namePart}_${guidPart}";
            return format("p_%s_%s", namePart, guidPart);
        }
    }

    /*
   The following genSoundFilePath() methods are used to generate the actual mp3 sound file name,
   relative to the web app root.  The name of each file must be the same as the file name created
   by the .../mybin/lameWav2mp3.rb script.

   These file names don't include the actual word english, unlike the genSoundName() versions.
   Instead, they use only the object guids.  The protects against brittleness when the english
   in a word or sentence changes, it won't break the sound file name.

   The generated file name format is:
    parentDir/hyphenSeparatedGuid(s).mp3
    */

    public String genSoundFilePath(Reply r, SoundSession ses)
    {
        //return "${genSoundFilePathBase(ses)}_r_${r.guid}.mp3";
        return format("%s_r_%s.mp3", genSoundFilePathBase(ses), r.getGuid());
    }


    public String genSoundFilePath(Sentence sen)
    {
        //return "${genSoundFilePathBase(sen.soundSession)}_s_${sen.guid}.mp3";
        return format("%s_s_%s.mp3", genSoundFilePathBase(sen.getSoundSession()), sen.getGuid());
    }

    /*
   Differs slightly from similar named methods above.  File path base name only includes
   sound dir and speaker name.  It doesn't include session date or lesson guid.
    */
    public String genSoundFilePath(Word w, Contributor speaker)
    {
        //return "${_baseSoundDirOrUrl}/${speaker.nickName}_w_${w.guid}.mp3";
        return format("%s/%s_w_%s.mp3", _baseSoundDirOrUrl, speaker.getNickName(), w.getGuid() );
    }

    /*
     NOTE: if the phrase has only 1 word, then treat it like a word.
    */
    public String genSoundFilePath(List<Word> phraseWordList, SoundSession session)
    {
        if (phraseWordList.size() == 1)
        {
            return genSoundFilePath(phraseWordList.get(0), session.getSpeaker());
        }
        else
        {
            //return "${genSoundFilePathBase(session)}_p_${NameUtil.toGuidStr(phraseWordList)}.mp3";
            return format("%s_p_%s.mp3", genSoundFilePathBase(session),
                NameUtil.toGuidStr(phraseWordList) );
        }
    }

    private String genSoundFilePathBase(SoundSession session)
    {
        //NOTE: all data from session must already be a file safe name.
        //return "${_baseSoundDirOrUrl}/${session.speaker.nickName}_${session.genYmdStr()}_${_lessonGuid}";
        return format("%s/%s_%s_%s", _baseSoundDirOrUrl, session.getSpeaker().getNickName(),
            session.genYmdStr(),_lessonGuid);
    }


    /*
    For recordGuide
     */
    public SortedMap sortPhrasesByEnglish(List<List<bar.Word>> wordLists)
    {
        SortedMap smap = new TreeMap();

        for(List<bar.Word> wordList : wordLists)
        {
            smap.put(NameUtil.toEnglishStr(wordList), NameUtil.toThaiStr(wordList));
        }

        return smap;
    }


    /*
    Given a list of words, remove from the list any word already in webapp's sound dir.

    For recordGuide
     */
    public Collection<bar.Word> filterOutRecordedWords(Collection<bar.Word> words,
        Contributor speaker)
    {
        if(words == null)
        {
            return null;
        }

        List<bar.Word> targetWords = new ArrayList<bar.Word>();

        for(bar.Word word : words)
        {
            String soundFilePath = genSoundFilePath(word, speaker);

            File soundFile = new File(soundFilePath);

            if(soundFile.exists())
            {
                targetWords.add(word);
            }
        }

        if (!targetWords.isEmpty())
        {
            words.removeAll(targetWords);
        }

        return words;
    }

    
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
    
    
    /*
    These genSoundId methods are used to create an audio element id.  Then a playSound(soundId)
    javascript method can play the specified sound.
    */

    public String genId(Word w)
    {
        //return "w_${NameUtil.toFileSafeName(w.english)}_${w.guid}"
        return genSoundName(w);
    }

    public String genId(Reply r)
    {
        //return "r_${NameUtil.toFileSafeName(r.english)}_${r.guid}"
        return genSoundName(r);
    }

    public String genId(Sentence s)
    {
        //return "s_${NameUtil.toFileSafeName(s.english)}_${s.guid}"
        return genSoundName(s);
    }

    public String genId(List<Word> wordList)
    {
        /*
        if (wordList.size() == 1)
        {
            return genId(wordList[0])
        }
        else
        {
            String namePart = NameUtil.toFileSafeName(NameUtil.toEnglishStr(wordList));
            String guidPart = NameUtil.toFileSafeName(NameUtil.toGuidStr(wordList));
            return "p_${namePart}_${guidPart}"
        }
        */
        return genSoundName(wordList);
    }


    /*
    These genSoundUrl methods are use to generate the full URL to a sound file.
    */

    public String genUrl(Word w, Contributor speaker)
    {
        //return "${_baseSoundUrl}/${speaker.nickName}_w_${w.guid}.mp3"
        return genSoundFilePath(w,speaker);
    }

    public String genUrl(Reply r, SoundSession ses)
    {
        //return "${genSoundFilePathBase(ses)}_r_${r.guid}.mp3"
        return genSoundFilePath(r,ses);
    }


    public String genUrl(Sentence sen)
    {
        //return "${genSoundFilePathBase(sen.soundSession)}_s_${sen.guid}.mp3"
        return genSoundFilePath(sen);
    }

    /*
   Differs slightly from similar named methods above.  File path base name only includes
   sound dir and speaker name.  It doesn't include session date or lesson guid.
    */


    /*
     NOTE: if the phrase has only 1 word, then treat it like a word.
    */

    public String genUrl(List<Word> phraseWordList, SoundSession session)
    {
        return genSoundFilePath(phraseWordList,session);
/*
        if (phraseWordList.size() == 1)
        {
            return genUrl(phraseWordList[0], session.speaker);
        }
        return "${genSoundFilePathBase(session)}_p_${NameUtil.toGuidStr(phraseWordList)}.mp3"
  */
    }

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
    

    protected final void log(String msg, Object... args)
    {
        System.out.printf(msg, args);
        System.out.println();
    }

}
