package foo;


import java.util.ArrayList;
import java.util.List;

/**
 */
public class AddEditUtil
{

    public static final char DASH = '-';
    public static final char COMMA = ',';
    public static final String WHITESPACE = "\\s+";



    /*
    remove any non thai characters, such as dashes and hyphens.
    the translator may put them into the word, but we don't want them in the normalized version of the word
    that we'll store in the db as the cannonical version.
     */
    public static final String normalizeThaiWord(String s)
    {
        if (s==null)
        {
            return null;
        }
        
        StringBuilder sb = new StringBuilder();

        for(int i=0; i<s.length(); i++)
        {
            if( (s.charAt(i)!=DASH) && (s.charAt(i)!=COMMA) )
            {
                sb.append( s.charAt(i) );
            }
        }
        return sb.toString().trim();
    }


    /*
    turn output of StringTokenizer to a List.  This should trim the tokens too.
     */
     public static final List<String> splitLine(String input)
    {
        List<String> list = new ArrayList<String>();
        for(String str : input.split(WHITESPACE))
        {
            list.add(str);
        }
        return list;
    }


    public static final boolean areSame(String a, String b)
    {
        if(a==b) return true;

        if( (a==null) || (b==null))
        {
            //if a or b is null, then both must be null
            // to get true (they are the same), otherwise false (they're different)
            return ((a==null) && (b==null));
        }

        //remove all white space, then compare
        return delWhitespace(a).equals( delWhitespace(b) );
    }


    public static final String delWhitespace(String s)
    {
        StringBuilder sb = new StringBuilder("");
        for(int i=0; i<s.length(); i++)
        {
            if( !Character.isWhitespace( s.charAt(i) ) )
            {
                sb.append(s.charAt(i));
            }
        }
        return sb.toString();
    }


    public static final String retNullOrNonEmptyStr(String val)
    {
        if (val==null) return null;
        if (val.trim()=="") return null;
        else return val;
    }


    private static final boolean isStrParam(Object obj)
    {
        return obj instanceof String;
    }

    /*
    NOTE: Also converts the string "null" to "".
     */
    private static final String retNullOrValOrFirstValInList(Object obj)
    {
        if(obj==null) return null;

        if(isStrParam(obj))
        {
            return (String)obj;
        }
        else
        {
            return ((List<String>)obj).get(0);
        }
    }

}
