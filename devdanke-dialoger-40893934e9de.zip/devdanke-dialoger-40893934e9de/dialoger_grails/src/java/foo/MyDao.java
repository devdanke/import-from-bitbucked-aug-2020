package foo;

import bar.Sentence;
import bar.SentenceLesson;

import java.util.ArrayList;
import java.util.List;

import bar.Word;
import groovy.lang.GroovyObjectSupport;
import org.springframework.validation.ObjectError;

/**
 */
public class MyDao
{
    /*
    private static final Object[] NO_ARGS =  new Object[]{};
    private static MyDao _instance;

    private MyDao(){ }

    public synchronized static MyDao getInstance()
    {
        if(_instance == null)
        {
            _instance = new MyDao();
        }
        return _instance;
    }


    public SentenceLesson findLessonById(long id)
    {
        return SentenceLesson.myFindById(id);
    }

    public List<SentenceLesson> findAllLessons(String query, int maxCount)
    {
        return SentenceLesson.myFindAllByQuery(query,maxCount);
    }


    public Sentence findSentenceById(long id)
    {
        return Sentence.myFindById(id);
    }


    public <T extends GroovyObjectSupport> boolean save(T entity)
    {
        entity.invokeMethod("validate", NO_ARGS);
        List<ObjectError> errors = (List<ObjectError>) entity.invokeMethod("errors", NO_ARGS);
        if(!errors.isEmpty())
        {
            for(ObjectError error : errors)
            {
                System.out.println("DB error: save: " + error.toString());
            }
            return false;
        }

        long id = getId(entity);
        if( ((Boolean) entity.invokeMethod("save", NO_ARGS)) )
        {
            System.out.println("id="+id+" saved ok.");
            return true;
        }
        else
        {
            System.out.println("save failed, id=" + id);
            return false;
        }
    }


    public <T extends GroovyObjectSupport> long getId(T entity)
    {
        return (Long) entity.getProperty("id");
    }


    public <T extends GroovyObjectSupport> boolean delete(T entity)
    {

        Long id = getId(entity);
        if( ((Boolean) entity.invokeMethod("delete", NO_ARGS)) )
        {
            System.out.println("id=" + id + " deleted ok.");
            return true;
        }
        else
        {
            System.out.println("delete failed, id=" + id);
            return false;
        }
    }



     //Removes all words, translator, and speaker from sentence
     //before deleting sen itself.

    public boolean deleteSen(Sentence sen)
    {
        List<Word> words = sen.getWords();
        if((words != null ) && !words.isEmpty())
        {
            List<Word> targWords = new ArrayList<Word>();
            targWords.addAll(words);

            for(Word target : targWords)
            {
                sen.invokeMethod("removeFromWords", new Object[]{target} );
            }
        }

        sen.setTranslator(null);
        sen.setSoundSession(null);

        return delete(sen);
    }
    */

}
