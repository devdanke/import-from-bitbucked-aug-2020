package foo;



/**
 * *************************************************************************************
 *
 * @Since 11/2011
 * <p/>
 * *************************************************************************************
 */
public class Conf
{

    //i think this is to check if a sound was already recorded.
    //it could help when rerecording bad sound files.
    public static final String LOCAL_FS_ROOT_SOUND_DIR = "/Users/me/_dev/dialoger/dialoger_grails/web-app/WEB-INF/sound_root";

    //to gen dummy sound files that make it easier to parse a big audio file from a sound session.
    public static final String LOCAL_FS_DUMMY_SOUND_DIR = "/Users/me/_dev/dialoger/dialoger_grails/web-app/WEB-INF/sound_dummy";

    //for sounds getting played in learner page
    public static final String EXT_SOUND_BASE_URL = "http://localhost:80/dialog/sound";
}
