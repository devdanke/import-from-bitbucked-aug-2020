package foo;

/**
 */
public enum SentenceAction
{
    DELETE("deleteSen"),
    MOVE_UP("moveUp"),
    MOVE_DOWN("moveDown"),
    ADD_REPLY("addReply"),
    UPDATE(false,"Update");

    private boolean _isStructuralChange;
    private String _name;

    private SentenceAction(boolean isStructuralChange, String name)
    {
        _isStructuralChange = isStructuralChange;
        _name = name;
    }

    private SentenceAction(String name)
    {
        this(true,name);
    }

    public boolean isStructuralChange()
    {
        return _isStructuralChange;
    }

    public String getName()
    {
        return _name;
    }

    public static SentenceAction toEnum(String name)
    {
        for(SentenceAction sa : SentenceAction.values())
        {
            if(sa.getName().equals(name)) return sa;
        }
        throw new RuntimeException("Unknown SentenceAction name: '" + name +"'");
    }


}

