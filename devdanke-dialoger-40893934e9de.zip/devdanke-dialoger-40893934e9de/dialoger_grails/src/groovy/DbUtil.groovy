import bar.Sentence

/*
logs error to stdout when a save fails.
*/
class DbUtil {

    static boolean save(Object entity, String name){

        entity.validate()
        if(entity.hasErrors()) {
            entity.errors.each { println( "* ${name}: ${it}" ) }
            return false
        }

        if( entity.save() ){
            println("* ${name}: with id=${entity.id} saved ok.")
            return true
        }
        else{
            println("${name}: had no errors, but save to db failed.")
            return false
        }
    }


    static boolean delete(Object entity, String name){

        def id = entity.id
        if( entity.delete() ){
            println("* ${name}: with id=${id} deleted ok.")
            return true
        }
        else{
            println("* ${name}: had no errors, but delete to db failed.")
            return false
        }
    }

    /*
     Removes all words, translator, and speaker from sentence
     before deleting sen itself.
     */
    static boolean deleteSen(Sentence sen){

        def id = sen.id
        if(sen.words?.size()>0){

            def myWordList = []
            sen.words.each { word ->
                myWordList.add(word)
            }
            myWordList.each { word ->
                sen.removeFromWords(word)
            }
        }

        sen.translator = null
        sen.soundSession = null
        
        if( sen.delete() ){
            println("* sen id=${id} deleted ok.")
            return true
        }
        else{
            println("* sen id=${id} had no errors, but delete to db failed.")
            return false
        }
    }
}