/**
 * Date: Jul 8, 2008
 *
 * This script will swap word id's in words and phrases.
 * It's used when I replace a faulty word in a sentence with a good one.
 * It takes two input params -o/--oldWordGuid & -n/--newWordGuid.
 */


def rootDir = "D:/_LINGO/__prod_sound"

if (args.length == 2){

    def oldWordGuid = args[0]
    def newWordGuid = args[1]
    println "* oldWordGuid=${oldWordGuid}, newWordGuid=${newWordGuid}, "

    new File(rootDir ).eachFileRecurse{ srcFile ->
        def String name = srcFile.name
        if( (name.startsWith("w_") || name.startsWith("p_")) && (name.contains(oldWordGuid))){

            //show all w_ and p_ files under root dir whose name has oldWordGuid.
            println "* targ=${name}"

            //for target files, replace oldWordGuid with newWordGuid.
            def newFileName = "${srcFile.parentFile.absolutePath}/${name.replaceAll(oldWordGuid, newWordGuid)}"
            println "* newFileName=${newFileName}"
            srcFile.renameTo( new File( newFileName ))
        }
    }
}
else{

    println("Usgage: WordSwapUtil oldWordGuid newWordGuid")
}


