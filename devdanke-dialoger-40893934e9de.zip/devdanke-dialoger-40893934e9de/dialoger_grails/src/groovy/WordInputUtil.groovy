import foo.NameUtil
import bar.Word

/**
 * Date: May 28, 2008
 */
class WordInputUtil {

    def String genSoundName(Word w){
        return "w_${w.guid}_${NameUtil.toFileSafeName(w.english)}"
    }

    /* Find the size of biggest string amoung: thai, eng, or phonetic */
    def maxSize(Word word){
        def size = word.thai.length()
        if(word.english?.length() > size ) size = word.english.length()
        if(word.phonetic?.length() > size ) size = word.phonetic.length()
        return size
    }

}