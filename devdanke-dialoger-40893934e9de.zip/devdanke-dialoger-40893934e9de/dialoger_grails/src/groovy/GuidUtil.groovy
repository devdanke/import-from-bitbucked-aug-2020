import java.text.SimpleDateFormat

/**
 * Date: May 20, 2008
 */
public class GuidUtil
{
    static GuidUtil gu;
    static Long nowMillis = System.currentTimeMillis();

    static synchronized GuidUtil getInstance(){

        if(gu == null) gu = new GuidUtil();
        return gu;
    }

    def synchronized Long nextGuid(){
        nowMillis++;
        def SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmssSSS")
        return new Long(sdf.format(new Date(nowMillis)))
    }

}
