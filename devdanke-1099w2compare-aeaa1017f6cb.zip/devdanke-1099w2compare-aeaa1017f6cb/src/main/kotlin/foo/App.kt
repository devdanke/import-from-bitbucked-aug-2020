package foo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class W21099CompareApplication

fun main(args: Array<String>) {
    runApplication<W21099CompareApplication>(*args)
}
