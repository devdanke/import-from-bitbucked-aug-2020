package foo

fun String.rightJustify(width: Int): String {

    if(this.length > width) throw RuntimeException("string length ${this.length} greater than width $width")

    val spaces = " ".repeat(width - this.length)
    return "${spaces}${this}"
}

fun String.leftJustify(width: Int): String {

    if(this.length > width) throw RuntimeException("string length ${this.length} greater than width $width")

    val spaces = " ".repeat(width - this.length)
    return "${this}${spaces}"
}

fun Int.commafy(): String {

    return this.toString().reversed().chars().toArray()
            .mapIndexed { index, chInt ->
                if((index > 0) && (index % 3==0) && (chInt != '-'.toInt()))
                    ",${chInt.toChar()}"
                else
                    chInt.toChar() }
            .joinToString(separator = "").reversed()
}

fun Int.negate(negate: Boolean): Int = if(negate) (this * -1) else this



