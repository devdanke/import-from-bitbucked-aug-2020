package foo

interface IItemGroup {

    fun name(): String
    fun data(): HashMap<String,Int>
    fun sum() = data().values.sum()
    fun getVal(k: String): Int {
        return checkNotNull(data()[k])
    }
}

class Result(val name: String) {

    // max amount you can make from work itself.
    var maxWages = 0
    // amount you actually made from work
    var actualWages = 0

    val plusGroups = mutableListOf<IItemGroup>()
    val minusGroups = mutableListOf<IItemGroup>()

    // actualWages - expenses
    fun netIncome(): Int {

        val totExpenses: Int = minusGroups.fold(0){ acc, it -> acc + it.sum()}
        val totCashBenefits: Int = plusGroups.fold(0){ acc, it -> acc + it.sum()}

        return actualWages + totCashBenefits - totExpenses
    }
}


class NonCashBenefits(): IItemGroup {

    var holidayCost = 0;
    var ptoCost = 0;

    var insureMedical = 0
    var insureDental = 0
    var insureVision = 0
    var insureLtd = 0
    var insureStd = 0
    var insureOther = 0  // legal ins etc

    // other benefits
    var commuterBenefit = 0
    var flexSpendAcct = 0  // pre tax money for medical etc
    
    override fun name() = "non-cash benefits"

    override fun data(): LinkedHashMap<String,Int> {
        val dat = LinkedHashMap<String,Int>()

        dat.put( "holidayCost", holidayCost )
        dat.put( "ptoCost", ptoCost )
        dat.put( "insureMedical", insureMedical )
        dat.put( "insureDental", insureDental )
        dat.put( "insureVision", insureVision )
        dat.put( "insureLtd", insureLtd )
        dat.put( "insureStd", insureStd )
        dat.put( "insureOther", insureOther )

        return dat
    }
}

class CashBenefits(): IItemGroup {

    var four01kMatch = 0

    override fun name() = "cash benefits"

    override fun data(): LinkedHashMap<String,Int> {
        val dat = LinkedHashMap<String,Int>()

        dat.put( "four01kMatch", four01kMatch )

        return dat
    }
}

class IndyBizExpenses(): IItemGroup {

    var selfEmployTaxFed = 0
    var selfEmployTaxState = 0
    var selfEmployTaxCity = 0

    var bizFeesState = 0
    var bizFeesCity = 0
    var bizFeeTaxPrep = 0

    var insureBiz = 0 // business umbrella insurance
    var insureBizVehicle = 0

    override fun name() = "biz expenses"

    override fun data(): LinkedHashMap<String,Int> {
        val dat = LinkedHashMap<String,Int>()

        dat.put( "selfEmployTaxFed", selfEmployTaxFed )
        dat.put( "selfEmployTaxState", selfEmployTaxState )
        dat.put( "selfEmployTaxCity", selfEmployTaxCity )
        dat.put( "bizFeesState", bizFeesState )
        dat.put( "bizFeesCity", bizFeesCity )
        dat.put( "bizFeeTaxPrep", bizFeeTaxPrep )
        dat.put( "insureBiz", insureBiz )
        dat.put( "insureBizVehicle", insureBizVehicle )

        return dat
    }
}