package foo

import kotlin.math.roundToInt

val YEARLY_MAX_WORK_DAYS = 52 * 5
val YEARLY_MAX_WORK_HOURS = YEARLY_MAX_WORK_DAYS * 8
val DEFAULT_PAID_HOLIDAYS = 8
val DEFAULT_PTO_DAYS = 10


interface IWorkMode {
    fun summary(): Result
}


class Ten99(val hourlyRate: Int, val holidays: Int = DEFAULT_PAID_HOLIDAYS, val ptoDays: Int = DEFAULT_PTO_DAYS,
        val name:String="1099") : IWorkMode {

    override fun summary(): Result  {

        val dayWage = hourlyRate * 8

        val r = Result(name)

        r.maxWages = hourlyRate * YEARLY_MAX_WORK_HOURS

        val actualDays = YEARLY_MAX_WORK_DAYS - (holidays + ptoDays)

        r.actualWages = actualDays * (hourlyRate * 8)

        ///////////////////////////////////
        // benefits a 1099 worker must provide themself
        val benefitExpenses = NonCashBenefits()

        benefitExpenses.holidayCost = holidays * dayWage
        benefitExpenses.ptoCost = ptoDays * dayWage

        benefitExpenses.insureMedical = 1100 * 12
        benefitExpenses.insureDental = 60 * 12

        benefitExpenses.commuterBenefit = actualDays * 3
        benefitExpenses.flexSpendAcct = 100

        r.minusGroups.add(benefitExpenses)

        ///////////////////////////////////
        // even more benefits a 1099 worker must provide themself
        val cashBenefits = CashBenefits()
        cashBenefits.four01kMatch = (0.03 * 5000).toInt()
        r.minusGroups.add(cashBenefits)

        ////////////////////////////////////
        // expenses a 1099 probably must pay
        val bizExpenses = IndyBizExpenses()

        bizExpenses.selfEmployTaxFed = (0.075 * (dayWage * actualDays)).roundToInt()
        bizExpenses.selfEmployTaxState = (0.015 * (dayWage * actualDays)).roundToInt()
        bizExpenses.selfEmployTaxCity = (0.003 * (dayWage * actualDays)).roundToInt()

        bizExpenses.bizFeesState = 300
        bizExpenses.bizFeesCity = 100

        bizExpenses.insureBiz = 500

        r.minusGroups.add(bizExpenses)

        return r
    }
}


class W2(var yearlySalary: Int, var holidays: Int = DEFAULT_PAID_HOLIDAYS, val ptoDays: Int = DEFAULT_PTO_DAYS,
        val name:String="W2")  : IWorkMode {

    override fun summary(): Result {

        val r = Result(name)

        r.maxWages = yearlySalary
        r.actualWages = yearlySalary

        ///////////////////////////////////
        // even more benefits a 1099 worker must provide themself
        val cashBenefits = CashBenefits()
        cashBenefits.four01kMatch = (0.03 * 5000).toInt()

        r.plusGroups.add(cashBenefits)

        return r
    }
}

