package foo



class ValSource(val itemGroup: IItemGroup?) {
    fun getVal(itemName: String, negate: Boolean): String {
        if(itemGroup != null) {
            return itemGroup.getVal(itemName).negate(negate).commafy()
        }
        else {
            return "-"
        }
    }
}


class Formatter (dataCol1: Result, dataCol2: Result, dataCol3: Result){

    val displayLabels = mutableListOf<String>()
    val dataCol1Vals = mutableListOf<String>()
    val dataCol2Vals = mutableListOf<String>()
    val dataCol3Vals = mutableListOf<String>()


    init {
        addColHeaderRow(dataCol1.name, dataCol2.name , dataCol3.name)
        addLineRow()

        addRow("max wages", dataCol1.maxWages, dataCol2.maxWages, dataCol3.maxWages)
        addRow("actual wages", dataCol1.actualWages, dataCol2.actualWages, dataCol3.actualWages)

        extractLabelsAndValues(dataCol1.plusGroups, dataCol2.plusGroups, dataCol3.plusGroups)
        extractLabelsAndValues(dataCol1.minusGroups, dataCol2.minusGroups, dataCol3.minusGroups, negateVals = true)

        addLineRow()
        addRow("net income", dataCol1.netIncome(), dataCol2.netIncome(), dataCol3.netIncome())
    }


    private fun extractLabelsAndValues(col1Data: List<IItemGroup>, col2Data: List<IItemGroup>, col3Data: List<IItemGroup>,
            negateVals: Boolean = false) {

        val col1GroupsMap = toMap(col1Data)
        val col2GroupsMap = toMap(col2Data)
        val col3GroupsMap = toMap(col3Data)

        val uniqueGroupNames = mutableSetOf<String>()
        uniqueGroupNames.addAll(col1GroupsMap.keys)
        uniqueGroupNames.addAll(col2GroupsMap.keys)
        uniqueGroupNames.addAll(col3GroupsMap.keys)

        uniqueGroupNames.forEach { groupName ->

            addSectionHeaderRow("[$groupName]")

            val col1Group = col1GroupsMap[groupName]
            val col2Group = col2GroupsMap[groupName]
            val col3Group = col3GroupsMap[groupName]

            val labels = listOf(col1Group, col2Group, col3Group).find{ it != null }!!.data().keys
            val col1ValSrc = ValSource(col1Group)
            val col2ValSrc = ValSource(col2Group)
            val col3ValSrc = ValSource(col3Group)

            labels.forEach { itemName ->
println("negateVales= $negateVals")
                displayLabels.add(itemName)
                dataCol1Vals.add(col1ValSrc.getVal(itemName, negateVals))
                dataCol2Vals.add(col2ValSrc.getVal(itemName, negateVals))
                dataCol3Vals.add(col3ValSrc.getVal(itemName, negateVals))
            }
        }
    }


    private fun addRow(displayLabel: String, c1Val: Int, c2Val: Int, c3Val: Int) {
        displayLabels.add(displayLabel)
        dataCol1Vals.add(c1Val.commafy())
        dataCol2Vals.add(c2Val.commafy())
        dataCol3Vals.add(c3Val.commafy())
    }
    private fun addLineRow() {
        displayLabels.add("---------")
        dataCol1Vals.add("---------")
        dataCol2Vals.add("---------")
        dataCol3Vals.add("---------")
    }
    private fun addSectionHeaderRow(sectionName: String) {
        displayLabels.add(sectionName)
        dataCol1Vals.add("")
        dataCol2Vals.add("")
        dataCol3Vals.add("")
    }
    private fun addColHeaderRow(c1Name: String, c2Name: String, c3Name: String) {
        displayLabels.add("")
        dataCol1Vals.add(c1Name)
        dataCol2Vals.add(c2Name)
        dataCol3Vals.add(c3Name)
    }


    private fun toMap(itemGroups: List<IItemGroup>): Map<String,IItemGroup> {

        val map = HashMap<String,IItemGroup>()

        itemGroups.forEach{ map[it.name()] = it }

        return map
    }


    private fun maxWidth(l: List<String>): Int = l.map { it.length }.max() ?: 0

    fun printable(): String {

        val col1MaxWidth = maxWidth(displayLabels)
        val col2MaxWidth = maxWidth(dataCol1Vals)
        val col3MaxWidth = maxWidth(dataCol2Vals)
        val col4MaxWidth = maxWidth(dataCol3Vals)

        val sb = StringBuilder()
        for(i in displayLabels.indices) {
            sb.append(displayLabels[i].leftJustify(col1MaxWidth+2))
            sb.append(dataCol1Vals[i].rightJustify(col2MaxWidth+3))
            sb.append(dataCol2Vals[i].rightJustify(col3MaxWidth+3))
            sb.append(dataCol3Vals[i].rightJustify(col4MaxWidth+3))
            sb.append("\n")
        }

        return sb.toString()
    }

}