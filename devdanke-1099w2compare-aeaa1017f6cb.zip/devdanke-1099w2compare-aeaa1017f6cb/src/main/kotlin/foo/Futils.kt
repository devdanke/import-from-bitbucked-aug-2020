package foo

class Futils {
    companion object {
        fun monthlyToDaily(benefits: List<Int>): Int {
            return Math.round(((benefits.sum() * 12) / 52.toDouble()) / 5).toInt()
        }

        fun yearlyToDaily(benefits: List<Int>): Int {
            return Math.round((benefits.sum() / 52.toDouble()) / 5).toInt()
        }

        fun maybeNeg(n: Int) = if(n>0) "-$n" else n.toString()
    }
}