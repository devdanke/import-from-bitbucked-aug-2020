package foo

import org.junit.Test


class MyTest {

    @Test
    fun ten99vsW2() {

        val ten99 = Ten99(hourlyRate = 95).summary()
        val w2company = W2(yearlySalary = 150_000, name = "W2-Company").summary()
        val w2agency = W2(yearlySalary = 666, name = "W2-Agency").summary()

        println(Formatter(ten99, w2company, w2agency).printable())
    }

}
