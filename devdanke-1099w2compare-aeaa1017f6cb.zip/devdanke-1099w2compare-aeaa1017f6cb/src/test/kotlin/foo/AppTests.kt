package foo

import org.junit.Test


class AppTests {

	@Test
	fun fooTest() {



	}


    fun netHourlyContractorAnnualIncome(hrlyRate: Int, maxWorkableHours: Int): Int {

        val hrlyRate = 94;
        val maxWorkableDays = 52 * 5;
        val maxWorkableHours = maxWorkableDays * 8;
        val maxIncome = hrlyRate * maxWorkableHours;

        val fedHolidaysObserved = 10 - 5

        val income = maxIncome - (fedHolidaysObserved * 8 * hrlyRate);

        val fedIncTaxRate = 0.1;
        val ficaTaxRate = 0.1;
        val totFedTax = income * (fedIncTaxRate + fedIncTaxRate);

        val stateBizTaxRate = 0.03;
        val stateLlcFee = 100;
        val stateBizLicFee = 100;

        val stateTax = income * stateBizTaxRate;
        val stateFees = stateLlcFee + stateBizLicFee;
        val totStateTaxEtc = stateTax + stateFees;

        val cityBizTaxRate = 0.01;
        val cityBizLicFee = 100;

        val totCityTaxEtc = (income * cityBizTaxRate) + cityBizLicFee;

        val monthlyDentalIns = 50;
        val monthlyMedicalIns = 1000;
        val monthlyEyeIns = 1000;

        return 0;
    }
}


/*
official name of social security is
Old Age, Survivors and Disability Insurance program (OASDI)
FICA is ss & medicare
If income > 200k/yr, then must pay 0.9 medicare surtax.

So, it looks like medicare is 2 * 1.45% for self employeed.

In other words, you withhold a 6.2 percent Social Security tax from your employee’s wages and
you pay an additional 6.2 percent as your employer share of the tax (6.2 employee portion + 6.2
employer portion = 12.4 percent total). Also, you withhold a 1.45 percent Medicare tax from your
employee’s wages and you pay an additional 1.45 percent as your employer share (1.45 employee
portion + 1.45 employer portion = 2.9 percent total). The total of all four portions is 15.3
percent (6.2 percent employee portion of Social Security + 6.2 percent employer portion of Social
Security + 1.45 percent employee portion of Medicare + 1.45 percent employer portion of
Medicare = 15.3 percent).
 */
data class FedTax (val income: Int, val selfEmployed: Boolean) {

    val SS_EMPLOYEE_PART_RATE = 0.062;
    val SS_EMPLOYER_PART_RATE = 0.062;
    val SS_CUTOFF_INCOME_2018 = 128700;

    val MEDICARE_RATE = 0.0145

    fun calcTotalAmount(): Double {

        val ssTaxRate = if(selfEmployed) { SS_EMPLOYEE_PART_RATE + SS_EMPLOYER_PART_RATE }
        else { SS_EMPLOYEE_PART_RATE };

        val ssWages = if(income > SS_CUTOFF_INCOME_2018) { SS_CUTOFF_INCOME_2018 } else { income };

       return (ssWages * ssTaxRate) + (income * MEDICARE_RATE);
    }
}

data class StateTaxEtc (val income: Int) {

    val SS_EMPLOYEE_PART_RATE = 0.062;
    val SS_EMPLOYER_PART_RATE = 0.062;
    val SS_CUTOFF_INCOME_2018 = 128700;

    val MEDICARE_RATE = 0.0145

    fun calcTotalAmount(selfEmployed: Boolean): Double {

        val ssTaxRate = if(selfEmployed) { SS_EMPLOYEE_PART_RATE + SS_EMPLOYER_PART_RATE }
        else { SS_EMPLOYEE_PART_RATE };

        val ssWages = if(income > SS_CUTOFF_INCOME_2018) { SS_CUTOFF_INCOME_2018 } else { income };

        return (ssWages * ssTaxRate) + (income * MEDICARE_RATE);
    }
}
