package foo.bar.habiforma

import com.fasterxml.jackson.dataformat.xml.XmlMapper
import com.fasterxml.jackson.module.kotlin.KotlinModule
import com.fasterxml.jackson.module.kotlin.readValue
import java.io.File
import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory
import org.h2.value.DataType.readValue
import java.util.concurrent.TimeUnit

fun String.runCommand(workingDir: File=File(".")) {

    ProcessBuilder(*split(" ").toTypedArray())
            .directory(workingDir)
            .redirectOutput(ProcessBuilder.Redirect.INHERIT)
            .redirectError(ProcessBuilder.Redirect.INHERIT)
            .start()
            .waitFor(60, TimeUnit.MINUTES)

}


fun myfunc() {
    val pomXml = File("./pom.xml").readText()

    val mapper = XmlMapper()
    val data = mapper.readValue<Map<String,Object>>(pomXml)

    val rawVersion = data["version"].toString()
    val verOnly = rawVersion.substring(0, rawVersion.indexOf("-SNAPSHOT"))
    val chunx = verOnly.split(".").toMutableList()
    val patchVer = chunx[2].toInt()
    val lastRelPatchVer = patchVer - 1
    chunx[2] = lastRelPatchVer.toString()
    val lastRelVerProbably = chunx.joinToString(".")

// https://aws.amazon.com/blogs/developer/deploying-java-applications-on-elastic-beanstalk-from-maven/

    println("version: '${lastRelVerProbably}'")

    val repoRootPath = "/Users/me/_dev/zMyFakeMavenReleaseRepo/foo/bar/habiforma2"
    val artifactPath = "${repoRootPath}/${lastRelVerProbably}/habiforma2-${lastRelVerProbably}.jar"

    "mvn aws:deploy -DdeployArtifact=${artifactPath}".runCommand()
}

fun main(args : Array<String>) {
    myfunc()
}


