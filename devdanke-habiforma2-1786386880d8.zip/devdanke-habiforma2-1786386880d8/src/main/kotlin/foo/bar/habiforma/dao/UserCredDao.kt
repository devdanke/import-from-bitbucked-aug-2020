package foo.bar.habiforma.dao

import mu.KLoggable
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
import java.time.ZonedDateTime
import java.util.*

@Component
class UserCredDao @Autowired constructor(val dbHelper: H2DbHelper) {

    companion object: Any(), KLoggable {

        override val logger = logger()

        val USER_CRED_TABLE = "USER_CRED"

        // id is uuid,
        val CREATE_USER_CRED_TABLE =
                """
        CREATE TABLE ${USER_CRED_TABLE} (
            id                  VARCHAR(100)  PRIMARY KEY,
            user_name           VARCHAR(100)  NOT NULL,
            pswd_salt           VARCHAR(100)  NOT NULL,
            hashed_pswd         VARCHAR(100)  NOT NULL,
            created             TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT unique_username_key UNIQUE (user_name)
        )""".trimIndent()

        // todo: revise this from habit backup to user cred
        val SELECT_COLS_FOR_IMPORT = "SELECT id, user_name, pswd_salt, hashed_pswd, " +
                "convert(parseDateTime(created,'yyyy-MM-dd hh:mm:ss.SSS'),timestamp) AS created"
    }

    init {
        dbHelper.createTable(CREATE_USER_CRED_TABLE)
        if(dbHelper.canBackupDb) {
            dbHelper.importDbData(USER_CRED_TABLE, SELECT_COLS_FOR_IMPORT)
        }
    }


    fun getUserCred(username: String): UserCredData? {

        val sql = "SELECT * FROM ${USER_CRED_TABLE} WHERE user_name= :username "
        val handle = dbHelper.jdbi.open();

        return handle.createQuery(sql)
                .bind("username", username)
                .mapToMap()
                .map { UserCredData(it["id"] as String, it["user_name"] as String, it["pswd_salt"] as String,
                        it["hashed_pswd"] as String, it["created"] as Date) }
                .firstOrNull()
    }


    /*
     returns userId guid
     throws if userName already exists.
     */
    fun createUserCred(username: String, hashword: String, salt: String, now: ZonedDateTime): CreateUserCredResult {

        try {

            val guid = UUID.randomUUID().toString()
            val sql = "INSERT INTO ${USER_CRED_TABLE} (id, user_name, pswd_salt, hashed_pswd) VALUES " +
                    "( :guid, :username, :salt, :hashword)"
            val h = dbHelper.jdbi.open();

            h.createUpdate(sql)
                    .bindMap(mapOf("guid" to guid,"username" to username,"salt" to salt,"hashword" to hashword))
                    .execute()

            dbHelper.exportTableData(USER_CRED_TABLE)

            return CreateUserCredResult(success = true, duplicate = false, userId = Optional.of(guid))
        }
        catch (e: Exception) {
            //          throw Exception("User already exists") // or return data class with nice fields.
            logger.warn { "Can't create userCred.  Reason: ${e.message}"}
            // todo distinguish between duplicate key violation or other error.
            return CreateUserCredResult(success=false,duplicate=true, userId=Optional.empty())
        }
//        else {
  //          throw Exception("User already exists") // or return data class with nice fields.
    //    }
    }

    data class CreateUserCredResult constructor(val success:Boolean, val duplicate:Boolean, val userId: Optional<String>)
}