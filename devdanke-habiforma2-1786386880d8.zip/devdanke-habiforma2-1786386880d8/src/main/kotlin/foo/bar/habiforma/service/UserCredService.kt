package foo.bar.habiforma.service

import org.springframework.beans.factory.annotation.Autowired

import java.time.ZonedDateTime
import foo.bar.habiforma.dao.UserCredDao
import mu.KLoggable
import java.security.SecureRandom
import org.mindrot.jbcrypt.BCrypt
import org.springframework.stereotype.Component

/*
Make username case insensitive. Always convert it to lowercase when is first comes to this service.
 */
@Component
class UserCredService @Autowired constructor(val dao: UserCredDao) {

    companion object: Any(), KLoggable {

        override val logger = logger()
        val secRand = SecureRandom()
    }

    /*
    returns userId guid
    throws if userName already exists. (actually maybe just return somekind of false if not found)
     */
    fun createUserCred(someUsername: String, password: String, now: ZonedDateTime): UserCredDao.CreateUserCredResult {
        val username = normalizeUsername(someUsername)
        val hashed = hash(password, BCrypt.gensalt())
        return dao.createUserCred(username, hashed.hashword, hashed.salt, now)
    }

    fun isLegit(someUsername: String, password: String): Boolean {
        val username = normalizeUsername(someUsername)
        val userCred = dao.getUserCred(username)
        if(userCred != null) {
            val candidateHashword = hash(password, userCred.pswdSalt).hashword
            return (userCred.hashedPswd == candidateHashword)
        }
        else {
            return false
        }
    }

    private fun hash(password: String, salt: String): HashResult {
        val hashword = BCrypt.hashpw(password, salt)
        return HashResult(hashword, salt)
    }


    private fun normalizeUsername(username:String) = username.toLowerCase()

    private data class HashResult(val hashword: String, val salt: String)
}