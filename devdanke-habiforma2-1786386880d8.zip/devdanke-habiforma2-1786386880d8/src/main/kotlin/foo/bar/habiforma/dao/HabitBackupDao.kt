package foo.bar.habiforma.dao

import mu.KLoggable
import org.jdbi.v3.core.kotlin.mapTo
import org.springframework.stereotype.Component
import java.time.ZonedDateTime
import java.util.*
import org.springframework.beans.factory.annotation.Autowired

/*
todo:
- make real mapper of row to data class (using kotlin plugin approach)
- use real binding vars instead of text interpolation for sql.
 */
@Component("h2")
class HabitBackupDao @Autowired constructor(val dbHelper: H2DbHelper): IHabitBackupDao {

    companion object: Any(), KLoggable {

        val MAX_USER_BACKUPS_COUNT = 10

        override val logger = logger()

        val HABIT_BACKUP_TABLE = "HABIT_BACKUP"
        val CREATE_HABIT_BACKUP_DATA_TABLE =
        """
        CREATE TABLE ${HABIT_BACKUP_TABLE} (
            id          VARCHAR(100)  PRIMARY KEY,
            user_id     VARCHAR(100)  NOT NULL,
            habit_data  VARCHAR(5120) NOT NULL,
            created     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""".trimIndent()

        val SELECT_COLS_FOR_IMPORT = "SELECT id, user_id, habit_data, " +
                "convert(parseDateTime(created,'yyyy-MM-dd hh:mm:ss.SSS'),timestamp) AS created"

        val LONG_TIME_AGO = ZonedDateTime.now().minusYears(1000)
    }

    init {
        dbHelper.createTable(CREATE_HABIT_BACKUP_DATA_TABLE)
        if(dbHelper.canBackupDb) {
            dbHelper.importDbData(HABIT_BACKUP_TABLE, SELECT_COLS_FOR_IMPORT)
        }
    }


    override fun getBackups(userId: String, afterDate: Optional<ZonedDateTime>): List<HabitBackupData> {

        val sql = "SELECT * FROM ${HABIT_BACKUP_TABLE} WHERE user_id= ? AND created > ? ORDER BY created"
        val handle = dbHelper.jdbi.open()

        return handle.createQuery(sql)
                .bind(0, userId)
                .bind(1, if(afterDate.isPresent) afterDate else LONG_TIME_AGO )
                .mapToMap()
                .list()
                .map { HabitBackupData(it["id"] as String, it["user_id"] as String, it["habit_data"] as String,
                        it["created"] as Date) }
    }

    override fun getBackup(userId: String, backupId: String): HabitBackupData? {

        val sql = "SELECT * FROM ${HABIT_BACKUP_TABLE} WHERE id= :backupId AND user_id= :userId ORDER BY created"
        val handle = dbHelper.jdbi.open();

        return handle.createQuery(sql)
                .bind("backupId", backupId)
                .bind("userId", userId)
                .mapToMap()
                .list()
                .map { HabitBackupData(it["id"] as String, it["user_id"] as String, it["habit_data"] as String, it["created"] as Date) }
                .firstOrNull()
    }

    // todo: right way to handle now date?  wanted for date testing, otherwise don't need.
    override fun createBackup(userId: String, habitData: String, now: ZonedDateTime): String {

        // handle possible duplicates
        if(isDuplicateBackup(HABIT_BACKUP_TABLE, userId, habitData)) {
            deleteDuplicateBackups(HABIT_BACKUP_TABLE, userId, habitData)
        }

        // normal backup
        val guid = UUID.randomUUID().toString()
        val params = mapOf("guid" to guid, "userId" to userId, "habitData" to habitData)

        val sql = "INSERT INTO ${HABIT_BACKUP_TABLE} (id, user_id, habit_data) VALUES ( :guid, :userId, :habitData )"
        val h = dbHelper.jdbi.open();

        h.createUpdate(sql).bindMap(params).execute()

        // handle possible too many backups
        deleteAnyExcessBackups( userId, MAX_USER_BACKUPS_COUNT)

        dbHelper.exportTableData(HABIT_BACKUP_TABLE)

        return guid
    }



    private fun deleteAnyExcessBackups(userId: String, maxUserBackupsCount: Int) {

        val count = dbHelper.rowCount(HABIT_BACKUP_TABLE, userId)
        if(count > maxUserBackupsCount) {

            val reapCount = (count - maxUserBackupsCount)
            deleteOldestRows(HABIT_BACKUP_TABLE, userId, reapCount)
        }
    }


    /*
    for the given user, delete the reapCount oldest rows by created date.
     */
    private fun deleteOldestRows(tableName: String, userId: String, reapCount: Int) {

        val subSelectOldestForUser = "SELECT TOP ${reapCount} id FROM ${tableName} WHERE user_id = :userId ORDER BY created ASC"
        val delSql = "DELETE FROM ${tableName} WHERE id IN ( ${subSelectOldestForUser}) ;"
        val delRowsCount = dbHelper.jdbi.open()
                .createUpdate(delSql)
                .bind("userId", userId)
                .execute()

        logger.debug { "For user ${userId}, deleted the ${delRowsCount} oldest row(s)." }
    }


    private fun deleteRows(tableName: String, userId: String, reapCount: Int) {

        val subSelectOldestForUser = "SELECT TOP ${reapCount} id FROM ${tableName} WHERE user_id = :userId ORDER BY created ASC"
        val delSql = "DELETE FROM ${tableName} WHERE id IN ( ${subSelectOldestForUser}) ;"
        val delRowsCount = dbHelper.jdbi.open()
                .createUpdate(delSql)
                .bind("userId", userId)

                .execute()

        logger.debug { "For user ${userId}, deleted the ${delRowsCount} oldest row(s)." }
    }

    fun isDuplicateBackup(tableName: String, userId: String, habitData: String): Boolean {

        return ( dbHelper.jdbi.open().select("SELECT count(*) FROM ${tableName} WHERE user_id = :userId AND habit_data = :habitData ; ")
                .bind("userId", userId)
                .bind("habitData", habitData)
                .mapTo<Long>().findOnly().toInt() ) > 0;
    }

    private fun deleteDuplicateBackups(tableName: String, userId: String, habitData: String) {

        val delSql = "DELETE FROM ${tableName} WHERE user_id = :userId AND habit_data = :habitData ;"
        val delRowsCount = dbHelper.jdbi.open()
                .createUpdate(delSql)
                .bind("userId", userId)
                .bind("habitData", habitData)

                .execute()

        logger.debug { "For user ${userId}, deleted ${delRowsCount} duplicate backup row(s)." }
    }

}