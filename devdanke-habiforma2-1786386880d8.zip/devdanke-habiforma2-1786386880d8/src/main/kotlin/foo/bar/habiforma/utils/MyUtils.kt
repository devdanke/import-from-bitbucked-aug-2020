package foo.bar.habiforma.utils

import java.io.File
import java.time.format.DateTimeFormatter

class MyUtils {

    companion object {
        val YYYYMMDDHHMMSS = DateTimeFormatter.ofPattern("yyyyMMddhhmmss")

        fun getCurDir() = File(".");

        fun getCurDirPath() = getCurDir().canonicalPath;

        fun canReadWrite(filePath: String): Boolean {
            val f = File(filePath)
            return f.canRead() && f.canWrite()
        }

    }


}