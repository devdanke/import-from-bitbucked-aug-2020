package foo.bar.habiforma.utils


import mu.KLogging
import org.apache.commons.lang3.exception.ExceptionUtils
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.ControllerAdvice
import org.springframework.web.bind.annotation.ExceptionHandler


@ControllerAdvice
class MyGlobalErrorHandler  {

    companion object: KLogging()

    // Handle all errors
    @ExceptionHandler(Exception::class)
    fun handleError(e: Exception): ResponseEntity<String> {

        val myMsg = "\nREASON:\n ${e.message}\n\nSTACK:\n${ExceptionUtils.getStackTrace(e)}"
        logger.debug { myMsg }
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .header(HttpHeaders.CONTENT_TYPE, "text/plain")
                .body(myMsg)
    }

}