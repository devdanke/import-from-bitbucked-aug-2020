package foo.bar.habiforma.interceptor

import foo.bar.habiforma.dao.UserCredData
import foo.bar.habiforma.service.UserCredService
import foo.bar.habiforma.utils.Konst
import mu.KLoggable
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.stereotype.Component
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter
import javax.servlet.ServletException
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

/**
 * This is an interceptor that saves a reference from the response into the request.
 * Spring can autowire HttpServletRequest but not HttpServletResponses.

 * We've got 3 solutions there:
 * 1) We inject HttpServletResponse as a parameter of every @Controller methods.
 * 2) We create a scoped-proxy factory bean that instantiate a filter which holds a threadlocal containing the response.
 * 3) We create an interceptor and save a reference to the response, inside the request which can be autowired by spring.

 * This is the solution number 3. It's kind of hacky, but it's being accessed only from the ApiKeySecuredAspect class.

 * Trust me, I'm an engineer.
 */
@Component
class AuthInterceptor @Autowired constructor(private val userCredService: UserCredService): HandlerInterceptorAdapter() {

    companion object: Any(), KLoggable {

        override val logger = logger()
        val AUTH_VAL_DELIM = "|"
        val AUTH_HEADER_KEY = HttpHeaders.AUTHORIZATION.toLowerCase()
    }

    init {
        logger.debug { "init called" }
    }

    @Throws(ServletException::class)
    override fun preHandle(req: HttpServletRequest, resp: HttpServletResponse, handler: Any?): Boolean {

        val rawAuthValue = req.getHeader(AUTH_HEADER_KEY)
        val reqMethod = req.method.toUpperCase()
        logger.debug { "reqMethod= ${reqMethod}, authToken=${rawAuthValue}" }

        if(reqMethod.startsWith("OPTION")){
            // case 1: allow option requests, which I believe are for CORS, to go through.
            return true;
        }
        else if(rawAuthValue != null) {

            // case 2: normal non-option request.  Lookup user. If they exist and have correct password, then authorize.

            val userAndPass = parseAuthHeader(rawAuthValue)
            val result = checkAuthorization(userAndPass.first, userAndPass.second)
            if(result.isLegit) {
                req.setAttribute(Konst.USER_CRED, result.userCred)
                //logger.debug { "Yes authorized" }
                //resp.setHeader( "AuthInterceptorHeader","yep")
                return true
            }
            else {
                logger.debug { "Not authorized. Provided auth creds don't match any valid user creds.." }
                resp.sendError(403,"Not authorized. Nyet, nein, nogo.")
                return false
            }
        }
        else {
            logger.debug { "Not authorized. Missing AUTH_HEADER and/or value." }
            //resp.setHeader( "AuthInterceptorHeader","nope")

            resp.sendError(403,"Not authorized. Nyet, nein, nogo.")
            return false
        }
    }


    fun checkAuthorization(userName: String, password: String): AuthResult {

        if(userCredService.isLegit(userName, password)) {
            return AuthResult(true, userCredService.dao.getUserCred(userName))
        }
        else {
            return AuthResult(false, null)
        }
    }

    fun parseAuthHeader(authHeader: String): Pair<String,String> {
        val parts = authHeader.split(AUTH_VAL_DELIM)
        if(parts == null || parts.size < 1) {
            logger.debug { "Cannot parse: '${authHeader}'." }
            return Pair("none","none")
        }
        return Pair(parts[0], parts[1])
    }

    data class AuthResult(val isLegit: Boolean, val userCred: UserCredData?)
}
