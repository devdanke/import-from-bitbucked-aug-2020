package foo.bar.habiforma.controller


import org.springframework.web.bind.annotation.*


@CrossOrigin
@RestController()
@RequestMapping("/api")
class HiController
{
    @GetMapping("/hi")
    fun getHi() = mapOf("payload" to "hi")

    @PostMapping("/hi")
    fun hiToYou(@RequestBody reqBody: Map<String,String>): Map<String,String> {
        val payload = "hi ${reqBody.getValue("name")}"
        return mapOf("payload" to payload)
    }


}