package foo.bar.habiforma.controller

// data is escaped json
data class BackupDto(val id: String, val habitData: String)