package foo.bar.habiforma.config


import foo.bar.habiforma.interceptor.AuthInterceptor
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.cors.CorsConfiguration
import org.springframework.web.cors.UrlBasedCorsConfigurationSource
import org.springframework.context.annotation.Bean
import org.springframework.web.filter.CorsFilter
import org.springframework.web.servlet.config.annotation.CorsRegistry
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer
import mu.KLoggable


@Configuration
class MyWebConfig: WebMvcConfigurerAdapter() {

    companion object: Any(), KLoggable { override val logger = logger() }

    @Autowired
    lateinit var authInterceptor: AuthInterceptor

    override fun addInterceptors(registry: InterceptorRegistry) {
        registry.addInterceptor(authInterceptor);
    }

    /*
    Only needed for local dev when sboot app runs separately from npm server.
     */
    @Bean
    fun corsConfigurer(): WebMvcConfigurer {

        logger.info { "Limited CORS allow for DEV only localhost:3000" }

        return object : WebMvcConfigurerAdapter() {

            override fun addCorsMappings(registry: CorsRegistry?) {

                registry!!.addMapping("/api/**").allowedOrigins("http://localhost:3000")

            }
        }
    }


}