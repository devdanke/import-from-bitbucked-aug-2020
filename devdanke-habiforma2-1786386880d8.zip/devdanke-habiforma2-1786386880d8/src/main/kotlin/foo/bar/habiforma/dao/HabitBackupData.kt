package foo.bar.habiforma.dao

import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.*

class HabitBackupData

    constructor(val id: String,
            val userId: String,
            val data: String, // fyi base64 encoded json
            val created: ZonedDateTime? )  // nullable, because on create, h2 db generates this date.
{
    // This is only for coming out of DB
    constructor(backupId: String,
            userId: String, habitData:
            String, createDate: Date):

            this(backupId, userId, habitData, ZonedDateTime.ofInstant(createDate.toInstant(), ZoneId.systemDefault()))
}


