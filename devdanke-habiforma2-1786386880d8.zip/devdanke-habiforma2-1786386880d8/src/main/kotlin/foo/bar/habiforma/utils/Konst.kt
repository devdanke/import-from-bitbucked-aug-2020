package foo.bar.habiforma.utils

class Konst {
    companion object {
        val USER_CRED = "USER_CRED"
    }
}