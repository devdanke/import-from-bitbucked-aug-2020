package foo.bar.habiforma.dao

import foo.bar.habiforma.config.MyConfig
import mu.KLoggable
import org.jdbi.v3.core.Jdbi
import org.jdbi.v3.core.kotlin.mapTo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
import java.nio.file.Files
import java.nio.file.Paths

@Component
class H2DbHelper @Autowired constructor(val config: MyConfig) {

    companion object: Any(), KLoggable {

        override val logger = logger()
    }


    var canBackupDb: Boolean = false
    val jdbi: Jdbi

    // todo: how different is init() to spring's @PostConstruct?
    init {

        // todo: get this from config
        jdbi = Jdbi.create("jdbc:h2:mem:habiforma2")
        jdbi.installPlugins() // todo: does this help?  is it really loading a jdbi3 kotlin plugin?

        canBackupDb = config.canBackupDb()

        if(canBackupDb) {
            logger.info { "Will backup/restore DB from dir '${config.dbDumpDir}'." }
        }
        else {
            logger.warn { "Cannot backup/restore DB because filePath isn't readable and/or writeable."}
        }
    }

    fun makeOutFilePath(tableName: String) = "${config.dbDumpDir}/${tableName}.csv"

    fun createTable(sql: String) {
        logger.info { "create table sql: ${sql}" }
        var h = jdbi.open()
        h.execute(sql)
    }

    fun importDbData(tableName: String, selectColumnsClause: String) {

        val dbBackupFilePath = makeOutFilePath(tableName)
        if(Files.exists(Paths.get(dbBackupFilePath))) {

            val fullSelectSql = "${selectColumnsClause} FROM CSVREAD('${dbBackupFilePath}')"

            val importFromCsvSql = "INSERT INTO ${tableName} ${fullSelectSql};"
            logger.debug { "importFromCsvSql: ${importFromCsvSql}" }
            var h = jdbi.open()
            h.createUpdate(importFromCsvSql).execute()

            logger.info { "At startup, ${rowCount(tableName)} rows read from DB backup file." }
        }
        else {
            logger.info { "Table backup file '${dbBackupFilePath}' not found. Will start with empty table." }
        }
    }

    fun exportTableData(tableName: String) {
        try {
            jdbi.open().execute("CALL CSVWRITE ('${makeOutFilePath(tableName)}', 'SELECT * FROM ${tableName}');")
        }
        catch (e: Exception) {
            logger.warn { "Unable to export latest ${tableName} data."; e }
        }
    }

    fun rowCount(tableName: String): Long {

        return jdbi.open().select("SELECT count(*) FROM ${tableName} ; ").mapTo<Long>().findOnly()
    }

    fun rowCount(tableName: String, userId: String): Int {

        return jdbi.open().select("SELECT count(*) FROM ${tableName} WHERE user_id = :userId ; ")
                .bind("userId", userId).mapTo<Long>().findOnly().toInt()
    }

}