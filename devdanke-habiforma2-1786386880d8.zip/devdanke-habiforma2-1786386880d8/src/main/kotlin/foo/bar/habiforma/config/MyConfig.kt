package foo.bar.habiforma.config

import foo.bar.habiforma.utils.MyUtils
import mu.KLoggable
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.PropertySource
import org.springframework.stereotype.Component
import java.io.File
import javax.annotation.PostConstruct

@Component
@ConfigurationProperties("habiforma")
@PropertySource("classpath:my.properties")
data class MyConfig(var dbDumpDir: String="") {

    companion object: Any(), KLoggable {

        override val logger = logger()
    }

    fun canBackupDb() = MyUtils.canReadWrite(dbDumpDir)

    @PostConstruct
    fun myInit() {
        logger.info { "config params= ${this.toString()}" }
        logger.info { "can backup db=${canBackupDb()}" }
    }
}
