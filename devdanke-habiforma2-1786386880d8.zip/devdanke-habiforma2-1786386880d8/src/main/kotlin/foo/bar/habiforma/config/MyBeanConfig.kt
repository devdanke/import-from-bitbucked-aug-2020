package foo.bar.habiforma.config

import mu.KLoggable
import mu.KLogging
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Configuration
import org.springframework.stereotype.Component
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer
import org.springframework.context.annotation.Bean
import org.springframework.http.CacheControl.maxAge
import org.springframework.web.servlet.config.annotation.CorsRegistry


@Configuration
class MyBeanConfig {

    companion object: Any(), KLoggable {
        override val logger = logger()

        private val me = "MyBeanConfig.companion: "

        // not sure this worked
        @Bean
        fun propertyPlaceholderConfigurer(): PropertySourcesPlaceholderConfigurer {
            logger.debug { "${me} propertyPlaceholderConfigurer() IN" }
            println("${me} propertyPlaceholderConfigurer() called")
            return PropertySourcesPlaceholderConfigurer()
        }

    }
}