package foo.bar.habiforma.utils

import javax.servlet.http.HttpServletRequest
import java.util.Enumeration



fun headersToString(req: HttpServletRequest): String {
    val sb = StringBuilder()
    val names: Enumeration<String> = req.headerNames
    while (names.hasMoreElements()) {
        val name = names.nextElement()
        sb.append("header: ").append(name).append("=").append(req.getHeader(name)).append("\n")
    }
    return sb.toString()
}