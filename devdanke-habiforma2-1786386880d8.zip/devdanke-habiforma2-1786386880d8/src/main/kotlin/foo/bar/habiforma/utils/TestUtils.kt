package foo.bar.habiforma.utils

import foo.bar.habiforma.MyApp
import foo.bar.habiforma.service.UserCredService
import org.apache.commons.codec.digest.DigestUtils
import org.apache.commons.codec.digest.DigestUtils.md5
import java.time.ZonedDateTime

class TestUtils {
    companion object {

        val CLI_SALT = "habiforma"


        fun injectSimulatedClientUser(uname: String,  pass: String, userCredSvc: UserCredService) {
            try {
                val clientHashedPass = simulateNaiveClientHashForTesting(CLI_SALT,pass)
                val userId = userCredSvc.createUserCred(uname, clientHashedPass, ZonedDateTime.now())
                MyApp.logger.debug { "Created userId: ${userId} for uname=${uname}, clientHashedPass=${clientHashedPass}" }
            }
            catch(e: Exception) {
                MyApp.logger.warn { "Failed to create username '${uname}', " +
                        "probably because they already existed in DB.\n${e.message}" }
            }
        }


        // result md5( salt + "-" + pass ).hex.upperCase
        fun simulateNaiveClientHashForTesting(salt: String, pass: String): String {
            return DigestUtils.md5Hex("${salt}-${pass}").toUpperCase()
        }
    }
}