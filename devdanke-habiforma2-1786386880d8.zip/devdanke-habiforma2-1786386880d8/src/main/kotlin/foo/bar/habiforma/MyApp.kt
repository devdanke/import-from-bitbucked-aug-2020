package foo.bar.habiforma

import foo.bar.habiforma.service.UserCredService
import foo.bar.habiforma.utils.MyUtils
import foo.bar.habiforma.utils.TestUtils
import mu.KLoggable
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication
import javax.annotation.PostConstruct


//import org.springframework.web.servlet.config.annotation.EnableWebMvc

@SpringBootApplication
//@EnableWebMvc
class MyApp {

    companion object: Any(), KLoggable {

        override val logger = logger()
    }

    // temp for test data until client can do.
    @Autowired
    lateinit var userCredSvc: UserCredService;

    @PostConstruct
    fun myInit() {

        logger.info { "Initialized."}
        val curDir = MyUtils.getCurDir()
        logger.info { "Current working dir=${MyUtils.getCurDirPath()}, " +
            "readable=${curDir.canRead()}, writeable=${curDir.canWrite()}"}

        // todo: temporary.  once client can create user, then use that instead of this.
        TestUtils.injectSimulatedClientUser("nick", "saban",   userCredSvc)
        TestUtils.injectSimulatedClientUser("danzo", "meboi", userCredSvc)
    }

}

fun main(args: Array<String>) {
    SpringApplication.run(MyApp::class.java, *args)
}


