package foo.bar.habiforma.service

import foo.bar.habiforma.controller.BackupDto
import foo.bar.habiforma.controller.BackupInfoDto
import foo.bar.habiforma.dao.HabitBackupData
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import foo.bar.habiforma.dao.IHabitBackupDao
import org.springframework.stereotype.Component
import java.util.*


@Component
class HabitBackupService @Autowired constructor(@Qualifier(value="h2") val dataMgr: IHabitBackupDao) {

    companion object  {
        val MY_DATE_FORMAT = DateTimeFormatter.ISO_INSTANT
    }

    fun getBackupInfos(userId: String, afterDate: Optional<ZonedDateTime>): List<BackupInfoDto> {

        // todo: should i add user id?  should i put url to get object? hateos?
        return dataMgr.getBackups(userId, afterDate)
                ?.sortedWith(compareBy({ it.created }))
                ?.reversed()
                ?.map { BackupInfoDto(it.id, it.created!!.format(MY_DATE_FORMAT),fullBackupRelLink(it.userId, it.id)) }

    }

    fun getBackup(userId: String, backupId: String): BackupDto? {

        val bu: HabitBackupData? = dataMgr.getBackup(userId, backupId)
        return if(bu != null) {
            BackupDto(bu.id, bu.data)
        }
        else
            null;
    }

    fun createBackup(userId: String, habitData: String, createDate: ZonedDateTime): BackupInfoDto {
        val backupId = dataMgr.createBackup(userId, habitData, createDate)
        return BackupInfoDto(backupId, createDate.format(MY_DATE_FORMAT), fullBackupRelLink(userId,backupId))
    }

    private fun fullBackupRelLink(userId: String, backupId: String) =  "users/~/backups/${backupId}"
}