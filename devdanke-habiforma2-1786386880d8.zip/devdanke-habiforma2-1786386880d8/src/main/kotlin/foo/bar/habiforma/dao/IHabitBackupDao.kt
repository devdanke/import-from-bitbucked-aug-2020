package foo.bar.habiforma.dao

import org.springframework.stereotype.Component
import java.time.ZonedDateTime
import java.util.*


@Component
interface IHabitBackupDao {

    fun getBackups(userId: String, afterDate: Optional<ZonedDateTime>): List<HabitBackupData>
    fun getBackup(userId: String, backupId: String): HabitBackupData?
    fun createBackup(userId: String, habitData: String, createDate: ZonedDateTime): String
}