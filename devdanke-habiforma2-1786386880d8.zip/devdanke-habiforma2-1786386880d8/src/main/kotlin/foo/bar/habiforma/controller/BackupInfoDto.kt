package foo.bar.habiforma.controller

data class BackupInfoDto(val id: String, val name: String, val backupRelLink: String)