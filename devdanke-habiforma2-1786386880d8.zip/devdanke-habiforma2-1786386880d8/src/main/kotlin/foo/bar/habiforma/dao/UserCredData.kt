package foo.bar.habiforma.dao

import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.*

class UserCredData

    constructor(
            val id: String,
            val userName: String,
            val pswdSalt: String,
            val hashedPswd: String,
            val created: ZonedDateTime? )

{
    // This is only for coming out of DB
    constructor(
            id: String,
            userName: String,
            pswdSalt: String,
            hashedPswd: String,
            createDate: Date):

            this(
                    id,
                    userName,
                    pswdSalt,
                    hashedPswd,
                    ZonedDateTime.ofInstant(createDate.toInstant(), ZoneId.systemDefault()))
}