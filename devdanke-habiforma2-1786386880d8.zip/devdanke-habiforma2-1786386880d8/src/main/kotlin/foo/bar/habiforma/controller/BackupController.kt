package foo.bar.habiforma.controller

import foo.bar.habiforma.dao.UserCredData
import foo.bar.habiforma.service.HabitBackupService
import foo.bar.habiforma.utils.Konst
import mu.KLoggable
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.format.annotation.DateTimeFormat
import org.springframework.web.bind.annotation.*
import java.time.ZonedDateTime
import java.util.*
import javax.servlet.http.HttpServletRequest

/*
Tilde in path is placeholder for userId.
Mostly, it's not needed in URL because it can always be found in UserCred.
 */
@RestController()
@RequestMapping("/api")
class BackupController @Autowired constructor(private val backupService: HabitBackupService)
{
    companion object: Any(), KLoggable {
        override val logger = logger()
    }

    @GetMapping("/users/~/backups")
    fun getBackups(req: HttpServletRequest,
            @RequestParam(name="after", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) after: ZonedDateTime?):
            List<BackupInfoDto> {

        val userCred = getUserCredOrThrow(req)

        val afterDate = if (after != null) Optional.of(after) else Optional.empty()
        return backupService.getBackupInfos(userCred.id, afterDate)
    }

    @GetMapping("/users/~/backups/{backupId}")
    fun getBackup(@PathVariable backupId: String, req: HttpServletRequest): BackupDto {

        val userCred = getUserCredOrThrow(req)
        val buDto: BackupDto? = backupService.getBackup(userCred.id, backupId)

        if (buDto != null) return buDto
        else throw Exception("No habit data found for backupId='$backupId'") // todo: throw proper 404
    }

    /*
    accept a post body of data.
    return the location of the newly created backup.
    note: if there's a prev backup with same md5 as new one, then delete old one(s) and keep newest.
    */
    @PostMapping("/users/~/backups")
    fun createBackup(@RequestBody reqBody: Map<String,String>, req: HttpServletRequest): BackupInfoDto {

        val userCred = getUserCredOrThrow(req)

        return backupService.createBackup(userCred.id, reqBody.getValue("habitData"), ZonedDateTime.now())
    }

    private fun getUserCredOrThrow(req: HttpServletRequest): UserCredData {

        val userCred = req.getAttribute(Konst.USER_CRED) as UserCredData?

        if(userCred==null) {
            throw Exception("Should be impossible to get here. Interceptor should already have rejected with 401.")
        }

        return userCred
    }


}