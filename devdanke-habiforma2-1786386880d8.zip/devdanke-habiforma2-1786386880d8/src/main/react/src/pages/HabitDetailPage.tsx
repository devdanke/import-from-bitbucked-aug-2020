import * as React from 'react';
import { Component } from 'react';

import AddHabitForm from "../components/AddHabitForm"

import BasePage from '../components/BasePage'

import IconButton from "material-ui/IconButton";
import NavigationArrowBack from "material-ui/svg-icons/navigation/arrow-back";
import {Link} from "react-router-dom";
import Konst from "../utils/Konst";


export default class HabitDetailPage extends Component <any,any>{

    constructor(props) {
        super(props);
    }

    render() {
        const backBtn = <IconButton containerElement={<Link to={Konst.route.HOME}/>}> <NavigationArrowBack /> </IconButton>;

        return (

            <BasePage className="basePage" body={
                <AddHabitForm
                    habId={this.props.location.state.habId}
                    action={this.props.location.state.action} />}

                      headerTitle="Habit"
                      topLeftButton={backBtn}

            />
        );
    }
}

