import * as React from 'react';
import { Component } from 'react';
import {connect} from 'react-redux'
import {Link} from 'react-router-dom'

import BasePage from '../components/BasePage'
import DividedList, {IItemData} from '../components/DividedList'
import CloudDownload from "material-ui/svg-icons/file/cloud-download";
import {default as MyRestClient} from "../utils/MyRestClient";
import AppDb from "../state/IAppDb";
import BackupService from "../service/BackupService";
import MyConfig from "../MyConfig";
import IUserCred from "../state/IUserCred";

import IconButton from "material-ui/IconButton";
import NavigationArrowBack from "material-ui/svg-icons/navigation/arrow-back";
import ActionBackup from "material-ui/svg-icons/action/backup";
import Dialog from "material-ui/Dialog";
import FlatButton from "material-ui/FlatButton";
import Konst from "../utils/Konst";
import ContentUndo from "material-ui/svg-icons/content/undo";
import ActionSettings from "material-ui/svg-icons/action/settings";
import ActionSwapVert from "material-ui/svg-icons/action/swap-vert";
import IRemoteBackupInfo from "../service/IRemoteBackupInfo";

interface BackupPageProps {
    appDb: AppDb;
    restoreBackupInternal: Function;
    resetIsDirty: Function;
    notifyStaleHabitData: Function;
}

interface BackupPageState {
    confirmDlg_open: boolean;
    confirmDlg_backupName: string;
    confirmDlg_backupHabitsById: object;
    userCred: IUserCred;
}


class BackupPage extends Component <BackupPageProps,BackupPageState>{
    me = "BackupPage"

    // refs to manipulate them from this page. because idomatic ways didn't work.
    backupsListRef: DividedList = null;

    /* *****************************************************************************************************************
     */
    constructor(props) {
        super(props);

        this.state = {
            confirmDlg_open: false,
            confirmDlg_backupName: null,
            confirmDlg_backupHabitsById: null,
            userCred: props.appDb.db.userCred
        }

        this.convertBackupInfoToItemData = this.convertBackupInfoToItemData.bind(this);
        this.backupHabits = this.backupHabits.bind(this);
        this.handleOpenConfirmDlg = this.handleOpenConfirmDlg.bind(this);
        this.handleNoRestore = this.handleNoRestore.bind(this);
        this.handleYesRestore = this.handleYesRestore.bind(this);
        this.checkForNewerBackup = this.checkForNewerBackup.bind(this);
        this.loadBackupInfosIntoDisplayList = this.loadBackupInfosIntoDisplayList.bind(this);
        this.restoreBackup = this.restoreBackup.bind(this);
    }


    /* *****************************************************************************************************************
     */
    backupHabits(event:any) {

        event.preventDefault()

        // i assume this will always be non-null. because i think i init it to empty array at startup.
        const safeHabitsStr: string = BackupService.toJsonSafeString(AppDb.getHabitList(this.props.appDb))

        const onSuccess = (respBodyObj)=>{
            // todo: FIX: actually, if server returns a backup info.  then i can just add it to existig list.
            // todo: no need to make two server calls.
            BackupService.getRemoteBackupInfos(this.props.appDb.db.userCred, this.loadBackupInfosIntoDisplayList);
            this.props.resetIsDirty()
        }

        const onError = (someKindOfErrOjb) => {
            console.warn("backupHabits(): failed because of: ", someKindOfErrOjb)
            return null; // currently, not using
        }

        MyRestClient.post(
            MyConfig.getBackupsUrl(),
            this.props.appDb.db.userCred,
            {habitData: safeHabitsStr},
            onSuccess,
            onError
        )
    }

    loadBackupInfosIntoDisplayList(backupInfos: IRemoteBackupInfo[]) {
        const processedBody = backupInfos.map(this.convertBackupInfoToItemData)

        // todo: this doesn't feel idomatic.  on the other hand, my idomatic-ish attempt didn't work.
        // trigger DividedList to rerender itself with latest data from server.
        // tried to force that by rerendering BackupsPage and also forceUpdate it, but didn't work.
        // neither of those make the DividedList.ctor fire again.
        this.backupsListRef.setState({dataItems: processedBody})
    }


    handleOpenConfirmDlg(backupName: string, habitsById:object) {
        this.setState({confirmDlg_open: true, confirmDlg_backupName:backupName, confirmDlg_backupHabitsById:habitsById})
    }


    handleNoRestore() {
        this.setState({confirmDlg_open: false, confirmDlg_backupName:null, confirmDlg_backupHabitsById:null})
    }


    handleYesRestore() {
        this.restoreBackup()
    }


    restoreBackup() {
        this.setState({confirmDlg_open: false, confirmDlg_backupName:"none at the moment"})
        this.props.restoreBackupInternal(this.state.confirmDlg_backupHabitsById)

        const goHome = () => { document.getElementById("backToHomePageBtn").click() }
        setTimeout(goHome, 500)
    }


    checkForNewerBackup() {

        const myHandler = (backupInfos)=> {
            if(backupInfos.length > 0) {
                this.props.notifyStaleHabitData()
            }
        }

        // rest msg to server
        BackupService.getRemoteBackupInfos(this.props.appDb.db.userCred, myHandler, this.props.appDb.db.whenLastBackup)
    }


    /* *****************************************************************************************************************
     */
    convertBackupInfoToItemData(backupInfo: IRemoteBackupInfo): IItemData {

        // def this func inside this other func so i'll have access to current data item.
        const dloadBackupAndPrepRestore = (event) => {
            event.preventDefault();

            const onSuccessDloadBackupData = (backupRespBody: object) => {
                const habitsById = BackupService.decodeAndMapById(backupRespBody["habitData"])
                this.handleOpenConfirmDlg(backupInfo.name, habitsById);
            }

            BackupService.getBackupDataForRestore(backupInfo.backupRelLink, this.state.userCred, onSuccessDloadBackupData);
        }

        const dloadBtn = <IconButton onClick={dloadBackupAndPrepRestore}> <CloudDownload /> </IconButton>

        const localDttm = new Date(backupInfo.name).toLocaleString()
        return {id:backupInfo.id, name:localDttm, actionBtn:dloadBtn}
    }



    /* *****************************************************************************************************************
     */
    render() {

        const backupsList = <DividedList
            ref={(divList) => { this.backupsListRef = divList; }}  // keep ref to force update after upload
            itemSvgIcon={<CloudDownload />}
            dataItems={[]}/>

        BackupService.getRemoteBackupInfos(this.state.userCred, this.loadBackupInfosIntoDisplayList);

        const actions = [
            <FlatButton
                label="No"
                primary={true}
                onClick={this.handleNoRestore}
            />,
            <FlatButton
                label="Yes"
                primary={true}
                onClick={this.handleYesRestore}
            />,
        ];

        return (
            <div>
                <BasePage className="basePage"

                    topLeftButton={<IconButton id="backToHomePageBtn" containerElement={<Link to={Konst.route.HOME}/>}><NavigationArrowBack /></IconButton>}
                    topRightButton={<IconButton onClick={this.backupHabits}><ActionBackup /></IconButton>}

                    headerTitle="Backups"
                    isDirty={this.props.appDb.db.hasUnsavedChanges}
                    isStale={this.props.appDb.rt.hasNewerRemoteBackup}

                    body={backupsList}

                    bottomLeftButton={<IconButton onClick={this.checkForNewerBackup}><ActionSwapVert /></IconButton>}
                    bottomRightButton={<IconButton containerElement={<Link to={Konst.route.SETTINGS}/>}> <ActionSettings/> </IconButton>}
                />

                <Dialog
                    title="Confirm Restore"
                    actions={actions}
                    modal={true}
                    open={this.state.confirmDlg_open}
                >
                    Restore backup {this.state.confirmDlg_backupName} ?
                </Dialog>
            </div>
        );
    }
}


//--- container housekeeping etc

function mapStateToProps(state) {
    return { appDb: state }
}

// todo: i should  (i think) handle in functions here instead of giving myDispatch to children.
function mapDispatchToProps(dispatch) {
    return( {

        resetIsDirty: () => { dispatch( {type: Konst.actn.NOT_DIRTY_NO_MORE}) },

        notifyStaleHabitData: () => { dispatch({type: Konst.actn.NOTIFY_STALE_HABIT_DATA}) },

        restoreBackupInternal: (habitsByIdBackup) => {
            dispatch( {type: Konst.actn.RESTORE_BACKUP, [Konst.arg.HABITS_BY_ID_BACKUP]:habitsByIdBackup}) }
    } )
}

export default connect(mapStateToProps, mapDispatchToProps)(BackupPage);


