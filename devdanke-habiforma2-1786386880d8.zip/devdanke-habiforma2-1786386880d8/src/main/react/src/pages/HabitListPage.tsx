import * as React from 'react';
import { Component } from 'react';
import {Link} from 'react-router-dom'
import {connect} from 'react-redux'

import BasePage from '../components/BasePage'
import HabitList from '../components/HabitList'
import ContentAdd from "material-ui/svg-icons/content/add";
import IconButton from "material-ui/IconButton";
import EditorModeEdit from "material-ui/svg-icons/editor/mode-edit";
import AppBar from "material-ui/AppBar";
import Drawer from "material-ui/Drawer";
import {NavigationClose} from "material-ui/svg-icons";
import DoneDatesList from "../components/DoneDatesList";
import StyleKonst from "../utils/StyleKonst";
import FileCloud from "material-ui/svg-icons/file/cloud";
import ActionSettings from "material-ui/svg-icons/action/settings";
import AppDb from "../state/IAppDb";
import MyConfig from "../MyConfig";
import Konst from "../utils/Konst";

interface IHabitListPageProps {
    appDb: AppDb;
}

interface IHabitListPageState {
    drawerOpen: boolean;
}

export class HabitListPage extends Component <IHabitListPageProps,IHabitListPageState>{

    constructor(props) {
        super(props);
        this.state = {drawerOpen: false};
    }

    render() {

        const addHabitBtn =
            <IconButton
                style={StyleKonst.TOUCH_ICON_SIZE}
                containerElement={<Link to={{
                    pathname: Konst.route.HABIT,
                    state: {
                        action: "ADD"
                    }
                }} />}  >
                <ContentAdd />
            </IconButton>;

        const habitListCompo = <HabitList />

        return (
            <div>
                <BasePage className="basePage"
                          body={habitListCompo}

                          headerTitle="Habits"
                          isDirty={this.props.appDb.db.hasUnsavedChanges}
                          isStale={this.props.appDb.rt.hasNewerRemoteBackup}

                          topLeftButton={addHabitBtn}

                          topRightButton={<IconButton
                          onClick={() => {this.setState({drawerOpen: !this.state.drawerOpen})}}>
                          <EditorModeEdit />
                      </IconButton>}

                          bottomLeftButton={<IconButton containerElement={<Link to={Konst.route.BACKUPS}/>}> <FileCloud/> </IconButton>}
                          bottomRightButton={<IconButton containerElement={<Link to={Konst.route.SETTINGS}/>}> <ActionSettings/> </IconButton>}

                />

                <Drawer width={"80%"} openSecondary={true} open={this.state.drawerOpen}
                        onRequestChange={(open) => this.setState({drawerOpen: !this.state.drawerOpen})} docked={false}
                        overlayStyle={{backgroundColor: 'rgba(255,255,255,.1)'}}>

                    <AppBar title="History"
                            showMenuIconButton={false}
                            iconElementRight={<IconButton
                                onClick={() => {this.setState({drawerOpen: !this.state.drawerOpen})}}>
                                <NavigationClose />
                            </IconButton>}
                    />

                    <DoneDatesList lookbackDaysCount={MyConfig.getDoneDatelookbackCount()}/>

                </Drawer>

            </div>

        );
    }

}

// container house keeping below here


function mapStateToProps(state) {
    return {
        appDb: state
    }
}

export default connect(mapStateToProps)(HabitListPage);




