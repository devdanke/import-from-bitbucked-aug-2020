
import * as React from 'react';
import { Component } from 'react';
import {connect} from 'react-redux'

import BasePage from '../components/BasePage'
import NavigationArrowBack from "material-ui/svg-icons/navigation/arrow-back";
import {Link} from "react-router-dom";
import IconButton from "material-ui/IconButton";

import List, {ListItem} from "material-ui/List";
import Divider from "material-ui/Divider";
import MyDateUtils from "../utils/MyDateUtils";
import Konst from "../utils/Konst";
import MyUtils from "../utils/MyUtils";
import IHabitData from '../state/IHabitData'
import MyConfig from "../MyConfig";
import RaisedButton from "material-ui/RaisedButton";
import AppDb from "../state/IAppDb";
import UserCredForm from "../components/UserCredForm";


interface SettingsPageProps {
    reduxedAddTestHabitData: Function;
    reduxedDeleteAllHabitData: Function;
    reduxedUpdateUserCred: Function;
    appDb: AppDb;
}


class SettingsPage extends Component <SettingsPageProps, any>{

    constructor(props) {
        super(props);

        this.handleAddTestHabitData = this.handleAddTestHabitData.bind(this);
        this.handleDeleteAllHabitData = this.handleDeleteAllHabitData.bind(this);
        this.handleInjectUserCred = this.handleInjectUserCred.bind(this);
        this.handleClearUserCred = this.handleClearUserCred.bind(this);
        this.updateUserCred = this.updateUserCred.bind(this);
        this.getUserCredText = this.getUserCredText.bind(this);
    }

    handleClearUserCred(event) {
        this.updateUserCred(null, null)
    }

    handleInjectUserCred(event) {
        this.updateUserCred("nick","saban")
    }

    updateUserCred(username:string, password:string) {
        this.props.reduxedUpdateUserCred(username,password)
    }


    handleAddTestHabitData(event) {

        let habit = MyUtils.makeHabitData(MyUtils.genHabitId(), "BOT LO < 11:30",
            [ MyDateUtils.todayMinusDayYmd(5),MyDateUtils.todayMinusDayYmd(8),MyDateUtils.todayMinusDayYmd(9)]);
        this.props.reduxedAddTestHabitData( habit );

        habit = MyUtils.makeHabitData(MyUtils.genHabitId(), "nang samatee",
            [ MyDateUtils.todayMinusDayYmd(1),MyDateUtils.todayMinusDayYmd(4) ] );
        this.props.reduxedAddTestHabitData( habit );

        habit = MyUtils.makeHabitData(MyUtils.genHabitId(), "exercise", []);
        this.props.reduxedAddTestHabitData( habit );
    }

    handleDeleteAllHabitData(event) {
        this.props.reduxedDeleteAllHabitData()
    }

    getUserCredText(): string {
        const userCred = this.props.appDb.db.userCred

        let username = userCred.username
        username = (username !== null) ? username : "?";

        let hashword = userCred.hashword
        hashword = (hashword !== null) ? hashword : "?";

        return `User:  ${username} | ${hashword}`
    }


    render() {

        // todo: make my own compo BackToHomeBtn since I use this button on all pages.
        const backBtn = <IconButton containerElement={<Link to={Konst.route.HOME}/>}> <NavigationArrowBack /> </IconButton>;

        const version = MyConfig.calcVersion()

        const addTestDataBtn = <RaisedButton key="addTestDataBtn" label="Add Test Habit Data" onClick={this.handleAddTestHabitData} />
        const deleteTestDataBtn = <RaisedButton key="deleteTestDataBtn" label="Delete Habit Data" onClick={this.handleDeleteAllHabitData} />

        const injectUserCredBtn = <RaisedButton key="injectUserCredBtn" label="Add Test User Cred" onClick={this.handleInjectUserCred} />

        const clearUserCredBtn = <RaisedButton key="clearUserCredBtn" label="Delete User Cred" onClick={this.handleClearUserCred} />

        const body =
            <List>
                <ListItem key="appVer" primaryText={`Version ${version}`} className="grayBottomBorder"/>

                <ListItem children={addTestDataBtn} className="grayBottomBorder"/>

                <ListItem children={deleteTestDataBtn} className="grayBottomBorder" />

                <ListItem children={injectUserCredBtn} className="grayBottomBorder" />

                <ListItem children={clearUserCredBtn} className="grayBottomBorder" />

                <ListItem key={"key-6a"} primaryText={this.getUserCredText()} className="grayBottomBorder" />

                <ListItem children={<UserCredForm
                    username={this.props.appDb.db.userCred.username}
                    hashword={this.props.appDb.db.userCred.hashword} key="key-7c"/>}
                    className="grayBottomBorder" />
            </List> ;


        return (
            <BasePage
                className="basePage"
                body={body}

                headerTitle="Settings"
                topLeftButton={backBtn}
            />
        );
  }
}


//--- container housekeeping

function mapStateToProps(state) {
    return {
        appDb: state
    }
}

function mapDispatchToProps(dispatch) {

    return(
        {
            reduxedUpdateUserCred: function (username: string, password: string) {

                let dispatchArg = {
                    type: Konst.actn.UPDATE_USER_CRED,
                    [Konst.arg.USERNAME]: username,
                    [Konst.arg.PASSWORD]: password
                };

                dispatch(dispatchArg)
            },

            reduxedAddTestHabitData: function (habit: IHabitData) {

                let dispatchArg = {
                    type: Konst.ADD_HABIT,
                    targetHabit: habit
                };

                dispatch(dispatchArg)
            },

            reduxedDeleteAllHabitData: function () {

                let dispatchArg = {
                    type: Konst.actn.DELETE_ALL_HABITS
                };

                dispatch(dispatchArg)
            }
        }
    )
}

// export default SettingsPage;
export default connect(mapStateToProps, mapDispatchToProps)(SettingsPage);