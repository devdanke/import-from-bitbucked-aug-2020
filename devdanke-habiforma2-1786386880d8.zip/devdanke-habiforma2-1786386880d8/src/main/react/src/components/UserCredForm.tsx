
import * as React from 'react';
import { Component } from 'react';
import {connect} from 'react-redux'
import { Redirect } from 'react-router-dom'

import AppDb from '../state/IAppDb'
import MyUtils from "../utils/MyUtils";
import Konst from '../utils/Konst';

import RaisedButton from "material-ui/RaisedButton";
import ActionHome from "material-ui/svg-icons/action/home";
import IconButton from "material-ui/IconButton";
import ActionDone from "material-ui/svg-icons/action/done";
import NavigationCancel from "material-ui/svg-icons/navigation/cancel";
import EditorModeEdit from "material-ui/svg-icons/editor/mode-edit";


interface IUserCredFormProps {
    appDb: AppDb;
    reduxedUpdateUserCred: Function;
    username: string;
    hashword: string;
}

interface IUserCredFormState {
    username: string;
    password: string;
    isEditMode: boolean;
    origUsername: string; // these orig vals for when user cancels edit.
    origPassword: string;
}

class UserCredForm extends Component<IUserCredFormProps, IUserCredFormState> {

    constructor(props: IUserCredFormProps) {
        super(props);

        console.log("UserCredForm props=", props)

        const username = (props.username !== null) ? props.username : ""
        const password = (props.hashword !== null) ? "*******" : ""

        this.state = {username: username,
            password: password,
            isEditMode: false,
            origUsername: username,
            origPassword: password
        }

        console.log("UserCredForm state=", this.state)

        this.handleUsernameChange = this.handleUsernameChange.bind(this);
        this.handlePasswordChange = this.handlePasswordChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleEditMode = this.handleEditMode.bind(this);
    }

    componentWillReceiveProps(nextProps){
        console.log("componentWillReceiveProps():", nextProps)
        const username = (nextProps.username !== null) ? nextProps.username : ""
        const password = (nextProps.hashword !== null) ? "*******" : ""
        this.setState({username: username, password: password, origUsername: username, origPassword: password});
    }


    handleUsernameChange(event) {
        this.setState({username: event.target.value});
    }

    handlePasswordChange(event) {
        this.setState({password: event.target.value});
    }

    handleCancel(event) {
        event.preventDefault();
        let me = "UserCredForm.handleCancel()"
        this.setState({isEditMode: false, username: this.state.origUsername, password: this.state.origPassword});
        console.log(me, "props=", this.props, "state=", this.state, "event=", event)
    }

    handleEditMode(event) {
        event.preventDefault();
        let me = "UserCredForm.handleEditMode()"
        this.setState({isEditMode: true});
    }

        // todo: i think stateMgr ought to be in charge of data validation, ie duplicate habitName check.
    handleSubmit(event) {
        event.preventDefault();
        let me = "UserCredForm.handleSubmit()"
        console.log(me, "props=", this.props, "state=", this.state, "event=", event)
        this.setState({isEditMode: false});

        if (!MyUtils.isNullOrEmpty(this.state.username) && !MyUtils.isNullOrEmpty(this.state.password) ) {
            this.props.reduxedUpdateUserCred(this.state.username, this.state.password)
        }
    }


    render() {

        return (

            <form>
                <label>
                    <input type="text" value={this.state.username} onChange={this.handleUsernameChange} disabled={!this.state.isEditMode}/>
                </label>
&nbsp;
                <label >
                    <input type="text" value={this.state.password} onChange={this.handlePasswordChange} disabled={!this.state.isEditMode} />
                </label>

                { !this.state.isEditMode && <IconButton onClick={this.handleEditMode} > <EditorModeEdit /> </IconButton> }

                { this.state.isEditMode && <IconButton onClick={this.handleSubmit}> <ActionDone/> </IconButton> }
                { this.state.isEditMode && <IconButton onClick={this.handleCancel} > <NavigationCancel /> </IconButton> }

            </form>
        );
    }
}




// container house keeping below here


function mapStateToProps(state) {
    return {
        appDb: state
    }
}


function mapDispatchToProps(dispatch) {

    return({ reduxedUpdateUserCred: function(username: string, password: string) {

        let dispatchArg = {
            type: Konst.actn.UPDATE_USER_CRED,
            [Konst.arg.USERNAME]: username,
            [Konst.arg.PASSWORD]: password
        };

        dispatch(dispatchArg)
    } })
}


export default connect(mapStateToProps, mapDispatchToProps)(UserCredForm);