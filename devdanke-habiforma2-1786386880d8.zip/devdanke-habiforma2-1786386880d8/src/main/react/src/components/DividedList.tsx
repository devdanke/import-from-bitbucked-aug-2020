import * as React from 'react';
import {Component, ReactElement} from 'react';


import {List, ListItem} from 'material-ui/List';
import Divider from "material-ui/Divider";


export interface IItemData {
    id: string,
    name: string,
    actionBtn: any // why can't i use IconButton type here?  When I do, I get a big compile error. feb2018
}

interface DividedListProps {
    itemSvgIcon: ReactElement<any>,//SvgIcon that will go into an IconButton.
    dataItems: IItemData[]
}

interface DividedListState {
    dataItems: IItemData[]
}


class DividedList extends Component<DividedListProps, DividedListState> {

    constructor(props: DividedListProps) {
        super(props)

        this.state = { dataItems: props.dataItems };

        this.toListItem = this.toListItem.bind(this);
    }

    toListItem(dataItem: IItemData): ReactElement<ListItem> {

        return <ListItem key={dataItem.id + "__" + dataItem.name}
                         primaryText={dataItem.name}
                         rightIconButton={dataItem.actionBtn}
                         className="grayBottomBorder"/>
    }


    render() {
        //console.log("********** DividedList.render() IN: dataItems.count=", this.state.dataItems.length)

        const dividedListItems: ReactElement<ListItem>[] = this.state.dataItems
            .map(this.toListItem)  // todo: wish i could use flatMap for this instead. then wouldn't need listItemsDivider()

        return (
            <List>
                {dividedListItems}
            </List>
        );
    }
}

export default DividedList;


