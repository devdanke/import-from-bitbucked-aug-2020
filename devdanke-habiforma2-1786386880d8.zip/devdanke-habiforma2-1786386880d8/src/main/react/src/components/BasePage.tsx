import * as React from 'react';
import {Component, ReactElement} from 'react';
import {connect} from 'react-redux'

import AppBar from 'material-ui/AppBar';
import Toolbar from "material-ui/Toolbar";
import ToolbarGroup from "material-ui/Toolbar/ToolbarGroup";

import MyUtils from "../utils/MyUtils";
import Konst from "../utils/Konst";
import AppDb from "../state/IAppDb";


interface IBasePageProps {
    appDb: AppDb;
    
    className: string;
    body: React.ReactNode;

    headerTitle: string;
    isDirty: boolean;

    topLeftButton: ReactElement<any>;
    topRightButton?: ReactElement<any>;
    bottomLeftButton?: ReactElement<any>;
    bottomRightButton?: ReactElement<any>;
}

interface IBasePageState {
    isDirty: boolean;
    isStale: boolean;
}

export class BasePage extends Component <IBasePageProps, IBasePageState> {

    constructor(props) {
        super(props);

        this.state = {
            isDirty: props.isDirty,
            isStale: props.isStale
        }
    }

    componentWillReceiveProps(nextProps){
        console.log("BasePage.componentWillReceiveProps():", nextProps)
        this.setState({isDirty: nextProps.appDb.db.hasUnsavedChanges});
        this.setState({isStale: nextProps.appDb.rt.hasNewerRemoteBackup});
    }

    render() {

        const isDirtySignal: string = this.state.isDirty ? "*" : "";
        const isStaleSignal: string = this.state.isStale ? "^" : "";

        const myAppBar = () => (
            <AppBar
                className="headerStyle"
                title={`${this.props.headerTitle} ${isDirtySignal} ${isStaleSignal}`}
                iconElementLeft={this.props.topLeftButton}
                iconElementRight={this.props.topRightButton}
            />
        );

        const footer = <Toolbar className="footerStyle">

            {MyUtils.exists(this.props.bottomLeftButton) &&
                <ToolbarGroup firstChild={true}> {this.props.bottomLeftButton} </ToolbarGroup>
            }

            {MyUtils.exists(this.props.bottomRightButton) &&
                <ToolbarGroup lastChild={true}> {this.props.bottomRightButton} </ToolbarGroup>
            }
        </Toolbar>

        return (
            <div className={this.props.className} >
                {myAppBar()}

                <div className="pageBody">
                    {this.props.body}
                </div>

                { (MyUtils.exists(this.props.bottomLeftButton) || MyUtils.exists(this.props.bottomRightButton)) && footer }

            </div>
        );
    }
}


// container house keeping below here


function mapStateToProps(state) {
    return {
        appDb: state
    }
}

export default connect(mapStateToProps)(BasePage);


