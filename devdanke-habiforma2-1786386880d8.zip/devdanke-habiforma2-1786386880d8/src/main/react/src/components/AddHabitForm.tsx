/* eslint-disable */

import * as React from 'react';
import { Component } from 'react';
import {connect} from 'react-redux'
import { Redirect } from 'react-router-dom'

import Konst from '../utils/Konst';
import MyUtils from "../utils/MyUtils";
import MyHabitsMap from "../state/MyHabitsMap";

import AppDb from '../state/IAppDb'
import IHabitData from '../state/IHabitData'
import RaisedButton from "material-ui/RaisedButton";
import Dialog from "material-ui/Dialog";
import FlatButton from "material-ui/FlatButton";


interface AddHabitFormProps {
    appDb: AppDb;
    reduxedAddEditDeleteHabit: Function;
    habId: string;
    action: string;
}

interface AddHabitFormState {
    habId: string;
    habName: string;
    habHist: string[];
    submitSuccess: boolean;

    confirmDlg_open: boolean;
}

class AddHabitForm extends Component<AddHabitFormProps, AddHabitFormState> {

    constructor(props: AddHabitFormProps) {
        super(props);

        let habitId: string = null
        let habitName: string = ""
        let habitHist: string[] = []

        if(this.props.action == 'EDIT') {

            const habit = MyHabitsMap.getByIdSafe(this.props.appDb.db.habitsById, this.props.habId)

            habitId = habit.id
            habitName = habit.name
            habitHist = habit.hist
        }

        this.state = {
            habId: habitId,
            habName: habitName,
            habHist:habitHist,
            submitSuccess: false,
            confirmDlg_open: false
        };

        this.handleNameChange = this.handleNameChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.deleteHabit = this.deleteHabit.bind(this);
        this.openConfirmDeleteDlg = this.openConfirmDeleteDlg.bind(this);
        this.handleAbortDelete = this.handleAbortDelete.bind(this);
    }



    handleNameChange(event) {

        this.setState({habName: event.target.value});
    }

    // todo: i think stateMgr ought to be in charge of data validation, ie duplicate habitName check.
    handleSubmit(event) {
        event.preventDefault();
        let me = "AddHabitForm.handleSubmit()"

        console.log(me, "IN", "this.props=", this.props, "localState=", this.state)

        try {
            // this bool is only be used in ADD mode.
            let duplicateHabitName = ((this.props.action == 'ADD') &&
                AppDb.isDupHabitName(this.props.appDb, this.state.habName) )
            console.log(me, "duplicateHabitName=", duplicateHabitName)

            let nullOrEmpty = MyUtils.isNullOrEmpty(this.state.habName)
            console.log(me, "nullOrEmpty=", nullOrEmpty, "this.state.habName=", this.state.habName)

            if(!duplicateHabitName && !nullOrEmpty) {
                this.props.reduxedAddEditDeleteHabit(
                    MyUtils.makeHabitData(this.state.habId, this.state.habName, this.state.habHist),
                    (this.state.habId==null) ? Konst.ADD_HABIT : Konst.REPLACE_HABIT
                );
                this.setState({submitSuccess: true});
            }
            else {
                // todo: put red line around habit name box
                console.log(me, "add new habit rejected because duplicate|null|empty habit name:", this.state.habName)
            }
        }
        catch (e) {
            console.error(me, e.toString())
        }
    }

    deleteHabit() {

        try {

            this.props.reduxedAddEditDeleteHabit(
                MyUtils.makeHabitData( this.state.habId, this.state.habName, this.state.habHist),
                Konst.DELETE_HABIT
            );
            this.setState({submitSuccess: true});// do i need this here?  need to review state machine for this form
        }
        catch (e) {
            console.error("problem deleting habit", e)
        }
    }

    handleAbortDelete(event) {
        event.preventDefault();
        console.log("Abort delete.");
        this.setState({confirmDlg_open: false})
    }

    openConfirmDeleteDlg(event) {

        event.preventDefault();
        this.setState({confirmDlg_open: true})
    }


    render() {

        if (this.state.submitSuccess) {
            return (
                <Redirect to="/"/>
            )
        }

        const actions = [
            <FlatButton
                label="No"
                primary={true}
                onClick={this.handleAbortDelete}
            />,
            <FlatButton
                label="Yes"
                primary={true}
                onClick={this.deleteHabit}
            />,
        ];

        return (

            <form style={{padding:"2em"}}>
                <br />

                <label>
                    Name:&nbsp;&nbsp;
                    <input type="text" value={this.state.habName} onChange={this.handleNameChange} />
                </label>
                <br />
                <br />

                <RaisedButton onClick={this.handleSubmit} label="Submit" primary={true} />
                &nbsp;
                <RaisedButton onClick={this.openConfirmDeleteDlg} label="Delete" secondary={true} disabled={this.props.action == 'ADD'}  />

                <Dialog
                    title="Delete Habit"
                    actions={actions}
                    modal={true}
                    open={this.state.confirmDlg_open}

                >
                    Really delete this habit?
                </Dialog>

            </form>
        );
    }
}


// container house keeping below here


function mapStateToProps(state) {
    return {
        appDb: state
    }
}


function mapDispatchToProps(dispatch) {

    return({ reduxedAddEditDeleteHabit: function(habit: IHabitData, actionType: string) {

        let dispatchArg = {
            type: actionType,
            targetHabit: habit
        };

        console.log("reduxedAddEditDeleteHabit(): habit=", habit, "submitMode=", dispatchArg.type)

        dispatch(dispatchArg)
    } })
}


export default connect(mapStateToProps, mapDispatchToProps)(AddHabitForm);