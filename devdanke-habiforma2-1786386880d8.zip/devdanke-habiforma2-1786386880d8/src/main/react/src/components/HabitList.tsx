import * as React from 'react';
import {Component, ReactElement} from 'react';
import {connect} from 'react-redux'

import {AvPlayArrow} from "material-ui/svg-icons";
import {List, ListItem} from 'material-ui/List';
import Divider from "material-ui/Divider";
import {IconButton} from "material-ui";
import {Link} from "react-router-dom";

import IHabitData from '../state/IHabitData'
import AppDb from "../state/IAppDb";
import Konst from "../utils/Konst";


interface HabitListProps {
    habitDataList: IHabitData[]
}

interface IHabitListDataItem {id: string, habitDataListFromConnect: Function }


class HabitList extends Component<HabitListProps,object> {

  render() {

    const listItems: ReactElement<ListItem>[]  = this.props.habitDataList.map(function(habitDataItem): ReactElement<ListItem> {

        let listItem = <ListItem
            key={habitDataItem.id}

            primaryText={habitDataItem.name}

            rightIconButton={
                <IconButton
                    containerElement={<Link to={{
                        pathname: Konst.route.HABIT,
                        state: {
                            action: "EDIT",
                            habId: habitDataItem.id
                        }
                    }}/>}> <AvPlayArrow/> </IconButton>
            }

        />

        return listItem
    });

    // add divider between list items
      // todo: can i do this with css and a bottom margin etc on each list item?
    const dividedListItems: ReactElement<any>[] = [].concat(...listItems.map(e => [(<Divider key={Math.random()}/>), e])).slice(1)

    return (
      <List>
          {dividedListItems}
      </List>
    );
  }
}


function mapStateToProps(state) {
    return { habitDataList: AppDb.getHabitList(state) }
}

export default connect(mapStateToProps)(HabitList);

