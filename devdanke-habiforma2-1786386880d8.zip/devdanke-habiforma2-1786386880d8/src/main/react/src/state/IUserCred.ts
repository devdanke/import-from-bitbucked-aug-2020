

export interface IUserCred {

    username: string

    // md5('habiforma'+'-'+pass).toHex.toUpper
    hashword: string
}

export default class UserCred implements IUserCred {

    username = null;

    // md5('habiforma'+'-'+pass).toHex.toUpper
    hashword = null;
}







