import Konst from "../utils/Konst";
import IUserCred from "./IUserCred";
import UserCred from "./IUserCred";
import MyHabitsMap from "./MyHabitsMap";
import MyUtils from "../utils/MyUtils";
import {IHabitData} from "./IHabitData";

/*
Problem 1:
didn't work as expected.
in interface, can't use [HABITS_BY_ID] or [Konst.HABITS_BY_ID]
const HABITS_BY_ID = Konst.HABITS_BY_ID
const HAS_LOCAL_STORAGE = Konst.HAS_LOCAL_STORAGE
const USER_CRED = Konst.USER_CRED

Problem 2:
also, can not model HABITS_BY_ID as Map<string,IHabitData>.
i don't know why it won't work.  typescript doesn't understand es6 collections.
*/
export interface IPersistantState {
    // HABITS_BY_ID: Map<string,IHabitData>. don't use because afaik react must have plain js objects
    // like Map<string, IHabitData>
    habitsById: object;
    userCred: UserCred;
    whenLastBackup: Date;

    // this is just for unsave habitData
    hasUnsavedChanges: boolean;
}

export interface IRuntimeState {
    hasLocalStorage: boolean;
    hasNewerRemoteBackup: boolean;
}

export interface IAppDb {
    // persist to local storage
    db: IPersistantState;

    // runtime only. don't save to local storage.
    rt: IRuntimeState
}

export default class AppDb implements IAppDb {

    db = {
        habitsById: {},
        userCred: new UserCred(),
        whenLastBackup: null,
        hasUnsavedChanges: false
    }

    rt = {
        hasLocalStorage: false,
        hasNewerRemoteBackup: false
    }

    static getHabitList(appDb:AppDb): IHabitData[] {

        return MyUtils.getValuesFromMapLikeThing(appDb.db.habitsById) as IHabitData[]
    }


    static getHabitNames(appDb:AppDb): Array<string> {
        return (<any> Object).values( AppDb.getHabitList(appDb)).map(habit => habit.name)
    }

    static isDupHabitName(appDb:AppDb, candidateHabitName): boolean {

        return  MyHabitsMap.containsKey(appDb.db.habitsById, candidateHabitName)
    }

}






