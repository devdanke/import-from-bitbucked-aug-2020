
import Konst from '../utils/Konst'
import MyUtils from '../utils/MyUtils'
import AppDb, {IAppDb} from './IAppDb'
import IHabitData from './IHabitData'
import LocalStorageSvc from "../service/StorageService";
import MyHabitsMap from "./MyHabitsMap";
import IUserCred, {default as UserCred} from "./IUserCred";


// todo: factor habits out of stateReduce method
export default class MyReducer {

    static readonly me = "MyReducer";

    /* ****************************************************************************************************
    ONE AND ONLY REDUCER (AFAIK)

    This is the official state changer function that I register with redux to do all state transformations.
    All state is contained in my AppDb object tree.  Only this function changes that state.

    actionObject has TODO: make typescript interface for action param type
    - a type field
    - a text field

    stateObject a state object that has fields that my app knows how to read from.

    *************************************************************************************************** */
    public static calcNextState(state: AppDb, action: any): AppDb
    {
        const me = MyReducer.me + ".calcNextState():"
        console.log(me, "action:", action, "pre-action state:", state)
        let newState: IAppDb = null

        switch (action.type) {

            case Konst.actn.NOTIFY_STALE_HABIT_DATA:

                newState =  MyReducer._updateRtState(state, {hasNewerRemoteBackup:true})
                break;

            case Konst.actn.NOT_DIRTY_NO_MORE:

                newState =  MyReducer._resetIsDirty( state )
                break;

            case Konst.actn.UPDATE_USER_CRED:

                newState =  MyReducer._updateUserCred( state, action[Konst.arg.USERNAME], action[Konst.arg.PASSWORD] )
                break;

            case Konst.actn.RESTORE_BACKUP:

                newState = MyReducer._restoreBackup(state, action[Konst.arg.HABITS_BY_ID_BACKUP])
                break;

            case Konst.ADD_HABIT:

                newState =  MyReducer._addHabit(state, action)
                break;

            case Konst.REPLACE_HABIT:

                let replacementHabit: IHabitData = action["targetHabit"]
                let postReplaceState = MyReducer._replaceHabit(state, replacementHabit)
                LocalStorageSvc.overwritePersistantState(postReplaceState.db)
                newState =  postReplaceState
                break;

            case Konst.DELETE_HABIT:

                newState =  MyReducer._deleteHabit(state,  action["targetHabit"].id)
                break;

            case Konst.actn.DELETE_ALL_HABITS:

                LocalStorageSvc.clearDbHabits();
                newState =  MyReducer._updateDbState(state, {habitsById:{}, hasUnsavedChanges:true})
                break;

            case Konst.HABIT_ADD_DONE_DATE:

                newState =  MyReducer._addDoneDate(state,
                    MyHabitsMap.getByIdSafe(state.db.habitsById, action.habId),
                    action.targetDate)
                break;

            case Konst.HABIT_DELETE_DONE_DATE:

                newState =  MyReducer._deleteDoneDate(state,
                    MyHabitsMap.getByIdSafe(state.db.habitsById, action.habId),
                    action.targetDate)
                break;

            case "@@redux/INIT":

                newState = state
                break;

            default:

                console.error(me, "unknown action.type", action.type)
                newState = state
                break;
        }
        console.log(me, "post-action state:", newState)
        return newState
    }


    private static _deleteDoneDate(state: AppDb, targetHabit: IHabitData, targetDate: string): AppDb {

        MyUtils.removeItem(targetHabit.hist, targetDate)

        const newState =  MyReducer._replaceHabit(state, targetHabit)

        LocalStorageSvc.overwritePersistantState(newState.db)

        return newState;
    }

    // todo extract params in calcNextState and pass as args to this func
    private static _addDoneDate(state: AppDb, targetHabit: IHabitData, targetDate: string): AppDb {

        if(targetHabit.hist.indexOf(targetDate)== -1) {
            targetHabit.hist.push(targetDate)
        }
        else {
            console.error("ILLEGAL STATE: TARGET DONE DATE WAS ALREADY IN HABIT HISTORY.",
                "actn.targetDate:", targetDate)
        }

        let revisedState = MyReducer._replaceHabit(state, targetHabit)
        LocalStorageSvc.overwritePersistantState(revisedState.db)
        return revisedState
    }


    private static _restoreBackup(state: AppDb, habitsByIdBackup: object): AppDb {

        console.log("_restoreBackup() habitsByIdBackup=", habitsByIdBackup)

        let newState = MyReducer._resetIsDirty(state)
        console.log("_restoreBackup() after _resetIsDirty() newState=", newState)

        newState =  MyReducer._updateDbState(newState, {habitsById:habitsByIdBackup, hasUnsavedChanges:false})
        console.log("_restoreBackup() after _updateDbState() newState=", newState)

        // must come last or in this method. another way is to put this method into _resetIsDirty (because it also calls db)
        LocalStorageSvc.restoreBackup(habitsByIdBackup)

        return newState;
    }


    // todo extract params in calcNextState and pass as args to this func
    private static _addHabit(state: AppDb, action: any): AppDb {

        const habitId = MyUtils.genHabitId()

        const habit: IHabitData = (<any> Object).assign({}, action["targetHabit"], {"id":habitId})

        let habitsWithNewHabit: object = MyHabitsMap.putHabit( state.db.habitsById, habit )

        let revisedState = MyReducer._updateDbState(state, {habitsById:habitsWithNewHabit, hasUnsavedChanges:true})

        LocalStorageSvc.overwritePersistantState(revisedState.db)

        return revisedState
    }

    // gotta be careful or obj.assign overwrites a bunch of stufff
    // update persistent state in appDb (db persist done seperately)
    private static _updateDbState(state: AppDb, propChanges: object): AppDb {

        const revisedProps = Object.assign({}, state.db, propChanges)
        return Object.assign({}, state, {db: revisedProps})
    }

    // update runtime state
    private static _updateRtState(state: AppDb, propChanges: object): AppDb {

        const revisedProps = Object.assign({}, state.rt, propChanges)
        return Object.assign({}, state, {rt: revisedProps})
    }


    private static _resetIsDirty(state: AppDb): AppDb {

        const nowIso: string = new Date().toISOString()

        let newState = MyReducer._updateDbState(state, {hasUnsavedChanges:false, whenLastBackup:nowIso})
        console.log("MyReducer._resetIsDirty(): after updateDbState(): newState=", newState)

        newState = MyReducer._updateRtState(newState, {hasNewerRemoteBackup: false})
        console.log("MyReducer._resetIsDirty(): after _updateRtState(): newState=", newState)

        LocalStorageSvc.overwritePersistantState(newState.db)

        return newState
    }


    private static _updateUserCred(state: AppDb, username: string, password: string): AppDb {

        const userCred = new UserCred()
        if(username !== null && password !== null) {

            userCred.username = username
            userCred.hashword = MyUtils.naivePasswordAddSaltThenMd5Temp(password)
        }
        else {
            console.warn("_updateUserCred(): one or both username/password were null.  Therefore, clearing userCred.")
        }

        const newState = MyReducer._updateDbState(state, {userCred:userCred})

        LocalStorageSvc.overwritePersistantState(newState.db)

        return newState
    }

    // note: doesn't update localStorage, only appDb.
    private static _replaceHabit(state: AppDb, replacementHabit: IHabitData):  AppDb {

        const habitId: string = replacementHabit.id
        const revisedHabitsById: object = (<any> Object).assign({}, state.db.habitsById, {[habitId]:replacementHabit})


        return MyReducer._updateDbState(state, {habitsById:revisedHabitsById, hasUnsavedChanges:true})
    }

    private static _deleteHabit(state: AppDb, targetHabitId: string): AppDb {

        let revisedHabitsById: object = MyUtils.removeProperty(targetHabitId, state.db.habitsById)

        const revisedState = MyReducer._updateDbState(state, {habitsById:revisedHabitsById, hasUnsavedChanges:true})
        LocalStorageSvc.overwritePersistantState(revisedState.db)
        return revisedState
    }

}


