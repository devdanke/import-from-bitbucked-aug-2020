export interface IHabitData {

    id: string;
    name: string;

    // list of dates formatted yyyymmdd
    hist: string[];
}


export default class HabitData implements IHabitData{

    id = null;
    name = null;
    hist = [];
}

