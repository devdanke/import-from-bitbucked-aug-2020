import IHabitData from "./IHabitData";
import MyUtils from "../utils/MyUtils";


export default class MyHabitsMap {


    // returns Habit from current state.
    public static getByIdSafe(habitsObj: object, habId:string): IHabitData {
        console.log("MyHabitsMap.getById() habits:", habitsObj)
        let habit: IHabitData = habitsObj[habId]
        return MyUtils.exists(habit) ?  Object.assign({}, habit)  : null
    }

    // return a new copy of the habitsObj with the new habit either added or overwriting the existing habit that had that id.
    public static putHabit(habitsObj: object, habit:IHabitData): object {
        console.log("MyHabitsMap.putHabit() habits:", habitsObj)

        return (<any> Object).assign({}, habitsObj, {[habit.id]:habit})
    }

    public static containsKey(habitsObj: object, candidateKey: string): boolean {

        let result =  habitsObj.hasOwnProperty(candidateKey)
        console.log("MyHabitsMap.containsKey() candidateKey:", candidateKey, "habit keys", Object.keys(habitsObj))
        return result
    }

}






