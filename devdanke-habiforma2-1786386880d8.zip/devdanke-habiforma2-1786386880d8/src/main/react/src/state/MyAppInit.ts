import {createStore, Store} from 'redux';


import AppDb from './IAppDb'
import StorageSvc from "../service/StorageService";
import MyReducer from "./MyReducer";
import MyConfig from "../MyConfig";
import Konst from "../utils/Konst";
import MyUtils from "../utils/MyUtils";


export default class MyAppInit {

    public static initAppDbStore(): Store<AppDb> {

        console.log("MyInit.initAppDbStore(): MyConfig:", MyConfig.toStr())

        let appDb: object = StorageSvc.getOrCreateLocalStorageBackingForAppDb()

        let store = createStore(MyReducer.calcNextState, appDb)
        return <Store<any>> store
    }

}


