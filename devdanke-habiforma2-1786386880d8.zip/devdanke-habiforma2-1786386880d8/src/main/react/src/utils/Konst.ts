import HabitListPage from "../pages/HabitListPage";
import SettingsPage from "../pages/SettingsPage";
import HabitDetailPage from "../pages/HabitDetailPage";
import BackupPage from "../pages/BackupPage";

export default class Konst {

    // redux actions
    public static readonly ADD_HABIT: string =     "ADD_HABIT";
    public static readonly REPLACE_HABIT: string = "REPLACE_HABIT";
    public static readonly DELETE_HABIT: string =  "DELETE_HABIT";

    public static readonly actn = {
        RESTORE_BACKUP : "RESTORE_BACKUP",
        DELETE_ALL_HABITS: "DELETE_ALL_HABITS",
        UPDATE_USER_CRED: "UPDATE_USER_CRED",
        NOT_DIRTY_NO_MORE: "NOT_DIRTY_NO_MORE",
        NOTIFY_STALE_HABIT_DATA: "NOTIFY_STALE_HABIT_DATA",
    }

    // action arguments
    public static readonly arg = {
        HABITS_BY_ID_BACKUP : "HABITS_BY_ID_BACKUP",

        // for actn UPDATE_USER_CRED
        USERNAME: "USERNAME",
        PASSWORD: "PASSWORD"
    }
    public static readonly HABIT_ADD_DONE_DATE: string =  "HABIT_ADD_DONE_DATE";
    public static readonly HABIT_DELETE_DONE_DATE: string =  "HABIT_DELETE_DONE_DATE";

    public static readonly PASSWORD_SALT = "habiforma"

    public static readonly route = {
        HOME:     "/",
        HABIT:    "/habit",
        SETTINGS: "/settings",
        BACKUPS:  "/backups"
    }
}
