
import MyUtils from "./MyUtils";

export default class MyDateUtils {

    private static MONTHS_1ST_CHAR: string[] = ['J','F','M','A','M','J','J','A','S','O','N','D']


    public static toYyyymmdd(aDate: Date): string {

        const m = (aDate.getMonth()+1).toString()

        const d = aDate.getDate().toString()

        const yyyy = aDate.getFullYear().toString();

        const result = yyyy + MyUtils.zeroPadDigit(m) + MyUtils.zeroPadDigit(d);

        return result
    }

    public static toYy_mmdd_hhmm(aDate: Date): string {

        const m = (aDate.getMonth()+1).toString()

        const result = aDate.getFullYear().toString().substr(2,2) + "-" +
            MyUtils.zeroPadDigit(m) +
            MyUtils.zeroPadDigit(aDate.getDate().toString()) + "-" +
            MyUtils.zeroPadDigit(aDate.getHours().toString()) +
            MyUtils.zeroPadDigit(aDate.getMinutes().toString())
            ;

        return result
    }

    // todo: maybe move to a TestUtils
    public static todayMinusDayYmd(daysBefore: number): string {
        let d = new Date();
        d.setDate(d.getDate()-daysBefore);
        return MyDateUtils.toYyyymmdd(d)
    }



    public static month1stChar(yyyymmdd: string): string {

        return MyDateUtils.MONTHS_1ST_CHAR[parseInt(yyyymmdd.substr(4,2))-1]
    }
}

