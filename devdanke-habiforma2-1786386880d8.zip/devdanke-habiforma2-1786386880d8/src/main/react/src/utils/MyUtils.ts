
import IHabitData from '../state/IHabitData'
import Konst from "./Konst";
import md5 from 'md5-hash'



export default class MyUtils {

    static getDeviceInfo(): any {
        return {
            windowInnerWidth: window.innerWidth,
            windowOuterWidth: window.outerWidth,
            windowInnerHeight: window.innerHeight,
            windowOuterHeight: window.outerHeight,
            screenOrientation: window.orientation,
            screen: window.screen,
            userAgent: navigator
            // https://developer.mozilla.org/en-US/docs/Web/API/Navigator
        }
    }

    public static exists(thing: any): boolean {
        return (typeof thing !== 'undefined')
    }

    public static existsAndNotNull(thing: any): boolean {
        return ((typeof thing !== 'undefined') && (thing != null))
    }

    // https://stackoverflow.com/questions/34401098/remove-a-property-in-an-object-immutably
    static removeProperty(deleteKey: string, target: object): object {

        console.log("MyUtils.removeProperty(): delKey=", deleteKey, "target=", target)

        let newObj =  (<any> Object).assign({}, target); //Object.create(target);

        let deleteSuccess = delete newObj[deleteKey];

        console.log("MyUtils.removeProperty(): newObj after delete=", newObj, "deleteSuccess=", deleteSuccess)

        return newObj
    }

    /*
     rand int between 0 and Number.MAX_SAFE_INTEGER

     todo: i think this is giving a number in scientific notation. i just want an int in some big range, like 0 to 1 billion.
     A guid would work too.  Maybe that's what I should use.
     todo: i don't like sci notation format!

     */
    static genRandInt(): number {
        return Math.floor(Math.random() * Number.MAX_VALUE)
    }

    static isNullOrEmpty(val: string): boolean {
        let result = ((val === null) || (val.trim().length === 0))
        return result
    }

    /*
    removeItem item from array.
    return nothing
     */
    static removeItem(arr: any[], item: any): void {
        let index = arr.indexOf(item);
        if (index > -1) {
            arr.splice(index, 1);
        }
    }

    static zeroPadDigit(digit: string) {
        return digit.length < 2 ? "0".concat(digit) : digit
    }

    static getValuesFromMapLikeThing(mapLikeThing: object) : object[] {

        return Object.keys(mapLikeThing).map(key => { return mapLikeThing[key] })

    }

    static makeHabitData(id: string, name: string, hist: string[]): IHabitData {
        return {id: id, name: name, hist: hist}
    }

    static genHabitId(): string {
        return "hab_" + MyUtils.genRandInt()
    }


    /*
    md5(salt+"="+pass).toHex.toUpperCase
    https://www.npmjs.com/package/md5-hash
    todo: switch to sha256 or whatever oswap recommends or use actual library.
     */
    static naivePasswordAddSaltThenMd5Temp(password: String): string {
        // todo: use a 'for real' js lib that does crypto safe hash to constant hash length.
        return md5(`${Konst.PASSWORD_SALT}-${password}`).toUpperCase()
    }


}

