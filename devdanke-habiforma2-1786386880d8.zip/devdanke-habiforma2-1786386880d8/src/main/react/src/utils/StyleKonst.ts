

export default class StyleKonst {

    public static readonly TOUCH_TEXT_SIZE: object = {fontSize: 'xx-large'};
    public static readonly TOUCH_ICON_SIZE: object = {transform: 'scale(1.8)'};

    // warning; nogo; This one blew up the appBar when applied.
    // instead had to apply text and icon size styles to each elem.
    public static readonly TOUCH_ALL_SIZE: object = {fontSize: 'x-large', transform: 'scale(1.5)'};
}

