// encode decode habit data for rest body. It can't be in json.
// encoding is 1st -> json 2nd -> base64
export default class MyDNCoder {

    public static encode(habitData: object): string {
        return btoa(JSON.stringify(habitData))
    }

    public static decode(encodedHabitData: string): object {
        return JSON.parse(atob(encodedHabitData))
    }

}

