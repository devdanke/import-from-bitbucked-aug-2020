import MyUtils from "./MyUtils";
import IUserCred from "../state/IUserCred";

export default class MyRestClient {

    //static makeAuthHeaderToken(appDb:AppDb):string  {
    static makeAuthHeaderToken(userCred: IUserCred):string  {
        return `${userCred.username}|${userCred.hashword}`
    }

    static get(url:string, userCred: IUserCred, onSuccess: any, onError: any) {

        const myHeaders = new Headers()
        myHeaders.append('Accept', 'application/json')
        myHeaders.append('Authorization', MyRestClient.makeAuthHeaderToken(userCred) )

        const request = new Request(url, {
            method: 'GET',
            mode: 'cors',
            //mode: 'no-cors',
            redirect: 'follow',
            headers: myHeaders
        });

        fetch(request)
        // kinda weird, gotta call then().then() because resp.json() returns another promise.
            .then(MyRestClient._detectAndConvertNon2xxToError)
            .then(resp=>resp.json()).then(onSuccess)
            .catch(onError)
    }


    // As of now, caller should provide the errorHandler.
    // For onError, maybe just log it and return a default value or user friendly display message.
    static post(url:string, userCred: IUserCred, data:object, onSuccess: any, onError: any) {

        const myHeaders = new Headers({
            'Accept':      'application/json',
            'Content-type': 'application/json',
            'Authorization': MyRestClient.makeAuthHeaderToken(userCred)
        });

        const req = new Request(url, {

            body: JSON.stringify(data), // must match 'Content-Type' header
            cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
            headers: myHeaders,
            mode: 'cors',
            //mode: 'no-cors',
            method: 'POST',
            redirect: 'follow'
        })
        console.log("post req=", req, "headers=", req.headers)

        return fetch(req)
            .then(MyRestClient._detectAndConvertNon2xxToError)
            .then((resp)=> {resp.json();})  // extract value. but that could cause an error.
            .then(onSuccess)
            .catch(onError)
    }

    static _detectAndConvertNon2xxToError(response) {
        if (!response.ok || response.status != 200) {
            //console.log("Going to throw a big fat error. Because server sent: ", response)
            throw Error(response.statusText);
        }
        else {
            //console.log("_detectAndConvertNon2xxToError not triggered.")
        }
        return response;
    }

}

