import * as React from 'react';
import * as ReactDOM from 'react-dom';

import { Provider } from 'react-redux';

import * as injectTapEventPlugin from 'react-tap-event-plugin'; // for material-ui

import './css/normalize-7.0.0.css';
import './css/mystyle.css';

import App from './App';

// import registerServiceWorker from './registerServiceWorker';
import AppDb from "./state/IAppDb";
import {Store} from "redux";
import MyInit from "./state/MyAppInit";
import MyUtils from "./utils/MyUtils";

injectTapEventPlugin();  // for material-ui

let store: Store<AppDb>  = MyInit.initAppDbStore()

console.log("index.tsx render(): store=", store )

ReactDOM.render(
    <Provider store={store}>
        <App />
    </Provider>
    ,
    document.getElementById('root'));


console.log("DISALBED registerServiceWorker()")
console.log("deviceInfo:", MyUtils.getDeviceInfo() )
// remove because chrome requires app be from https, which i don't have yet.
// registerServiceWorker();


