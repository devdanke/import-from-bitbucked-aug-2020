/* eslint-disable */

import * as React from 'react';
import {Component} from 'react';

//import { BrowserRouter, Route } from 'react-router-dom'
import { HashRouter, Route } from 'react-router-dom'
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

import HabitListPage from "./pages/HabitListPage";
import HabitDetailPage from "./pages/HabitDetailPage";
import SettingsPage from "./pages/SettingsPage";
import BackupPage from "./pages/BackupPage";
import MyConfig from "./MyConfig";
import Konst from "./utils/Konst";

export default class App extends Component {


  render() {
      console.log("App.render()")

      // Note: Using HashRouter because it reduces changes of accidental redirect of non-home page
      // to server, eg http://host/backups.  also, when server not reachable, non-home pages don't
      // show blank and spinning timer for ever.
        return (
            <MuiThemeProvider>

                <HashRouter basename={MyConfig.calcDeployEnvInfo().baseDir} >
                    <div id="routerWrapperDiv">
                        <Route path={Konst.route.HOME} exact component={HabitListPage}/>
                        <Route path={Konst.route.HABIT} exact component={HabitDetailPage}/>
                        <Route path={Konst.route.SETTINGS} exact component={SettingsPage}/>
                        <Route path={Konst.route.BACKUPS} exact component={BackupPage}/>
                    </div>
                </HashRouter>
            </MuiThemeProvider>

        );
  }
}



