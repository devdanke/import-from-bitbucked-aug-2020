
import MyDateUtils from "./utils/MyDateUtils";

// TODO: Most of this file is a mess.  Need better way to get Maven version and build target env onto settings page.

// https://medium.com/the-missing-bit/using-node-env-with-typescript-and-webpack-689a85041978
declare var process : {
    env: {
        NODE_ENV: string,
        REACT_APP_BASEDIR: string,
        REACT_APP_USERID: string,
        REACT_APP_MAVEN_BUILD_VER: string
    }
}

export default class MyConfig {

    static readonly me = "MyConfig"

    static readonly CFG_MAVEN_BUILD_VER: string = ((process.env.REACT_APP_MAVEN_BUILD_VER) ? (process.env.REACT_APP_MAVEN_BUILD_VER) : 'local-dev');
    static readonly CFG_REACT_APP_NODE_ENV: string = process.env.NODE_ENV;
    // todo: if really not needed, remove from pkg.json too.
    static readonly CFG_REACT_APP_BASEDIR: string = process.env.REACT_APP_BASEDIR;

    static readonly CFG_BASE_API_PATH = "api";
    static readonly CFG_LOCAL_DEV_BASE_API_URL = `http://localhost:5000/${MyConfig.CFG_BASE_API_PATH}`;

    static readonly APP_VER = "2"  // march 18


    static getDoneDatelookbackCount(): number {
        // 10 because of iPhone SE narrow width.
        // todo: make this an automatic calc later. or let use decide because it copies habit names.
        return 10;
    }


    /*
    In the simplest local dev mode, react runs from node on port 3000 and rest api runs from spring boot on port 5000.
    In all other cases, react and rest api run from same server with same base url.
     */
    static getBaseApiUrl(): string {
        if(window.location.port==="3000") {
            // special case simple local dev
            return `http://localhost:5000/${MyConfig.CFG_BASE_API_PATH}`;
        }
        else {
            // most common
            return `${window.location.origin}/${MyConfig.CFG_BASE_API_PATH}`;
        }
    }

    static getBackupsUrl(): string {
        return  `${MyConfig.getBaseApiUrl()}/users/~/backups`;
        //return  `${MyConfig.getBaseApiUrl()}/users/${MyConfig.getUserId()}/backups`;
    }

    // todo: move outside app.  do in build process
    static calcVersion(): string {

        console.log("reactAppNodeEnv:", MyConfig.CFG_REACT_APP_NODE_ENV)

        let targetRuntimeEnv: string = null

        if( !MyConfig.CFG_REACT_APP_NODE_ENV ) {
            targetRuntimeEnv = "buildEnv-undefined"
        }
        else if ( MyConfig.CFG_REACT_APP_NODE_ENV === 'development') {
            targetRuntimeEnv = "D"
        }
        else if ( MyConfig.CFG_REACT_APP_NODE_ENV === 'production' ) {
            targetRuntimeEnv =  "P"
        }
        else  {
            targetRuntimeEnv =  "buildEnv-unknown"
            console.warn("unknown build env: ", MyConfig.CFG_REACT_APP_NODE_ENV)
        }

        return targetRuntimeEnv +"-" + MyConfig.CFG_MAVEN_BUILD_VER
    }

    static calcDeployEnvInfo(): any {

        let deployEnvName = (MyConfig.CFG_REACT_APP_BASEDIR.indexOf("/") !== 0) ? "prod": MyConfig.CFG_REACT_APP_BASEDIR.substr(1)
        let appBaseDir = (deployEnvName==="prod") ? "" : MyConfig.CFG_REACT_APP_BASEDIR

        // envName is to display on settings page
        // appBaseDir is subdir app run from on aws: prod=/, dev=/dev, stage=/stage
        return {
            envName: deployEnvName,
            baseDir: appBaseDir
        }
    }


    // just for logging
    static toStr(): string {

        return Object.getOwnPropertyNames(MyConfig)
            .filter(name => name.startsWith("CFG_"))
            .map(prop => `${prop}='${MyConfig[prop]}'`)
            .toString()
    }
}



