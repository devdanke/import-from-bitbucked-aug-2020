
/*
Must keep syncronized with server's definition.
 */

export default class IRemoteBackupInfo {
    id: string;
    name: string;
    backupRelLink: string;
}






