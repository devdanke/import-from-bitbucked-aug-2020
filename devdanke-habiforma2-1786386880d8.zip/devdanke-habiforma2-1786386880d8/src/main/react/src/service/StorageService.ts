import Konst from '../utils/Konst'
import MyUtils from '../utils/MyUtils'
import {default as AppDb, IPersistantState} from '../state/IAppDb'
import IHabitData from '../state/IHabitData'
import IUserCred, {default as UserCred} from "../state/IUserCred";
import MyConfig from "../MyConfig";
import DbUpgradeService from "./DbUpgradeService";

export interface IDbReadResult {val: any, isUndef: boolean, isNull: boolean }
export class DbResult implements IDbReadResult { val= null; isUndef=false; isNull=false;}

export class DbKonst  {

    static readonly HABITS_BY_ID= "HABITS_BY_ID";
    static readonly USER_CRED= "USER_CRED";
    static readonly HAS_UNSAVED_CHANGES= "HAS_UNSAVED_CHANGES";
    static readonly WHEN_LAST_BACKUP= "WHEN_LAST_BACKUP";
    static readonly APP_VER= "APP_VER";
}
/*
Store entire habitDb (from memory).  Add/update/delete of individual habits happens in MyStateManager.
 */
export default class StorageService {

    /* ***************************************************************************
 */
    static getOrCreateLocalStorageBackingForAppDb(): AppDb {

        const appDb = new AppDb();

        appDb.rt.hasLocalStorage = StorageService._hasLocalStorage();
        console.log("hasLocalStorage=", appDb.rt.hasLocalStorage, "empty db:", appDb);

        if(appDb.rt.hasLocalStorage) {

            const converter = new DbUpgradeService()
            converter.detectAndUpgradeOldSchema()

            appDb.db.habitsById = StorageService._loadValOrFixAndUseDefault(DbKonst.HABITS_BY_ID,{},
                StorageService._fixNullorUndefined)

            appDb.db.userCred = StorageService._loadValOrFixAndUseDefault(DbKonst.USER_CRED,new UserCred(),
                StorageService._fixNullorUndefined)

            appDb.db.hasUnsavedChanges = StorageService._loadValOrFixAndUseDefault(DbKonst.HAS_UNSAVED_CHANGES, false,
                StorageService._fixNullorUndefined )

            appDb.db.whenLastBackup = StorageService._loadValOrFixAndUseDefault(DbKonst.WHEN_LAST_BACKUP, null,
                StorageService._fixUndefined )

            console.log("initialized appDb=", appDb)
        }
        else {
            console.warn("LocalStorage not supported. All habit data will be lost when webapp closes." )
        }

        return appDb
    }


    static overwritePersistantState(state: IPersistantState) {

        console.log("over write local storage with:", state)
        localStorage.setItem(DbKonst.APP_VER, JSON.stringify(MyConfig.APP_VER))
        localStorage.setItem(DbKonst.HABITS_BY_ID, JSON.stringify(state.habitsById))
        localStorage.setItem(DbKonst.USER_CRED,    JSON.stringify(state.userCred))
        localStorage.setItem(DbKonst.HAS_UNSAVED_CHANGES, JSON.stringify(state.hasUnsavedChanges))
        localStorage.setItem(DbKonst.WHEN_LAST_BACKUP, JSON.stringify(state.whenLastBackup))
    }


    static clearDbHabits() {

        localStorage.setItem(DbKonst.HABITS_BY_ID, "{}")
    }


    /* ***************************************************************************
       Save current habit data, then replace it with backup habit data.
     */
    static restoreBackup(habitsById: object) {
        console.log("restoreBackup(): habitsByIdBackup=", habitsById)

        localStorage.setItem(DbKonst.HABITS_BY_ID, JSON.stringify(habitsById));
    }


    /* ***************************************************************************
     */
    static _validateOrDeleteEachHabit(habitsById) {

        Object.keys(habitsById).map(function(key, index) {
            if(habitsById[key] === null ) {
                delete habitsById[key]
            }
        });

        return habitsById
    }

    static load(itemKey: string): object {
        const value = window.localStorage.getItem(itemKey)
        return MyUtils.exists(value) ? JSON.parse(value) : null;
    }

    /* ***************************************************************************
     */
    static _loadValOrFixAndUseDefault(key: string, defaultValue: any, fixer: Function): any {

        const result = new DbResult()

        const rawVal = localStorage.getItem(key)
        result.isUndef = (typeof rawVal === 'undefined')
        result.isNull = (rawVal == null)
        result.val = MyUtils.exists(rawVal) ? JSON.parse(rawVal) : null;

        return fixer(result, key, defaultValue)
    }


    /* ***************************************************************************
     */
    static _fixNullorUndefined(result: DbResult, dbKey: string, defaultValue: any): any {
        if(result.isUndef || result.isNull) {
            localStorage.setItem(dbKey, JSON.stringify(defaultValue))
            result.val = defaultValue
        }

        return result.val
    }


    /* ***************************************************************************
     */
    static _fixUndefined(result: DbResult, dbKey: string, defaultValue: any): any {
        if(result.isUndef || result.isNull) {
            console.log(`localStorage had invalid value for ${dbKey}.`, 
                `Fixed it in DB.  Will use default value= '${JSON.stringify(defaultValue)}'.`, )
            localStorage.setItem(dbKey, JSON.stringify(defaultValue))
            result.val = defaultValue
        }

        return result.val
    }


    /*
    from:
      https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API
     */
    static _hasLocalStorage() {
        let storage = null;
        try {
            storage = window['localStorage'];
            let    x = '__storage_test__';
            storage.setItem(x, x);
            storage.removeItem(x);
            return true;
        }
        catch(e) {
            return e instanceof DOMException && (
                    // everything except Firefox
                e.code === 22 ||
                // Firefox
                e.code === 1014 ||
                // test name field too, because code might not be present
                // everything except Firefox
                e.name === 'QuotaExceededError' ||
                // Firefox
                e.name === 'NS_ERROR_DOM_QUOTA_REACHED') &&
                // acknowledge QuotaExceededError only if there's something already stored
                storage.length !== 0;
        }
    }

}

