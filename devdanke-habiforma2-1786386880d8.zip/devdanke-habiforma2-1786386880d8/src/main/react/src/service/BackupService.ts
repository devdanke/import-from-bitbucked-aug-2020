
import IHabitData from '../state/IHabitData'
import MyDNCoder from "../utils/MyDNCoder";
import MyConfig from "../MyConfig";
import {default as MyRestClient} from "../utils/MyRestClient";
import AppDb from "../state/IAppDb";
import IUserCred from "../state/IUserCred";
import MyUtils from "../utils/MyUtils";


export interface IRestoreResult {
    success: boolean;
    reason?: string;
}

export default class BackupService {

    /* ***************************************************************************
    hopefully, onSuccess will be given a list of backup infos.

    If there's an error. Just log it and return an empty list.
     */
    static getRemoteBackupInfos(userCred: IUserCred, onSuccess, afterDate: Date = null) {

        const qstr = (afterDate != null) ? `?after=${afterDate}` : ""

        console.log("url=", MyConfig.getBackupsUrl()+qstr)
        const onError =  (errObjOfSomeKind) => {
            console.error("getBackupInfos(): failed because: ", errObjOfSomeKind);
            return []  // empty list of backupInfos
        }
        MyRestClient.get(MyConfig.getBackupsUrl()+qstr, userCred, onSuccess, onError);
    }

    /* ***************************************************************************
     */
    static getBackupDataForRestore(backupRelLink: string, userCred: IUserCred, onSuccess: Function) {

        const targetBackupUrl = `${MyConfig.getBaseApiUrl()}/${backupRelLink}`
        const onError =  (errObjOfSomeKind) => {
            console.error("getBackupDataForRestore(): failed because: ", errObjOfSomeKind);
        }
        MyRestClient.get(targetBackupUrl, userCred, onSuccess, onError);
    }


    /* ***************************************************************************
     */
    private static _habitToHabitById(habitsByIdMap: object, hd: IHabitData): object {
        habitsByIdMap[hd.id] = hd
        return habitsByIdMap
    }

    /* ***************************************************************************
     */
    private static _convertHabitListToHabitsById(habitList: IHabitData[]) {

        const habitsById = habitList.reduce( this._habitToHabitById,  {})
        console.log("convertHabitListToHabitsById(): input=", habitList, "output=",habitsById)
        return habitsById;
    }

    /*
    Encode data in Base64 so it's safe to be in Post body as JSON (ie not cause parse errors).
    TODO: is this needed? i think json.stringify already makes json safe.
     */
    static toJsonSafeString(habitDataList: IHabitData[]): string {

        return MyDNCoder.encode(habitDataList);
    }

    static decodeAndMapById(habitListBase64Encoded: string): object {

        const habitList = MyDNCoder.decode(habitListBase64Encoded) as IHabitData[];
        console.log("decoded habitList=", habitList);

        return BackupService._convertHabitListToHabitsById(habitList);
    }
}
