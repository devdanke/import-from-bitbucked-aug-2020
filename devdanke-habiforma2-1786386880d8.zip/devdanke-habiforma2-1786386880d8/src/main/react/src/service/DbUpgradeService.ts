
import IHabitData from '../state/IHabitData'
import Konst from "../utils/Konst";
import md5 from 'md5-hash'
import {DbKonst, default as StorageService} from "./StorageService";
import MyUtils from "../utils/MyUtils";
import UserCred from "../state/IUserCred";

/*
Convert on DB Version to another.
 */
export default class DbUpgradeService {

    detectAndUpgradeOldSchema() {
        const appVer = this._readRaw(DbKonst.APP_VER)
        if(appVer===null || appVer==="1") {
            this._convertUserCredSchemaV1orVNoneToV2()
        }
        else {
            //console.log("DB schema conversion not needed.")
        }
    }

    _convertUserCredSchemaV1orVNoneToV2() {
        const userCred = this._readToJson(DbKonst.USER_CRED);
        if(MyUtils.existsAndNotNull(userCred)) {
            if(MyUtils.existsAndNotNull(userCred.USERNAME) && MyUtils.existsAndNotNull(userCred.HASHWORD)) {
                const newUserCred = new UserCred()
                newUserCred.username = userCred.USERNAME
                newUserCred.hashword = userCred.HASHWORD
                localStorage.setItem(DbKonst.USER_CRED, JSON.stringify(newUserCred))
                console.log("Converted userCred v? to v2")
            }
        }
    }

    _readRaw(key: string): string {
        return localStorage.getItem(key)
    }

    _readToJson(key: string): any {

        return StorageService.load(key)
    }
}

