what are swagger urls?

mvn aws:deploy
https://goo.gl/ZqKgNg


https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet

aws
===

ec2
---
- My app is under /opt/elasticbeanstalk/deploy/.  It's called software_bundle.
- Become root: `sudo su`
- ssh: `ssh -i z-my-aws/habiforma2-uswest2-ssh-cred-keypair.pem  ec2-user@ec2-34-216-156-183.us-west-2.compute.amazonaws.com`
- ssh: even better, use `ssh hf2`, defined in .ssh/config with:

```
    Host hf2
        HostName ec2-34-216-156-183.us-west-2.compute.amazonaws.com
        User ec2-user
        IdentityFile ~/_dev/habiforma2/z-my-aws/habiforma2-uswest2-ssh-cred-keypair.pem
```
- prod release/deploy: 
```
mvn --batch-mode release:prepare -P aws,react; mvn release:perform  -P aws,react; staging_deploy.kts
```

how to build and run latest sboot and react
-------------------------------------------
- (can test with 'npm run build' to pre-discover error)
- mvn clean package -Preact,aws
- java -jar target/habiforma2-0.0.9-SNAPSHOT.jar
- what is the react app base url?


list all icons
--------------
https://material.io/icons/


run react standalone
====================
- prod build (npm run build)
    - npm install http-server -D
    - ./node_modules/.bin/http-server build -p 5000


misc
====
- goreact alias



