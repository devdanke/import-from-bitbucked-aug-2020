package lingo.flashdeck.mvcweb;

import lingo.flashdeck.quizzer.xmlgen.lesson.Item;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;
import lingo.flashdeck.quizzer.xmlgen.lesson.RepType;

import static java.lang.String.format;

/**
 * *************************************************************************************
 *
 * @Since 1/9/12
 *
 *
 *

    protected String calcLessonType(Lesson lesson)
    {
        Item item = lesson.getItem().get(0);
        RepType f1RepType = item.getFact1().getRepType();
        RepType f2RepType = item.getFact2().getRepType();

        if( isPic(f1RepType) && isSound(f2RepType) )
        {
            return "PIC__SOUND"; //most common
        }
        else if( isTextThai(f1RepType) && isSound(f2RepType) )
        {
            return "TEXT_TH__SOUND"; //thai numbers lesson
        }
        else if( isSound(f1RepType) && isText(f2RepType) )
        {
            return "SOUND__TEXT"; //tones lesson
        }
        else if( isCanvas(f1RepType) && isSound(f2RepType) )
        {
            return "CANVAS__SOUND"; //same as PIC__SOUND but browser draws
        }
        else if( isTextThai(f1RepType) && isText(f2RepType) )
        {
            return "TEXT_TH__TEXT"; //same as PIC__SOUND but browser draws
        }
        else
        {
            throw new RuntimeException(format("lesson '%s' has unknown repType. fact1: %s, fact2: %s",
                lesson.getName(), f1RepType, f2RepType));
        }
    }
 *
 * *************************************************************************************
 */
public enum LessonRepType
{
    PIC__SOUND,
    TEXT_TH__SOUND,
    SOUND__TEXT,
    CANVAS__SOUND,
    TEXT_TH__TEXT;

    /*
    based on first item, decide whether lesson is type:
    PIC__SOUND (most common),
    SOUND__TEXT (tones lesson),
    TEXT_TH__SOUND (thai numbers).
     */
    public static String calcType(String lessonName, RepType f1RepType, RepType f2RepType)
    {
        if( isPic(f1RepType) && isSound(f2RepType) )
        {
            return "PIC__SOUND"; //most common
        }
        else if( isTextThai(f1RepType) && isSound(f2RepType) )
        {
            return "TEXT_TH__SOUND"; //thai numbers lesson
        }
        else if( isSound(f1RepType) && isText(f2RepType) )
        {
            return "SOUND__TEXT"; //tones lesson
        }
        else if( isCanvas(f1RepType) && isSound(f2RepType) )
        {
            return "CANVAS__SOUND"; //same as PIC__SOUND but browser draws
        }
        else if( isTextThai(f1RepType) && isText(f2RepType) )
        {
            return "TEXT_TH__TEXT"; //same as PIC__SOUND but browser draws
        }
        else
        {
            throw new RuntimeException(format("lesson '%s' has unknown repType. fact1: %s, fact2: %s",
                lessonName, f1RepType, f2RepType));
        }
    }

    //TODO: maybe add these to Java enum for the repTypes, eg
    private  static boolean isSound(RepType repType)
    {
        return RepType.SOUND == repType;
    }

    private  static boolean isPic(RepType repType)
    {
        return RepType.PIC == repType;
    }

    private  static boolean isText(RepType repType)
    {
        return RepType.TEXT == repType;
    }

    private  static boolean isTextThai(RepType repType)
    {
        return RepType.TEXT_TH == repType;
    }

    private  static boolean isCanvas(RepType repType)
    {
        return RepType.CANVAS== repType;
    }
}
