package lingo.flashdeck.mvcweb;

import lingo.flashdeck.common.util.MyAssert;

/**
 * *******************************************************************
 * ********************************************************************
 */
public class MyConfig
{
    private final String _lessonServiceUrl;

    public MyConfig(String lessonServiceUrl)
    {
        MyAssert.notNullOrEmpty("lessonServiceUrl", lessonServiceUrl);
        _lessonServiceUrl = lessonServiceUrl;
    }

    public String getLessonServiceUrl()
    {
        return _lessonServiceUrl;
    }
}
