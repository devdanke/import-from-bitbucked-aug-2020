package lingo.flashdeck.mvcweb;

/**
 * Holds an item's id,
 */

public class TakenResult
{
    private long _itemId;
    private boolean _isCorrect;

    public TakenResult(long itemId, boolean correct)
    {
        _itemId = itemId;
        _isCorrect = correct;
    }

    public long getItemId()
    {
        return _itemId;
    }

    public boolean isCorrect()
    {
        return _isCorrect;
    }
}
