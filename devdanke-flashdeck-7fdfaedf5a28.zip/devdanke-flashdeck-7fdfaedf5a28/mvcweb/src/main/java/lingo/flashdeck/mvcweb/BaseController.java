package lingo.flashdeck.mvcweb;

import lingo.flashdeck.quizzer.xmlgen.lesson.Item;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;
import lingo.flashdeck.quizzer.xmlgen.lesson.RepType;
import org.springframework.web.context.ServletContextAware;

import javax.servlet.ServletContext;

import static java.lang.String.format;

/**
 * *******************************************************************
 * ********************************************************************
 */

public class BaseController
    implements ServletContextAware
{
    protected static final String LSN_REP_TYPE = "lessonRepType";


    private ServletContext _servletContext;

    public void setServletContext(ServletContext servletContext)
    {
        _servletContext = servletContext;
    }

    /**
     * NOTE: the returned context name is returned with a leading slash, e.g. /my-context
     * @return
     */
    public String getContextName()
    {
        return _servletContext.getContextPath();
    }



}
