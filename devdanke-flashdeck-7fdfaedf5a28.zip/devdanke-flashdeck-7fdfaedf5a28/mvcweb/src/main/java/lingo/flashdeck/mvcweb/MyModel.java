package lingo.flashdeck.mvcweb;


import com.google.common.collect.Lists;
import lingo.flashdeck.common.deck.BoxItem;
import lingo.flashdeck.common.deck.Deck;
import lingo.flashdeck.common.deck.IDeckManager;
import lingo.flashdeck.quizzer.LessonMapper;
import lingo.flashdeck.quizzer.QuizDeck;
import lingo.flashdeck.quizzer.QuizManager;
import lingo.flashdeck.quizzer.Sorter;
import lingo.flashdeck.quizzer.xmlgen.lesson.Item;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * 
 */
@Component
public class MyModel
{
    public static final Long MY_LEARNER_ID = 7L;

    private static final Logger _log = LoggerFactory.getLogger(MyModel.class);
    
    //NOTE: quiz.jsp depends on this not ending with /, because it'll be added.
    //Might be better to put correct full path into the Lesson Fact when loading.
    private final String _mediaServerBaseUrl;// = "http://localhost";
    public static final String DEFAULT_LESSON_INDEX_FILE_NAME =  "lessons.txt";

    private final QuizManager _quizMgr;
    private IDeckManager _deckMgr;
    private final List<Lesson> _lessons;
    private final Map<Long,Lesson> _lessonsById;


    @Autowired
    public MyModel(MyConfig config, IDeckManager deckMgr)
    {
        _log.debug("IN");
        Long learnerId = MY_LEARNER_ID;

        _deckMgr = deckMgr;
        
        _mediaServerBaseUrl = config.getLessonServiceUrl();

        try
        {
            _lessons = loadLessons(_mediaServerBaseUrl, DEFAULT_LESSON_INDEX_FILE_NAME);
            _lessonsById = LessonMapper.mapLessonById(_lessons);
            
            Collections.sort(_lessons, Sorter.SORT_LESSONS_BY_NAME);
            List<Deck> decks = _deckMgr.findDecksByLearner(learnerId);

            _quizMgr = new QuizManager(_lessons, decks);
        }
        catch(Error er)
        {
            _log.error("error initializing MyModel", er);
            throw new RuntimeException(er);
        }

        _log.debug("myModel.ctor OUT");
    }

    
    public QuizManager getQuizMgr()
    {
        return _quizMgr;
    }

    public List<Lesson> getLessons()
    {
        return Lists.newArrayList(_lessons);
    }

    public void saveQuizResults(QuizDeck quizDeck, Map<Long,Boolean> answerMap)
    {
        _quizMgr.processQuizResults(_deckMgr, quizDeck, answerMap);
    }

    public String getBaseMediaUrl()
    {
        return _mediaServerBaseUrl;
    }

    public void deleteDecks(Collection<Long> lessonIds)
    {
        for(Long lessonId : lessonIds)
        {
            Long deckId = _quizMgr.getDeckByLessonId(lessonId).getId();

            //TODO move this delete fully inside QuizManager to avoid this two step delete outside.
            _deckMgr.delete(deckId);
            _quizMgr.removeDeletedDeck(deckId);
        }
    }

    
    public void addDecks(Collection<Long> lessonIds)
    {
        for(Long lessonId : lessonIds)
        {
            Lesson lesson = _lessonsById.get(lessonId);

            //TODO maybe make this one step process by doing it all in QuizManager?
            Deck deck = new Deck(MY_LEARNER_ID, lessonId, makeBoxItemsForLesson(lesson) );

            _deckMgr.save( deck );
            
            _quizMgr.addDeck(new QuizDeck(deck, lesson ) );
        }
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////
    // support methods
    ////////////////////////////////////////////////////////////////////////////////////////////////

    public static List<Lesson> loadLessons(String mediaBaseUrl, String lessonIndexFileName)
    {
        try
        {
            List<Lesson> lessons = Lists.newArrayList();

            WebFileLoader lm = new WebFileLoader(mediaBaseUrl);
            String rawLessonList = lm.loadFile(lessonIndexFileName);
            BufferedReader reader = new BufferedReader(new StringReader(rawLessonList));
            List<String> rawLessonXml = Lists.newArrayList();
            String line;
            while((line = reader.readLine())!=null)
            {
                line = line.trim();

                if(line.startsWith("#") || line.isEmpty())
                {
                    continue;
                }

                _log.debug("about to load lesson: {}", line);
                rawLessonXml.add( lm.loadFile(line) );
                _log.debug("loaded lesson: {}", line);
            }

            for(String rawXml : rawLessonXml)
            {
                Lesson lesson = XmlUtil.parse(rawXml);
                _log.debug("parsed: {}", lesson.getName() );
                lessons.add(lesson);
            }

            return lessons;
        }
        catch(IOException ioe)
        {
            throw new RuntimeException(ioe);
        }
    }


     private List<BoxItem> makeBoxItemsForLesson(Lesson lesson)
    {
        List<BoxItem> boxItems = Lists.newArrayList();

        for(Item item : lesson.getItem())
        {
            boxItems.add(new BoxItem(item.getId()));
        }
        return boxItems;
    }
}
