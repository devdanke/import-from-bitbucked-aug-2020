package lingo.flashdeck.mvcweb;

import lingo.flashdeck.common.util.MyAssert;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import org.apache.commons.lang3.CharEncoding;

/**
 * *******************************************************************
 * ********************************************************************
 */

public class WebFileLoader
{
    private final String _baseUrl;
    private final Logger _log = LoggerFactory.getLogger(WebFileLoader.class);

    public WebFileLoader(String baseUrl)
    {
        MyAssert.notNull("baseUrl", baseUrl);

        if (baseUrl.endsWith("/"))
        {
            _baseUrl = baseUrl.trim();
        } else
        {
            _baseUrl = baseUrl.trim() + "/";
        }
        _log.info("INIT PARAM: baseUrl={}", _baseUrl);
    }


    public String loadFile(String relUrl)
    {
        //return loadFileWithHttpClient(relUrl);
        String str = loadFileWithUrlConnectionGaeSafe(relUrl);
        _log.trace("*str={}", str);
        return str;
    }


    public String loadFileWithUrlConnectionGaeSafe(String relUrl)
    {
        BufferedReader reader = null;
        try
        {
            String urlStr = _baseUrl + relUrl;
            URL targUrl = new URL(urlStr);
            _log.info("load lesson file: {}", urlStr);

            URLConnection urlCon = targUrl.openConnection();
            reader = new BufferedReader(
                new InputStreamReader(urlCon.getInputStream(),CharEncoding.UTF_8));
            String line;
            StringBuilder sb = new StringBuilder();
            while ((line = reader.readLine()) != null)
            {
                sb.append(line).append("\n");
            }
            return sb.toString();
        }
        catch (IOException ioe)
        {
            throw new RuntimeException(ioe);
        }
        finally
        {
            if(reader != null)
            {
                try{ reader.close();}catch(Exception e)
                {
                    _log.warn("couldn't close inputstream:-(");
                }
            }
        }
    }


    public String loadFileWithHttpClient(String relUrl)
    {

        HttpClient httpclient = new DefaultHttpClient();
        try
        {
            HttpGet get = new HttpGet(_baseUrl + relUrl);

            // Create a response handler
            ResponseHandler<String> responseHandler = new BasicResponseHandler();
            String responseBody = httpclient.execute(get, responseHandler);
            return responseBody;
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            // When HttpClient instance is no longer needed,
            // shut down the connection manager to ensure
            // immediate deallocation of all system resources
            httpclient.getConnectionManager().shutdown();
        }
    }

}
