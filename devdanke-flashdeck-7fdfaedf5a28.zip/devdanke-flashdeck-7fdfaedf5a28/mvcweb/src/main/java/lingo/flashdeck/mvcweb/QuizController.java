package lingo.flashdeck.mvcweb;

import ch.qos.logback.classic.turbo.MDCValueLevelPair;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lingo.flashdeck.common.util.obj;
import lingo.flashdeck.quizzer.QuizDeck;
import lingo.flashdeck.quizzer.xmlgen.lesson.Item;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

@Controller
public class QuizController
    extends BaseController
{
    //pages
    private static final String QUIZ_PAGE = "quiz.jsp";

    //jsp/querstring/form/path param names
    private static final String LESSON = "lesson";
    private static final String CUR_ITEM = "curItem";
    private static final String UNTAKEN = "untaken";
    private static final String TAKEN = "taken";
    private static final String DECK_ID = "deckId";
    private static final String ITEMS_IN_QUIZ_COUNT = "itemsInQuizCount";
    private static final String CUR_ITEM_INDEX = "curItemIndex";
    private static final String BASE_MEDIA_URL = "baseMediaUrl";
    private static final String CONTEXT_NAME = "contextName";

    private static final String RIGHT = "t";
    private static final String WRONG = "f";
    private static final String SEP = ";";

    private static final int FIRST = 0;

    private final MyModel _model;

    private final Logger _log = LoggerFactory.getLogger(QuizController.class);

    @Autowired
    public QuizController(MyModel model)
    {
        _model = model;
    }


    /*
    Called when quiz starts.  Setup form variables.
    Establish the random order of the items.
    Set current item.
     */
    @RequestMapping("/quiz/{deckId}")
    public ModelAndView setupQuiz(@PathVariable Long deckId)
    {
        _log.debug("setup quiz");

        QuizDeck quizDeck = _model.getQuizMgr().getDeck(deckId);

        List<Long> randAssocIds = quizDeck.getNextReadyItemIdsOrdered();
        Long firstAssocId = randAssocIds.remove(FIRST);
        
        ModelAndView mv = new ModelAndView(QUIZ_PAGE);
        mv.addAllObjects( addCommonQuizPageData(quizDeck) );

        mv.addObject(CUR_ITEM, quizDeck.getItemById(firstAssocId));
        mv.addObject(UNTAKEN,  Joiner.on(SEP).join(randAssocIds));
        mv.addObject(TAKEN, "");
        mv.addObject(CUR_ITEM_INDEX, 1 );

        return mv;
    }


    /*
    Called when quiz starts.  Setup form variables.
    Establish the random order of the items.
    Set current item.

    TODO: route to different method for last quiz item.  i'll know this just before it happens.
    TODO: yes, for final submit, make form method POST instead of GET to distinguish handler.

     */
    @RequestMapping("/quiz/{deckId}/item/{itemId}")
    public ModelAndView processItemResult(@PathVariable Long deckId, @PathVariable Long itemId,
        @RequestParam("itemResult") boolean isCorrect, @RequestParam("untaken") String untaken,
        @RequestParam("taken") String taken, HttpServletResponse resp)
    {
        _log.debug("processItemResult: deckId={}, itemId={}, isCorrect={}, taken={}, untaken={}",
            obj.arr(deckId, itemId, isCorrect, taken, untaken));

        QuizDeck quizDeck = _model.getQuizMgr().getDeck(deckId);

        //tack on most recent result
        String takenNextGen = appendTakenResult(taken, itemId, isCorrect);
        
        List<Long> untakenItemIds = splitUntakenList(untaken);
        if(!untakenItemIds.isEmpty())
        {
            ModelAndView mv = new ModelAndView(QUIZ_PAGE);
            
            mv.addAllObjects(addCommonQuizPageData(quizDeck));

            mv.addObject(CUR_ITEM, quizDeck.getItemById(untakenItemIds.remove(FIRST)));
            mv.addObject(UNTAKEN, Joiner.on(SEP).join(untakenItemIds));
            mv.addObject(TAKEN, takenNextGen);

            //TODO: find simpler way to get this.
            int itemCount = quizDeck.getNextReadyItemIdsOrdered().size();
            mv.addObject(CUR_ITEM_INDEX, (itemCount - untakenItemIds.size()) );

            resp.setContentType("text/html; charset=UTF-8");
            return mv;
        }
        else
        {
            _log.debug("quiz is done. save results to db");
            _model.saveQuizResults(quizDeck, toAnswerMap(takenNextGen));
            try
            {
                //resp.sendRedirect("decks"); 400
                resp.sendRedirect( getContextName() + "/app/decks");
                return null;
            }
            catch(Exception e)
            {
                throw new RuntimeException(e);
            }
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////
    // support methods
    ////////////////////////////////////////////////////////////////////////////////////////////////

    
    private Map<String,Object> addCommonQuizPageData(QuizDeck quizDeck)
    {
        Map<String,Object> map = Maps.newHashMap();

        map.put(LESSON, quizDeck.getLesson());
        map.put(DECK_ID, quizDeck.getId());
        map.put(ITEMS_IN_QUIZ_COUNT, quizDeck.getNextReadyItemIdsOrdered().size());
        map.put(BASE_MEDIA_URL, _model.getBaseMediaUrl());

        Lesson lesson = quizDeck.getLesson();
        Item anItem = lesson.getItem().get(0);
        map.put(LSN_REP_TYPE,
            LessonRepType.calcType(
                lesson.getName(),
                anItem.getFact1().getRepType(),
                anItem.getFact2().getRepType()));

        return map;
    }


    private String appendTakenResult(String taken, Long itemId, boolean isCorrect)
    {
        String sep = SEP;
        if((taken == null) || (taken.isEmpty()))
        {
            sep = "";
        }

        //tack on most recent result
        String isCorrectToken = RIGHT;
        if(!isCorrect) isCorrectToken = WRONG;
        return  taken + sep + itemId + isCorrectToken;
    }


    /**
     *
     * @param taken
     * @return map of assocId -> isCorrect
     */
    private Map<Long,Boolean> toAnswerMap(String taken)
    {
        //_log.debug("taken='{}'", taken);
        Map<Long,Boolean> answerMap = Maps.newHashMap();

        for(String rawResult : taken.split(SEP) )
        {
            int lastDigPos = rawResult.length()-1;
            long id = Long.valueOf( rawResult.substring(FIRST, lastDigPos ) );
            boolean isCorrect = rawResult.endsWith(RIGHT);
            answerMap.put(id, isCorrect);
        }

        return answerMap;
    }
    

    private List<Long> splitUntakenList(String untaken)
    {
        List<Long> ids = Lists.newArrayList();

        List<String> idStrings = Lists.newArrayList(untaken.split(SEP));
        for(String str : idStrings)
        {
            str = str.trim();
            if(!str.isEmpty() && Character.isDigit(str.charAt(FIRST)))
            {
                ids.add(Long.valueOf(str));
            }
        }

        return ids;
    }
    
}
