package lingo.flashdeck.mvcweb;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;


import com.google.common.collect.Sets;
import lingo.flashdeck.quizzer.DeckItemCounts;
import lingo.flashdeck.quizzer.QuizDeck;
import lingo.flashdeck.quizzer.QuizManager;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Controller
public class DeckController
    extends BaseController
{
    //pages
    private static final String DECK_PAGE = "decks.jsp";
    private static final String LESSON_PAGE = "lessons.jsp";

    //page jsp params
    public static final String LESSON_STATUS_BY_ID = "lessonStatusById";

    //page form fields
    public static final String ADD_LESSON = "addLesson";
    public static final String KEEP_LESSON = "keepLesson";


    private final MyModel _model;

    private final Logger _log = LoggerFactory.getLogger(DeckController.class);
    
    @Autowired
    public DeckController(MyModel model)
    {
        _model = model;
    }

    @RequestMapping("/lessons")
    public ModelAndView getLessons()
    {
        _log.debug("get lessons");

        List<Lesson> lessons = _model.getLessons();
        Set<Long> activeLessonIds = _model.getQuizMgr().getActiveLessonIds();

        Map<Long,Boolean> lessonStatusById = Maps.newHashMap();

        for(Lesson lesson : lessons)
        {
            boolean isActive = activeLessonIds.contains(lesson.getId());
            lessonStatusById.put( lesson.getId(), isActive );
        }

        ModelAndView mv = new ModelAndView(LESSON_PAGE);
        mv.addObject("lessons", lessons);
        mv.addObject(LESSON_STATUS_BY_ID, lessonStatusById);
        _log.debug("lessonStatusById: {}" , lessonStatusById.toString());
        return mv;
    }


    @RequestMapping("/change-decks")
    public ModelAndView changeDecks(
        @RequestParam(value= ADD_LESSON, required = false) Set<String> addedLessonIds,
        @RequestParam(value = KEEP_LESSON, required = false) Set<String> keptLessonIds,
        HttpServletResponse resp)
        throws IOException
    {
        _log.debug("change decks");

        _log.debug("addedLessonIds:   {}", addedLessonIds);
        _log.debug("keptLessonIds:   {}", keptLessonIds);

        Set<Long> activeLessonIds = _model.getQuizMgr().getActiveLessonIds();
        _log.debug("activeLessonIds:{}", activeLessonIds);

        Set<Long> decksToDeactivate = calcDeselectedLessons(activeLessonIds, keptLessonIds);
        _log.debug("decksToDeactivate: {}", decksToDeactivate);

        _model.deleteDecks(decksToDeactivate);

        _model.addDecks( convertToListOfIds(addedLessonIds));

        resp.sendRedirect("/mvcweb/app/decks");
        return null;
    }


    @RequestMapping("/decks")
    public ModelAndView getDecks()
    {
        _log.debug("get quizDecks");

        QuizManager qm = _model.getQuizMgr();

        List<QuizDeck> quizDecks = qm.getDecks();

        Integer totalItemCount = 0;
        Integer totalReadyNowCount = 0;

        Map<Long,DeckItemCounts> countsByDeck = Maps.newHashMap();
        for(QuizDeck quizDeck : quizDecks)
        {
            DeckItemCounts deckItemCounts = quizDeck.getBoxAndReadyCounts();
            countsByDeck.put(quizDeck.getId(), deckItemCounts);
            totalItemCount += deckItemCounts.getItemCount();
            totalReadyNowCount += deckItemCounts.getReadyNow();
        }

        ModelAndView mv = new ModelAndView(DECK_PAGE);
        mv.addObject("decks", quizDecks);
        mv.addObject("deckItemCounts", countsByDeck);
        mv.addObject("totalItemCount", totalItemCount);
        mv.addObject("totalReadyNowCount", totalReadyNowCount);
        return mv;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////
    // support methods
    ////////////////////////////////////////////////////////////////////////////////////////////////

    private Set<Long> calcDeselectedLessons(Set<Long> activeLessonIds, Set<String> keptLessonIds)
    {
        Set<Long> deselectedActiveIds = Sets.newHashSet( activeLessonIds );
        if(keptLessonIds != null)
        {
            for(String idStr : keptLessonIds)
            {
                Long keptId = Long.valueOf(idStr);
                if( deselectedActiveIds.contains(keptId) )
                {
                    deselectedActiveIds.remove(keptId);
                }
            }
            deselectedActiveIds.removeAll(keptLessonIds);
        }
        return deselectedActiveIds;
    }

    private List<Long> convertToListOfIds(Set<String> idStrings)
    {
        List<Long> ids = Lists.newArrayList();

        if(idStrings != null)
        {
            for(String idStr : idStrings)
            {
                ids.add( Long.valueOf(idStr) );                
            }
        }


        return ids;
    }
}
