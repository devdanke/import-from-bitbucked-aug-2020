package lingo.flashdeck.mvcweb;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lingo.flashdeck.common.util.obj;
import lingo.flashdeck.quizzer.QuizDeck;
import lingo.flashdeck.quizzer.xmlgen.lesson.Item;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

@Controller
public class LearnController
    extends BaseController
{
    //pages
    private static final String LEARN_PAGE = "learn.jsp";

    //jsp/querstring/form/path param names
    private static final String LESSON = "lesson";
    private static final String CUR_ITEM = "curItem";

    private static final String UNTAKEN = "untaken";
    private static final String TAKEN = "taken";
    private static final String DONE = "doneItems";


    private static final String DECK_ID = "deckId";
    private static final String ITEMS_IN_QUIZ_COUNT = "itemsInQuizCount";
    private static final String CUR_ITEM_INDEX = "curItemIndex";
    private static final String BASE_MEDIA_URL = "baseMediaUrl";

    private static final String RIGHT = "t";
    private static final String WRONG = "f";
    private static final String SEP = ";";

    private static final int FIRST = 0;

    private final MyModel _model;

    private final Logger _log = LoggerFactory.getLogger(LearnController.class);


    @Autowired
    public LearnController(MyModel model)
    {
        _model = model;
    }


    /*
    Called when quiz starts.

    Setup form variables.
    Establish the random order of the items.
    Set current item.
     */
    @RequestMapping("/learn/{deckId}")
    public ModelAndView setupQuiz(@PathVariable Long deckId)
    {
        _log.debug("setup learn mode");

        QuizDeck quizDeck = _model.getQuizMgr().getDeck(deckId);

        List<Long> itemIds = quizDeck.getAllItemIdsShuffled();
        Long firstItemId = itemIds.remove(FIRST);
        
        ModelAndView mv = new ModelAndView(LEARN_PAGE);
        mv.addAllObjects( addCommonPageData(quizDeck) );

        mv.addObject(CUR_ITEM, quizDeck.getItemById(firstItemId));
        mv.addObject(UNTAKEN,  Joiner.on(SEP).join(itemIds));
        mv.addObject(TAKEN, "");
        mv.addObject(DONE, "");
        mv.addObject(CUR_ITEM_INDEX, 1 );

        return mv;
    }


    /*
    This is called during after each answer during a learning rounds, but not for the last question
      in a round.

      This method does 3 things:
       1) remove the just answered item from the untaken list.
       2) add that item to the taken list.
       3) get the sound and pic names of the next item into the page.
    */
    @RequestMapping("/learn/{deckId}/item/{itemId}")
    public ModelAndView processItemResult(@PathVariable Long deckId, @PathVariable Long itemId,
        @RequestParam("itemResult") boolean isCorrect, @RequestParam("untaken") String untaken,
        @RequestParam("taken") String taken, @RequestParam("doneItems") String doneItems,
        HttpServletResponse resp)
    {
        _log.debug("processItemResult: deckId={}, itemId={}, isCorrect={}, taken={}, untaken={}, " +
            "doneItems={}",
            obj.arr(deckId, itemId, isCorrect, taken, untaken, doneItems));

        //tack on most recent result
        String takenNextGen = appendTakenResult(taken, itemId, isCorrect);

        List<Long> untakenItemIds = splitItemIdsStr(untaken);
        ModelAndView mv = new ModelAndView(LEARN_PAGE);


        QuizDeck quizDeck = _model.getQuizMgr().getDeck(deckId);
        mv.addAllObjects(addCommonPageData(quizDeck));

        mv.addObject(CUR_ITEM, quizDeck.getItemById(untakenItemIds.remove(FIRST)));
        mv.addObject(UNTAKEN, Joiner.on(SEP).join(untakenItemIds));
        mv.addObject(TAKEN, takenNextGen);

        /* *********************************************

        CHANGE THIS

        WONT USE QUIZDECK FOR GETTING ITEMS AFTER THE INITIAL SETUP.
        AFTER THAT, ALL STATE IS HELD IN THE PAGE ITSELF.

         */
        int itemCount = quizDeck.getNextReadyItemIdsOrdered().size();
        mv.addObject(CUR_ITEM_INDEX, (itemCount - untakenItemIds.size()) );

        resp.setContentType("text/html; charset=UTF-8");
        return mv;
    }


    /*
    This method is only called after the user answers the last question in
    the round (i.e. when untaken="").

    Actions
    - move correct items from taken to done
    - move incorrect items from taken to untaken
    - if untaken is empty, then lesson is done
    - else resume item taking mode
    */
    @RequestMapping(value="/learn/{deckId}/item/{itemId}", params = "untaken=")
    public ModelAndView processLastItemResultInRound(@PathVariable Long deckId,
        @PathVariable Long itemId,
        @RequestParam("itemResult") boolean isCorrect,
        @RequestParam("taken") String taken, @RequestParam("doneItems") String doneItems,
        HttpServletResponse resp)
    {
        _log.debug("processLastItemResultInRound: deckId={}, itemId={}, isCorrect={}, taken={}, " +
            "doneItems={}",
            obj.arr(deckId, itemId, isCorrect, taken, doneItems));

        List<Long> untakenIds = Lists.newArrayList();

        //move correct taken items to doneItems
        List<Long> doneItemIds = splitItemIdsStr(doneItems);
        for(TakenResult tr : parseTaken(taken))
        {

            if(tr.isCorrect())
            {
                doneItemIds.add(tr.getItemId());
            }
            else
            {
                //got it wrong so put it back for user retry
                untakenIds.add(tr.getItemId());
            }
        }

        //todo: add check that total item count (done,taken == lesson.size)
        //todo: prevents hacker from manipulating counts to cause endless loops etc.

        //check to see if user is done.
        if(doneItemIds.size() == _model.getQuizMgr().getDeck(deckId).getLesson().getItem().size())
        {
            _log.debug("learning session is done.");
            try
            {
                resp.sendRedirect( getContextName() + "/app/decks");
                return null;
            }
            catch(Exception e)
            {
                throw new RuntimeException(e);
            }
        }
        else
        {
            //prepare to keep user in the learning loop til they get all questions correct.

        }

        


        //QuizDeck quizDeck = ;

        //tack on most recent result
        String takenNextGen = appendTakenResult(taken, itemId, isCorrect);

        //List<Long> untakenItemIds = splitItemIdsStr(untaken);
        return null;

    }



    ////////////////////////////////////////////////////////////////////////////////////////////////
    // support methods
    ////////////////////////////////////////////////////////////////////////////////////////////////

    /*
    @param taken a list of taken item ids and the result, correct or not.  e.g. 5t;88f;6f
     */
    private List<TakenResult> parseTaken(String takenCgiVar)
    {
        List<TakenResult> list = Lists.newArrayList();
        for(String str : takenCgiVar.split(SEP))
        {
            list.add( new TakenResult(
                Long.parseLong(str.substring(0, str.length() - 1)),  str.endsWith(RIGHT)) );
        }
        return list;
    }


    private Map<String,Object> addCommonPageData(QuizDeck quizDeck)
    {
        Map<String,Object> map = Maps.newHashMap();

        map.put(LESSON, quizDeck.getLesson());
        map.put(DECK_ID, quizDeck.getId());
        map.put(ITEMS_IN_QUIZ_COUNT, quizDeck.getNextReadyItemIdsOrdered().size());
        map.put(BASE_MEDIA_URL, _model.getBaseMediaUrl());

        Lesson lesson = quizDeck.getLesson();
        Item anItem = lesson.getItem().get(0);
        map.put(LSN_REP_TYPE,
            LessonRepType.calcType(
                lesson.getName(),
                anItem.getFact1().getRepType(),
                anItem.getFact2().getRepType()));

        return map;
    }


    private String appendTakenResult(String taken, Long itemId, boolean isCorrect)
    {
        String sep = SEP;
        if((taken == null) || (taken.isEmpty()))
        {
            sep = "";
        }

        //tack on most recent result
        String isCorrectToken = RIGHT;
        if(!isCorrect) isCorrectToken = WRONG;
        return  taken + sep + itemId + isCorrectToken;
    }


    /**
     *
     * @param taken
     * @return map of assocId -> isCorrect
     */
    private Map<Long,Boolean> toAnswerMap(String taken)
    {
        //_log.debug("taken='{}'", taken);
        Map<Long,Boolean> answerMap = Maps.newHashMap();

        for(String rawResult : taken.split(SEP) )
        {
            int lastDigPos = rawResult.length()-1;
            long id = Long.valueOf( rawResult.substring(FIRST, lastDigPos ) );
            boolean isCorrect = rawResult.endsWith(RIGHT);
            answerMap.put(id, isCorrect);
        }

        return answerMap;
    }
    

    private List<Long> splitItemIdsStr(String itemIdsStr)
    {
        List<Long> ids = Lists.newArrayList();

        List<String> idStrings = Lists.newArrayList(itemIdsStr.split(SEP));
        for(String str : idStrings)
        {
            str = str.trim();
            if(!str.isEmpty() && Character.isDigit(str.charAt(FIRST)))
            {
                ids.add(Long.valueOf(str));
            }
        }

        return ids;
    }
    
}
