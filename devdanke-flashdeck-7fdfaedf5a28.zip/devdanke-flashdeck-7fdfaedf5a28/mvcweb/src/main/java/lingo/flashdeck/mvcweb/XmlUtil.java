package lingo.flashdeck.mvcweb;


import com.google.common.io.Resources;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;


import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;

/**
 */
public class XmlUtil
{

    /*
    NOTE: The JAXBContext is thread-safe, but the marshaller and unmarshaller are not.
    http://jaxb.java.net/guide/Performance_and_thread_safety.html
     */

    public static Lesson parseResource(String resourceName)
    {
        try
        {
            URL url = Resources.getResource(resourceName);
            String xml = Resources.toString(url, Charset.defaultCharset());
            return parse(xml);
        }
        catch(IOException ioe)
        {
            throw new RuntimeException("probably can't find resource: "+resourceName, ioe);
        }
    }

    
    /**
     */
    public static Lesson parse(String xml)
    {
        try
        {
            JAXBContext _jaxbCtx = JAXBContext.newInstance(Lesson.class);
            Unmarshaller um = _jaxbCtx.createUnmarshaller();
            return (Lesson) um.unmarshal(new StringReader(xml));
        }
        catch (Exception e)
        {
            throw new RuntimeException("cannot parse: "+xml,e);
        }
    }

}
