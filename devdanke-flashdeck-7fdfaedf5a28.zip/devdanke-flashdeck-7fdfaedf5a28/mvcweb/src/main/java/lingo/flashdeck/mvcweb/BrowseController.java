package lingo.flashdeck.mvcweb;

import java.util.List;

import com.google.common.collect.Lists;
import lingo.flashdeck.quizzer.QuizDeck;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import lingo.flashdeck.quizzer.xmlgen.lesson.Item;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;


@Controller
public class BrowseController
    extends BaseController
{
    //pages
    private static final String BROWSE_PAGE = "browse.jsp";

    //jsp/querstring/form/path param names
    private static final String LESSON = "lesson";
    private static final String BASE_MEDIA_URL = "baseMediaUrl";

    private final MyModel _model;

    private final Logger _log = LoggerFactory.getLogger(BrowseController.class);

    @Autowired
    public BrowseController(MyModel model)
    {
        _model = model;
    }

private static final String ITEMS_IN_ROWS = "itemRows";
    /*
    Called when quiz starts.  Setup form variables.
    Establish the random order of the items.
    Set current item.
     */
    @RequestMapping("/browse/{deckId}")
    public ModelAndView browse(@PathVariable Long deckId)
    {
        _log.debug("browse deckId={}", deckId);

        QuizDeck quizDeck = _model.getQuizMgr().getDeck(deckId);

        ModelAndView mv = new ModelAndView(BROWSE_PAGE);

        List<List<Item>> itemRows = Lists.newArrayList();
        Lesson lesson = quizDeck.getLesson();
        List<Item> items = lesson.getItem();
        int itemCount = items.size();
        int i=0;
        int columnCount = 4;
        if (items.size() < 10) columnCount = 3;
        while(i < itemCount)
        {
            List<Item> row = Lists.newArrayList();
            itemRows.add(row);
            for(int j=0 ; j<columnCount && i<itemCount; j++, i++)
            {
                row.add(items.get(i));
            }
        }

        mv.addObject(LESSON, lesson);
        mv.addObject(ITEMS_IN_ROWS, itemRows);
        mv.addObject(BASE_MEDIA_URL, _model.getBaseMediaUrl());
        Item anItem = lesson.getItem().get(0);
        mv.addObject(LSN_REP_TYPE,
            LessonRepType.calcType(
                lesson.getName(),
                anItem.getFact1().getRepType(),
                anItem.getFact2().getRepType()));

        return mv;
    }


}
