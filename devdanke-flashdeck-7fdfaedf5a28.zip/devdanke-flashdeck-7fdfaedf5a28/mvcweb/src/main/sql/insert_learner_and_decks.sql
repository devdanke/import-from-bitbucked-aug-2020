
INSERT INTO learner ( id,  username, password )
VALUES ( 7, 'aUser', 'aPassword' );

-- create quizDecks

--lesson: state capitals 1-5
INSERT INTO quizDeck ( id, learner_id, lesson_id )
VALUES ( 100, 7, 2000 );

    -- create box items
    INSERT INTO box_item ( box_type, deck_id, item_id )
    VALUES
    ( 'BOX_1_OF_5', 100, 1 ),
    ( 'BOX_1_OF_5', 100, 2 ),
    ( 'BOX_1_OF_5', 100, 3 ),
    ( 'BOX_1_OF_5', 100, 4 ),
    ( 'BOX_1_OF_5', 100, 5 );

--lesson: state capitals 6-10
INSERT INTO quizDeck ( id, learner_id, lesson_id )
VALUES ( 101, 7, 2001 );

    -- create box items
    INSERT INTO box_item ( box_type, deck_id, item_id )
    VALUES
    ( 'BOX_1_OF_5', 101, 1 ),
    ( 'BOX_1_OF_5', 101, 2 ),
    ( 'BOX_1_OF_5', 101, 3 ),
    ( 'BOX_1_OF_5', 101, 4 ),
    ( 'BOX_1_OF_5', 101, 5 );

--lesson: thai # 0 - 10 script - text
INSERT INTO quizDeck ( id, learner_id, lesson_id )
VALUES ( 102, 7, 2002 );

    -- create box items
    INSERT INTO box_item ( box_type, deck_id, item_id )
    VALUES
    ( 'BOX_1_OF_5', 102, 1 ),
    ( 'BOX_1_OF_5', 102, 2 ),
    ( 'BOX_1_OF_5', 102, 3 ),
    ( 'BOX_1_OF_5', 102, 4 ),
    ( 'BOX_1_OF_5', 102, 5 ),
    ( 'BOX_1_OF_5', 102, 6 ),
    ( 'BOX_1_OF_5', 102, 7 ),
    ( 'BOX_1_OF_5', 102, 8 ),
    ( 'BOX_1_OF_5', 102, 9 ),
    ( 'BOX_1_OF_5', 102, 10 ),
    ( 'BOX_1_OF_5', 102, 11 );

--lesson: thai # 0 - 10 script/text - sound
INSERT INTO quizDeck ( id, learner_id, lesson_id )
VALUES ( 103, 7, 2003 );

    -- create box items
    INSERT INTO box_item ( box_type, deck_id, item_id )
    VALUES
    ( 'BOX_1_OF_5', 103, 1 ),
    ( 'BOX_1_OF_5', 103, 2 ),
    ( 'BOX_1_OF_5', 103, 3 ),
    ( 'BOX_1_OF_5', 103, 4 ),
    ( 'BOX_1_OF_5', 103, 5 ),
    ( 'BOX_1_OF_5', 103, 6 ),
    ( 'BOX_1_OF_5', 103, 7 ),
    ( 'BOX_1_OF_5', 103, 8 ),
    ( 'BOX_1_OF_5', 103, 9 ),
    ( 'BOX_1_OF_5', 103, 10 );


--///

--lesson: thai chars 1 to 11, pic->sound
INSERT INTO quizDeck ( id, learner_id, lesson_id )
VALUES ( 104, 7, 2004 );

    -- create box items
    INSERT INTO box_item ( box_type, deck_id, item_id )
    VALUES
    ( 'BOX_1_OF_5', 104, 1 ),
    ( 'BOX_1_OF_5', 104, 2 ),
    ( 'BOX_1_OF_5', 104, 3 ),
    ( 'BOX_1_OF_5', 104, 4 ),
    ( 'BOX_1_OF_5', 104, 5 ),
    ( 'BOX_1_OF_5', 104, 6 ),
    ( 'BOX_1_OF_5', 104, 7 ),
    ( 'BOX_1_OF_5', 104, 8 ),
    ( 'BOX_1_OF_5', 104, 9 ),
    ( 'BOX_1_OF_5', 104, 10 ),
    ( 'BOX_1_OF_5', 104, 11 );


--lesson: thai chars 12 to 22, pic->sound
INSERT INTO quizDeck ( id, learner_id, lesson_id )
VALUES ( 105, 7, 2005 );

    -- create box items
    INSERT INTO box_item ( box_type, deck_id, item_id )
    VALUES
    ( 'BOX_1_OF_5', 105, 1 ),
    ( 'BOX_1_OF_5', 105, 2 ),
    ( 'BOX_1_OF_5', 105, 3 ),
    ( 'BOX_1_OF_5', 105, 4 ),
    ( 'BOX_1_OF_5', 105, 5 ),
    ( 'BOX_1_OF_5', 105, 6 ),
    ( 'BOX_1_OF_5', 105, 7 ),
    ( 'BOX_1_OF_5', 105, 8 ),
    ( 'BOX_1_OF_5', 105, 9 ),
    ( 'BOX_1_OF_5', 105, 10 ),
    ( 'BOX_1_OF_5', 105, 11 );

--lesson: thai chars 23 to 33, pic->sound
INSERT INTO quizDeck ( id, learner_id, lesson_id )
VALUES ( 106, 7, 2006 );

    -- create box items
    INSERT INTO box_item ( box_type, deck_id, item_id )
    VALUES
    ( 'BOX_1_OF_5', 106, 1 ),
    ( 'BOX_1_OF_5', 106, 2 ),
    ( 'BOX_1_OF_5', 106, 3 ),
    ( 'BOX_1_OF_5', 106, 4 ),
    ( 'BOX_1_OF_5', 106, 5 ),
    ( 'BOX_1_OF_5', 106, 6 ),
    ( 'BOX_1_OF_5', 106, 7 ),
    ( 'BOX_1_OF_5', 106, 8 ),
    ( 'BOX_1_OF_5', 106, 9 ),
    ( 'BOX_1_OF_5', 106, 10 ),
    ( 'BOX_1_OF_5', 106, 11 );

--lesson: thai chars 34 to 35, pic->sound
INSERT INTO quizDeck ( id, learner_id, lesson_id )
VALUES ( 107, 7, 2007 );

    -- create box items
    INSERT INTO box_item ( box_type, deck_id, item_id )
    VALUES
    ( 'BOX_1_OF_5', 107, 1 ),
    ( 'BOX_1_OF_5', 107, 2 ),
    ( 'BOX_1_OF_5', 107, 3 ),
    ( 'BOX_1_OF_5', 107, 4 ),
    ( 'BOX_1_OF_5', 107, 5 ),
    ( 'BOX_1_OF_5', 107, 6 ),
    ( 'BOX_1_OF_5', 107, 7 ),
    ( 'BOX_1_OF_5', 107, 8 ),
    ( 'BOX_1_OF_5', 107, 9 ),
    ( 'BOX_1_OF_5', 107, 10 ),
    ( 'BOX_1_OF_5', 107, 11 );

--lesson: days
INSERT INTO quizDeck ( id, learner_id, lesson_id )
VALUES ( 108, 7, 2008 );

    -- create box items
    INSERT INTO box_item ( box_type, deck_id, item_id )
    VALUES
    ( 'BOX_1_OF_5', 108, 1 ),
    ( 'BOX_1_OF_5', 108, 2 ),
    ( 'BOX_1_OF_5', 108, 3 ),
    ( 'BOX_1_OF_5', 108, 4 ),
    ( 'BOX_1_OF_5', 108, 5 ),
    ( 'BOX_1_OF_5', 108, 6 ),
    ( 'BOX_1_OF_5', 108, 7 ),
    ( 'BOX_1_OF_5', 108, 8 ),
    ( 'BOX_1_OF_5', 108, 9 ),
    ( 'BOX_1_OF_5', 108, 10 ),
    ( 'BOX_1_OF_5', 108, 11 ),
    ( 'BOX_1_OF_5', 108, 12 ),
    ( 'BOX_1_OF_5', 108, 13 ),
    ( 'BOX_1_OF_5', 108, 14 ),
    ( 'BOX_1_OF_5', 108, 15 ),
    ( 'BOX_1_OF_5', 108, 16 ),
    ( 'BOX_1_OF_5', 108, 17 ),
    ( 'BOX_1_OF_5', 108, 18 ),
    ( 'BOX_1_OF_5', 108, 19 ),
    ( 'BOX_1_OF_5', 108, 20 ),
    ( 'BOX_1_OF_5', 108, 21 ),
    ( 'BOX_1_OF_5', 108, 22 );

