UPDATE box_item
SET
    date_taken = null,
    box_type = 'BOX_1_OF_5';


