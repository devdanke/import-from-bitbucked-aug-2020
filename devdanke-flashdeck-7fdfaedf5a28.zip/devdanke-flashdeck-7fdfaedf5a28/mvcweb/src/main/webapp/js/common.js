
function playSound(audioElemId)
{
    document.getElementById(audioElemId).play();
}


