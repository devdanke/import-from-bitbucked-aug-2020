var gFact1RepType;
var gFact2RepType;

function myLearnPagePrep(fact1RepType, fact2RepType)
{
    $("#fact2").addClass("hideMe"); //if not first, will see answer in tones lesson too soon:-(

    gFact1RepType = fact1RepType;
    gFact2RepType = fact2RepType;
    initFactStyleClass();

    $("#showAnsBtn").attr('disabled', false);
    $("#showAnsBtn").attr('class', 'activeBtn');

    $("#rightBtn").attr('disabled', true);
    $("#rightBtn").attr('class', 'inactiveBtn');

    $("#wrongBtn").attr('disabled', true);
    $("#wrongBtn").attr('class', 'inactiveBtn');

    //give answer btn focus, so space key plays sound
    $("#showAnsBtn").trigger("focus");
}


function initFactStyleClass()
{
    //assign style to factN spans
    if(gFact1RepType == "TEXT_TH")
    {
        $("#fact1").addClass("thaiScript");
    }
    if(gFact2RepType == "TEXT_TH")
    {
        $("#fact2").addClass("thaiScript");
    }
}


function spaceKeyPlaySound(evt)
{
   if(evt.keyCode == 32)
   {
       playSound("fact2Sound");
   }
}


function goToPostAnswerState()
{
    $("#showAnsBtn").attr('disabled', true);
    $("#showAnsBtn").attr('class', 'inactiveBtn');

    $("#rightBtn").attr('disabled', false);
    $("#rightBtn").attr('class', 'activeBtn');

    $("#wrongBtn").attr('disabled', false);
    $("#wrongBtn").attr('class', 'activeBtn');

    $("#fact2").removeClass("hideMe");

    if( gFact2RepType == "SOUND")
    {
        $("#speaker").trigger("focus");
        playSound("fact2Sound");
    }
}



