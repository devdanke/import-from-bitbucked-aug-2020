package lingo.flashdeck.decksvc;

import lingo.flashdeck.common.deck.Deck;
import lingo.flashdeck.common.deck.IDeckManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class RestController
{
    private static final String DECKS_JSP = "/WEB-INF/jsp/decks.jsp";
    private Logger _log = LoggerFactory.getLogger(RestController.class);
    private IDeckManager _deckMgr;

    @Autowired
    public RestController(IDeckManager deckMgr)
    {
        _log.info("in");
        _deckMgr = deckMgr;
    }

    
	@RequestMapping(method=RequestMethod.GET, value="/decks/learner/{id}")
	public ModelAndView findDecksByLearner(@PathVariable Long id)
    {
        _log.info("get decks for learner id={}", id);

        List<Deck> decks = _deckMgr.findDecksByLearner(id);
        _log.info("decks.size={}", decks.size());
        ModelAndView mv = new ModelAndView(DECKS_JSP);
        mv.addObject("decks", decks);
		return mv;
	}
	
    @RequestMapping(method = RequestMethod.POST, value = "/deck")
    public ModelAndView save(@RequestBody Deck deck)
    {
        _log.info("save new deck, then return it with ID values");

        _deckMgr.save(deck);

        ModelAndView mv = new ModelAndView(DECKS_JSP);
        mv.addObject("deck", deck);
		return mv;
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/deck/{id}")
    public ModelAndView delete(@PathVariable Long id)
    {
        _log.info("delete deck id={}", id);

        _deckMgr.delete(id);

		return new ModelAndView();
    }


    @RequestMapping(method = RequestMethod.PUT, value = "/deck")
    public ModelAndView update(@RequestBody Deck deck)
    {
        _log.info("update deck id={}, then return it", deck.getId());

        _deckMgr.update(deck);

        ModelAndView mv = new ModelAndView(DECKS_JSP);
        mv.addObject("deck", deck);
		return mv;
    }

}
