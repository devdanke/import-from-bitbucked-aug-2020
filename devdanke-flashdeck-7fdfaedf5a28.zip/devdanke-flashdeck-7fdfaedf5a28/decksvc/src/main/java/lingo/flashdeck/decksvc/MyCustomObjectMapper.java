package lingo.flashdeck.decksvc;

import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;

/**
 * needed to customize the jackson object mapper. spring didn't seem to have a way to
 * call the configure(propName,propVal) method.
 */

public class MyCustomObjectMapper
    extends ObjectMapper
{
    //TODO: how to call these configure methods from a Spring conf file?
    public MyCustomObjectMapper()
    {
        super();
        configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        configure(SerializationConfig.Feature.INDENT_OUTPUT, true);
    }
}
