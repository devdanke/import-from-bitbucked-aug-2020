copy over content from /home/content/web...
run bin/lsnsvc-clean-content.sh
revise version to today's date e.g. 20110802

gae:deploy

https://appengine.google.com/
go to appengine and activate latest version

verify: http://lsnsvc.appspot.com/content/lessons.txt

TODO:
- don't keep content in project
- instead copy just what's needed from cms/web to target dir
- substitute proj.version into a version.txt that is copied to root or index.html