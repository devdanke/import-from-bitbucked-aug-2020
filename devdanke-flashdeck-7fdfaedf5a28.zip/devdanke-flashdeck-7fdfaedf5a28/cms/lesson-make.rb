#!/usr/bin/ruby

# ruby file to create lesson from legacy lesson

# get root dir as input: arg 1


# ASSUME: images in pics, audio in ogg dir, and lesson will be put into root dir
#ASSUME: you're in the target dir

#todo fix problem of slugs when not using jpeg, eg when using gif
#todo in big stdout message, list any slugs
#todo assume you're in lesson dir, just ask y/n to continue




# **********************************************************************
def extractFileNames(filePaths)

    results = Array.new
    results = filePaths.collect{ |path|
        startPos = path.rindex("/") + 1
        fname = path.slice(startPos,path.length)
    }
    return results
end #extractFileNames


# **********************************************************************
def removeTokenFromList(fileNames, token)

    results = fileNames.collect{ |name|
        name.sub(token,"")
    }
    return results
end #removeTokenFromList


# **********************************************************************
def showItems(array)
    puts "----"
    array.sort!.each { |item|
        puts "> #{item}"
    }
    puts ""
end #showItems


# **********************************************************************
def makeLessonDefFile( lessonName, question, lessonDir, imgFiles, sndFiles)

  dttm = Time.new.strftime("%Y%m%d%H%M")

    lessonTmpl = %{<?xml version="1.0" encoding="utf-8"?>
<lesson id="#{dttm}">
    <name>%_NAME_%</name>
    <question>%_QUESTION_%</question>
    <!-- <property name="sortOrder">document</property> -->
    <rootPath>#{lessonDir}</rootPath>

    %_ITEMS_%

</lesson>
    }

    itemTmpl = %{
    <item id="%_ITEM_ID_%">
        <fact1 repType="PIC" tip="%_PIC_TIP_%" >%_PIC_FILE_%</fact1>
        <fact2 repType="SOUND">%_SND_FILE_%</fact2>
    </item>
    }


    itemId = 0
    items = ""
    imgFiles.each{ |fileName|

        itemId += 1

        baseName = fileName.sub(".jpg","")

        sndFile = baseName
        if !sndFiles.include?("#{baseName}.ogg") then
            sndFile = "SLUG"
        end

        item = itemTmpl.sub("%_ITEM_ID_%", itemId.to_s)
        item = item.sub("%_PIC_FILE_%", "pic/#{fileName}")
        item = item.sub("%_PIC_TIP_%", baseName.gsub("-", " "))
        item = item.sub("%_SND_FILE_%", "ogg/#{sndFile}.ogg")

        items = "#{items} #{item}";
    }

    result = lessonTmpl.sub("%_NAME_%", lessonName)
    result = result.sub("%_QUESTION_%", question)
    result = result.sub("%_ITEMS_%", items)

    return result

end #makeLessonFile


def assertUserGaveLessonDirName()
    unless ARGV.length == 1
      puts "Missing input param:-("
      puts "Usage: ruby #{$0} <lesson directory>\n"
      exit
    end

    return ARGV[0]
end


# **********************************************************************
def main()

    lessonDirName = assertUserGaveLessonDirName()


    imgFiles = Dir["pic/*"]
    imgFiles = extractFileNames(imgFiles)
    showItems(imgFiles)

    sndFiles = Dir["ogg/*"]
    sndFiles = extractFileNames(sndFiles)
    showItems(sndFiles)


    lesson =  makeLessonDefFile(lessonDirName.capitalize,
        "How do you say this #{lessonDirName}?",
        lessonDirName, imgFiles, sndFiles )

    puts lesson

    File.open("#{lessonDirName}.xml", 'w') {|f| f.write(lesson) }

    exit
end #main


###############################
# RUN SCRIPT
###############################
main()
