#!/usr/bin/ruby

require 'fileutils'

#ASSUME: you are in the temp dir where target files are


WAV="wav"
FLAC="flac"
OGG="ogg"
MP3="mp3"
FORMATS = [WAV, FLAC, OGG, MP3]

def removeAllBut(srcFormat)

    formats = Array.new(FORMATS)

    formats.delete(srcFormat)

    formats.each{ |format|
        puts "remove files of type *.#{format}"
        `rm -f *.#{format}`
    }
end

def createWavFiles(srcFormat)

    Dir["*#{srcFormat}"].sort!.each{ |file|

        baseName = file.sub(".#{srcFormat}","")
        puts "********** baseName: #{baseName}"

        if srcFormat == MP3 then
            `mpg123  -w #{baseName}.wav   #{file}`
            puts "********** done mp3->wav"
        end

        if srcFormat == FLAC then
            `flac -d  #{baseName}.flac   #{file}`
            puts "********** done flac->wav"
        end

    }
end


def convertWavToOthers()

    Dir["*#{WAV}"].sort!.each{ |file|

        baseName = file.sub(".#{WAV}","")
        puts "********** baseName: #{baseName}"

        `lame --vbr-new -b 160 #{baseName}.wav #{baseName}.mp3`
        puts "********** done wav->mp3"


        # want to make smaller, mono flac files, but don't know how yet.
        `flac #{baseName}.wav`
        #`flac --channels=1 #{baseName}.wav -o #{baseName}_mono.flac`
        `flac --test #{baseName}.flac`
        puts "********** done wav->flac"

        `oggenc #{baseName}.flac`
        puts "********** done flac->ogg"
    }
end


def assertUserGaveValidSoundType()
    if ARGV.length != 1 then
      puts "Missing input param:-("
      puts "Usage: ruby #{$0} <flac|mp3|wav|ogg>\n"
      exit
    end

    soundType = ARGV[0].downcase

    if !FORMATS.include?(soundType) then
      puts "Unknown sound type: #{ARGV[0]}"
      puts "Usage: ruby #{$0} <flac|mp3|wav|ogg>\n"
      exit
    end

    return soundType
end


def copyGeneratedFilesToTheirDir(srcFormat)

  FORMATS.each{ |format|

    if(srcFormat != format) then
      Dir.glob("*.#{format}"){ |fname|
          FileUtils.cp(fname, "../#{format}")
      }
    end
  }

end

def main()
    srcFormat = assertUserGaveValidSoundType()

    puts "srcFormat is: '#{srcFormat}"

    removeAllBut(srcFormat)

    if srcFormat != WAV then
        puts "+++++++++++++ create wav files from #{srcFormat} "
        createWavFiles(srcFormat)
    end

    puts "+++++++++++++ convert wav to others "
    convertWavToOthers()

    puts "+++++++++++++ copy result files to proper destination"
    copyGeneratedFilesToTheirDir(srcFormat)

end

main()
