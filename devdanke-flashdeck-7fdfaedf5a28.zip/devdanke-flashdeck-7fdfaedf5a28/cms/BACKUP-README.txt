How to upload to Google docs:

1) Login devdanke/Dc3
2) goto Google docs
3) click Upload button
-- done --


