#!/usr/bin/ruby

# the given lesson folder, move all files into their correct folder

# get target lesson dir as user input: arg 1

# ASSUME: in lesson dir standard dirs already exist

# TODO: if they don't exist, create standard dirs: pic, wav, ogg, mp3, flac, misc



def assertValidLessonDir()
    unless ARGV.length == 1
      puts "Missing input param:-("
      puts "Usage: ruby #{$0} <lesson directory>\n"
      exit
    end

    return ARGV[0]
end


# **********************************************************************
def main()

    lessonDir = assertValidLessonDir()

    puts "********* lessonDir: #{lessonDir}"


    Dir.chdir(lessonDir)

    `mv *.wav wav`
    `mv *.flac flac`
    `mv *.ogg ogg`
    `mv *.mp3 mp3`

    `mv *.jpg  pic`
    `mv *.jpeg pic`
    `mv *.gif  pic`
    `mv *.png  pic`

    Dir.chdir("..")


    exit
end #main


###############################
# RUN SCRIPT
###############################
main()
