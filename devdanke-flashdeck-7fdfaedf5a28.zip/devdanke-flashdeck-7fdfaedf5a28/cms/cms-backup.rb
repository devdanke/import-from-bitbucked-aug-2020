#!/usr/bin/ruby

puts "backup /home/lingo_content/web to 7z file"

dttm = Time.new.strftime("%Y%m%d")
archName="backup/cms-backup-#{dttm}.7z"
#`rm *.7z`
`7z a #{archName} /home/lingo_content/web '-xr!?*.wav' '-xr!?*.mp3' '-xr!?*.ogg' '-xr!?*.au'`

puts "created #{archName}"
