package lingo.flashdeck.common.deck;


/**

 */
public enum BoxType
{
    BOX_1_OF_5(1),
    BOX_2_OF_5(2),
    BOX_3_OF_5(4),
    BOX_4_OF_5(8),
    BOX_5_OF_5(16);

    /*
    how long to wait after the last success, i.e. items not in box 1, until it's time to
    review a question in this box again.
    time is in days.
     */
    private static final int MAX_ORDINAL = 4;
    private int _reviewDelayDays;

    private BoxType(int reviewDelayDays)
    {
        _reviewDelayDays = reviewDelayDays;
    };


    public boolean isLast(){ return (ordinal()==MAX_ORDINAL); }

    /*
    move to next box.
    if box is already last, then keep it there.
     */
    public BoxType next()
    {
        BoxType nextBox;
        if(isLast())
        {
            //if itemResult is in box 5, it stays there.
            nextBox = BOX_5_OF_5;
        }
        else
        {
            nextBox = values()[ordinal()+1];
        }
        return nextBox;
    }

    public int getReviewDelayDays()
    {
        return _reviewDelayDays;
    }
}
