package lingo.flashdeck.common.data;

import java.util.List;

/**
 * *************************************************************
 * *************************************************************
 */
public interface IDao
{
    List<IDeckEntity> findDecksByLearner(Long learnerId);

    List<IBoxItemEntity> findBoxItemsForDecks(List<IDeckEntity> deckEntities);

    void save(IDeckEntity deckEntity, List<IBoxItemEntity> boxItemEntities);

    void deleteDeck(Long deckId);

    /*
   Replace existing box items with these new ones.
    */
    void saveNewBoxPositions(Long deckId, List<IBoxItemEntity> newBoxItemEntities);

    void cleanup();
}
