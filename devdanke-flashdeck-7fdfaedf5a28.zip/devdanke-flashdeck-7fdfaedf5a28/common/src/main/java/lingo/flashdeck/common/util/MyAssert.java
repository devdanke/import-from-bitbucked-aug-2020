package lingo.flashdeck.common.util;

import java.util.Collection;
import java.util.List;

/**
 * TODO move this to package outside lingo.  
 */
public class MyAssert
{
    public static void notNull(String paramName, Object param)
    {
        if(param == null) throw new IllegalArgumentException(paramName + " cannot be null");
    }

    public static void notNullOrEmpty(String paramName, Collection param)
    {
        notNull(paramName,param);
        if(param.isEmpty()) throw new IllegalArgumentException(paramName + " cannot be empty");
    }

    public static void notNullOrEmpty(String paramName, String param)
    {
        notNull(paramName,param);
        if(param.trim().isEmpty()) throw new IllegalArgumentException(paramName + " cannot be empty");
    }

    public static void mustHaveNullIdForAdd(Long rowId)
    {
        if(rowId != null) throw new IllegalArgumentException("id must be null for add");
    }


    public static boolean areEqualNonNullLists(List thisList, List thatList)
    {
        if(thisList.size() != thatList.size()) return false;

        for(int i=0; i<thisList.size(); i++)
        {
            if(!thisList.get(i).equals( thatList.get(i) ) ) return false;
        }
        return true;
    }

    public static boolean isNullOrEmpty(Collection collection)
    {
        if(collection == null) return true;

        return collection.isEmpty();
    }
}
