package lingo.flashdeck.common.deck;


import lingo.flashdeck.common.util.IHaveId;
import lingo.flashdeck.common.util.IHaveOwnerId;
import lingo.flashdeck.common.util.MyAssert;
import org.joda.time.DateTime;


/** *******************************************************************
 * Although I'd like to avoid setters for fields that are immutable,
 * I need them for Jackson deserialization.
 ******************************************************************* */
public class BoxItem
    implements IHaveId, IHaveOwnerId
{
    private Long _id;
    private Long _deckId;
    private BoxType _boxType;
    private Long _itemId;
    private DateTime _dateTaken;


    public BoxItem(){} // only for jaxb
    
    /*
    core constructor with asserts on stuff that can never be null
     */
    private BoxItem(BoxType boxType, Long itemId, DateTime dateTaken)
    {
        MyAssert.notNull("boxType", boxType);
        MyAssert.notNull("itemId", itemId);

        _boxType = boxType;
        _itemId = itemId;
        _dateTaken = dateTaken;
    }

    /*
    Used in DeckManager converting BoxItemDtos from DB to BoxItems
     */
    public BoxItem(Long id, Long deckId, BoxType boxType, Long itemId, DateTime dateTaken)
    {
        this(deckId, boxType,itemId,dateTaken);
        MyAssert.notNull("id", id);

        _id = id;
    }

    /*
    Used in Leitner, when creating new boxItems to reflect quiz results.
     */
    public BoxItem(Long deckId, BoxType boxType, Long itemId, DateTime dateTaken)
    {
        this(boxType,itemId,dateTaken);
        MyAssert.notNull("deckId", deckId);

        _deckId = deckId;
    }

    /*
    Used in QuizManager when learner picks new lesson and we create deck for it.
     */
    public BoxItem(Long itemId)
    {
        this(BoxType.BOX_1_OF_5, itemId, null);
    }


    public void setOwnerId(Long ownerId)
    {
        //TODO remove after learn how make Jackson not blowup
    }

    /*
    Use after saving a BoxItemDto for the first time.
    Then need to copy its id to this, its corresponding BoxItem object.
     */
    public void setId(Long id)
    {
        //must allow null for when Jackson deserialized unsaved remote deck.
        //MyAssert.notNull("id", id);
        _id = id;
    }

    public Long getId()
    {
        return _id;
    }

    public Long getDeckId()
    {
        return _deckId;
    }

    public Long getOwnerId()
    {
        return _deckId;
    }

    public BoxType getBoxType()
    {
        return _boxType;
    }

    public Long getItemId()
    {
        return _itemId;
    }

    public DateTime getDateTaken()
    {
        return _dateTaken;
    }

    public void setDeckId(Long deckId)
    {
        _deckId = deckId;
    }

    public void setBoxType(BoxType boxType)
    {
        _boxType = boxType;
    }

    public void setItemId(Long itemId)
    {
        _itemId = itemId;
    }

    public void setDateTaken(DateTime dateTaken)
    {
        _dateTaken = dateTaken;
    }
}
