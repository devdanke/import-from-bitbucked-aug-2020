package lingo.flashdeck.common.util;

/**

 */
public interface IHaveId
{
    Long getId();
}
