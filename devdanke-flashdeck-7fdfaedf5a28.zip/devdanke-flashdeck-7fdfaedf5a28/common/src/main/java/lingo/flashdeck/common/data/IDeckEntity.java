package lingo.flashdeck.common.data;

import com.google.common.annotations.VisibleForTesting;
import lingo.flashdeck.common.util.IHaveId;

/**
 * *************************************************************
 * *************************************************************
 */
public interface IDeckEntity
    extends IHaveId
{
    Long getId();

    @VisibleForTesting
    void setId(Long id);

    Long getLessonId();

    Long getLearnerId();

    boolean isSame(IDeckEntity that);
}
