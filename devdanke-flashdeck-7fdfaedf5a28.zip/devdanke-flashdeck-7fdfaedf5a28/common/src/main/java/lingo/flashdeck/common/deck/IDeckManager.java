package lingo.flashdeck.common.deck;


import java.util.List;

/**
 * *******************************************************************
 * ********************************************************************
 */
public interface IDeckManager
{
    List<Deck> findDecksByLearner(Long learnerId);

    /**
   when first creating a deck, also create it's box items.
   when box items are first created, they have no dateTaken value.
     TODO: Because this save can happen away from the DB, I must make sure
     the new IDs for deck and boxItems are in this deck or one I could return.

     CONTRACT: after the save, the deck the datasvc_client gets back has non null IDs in deck and boxItems.
    */
    void save(Deck deck);

    /**
     * Only the boxItems can be changed.  All else is immutable.
     * Each boxItem must have a null ID.
     * CONTRACT: After the deck is updated, each boxItem has a non null ID.
     *
     * @param deck
     */
    void update(Deck deck);

    void delete(Long deckId);

    void cleanup();
}
