package lingo.flashdeck.common.data;

import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import lingo.flashdeck.common.deck.BoxItem;
import lingo.flashdeck.common.deck.BoxType;
import lingo.flashdeck.common.deck.Deck;
import lingo.flashdeck.common.deck.IDeckManager;
import lingo.flashdeck.common.util.CommonMapper;
import lingo.flashdeck.common.util.MyAssert;
import org.joda.time.DateTime;

import java.util.List;

/**
 * *************************************************************
 * *************************************************************
 */

public abstract class AbsDeckManager
    implements IDeckManager
{
    protected IDao _dao;

    public AbsDeckManager(IDao dao)
    {
        MyAssert.notNull("dao", dao);

        _dao = dao;
    }

    /**
     * First, load deckDtos from DB. Second, load related BoxItemDtos.  Finally, put them together.
     *
     */
    public List<Deck> findDecksByLearner(Long learnerId)
    {
        List<Deck> decks = Lists.newArrayList();

        List<IDeckEntity> deckEntities = _dao.findDecksByLearner(learnerId);
        if(!deckEntities.isEmpty())
        {
            List<IBoxItemEntity> boxItemEntities = _dao.findBoxItemsForDecks(deckEntities);
            List<BoxItem> boxItems = Lists.newArrayList();
            for(IBoxItemEntity bid : boxItemEntities)
            {
                DateTime dateTaken = null;
                if(bid.getDateTaken()!=null)
                {
                    dateTaken = new DateTime(bid.getDateTaken());
                }
                boxItems.add(new BoxItem(bid.getId(), bid.getDeckId(), bid.getBoxType(),
                    bid.getItemId(), dateTaken));
            }

            Multimap<Long,BoxItem> boxItemsByDeckId = CommonMapper.mapKidsByOwenerId(boxItems);

            for(IDeckEntity de : deckEntities)
            {
                decks.add(new Deck(de.getId(), learnerId, de.getLessonId(),
                    boxItemsByDeckId.get(de.getId())));
            }
        }

        return decks;
    }

    public void save(Deck deck)
    {
        if(deck.getId() != null)
        {
            throw new IllegalArgumentException("deck id must be null");
        }

        IDeckEntity dd = createDeckEntity(deck.getLearnerId(), deck.getLessonId());

        List<IBoxItemEntity> bids = Lists.newArrayList();
        for(BoxItem bi : deck.getBoxItems())
        {
            if(bi.getId() != null)
            {
                throw new IllegalArgumentException("boxItem id must be null");
            }

            bids.add( createBoxItemEntity(bi.getItemId()) );
        }

        _dao.save(dd, bids);

        //now associate the DB ids with the Deck
        deck.setId(dd.getId());

        int i=0;
        for(IBoxItemEntity bid : bids)
        {
            BoxItem bi = deck.getBoxItems().get(i++);
            bi.setId(bid.getId());
            bi.setDeckId(bid.getDeckId());
        }

    }

    public void update(Deck deck)
    {
        //TODO verify incoming boxItems have valid deckId and other required fields.

        List<IBoxItemEntity> bids = Lists.newArrayList();
        DateTime now = new DateTime();
        for(BoxItem bi: deck.getBoxItems())
        {
            bids.add(createBoxItemEntity(deck.getId(), bi.getBoxType(), bi.getItemId(), now));
        }

        _dao.saveNewBoxPositions(deck.getId(), bids);

        int i=0;
        for(IBoxItemEntity bid : bids)
        {
            BoxItem bi = deck.getBoxItems().get(i++);
            bi.setId(bid.getId());
        }
    }

    public void delete(Long deckId)
    {
        _dao.deleteDeck(deckId);
    }

    public void cleanup()
    {
        _dao.cleanup();
    }


    protected abstract IDeckEntity createDeckEntity(Long learnerId, Long lessonId);
    protected abstract IBoxItemEntity createBoxItemEntity(Long itemId);
    protected abstract IBoxItemEntity createBoxItemEntity(Long deckId, BoxType boxType, Long itemId,
        DateTime dateTaken);

}
