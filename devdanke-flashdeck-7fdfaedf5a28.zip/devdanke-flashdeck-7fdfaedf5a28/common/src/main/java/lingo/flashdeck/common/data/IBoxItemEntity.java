package lingo.flashdeck.common.data;

import lingo.flashdeck.common.deck.BoxType;
import lingo.flashdeck.common.util.IHaveId;
import org.joda.time.DateTime;

/**
 * *************************************************************
 * *************************************************************
 */
public interface IBoxItemEntity
    extends IHaveId
{
    Long getId();

    Long getDeckId();

    void setDeckId(Long deckId);

    DateTime getDateTaken();

    BoxType getBoxType();

    Long getItemId();

    boolean isSame(IBoxItemEntity that);
}
