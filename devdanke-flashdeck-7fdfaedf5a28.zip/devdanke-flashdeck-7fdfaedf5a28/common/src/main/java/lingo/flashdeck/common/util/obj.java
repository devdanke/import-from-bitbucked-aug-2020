package lingo.flashdeck.common.util;

/**
 * *******************************************************************
 * ********************************************************************
 */

public class obj
{
    public static Object[] arr(Object... objects)
    {
        return objects;
    }
}
