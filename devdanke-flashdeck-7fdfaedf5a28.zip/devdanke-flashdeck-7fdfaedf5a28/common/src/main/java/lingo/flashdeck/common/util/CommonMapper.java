package lingo.flashdeck.common.util;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;

import java.util.List;
import java.util.Map;


/**
 I often need to turn a list into a map, with the key being the list items id.
 */
public class CommonMapper
{
    /*
    The db entity classes implement IHaveId and their ids are Long
     */
    public static <T extends IHaveId> Map<Long,T> mapById(List<T> things)
    {
        Map<Long,T> map = Maps.newHashMap();

        for(T thing : things)
        {
            map.put(thing.getId(), thing);
        }

        return map;
    }

    /*
    The db entity classes implement IHaveId and their ids are Long
     */
    public static <T extends IHaveOwnerId> Multimap<Long,T> mapKidsByOwenerId(List<T> children)
    {
        Multimap<Long,T> map = ArrayListMultimap.create();

        for(T child : children)
        {
            map.put(child.getOwnerId(), child);
        }

        return map;
    }


}
