package lingo.flashdeck.common.deck;


import com.google.common.collect.Lists;
import lingo.flashdeck.common.util.IHaveId;
import lingo.flashdeck.common.util.IHaveOwnerId;
import lingo.flashdeck.common.util.MyAssert;

import java.util.Collection;
import java.util.List;

/** ********************************************************************
 * One of several classes that hold Deck data, but don't have any reference
 * to the DB.  Ideally don't have any ref to Jackson either.
 * <p/>
 * Although I'd like to avoid setters for fields that are immutable,
 * I need them for Jackson deserialization.
 ******************************************************************** */
public class Deck
    implements IHaveId, IHaveOwnerId
{

    private Long _id;
    private Long _learnerId;  //only needed for save to DB
    private Long _lessonId;
    private List<BoxItem> _boxItems;


    public Deck(){} // only for jaxb

    /**
    This is for creating a Deck from a DeckDto that just came out of the database.
     */
    public Deck(Long id, Long learnerId, Long lessonId, Collection<BoxItem> boxItems)
    {
        this(learnerId,lessonId,boxItems);
        MyAssert.notNull("id", id);
        _id = id;
    }


    /**
    This for create a new Deck when a learner picks a new lesson to study.
     */
    public Deck( Long learnerId, Long lessonId, Collection<BoxItem> boxItems)
    {
        MyAssert.notNull("learnerId", learnerId);
        MyAssert.notNull("lessonId", lessonId);
        MyAssert.notNullOrEmpty("boxItems", boxItems);

        _learnerId = learnerId;
        _lessonId = lessonId;
        _boxItems = Lists.newArrayList(boxItems);
    }


    public Long getId()
    {
        return _id;
    }



    public void setId(Long id)
    {
        //must allow null for when  Jackson is setting from unsaved remote deck.
        //MyAssert.notNull("id", id);
        _id = id;
    }

    public Long getLearnerId()
    {
        return _learnerId;
    }

    public void setOwnerId(Long ownerId)
    {
        //TODO remove after learn how make Jackson not blowup
    }

    public Long getOwnerId()
    {
        return _learnerId;
    }

    public Long getLessonId()
    {
        return _lessonId;
    }

    public List<BoxItem> getBoxItems()
    {
        return _boxItems;
    }

    /**
     * Used after learner finishes a quiz to save the new results.
     *
     * Also used in a DeckManager proxy situation to copy server boxItems into local deck.
     * 
     * @param boxItems
     */
    public void setBoxItems(List<BoxItem> boxItems)
    {
        _boxItems = boxItems;
    }

    public void setLearnerId(Long learnerId)
    {
        _learnerId = learnerId;
    }

    public void setLessonId(Long lessonId)
    {
        _lessonId = lessonId;
    }
}
