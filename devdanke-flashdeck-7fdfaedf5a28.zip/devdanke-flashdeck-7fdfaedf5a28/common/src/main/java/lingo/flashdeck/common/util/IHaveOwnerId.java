package lingo.flashdeck.common.util;

/**

 */
public interface IHaveOwnerId
{
    Long getOwnerId();
}
