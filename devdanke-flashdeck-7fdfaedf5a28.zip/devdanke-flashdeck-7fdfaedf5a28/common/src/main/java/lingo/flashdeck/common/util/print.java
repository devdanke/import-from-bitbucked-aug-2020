package lingo.flashdeck.common.util;


public class print
{
    public static void out(Object msg)
    {
        System.out.println("********************* " + msg);
    }
}
