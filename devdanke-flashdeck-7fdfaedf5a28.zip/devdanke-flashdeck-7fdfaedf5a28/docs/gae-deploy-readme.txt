--- for all --------------------------
increment proj version

mvn -P gae gae:deploy

https://appengine.google.com/
devdanke/Dc3

go to appengine and activate latest version

--- for decksvc --------------------------

verify: base url: http://decksvc.appspot.com/
http://decksvc.appspot.com/app/decks/learner/7

try to view logs

--- for lsnsvc --------------------------

appName=lsnsvc

--- for mvcweb --------------------------

mvc clean -P run_in_gae gae:deploy


appName: tonaltalk
url: http://tonaltalk.appspot.com

http://tonaltalk.appspot.com/app/decks