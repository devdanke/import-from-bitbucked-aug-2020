package lingo.flashdeck.data_gae;

import com.google.appengine.tools.development.testing.LocalDatastoreServiceTestConfig;
import com.google.appengine.tools.development.testing.LocalServiceTestHelper;
import lingo.flashdeck.common.data.IBoxItemEntity;
import lingo.flashdeck.common.data.IDeckEntity;
import lingo.flashdeck.common.deck.BoxType;
import lingo.flashdeck.data.AbsDaoTest;
import org.joda.time.DateTime;
import org.junit.AfterClass;
import org.junit.BeforeClass;


/**
 * See super class, AbsDaoTest for tests common to all Daos.
 */
public class DaoGaeTest
    extends AbsDaoTest
{
    private static final LocalServiceTestHelper _gaeTestHelper =
        new LocalServiceTestHelper(new LocalDatastoreServiceTestConfig());


    @BeforeClass
    public static void setup()
    {
        _gaeTestHelper.setUp();
        _dao = new DaoGae();
    }


    @AfterClass
    public static void cleanup()
    {
        _dao.cleanup();
        _gaeTestHelper.tearDown();
    }

    protected IBoxItemEntity createBoxItemEntity(long itemId)
    {
        return new BoxItemGae(itemId);
    }

    protected IBoxItemEntity createBoxItemEntity(long deckId, BoxType boxType, long itemId,
        DateTime dateTaken)
    {
        return new BoxItemGae(deckId, boxType, itemId, dateTaken);
    }

    protected IDeckEntity createDeckEntity(long learnerId, long lessonId)
    {
        return new DeckEntityGae(learnerId, lessonId);
    }

}