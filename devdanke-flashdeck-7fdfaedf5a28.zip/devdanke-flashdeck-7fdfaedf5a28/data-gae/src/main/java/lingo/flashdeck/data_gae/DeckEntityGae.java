package lingo.flashdeck.data_gae;


import com.google.common.annotations.VisibleForTesting;
import com.googlecode.objectify.annotation.Indexed;
import com.googlecode.objectify.annotation.Unindexed;
import lingo.flashdeck.common.data.IDeckEntity;
import lingo.flashdeck.common.util.MyAssert;

import javax.persistence.Id;


/**
 */
@Unindexed
public class DeckEntityGae
    implements IDeckEntity
{
    @Id
    private Long _id;

    private Long _lessonId;

    @Indexed
    private Long _learnerId;


    public DeckEntityGae(){} //for objectivity

    /*
     */
    public DeckEntityGae(Long learnerId, Long lessonId)
    {
        MyAssert.notNull("learnerId", learnerId);
        MyAssert.notNull("lessonId", lessonId);

        _learnerId = learnerId;
        _lessonId = lessonId;
    }

    public Long getId()
    {
        return _id;
    }

    @VisibleForTesting
    public void setId(Long id)
    {
        _id = id;
    }

    public Long getLessonId()
    {
        return _lessonId;
    }

    public Long getLearnerId()
    {
        return _learnerId;
    }

    public boolean isSame(IDeckEntity that)
    {
        return (_id.equals(that.getId())) &&
            (_learnerId.equals(that.getLearnerId())) &&
            (_lessonId.equals(that.getLessonId()));
    }

    @Override
    public String toString()
    {
        return "DeckEntityGae{" +
            "_id=" + _id +
            ", _lessonId=" + _lessonId +
            ", _learnerId=" + _learnerId +
            '}';
    }
}
