package lingo.flashdeck.data_gae;


import com.google.common.collect.Lists;
import com.googlecode.objectify.Key;
import com.googlecode.objectify.Objectify;
import com.googlecode.objectify.ObjectifyService;
import lingo.flashdeck.common.data.IBoxItemEntity;
import lingo.flashdeck.common.data.IDao;
import lingo.flashdeck.common.data.IDeckEntity;
import lingo.flashdeck.common.util.MyAssert;
import lingo.flashdeck.common.util.obj;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 */
public class DaoGae
    implements IDao
{
    private Logger _log = LoggerFactory.getLogger(DaoGae.class);

    /*
     */
    public DaoGae()
    {
        ObjectifyService.register(BoxItemGae.class);
        ObjectifyService.register(DeckEntityGae.class);
    }


    public List<IDeckEntity> findDecksByLearner(Long learnerId)
    {
        Objectify ofy = ObjectifyService.begin();
        List<IDeckEntity> deckEntities = Lists.newArrayList();
        deckEntities.addAll(ofy.query(DeckEntityGae.class).filter("_learnerId", learnerId).list());
        return deckEntities;
    }


    public List<IBoxItemEntity> findBoxItemsForDecks(List<IDeckEntity> deckEntities)
    {
        MyAssert.notNullOrEmpty("deckEntities", deckEntities);

        List<IBoxItemEntity> bies = Lists.newArrayList();

        Objectify ofy = ObjectifyService.begin();
        for(IDeckEntity de : deckEntities)
        {
            bies.addAll(ofy.query(BoxItemGae.class).filter("_deckId", de.getId()).list());
        }

        return bies;
    }


    public void save(IDeckEntity deckEntity, List<IBoxItemEntity> boxItemsEntities)
    {
        MyAssert.mustHaveNullIdForAdd(deckEntity.getId());

        Objectify ofy = ObjectifyService.begin();
        ofy.put(deckEntity);
        
        for(IBoxItemEntity bid: boxItemsEntities)
        {
            bid.setDeckId(deckEntity.getId());
        }
        ofy.put(boxItemsEntities);
    }


    /**
     * delete deck and its boxItems
     *
     * @param deckId
     */
    public void deleteDeck(Long deckId)
    {
        Objectify ofy = ObjectifyService.begin();

        List<Key<BoxItemGae>> gbiKeys =
            ofy.query(BoxItemGae.class).filter("_deckId", deckId).listKeys();

        ofy.delete(gbiKeys);

        ofy.delete(DeckEntityGae.class, deckId);
    }


    /*
    Replace existing box items with these new ones.
     */
    public void saveNewBoxPositions(Long deckId, List<IBoxItemEntity> newBoxItems)
    {
        MyAssert.notNull("deckId", deckId);
        MyAssert.notNullOrEmpty("newBoxItems", newBoxItems);

        //delete deck's existing boxItems
        try
        {
            Objectify ofy = ObjectifyService.begin();
            List<Key<BoxItemGae>> gbiKeys =
                ofy.query(BoxItemGae.class).filter("_deckId", deckId).listKeys();

            ofy.delete(gbiKeys);
            _log.debug("{} boxItems deleted for deck {}", obj.arr(newBoxItems.size(), deckId));

            //save new ones
            ofy.put(newBoxItems);
            _log.info("{} boxItems saved for deck {}", obj.arr(newBoxItems.size(), deckId));
        }
        catch(Exception e)
        {
            _log.error("save quiz results failed", e);
            throw new RuntimeException(e);
        }
    }

    
    public void cleanup()
    {
    }


}
