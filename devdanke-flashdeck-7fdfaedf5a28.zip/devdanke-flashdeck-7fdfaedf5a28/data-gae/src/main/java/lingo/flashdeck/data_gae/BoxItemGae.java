package lingo.flashdeck.data_gae;

import com.googlecode.objectify.annotation.Indexed;
import com.googlecode.objectify.annotation.Unindexed;
import lingo.flashdeck.common.data.IBoxItemEntity;
import lingo.flashdeck.common.deck.BoxType;
import lingo.flashdeck.common.util.MyAssert;
import org.joda.time.DateTime;

import javax.persistence.Id;
import java.util.Date;


@Unindexed 
public class BoxItemGae
    implements IBoxItemEntity
{
    @Id
    private Long _id;

    @Indexed
    private Long _deckId;

    private BoxType _boxType;

    private Long _itemId;

    private Date _dateTaken;


    public BoxItemGae(){} //for objectivity

    /*
    Use this when creating boxItems for new deck.
    These have not taken date.
     */
    public BoxItemGae(Long itemId)
    {
        this(null,BoxType.BOX_1_OF_5,itemId,null);
    }


    /*
     */
    private BoxItemGae(Long deckId, BoxType boxType, Long itemId)
    {
        MyAssert.notNull("boxType", boxType);
        MyAssert.notNull("itemId", itemId);

        _deckId = deckId;
        _boxType = boxType;
        _itemId = itemId;
    }


    /*
    Use this when creating new BoxItems after a quiz was taken.
     */
    public BoxItemGae(Long deckId, BoxType boxType, Long itemId, DateTime dateTaken)
    {
        this(deckId,boxType,itemId);
        if(dateTaken != null)
        {
            _dateTaken = dateTaken.toDate();
        }

    }

    public Long getId()
    {
        return _id;
    }

    public Long getDeckId()
    {
        return _deckId;
    }

    /**
     * Need this method when saving a deck and it's box items the first time.
     * BoxItemDtos are created before deckDto.id is known.  After DeckEntityGae is
     * saved then its id is added to the BoxItemGae via this setter.
     * @param deckId
     */
    public void setDeckId(Long deckId)
    {
        MyAssert.notNull("deckId", deckId);
        _deckId = deckId;
    }

    public DateTime getDateTaken()
    {
        if(_dateTaken != null) return new DateTime(_dateTaken);
        else return null;
    }

    public BoxType getBoxType()
    {
        return _boxType;
    }

    public Long getItemId()
    {
        return _itemId;
    }



    public boolean isSame(IBoxItemEntity that)
    {
        if (_boxType != that.getBoxType()) return false;
        if (_dateTaken != null ? !_dateTaken.equals(that.getDateTaken()) : that.getDateTaken() != null)
            return false;
        if (_deckId != null ? !_deckId.equals(that.getDeckId()) : that.getDeckId() != null) return false;
        if (_id != null ? !_id.equals(that.getId()) : that.getId() != null) return false;
        if (_itemId != null ? !_itemId.equals(that.getItemId()) : that.getItemId() != null) return false;

        return true;
    }



    @Override
    public String toString()
    {
        return "BoxItemGae{" +
            "_id=" + _id +
            ", _deckId=" + _deckId +
            ", _boxType=" + _boxType +
            ", _itemId=" + _itemId +
            ", _dateTaken=" + _dateTaken +
            '}';
    }
}
