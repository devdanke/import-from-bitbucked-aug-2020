package lingo.flashdeck.data_gae;

import lingo.flashdeck.common.data.AbsDeckManager;
import lingo.flashdeck.common.data.IBoxItemEntity;
import lingo.flashdeck.common.data.IDao;
import lingo.flashdeck.common.data.IDeckEntity;
import lingo.flashdeck.common.deck.BoxType;
import org.joda.time.DateTime;


/**
 * Use this when the datastore/db are local, which means the entity objects has id fields populated
 * by the db.
 *
 */
public class DeckManagerGae
    extends AbsDeckManager
{

    public DeckManagerGae(IDao dao)
    {
        super(dao);
    }


    @Override
    protected IDeckEntity createDeckEntity(Long learnerId, Long lessonId)
    {
        return new DeckEntityGae(learnerId, lessonId);
    }

    @Override
    protected IBoxItemEntity createBoxItemEntity(Long itemId)
    {
        return new BoxItemGae(itemId);
    }

    @Override
    protected IBoxItemEntity createBoxItemEntity(Long deckId, BoxType boxType, Long itemId,
        DateTime dateTaken)
    {
        return  new BoxItemGae(deckId,boxType,itemId,dateTaken);
    }
}
