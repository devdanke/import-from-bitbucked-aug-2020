# README #

This is similar to lingo, but it focuses on a quizzer UI.  

It also has a rudimentary content management system.  And scripts for processing audio and graphic files to make the work with the quizzer web app.