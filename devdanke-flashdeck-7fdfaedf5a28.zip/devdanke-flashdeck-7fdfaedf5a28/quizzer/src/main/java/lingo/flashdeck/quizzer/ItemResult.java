package lingo.flashdeck.quizzer;


public class ItemResult
{
    private Long _itemId;

    private Boolean _isCorrect;

    public ItemResult(Long itemId, Boolean isCorrect)
    {
        _itemId = itemId;
        _isCorrect = isCorrect;
    }


    public Long getItemId()
    {
        return _itemId;
    }

    public void setItemId(Long itemId)
    {
        _itemId = itemId;
    }

    public Boolean getCorrect()
    {
        return _isCorrect;
    }

    public Boolean isCorrect()
    {
        return _isCorrect;
    }

    public void setCorrect(Boolean correct)
    {
        _isCorrect = correct;
    }


    public boolean isSame(Object o)
    {
        if (this == o) return true;
        if (!(o instanceof ItemResult)) return false;

        ItemResult that = (ItemResult) o;

        if (!_isCorrect.equals(that._isCorrect)) return false;
        if (!_itemId.equals(that._itemId)) return false;

        return true;
    }


    @Override
    public String toString()
    {
        return "ItemResult{" +
            ", _itemId=" + _itemId +
            ", _isCorrect=" + _isCorrect +
            '}';
    }
}
