package lingo.flashdeck.quizzer;


import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;

import java.text.Collator;
import java.util.Comparator;

/**
 * *******************************************************************
 * Return classes the implement Comparable to sort lists.
 * ********************************************************************
 */

public class Sorter
{
    public static Comparator<QuizDeck> SORT_DECKS_BY_NAME = new SortDecksByName();
    public static Comparator<Lesson> SORT_LESSONS_BY_NAME = new SortLessonsByName();

    
    public static class SortDecksByName
        implements Comparator<QuizDeck>
    {
        public int compare(QuizDeck d1, QuizDeck d2)
        {
            Collator collator = Collator.getInstance();

            return collator.compare(d1.getLesson().getName(), d2.getLesson().getName());
        }
    }


    public static class SortLessonsByName
        implements Comparator<Lesson>
    {
        public int compare(Lesson lsn1, Lesson lsn2)
        {
            Collator collator = Collator.getInstance();

            return collator.compare(lsn1.getName(), lsn2.getName());
        }
    }

}
