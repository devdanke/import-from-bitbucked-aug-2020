package lingo.flashdeck.quizzer;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;
import lingo.flashdeck.common.deck.BoxItem;
import lingo.flashdeck.common.deck.BoxType;
import lingo.flashdeck.common.util.MyAssert;
import lingo.flashdeck.quizzer.xmlgen.lesson.Item;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 */
public class Leitner
{
    private static Logger __log = LoggerFactory.getLogger(Leitner.class);


    /**
     * <p/>
     * Get the current boxItem list from the deck.
     * For each one that does NOT have a related ItemResult, recreate it (to avoid JPA persist of a
     * detached entity problem later) and add it to final result list.
     * For each one that does have an itemResult, calculate it's new box position and put
     * it in the final list.
     * <p/>
     * The result that unquizzed boxItems are unchanged.  Quizzed boxItems are altered in-place
     * to reflect their new box position.
     *
     * @param deckDto
     * @param itemResults
     * @param dateTaken
     */
    public static  List<BoxItem> calcNextBoxPositions(Long deckId,
        List<BoxItem> curBoxPositions, List<ItemResult> itemResults, DateTime dateTaken)
    {
        MyAssert.notNull("deckId", deckId);
        MyAssert.notNullOrEmpty("curBoxPositions", curBoxPositions);
        MyAssert.notNull("dateTaken", dateTaken);
        MyAssert.notNullOrEmpty("itemResults", itemResults);
        MyAssert.notNull("dateTaken", dateTaken);

        Map<Long,ItemResult> itemResultsById = LessonMapper.mapItemResultById(itemResults);

        List<BoxItem> nextBoxPositions = Lists.newArrayList();
        for(BoxItem curBoxItemDto : curBoxPositions)
        {
            Long itemId = curBoxItemDto.getItemId();
            Object[] logArgs = new Object[]{deckId, itemId};
            BoxType curBox = curBoxItemDto.getBoxType();
            BoxType nextBox = curBox;
            DateTime newDateTaken = curBoxItemDto.getDateTaken();
            ItemResult itemResult = itemResultsById.get( itemId );
            if( itemResult != null )
            {
                //boxItem was in the quiz
                newDateTaken = dateTaken;
                if( itemResult.isCorrect() )
                {
                    //__log.debug("deckId={}, itemId={}: in quiz and correct", logArgs);
                    nextBox = curBox.next(); //you advance!
                }
                else
                {
                    //__log.debug("deckId={}, itemId={}: in quiz and wrong", logArgs);
                    nextBox = BoxType.BOX_1_OF_5;//back to square one:-(
                }
            }
            else
            {
                //__log.debug("deckId={}, itemId={}: not in quiz", logArgs);
            }

            nextBoxPositions.add(new BoxItem(deckId, nextBox, itemId, newDateTaken));
        }

        return nextBoxPositions;
    }



    /*
     */
    public static List<Item> getItemsReadyForReview(QuizDeck quizDeck, DateTime someDate)
    {
        List<Item> todayItems = Lists.newArrayList();
        for(BoxItem boxItemDto : quizDeck.getBoxItems())
        {
            if( isReadyForReview(boxItemDto.getDateTaken(), boxItemDto.getBoxType(), someDate))
            {
                todayItems.add( quizDeck.getItemById(boxItemDto.getItemId()) );
            }
        }
        return todayItems;
    }



    ///////////////////////////////////////////////////////////////////////////////////
    // static and package private just for testing.
    // if can be sure they can be tested via instance methods, then do so.
    // and make them private instance methods.
    ///////////////////////////////////////////////////////////////////////////////////

    /*
    this version of this method lets you pass in a future date for 'today', whichs
    makes testing easier.
     */
    @VisibleForTesting
    static boolean isReadyForReview(DateTime dateTaken, BoxType boxType, DateTime now)
    {
        //if deck never quized before, take a quiz!
        if(dateTaken==null) return true;

        DateTime endReviewDelay = dateTaken.plusDays( boxType.getReviewDelayDays() );
        return now.isAfter(endReviewDelay);
    }


}
