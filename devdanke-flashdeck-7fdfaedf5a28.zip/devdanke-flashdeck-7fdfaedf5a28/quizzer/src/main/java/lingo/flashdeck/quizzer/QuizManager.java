package lingo.flashdeck.quizzer;


import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lingo.flashdeck.common.deck.BoxItem;
import lingo.flashdeck.common.deck.Deck;
import lingo.flashdeck.common.deck.IDeckManager;
import lingo.flashdeck.common.util.MyAssert;
import lingo.flashdeck.common.util.obj;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
/**
 */
public class QuizManager
{
    private Logger _log = LoggerFactory.getLogger(QuizManager.class);
    
    private final Map<Long,QuizDeck> _quizDecksById;
    private final Map<Long,QuizDeck> _quizDecksByLessonId;


    /**
     *  The purpose of the QuizManager is to assemble the high-level QuizDeck objects and make them
     *  available to the application presenting quizes.
     *
     *  For now (May 4) I've decided to keep the Db stuff out of QuizManager.
     *
     * @param dataMgr
     * @param learnerId
     * @param lessons for now all lessons.  later, just this learner's lessons.
     * @param boxItems boxItems for each deckDto.  There must be as many boxItems
     * as there are items in all the lessons.
     */
    public QuizManager( List<Lesson> lessons, List<Deck> decks)
    {
        MyAssert.notNullOrEmpty("lessons", lessons);
        MyAssert.notNull("decks", decks);

        _quizDecksById = Maps.newHashMap();
        _quizDecksByLessonId = Maps.newHashMap();

        if(!decks.isEmpty())
        {
            Map<Long,Lesson> lessonsById = LessonMapper.mapLessonById(lessons);

            for(Deck deck : decks)
            {
                Long deckId = deck.getId();
                Long lessonId = deck.getLessonId();
                Lesson lesson = lessonsById.get(lessonId);
                if(lesson == null)
                {
                    _log.error("cannot find lesson for deckId={} with lessonId={}",
                        obj.arr(deckId, lessonId) );
                    continue;
                }
                QuizDeck quizDeck = new QuizDeck(deck, lesson);
                _quizDecksById.put(deckId, quizDeck);
                _quizDecksByLessonId.put(lessonId, quizDeck);
            }
        }

    }


    public List<QuizDeck> getDecks()
    {
        List<QuizDeck> quizDecks = Lists.newArrayList(_quizDecksById.values());
        Collections.sort(quizDecks, Sorter.SORT_DECKS_BY_NAME);
        return quizDecks;
    }

    
    public QuizDeck getDeck(Long id)
    {
        return _quizDecksById.get(id);
    }


    public QuizDeck getDeckByLessonId(Long lessonId)
    {
        return _quizDecksByLessonId.get(lessonId);
    }


    public void addDeck(QuizDeck quizDeck)
    {
        _quizDecksById.put(quizDeck.getId(), quizDeck);
        _quizDecksByLessonId.put(quizDeck.getLesson().getId(), quizDeck);
    }


    public void processQuizResults(IDeckManager deckMgr, QuizDeck quizDeck,
        Map<Long,Boolean> answerMap)
    {
        DateTime quizDate = new DateTime();

        List<ItemResult> itemResults = Lists.newArrayList();
        for(Map.Entry<Long,Boolean> entry : answerMap.entrySet())
        {
            itemResults.add(new ItemResult(entry.getKey(), entry.getValue()) );
        }

        List<BoxItem> newBoxItemPositions = Leitner.calcNextBoxPositions(quizDeck.getId(),
            quizDeck.getBoxItems(), itemResults, quizDate);

        Deck deck = quizDeck.getDeck();
        deck.setBoxItems(newBoxItemPositions);
        deckMgr.update(deck);
    }


    public void removeDeletedDeck(Long deckId)
    {
        //sanity check
        
        if(!_quizDecksById.containsKey(deckId))
        {
            throw new IllegalStateException("cannot remove quizDeck QuizMgr doesn't have. deckId=" + deckId);
        }
        QuizDeck quizDeck = _quizDecksById.remove(deckId);
        _quizDecksByLessonId.remove(quizDeck.getLesson().getId());
    }


    public Set<Long> getActiveLessonIds()
    {
        return Sets.newHashSet(_quizDecksByLessonId.keySet());
    }


}
