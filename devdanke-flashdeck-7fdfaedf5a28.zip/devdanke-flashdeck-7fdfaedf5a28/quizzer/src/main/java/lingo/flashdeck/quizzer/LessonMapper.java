package lingo.flashdeck.quizzer;

import com.google.common.collect.Maps;
import lingo.flashdeck.quizzer.xmlgen.lesson.Item;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;

import java.util.List;
import java.util.Map;

/**
 I often need to turn a list into a map, with the key being the list items id.
 */
public class LessonMapper
{

    /*
    TODO: allow this to become generic by telling JAXB that this (and Lesson) implement IHaveId.
    Maybe I could make a generic method out of this.
    Take list of assoc, each which implements IHaveId.
    Turn return Map of id to item.
     */
    public static Map<Long,Item> mapItemById(List<Item> Items)
    {
        Map<Long,Item> map = Maps.newHashMap();

        for(Item item : Items)
        {
            map.put(item.getId(), item);
        }

        return map;
    }

    /*
    TODO: allow this to become generic by telling JAXB that this (and Lesson) implement IHaveId.
     */
    public static Map<Long,Lesson> mapLessonById(List<Lesson> lessons)
    {
        Map<Long,Lesson> map = Maps.newHashMap();

        for(Lesson lesson : lessons)
        {
            map.put(Long.valueOf(lesson.getId()), lesson);
        }

        return map;
    }


    public static Map<Long,ItemResult> mapItemResultById(List<ItemResult> itemResults)
    {
        Map<Long,ItemResult> map = Maps.newHashMap();

        for(ItemResult itemResult : itemResults)
        {
            map.put(itemResult.getItemId(), itemResult);
        }

        return map;
    }




}
