package lingo.flashdeck.quizzer;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;
import lingo.flashdeck.common.deck.BoxItem;
import lingo.flashdeck.common.deck.Deck;
import lingo.flashdeck.common.util.IHaveId;
import lingo.flashdeck.common.util.MyAssert;

import lingo.flashdeck.quizzer.xmlgen.lesson.Item;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;
import lingo.flashdeck.quizzer.xmlgen.lesson.Property;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;
import java.util.Map;


/**
 * This deck holds a DeckDto from DB.  It also gets loaded with an XML based lesson.
 * Typically this deck will come from QuizManager.

 */
public class QuizDeck
    implements IHaveId
{
    private final Logger _log = LoggerFactory.getLogger(QuizDeck.class);

    public String SORT_BY = "sortOrder";
    public String DOC_ORDER = "document";

    private Deck _deck;
    private Lesson _lesson;
    //private List<BoxItem> _boxItems;
    private Map<Long, Item> _itemsById;


    public QuizDeck(Deck deck, Lesson lesson /*List<BoxItem> boxItems */)
    {
        MyAssert.notNull("deck", deck);
        MyAssert.notNull("lesson", lesson);
        //MyAssert.notNullOrEmpty("boxItems", boxItems);

        _deck = deck;
        _lesson = lesson;
        _itemsById = LessonMapper.mapItemById(lesson.getItem());
        //_boxItems = boxItems;
    }


    public Long getId()
    {
        return _deck.getId();
    }

    public List<Integer> getBoxCounts()
    {
        int[] boxCount = new int[5];

        List<BoxItem> boxItems = _deck.getBoxItems();
        for(int i=0; i< boxItems.size(); i++)
        {
            BoxItem bi = boxItems.get(i);
            boxCount[bi.getBoxType().ordinal()] += 1;
        }

        List<Integer> result = Lists.newArrayList();
        for(int i=0; i<boxCount.length;i++)
        {
            result.add(boxCount[i]);
        }

        return result;
    }

    public Lesson getLesson()
    {
        return _lesson;
    }


    public Deck getDeck()
    {
        return _deck;
    }

    /**
     * For learn mode
     *
     * return all item IDs in random order
     *
     * @return
     */
    public List<Long> getAllItemIdsShuffled()
    {
        List<Long> itemIds = Lists.newArrayList();

        for( Item item : _lesson.getItem() )
        {
            itemIds.add(item.getId());
        }

        Collections.shuffle(itemIds);
        return itemIds;
    }

    /**
     * By default the item IDs will be randomly sorted.
     * But if the lesson has a property sort=docOrder, then the IDs
     * will be given in the order they appear in the lesson xml document.
     * 
     * @return
     */
    public List<Long> getNextReadyItemIdsOrdered()
    {
        List<Long> itemIds = Lists.newArrayList();

        for( Item item : getNextPossibleReadyItems() )
        {
            itemIds.add(item.getId());
        }

        if(!hasPropValue(_lesson, SORT_BY, DOC_ORDER))
        {
            //common case. 
            Collections.shuffle(itemIds);
        }

        return itemIds;
    }

    public Item getItemById(Long id)
    {
        return _itemsById.get(id);
    }

    /*
    Called by DataManager before saving them to db.
     */
    public List<BoxItem> getBoxItems()
    {
        return Lists.newArrayList(_deck.getBoxItems());
    }


    /*
     */
    public List<Item> getReadyNowItems()
    {
        return  Leitner.getItemsReadyForReview(this, new DateTime()) ;
    }


    /*
    returns a shuffled list of ready items
    keep going to future day to find the day on which some items are ready.
     */
    private List<Item> getNextPossibleReadyItems()
    {
        DateTime date = new DateTime();
        List<Item> readyItems = Leitner.getItemsReadyForReview(this, date);
        while(readyItems.isEmpty())
        {
            date = date.plusDays(1);
            readyItems = Leitner.getItemsReadyForReview(this, date);
        }
        return readyItems;
    }


    public DeckItemCounts getBoxAndReadyCounts()
    {
        List<Integer> counts = Lists.newArrayList();

        for(int boxCount : getBoxCounts())
        {
            counts.add(boxCount);
        }

        return new DeckItemCounts(counts, getReadyNowItems().size(), getNextPossibleReadyItems().size());
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////
    // support methods
    ////////////////////////////////////////////////////////////////////////////////////////////////

    @VisibleForTesting
    boolean hasPropValue(Lesson lesson, String propName, String propVal)
    {
        List<Property> props = lesson.getProperty();
        if(props == null) return false;

        for(Property prop : props)
        {
            if( prop.getName().equals(propName) && prop.getValue().equals(propVal) )
            {
                return true;
            }
        }

        return false;

    }

}
