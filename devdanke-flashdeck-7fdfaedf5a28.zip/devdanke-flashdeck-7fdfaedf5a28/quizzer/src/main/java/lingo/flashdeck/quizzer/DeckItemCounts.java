package lingo.flashdeck.quizzer;

import lingo.flashdeck.common.util.MyAssert;

import java.util.List;

/**
 */
public class DeckItemCounts
{
    private final List<Integer> _boxCounts;
    private final Integer _readyNow;
    private final Integer _readyNext;
    private Integer _itemCount;

    public DeckItemCounts(List<Integer> boxCounts, Integer readyNow, Integer readyNext)
    {
        MyAssert.notNullOrEmpty("boxCounts", boxCounts);
        MyAssert.notNull("readyNow", readyNow);
        MyAssert.notNull("readyNext", readyNext);

        _boxCounts = boxCounts;
        _readyNow = readyNow;
        _readyNext = readyNext;
        _itemCount =0;
        for(Integer boxCount : boxCounts)
        {
            _itemCount += boxCount;
        }
    }

    public List<Integer> getBoxCounts()
    {
        return _boxCounts;
    }

    public Integer getReadyNow()
    {
        return _readyNow;
    }

    public Integer getReadyNext()
    {
        return _readyNext;
    }

    public Integer getItemCount()
    {
        return _itemCount;
    }

}
