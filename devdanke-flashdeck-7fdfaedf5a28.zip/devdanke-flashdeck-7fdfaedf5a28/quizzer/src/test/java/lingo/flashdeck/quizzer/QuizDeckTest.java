package lingo.flashdeck.quizzer;

import com.google.common.collect.Lists;
import lingo.flashdeck.common.deck.BoxItem;
import lingo.flashdeck.common.deck.Deck;
import lingo.flashdeck.quizzer.xmlgen.lesson.Item;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

/**
 */
public class QuizDeckTest
{

    @Test
    public void quizDeckGivesCorrectDeckId()
    {
        String testName = "quizDeckGivesCorrectDeckId";

        Long expectDeckId = 723900L;

        Lesson lesson = TestDataUtil.makeLesson(testName);
        QuizDeck quizDeck = makeQuizDeck(expectDeckId, lesson);

        Assert.assertEquals("deckId", expectDeckId, quizDeck.getId());
    }

    @Test
    public void deckCalcsCorrectBoxCounts()
    {
        String testName = "deckCalcsCorrectBoxCounts";

        Long expectDeckId = 76669L;
        Integer expectItemCount = 3;

        Lesson lesson = TestDataUtil.makeLesson(testName, expectItemCount);
        QuizDeck quizDeck = makeQuizDeck(expectDeckId, lesson);

        Integer ZERO = 0;
        List<Integer> boxCounts = quizDeck.getBoxCounts();

        Assert.assertEquals("box1 count", expectItemCount, boxCounts.get(0) );
        Assert.assertEquals("box1 count", ZERO,  boxCounts.get(1) );
        Assert.assertEquals("box1 count", ZERO,  boxCounts.get(2) );
        Assert.assertEquals("box1 count", ZERO,  boxCounts.get(3) );
        Assert.assertEquals("box1 count", ZERO,  boxCounts.get(4) );
    }



    /*
     */
    public static Deck makeDeck(Long deckId, Long learnerId, Lesson lesson)
    {
        List<BoxItem> boxItems = Lists.newArrayList();
        for(Item item : lesson.getItem() )
        {
            boxItems.add( new BoxItem(item.getId()) );
        }

        return new Deck(deckId, learnerId, lesson.getId(), boxItems);
    }

    /*
     */
    public static QuizDeck makeQuizDeck(Long deckId, Lesson lesson)
    {
        Long learnerId = 87659L;

        return new QuizDeck( makeDeck(deckId, learnerId, lesson), lesson );
    }

    public static QuizDeck makeQuizDeck(Integer deckId, Lesson lesson)
    {
        return makeQuizDeck(new Long(deckId), lesson);
    }
}
