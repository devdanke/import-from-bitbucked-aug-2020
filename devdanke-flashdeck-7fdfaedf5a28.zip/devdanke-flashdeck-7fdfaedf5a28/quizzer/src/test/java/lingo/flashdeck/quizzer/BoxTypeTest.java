package lingo.flashdeck.quizzer;

import lingo.flashdeck.common.deck.BoxType;
import org.junit.Assert;
import org.junit.Test;

/**
 */
public class BoxTypeTest
{
    @Test
    public void calcNextBoxCorrectly()
    {
        //                                expect              actual
        Assert.assertEquals("box 1.next", BoxType.BOX_2_OF_5, BoxType.BOX_1_OF_5.next() );
        Assert.assertEquals("box 2.next", BoxType.BOX_3_OF_5, BoxType.BOX_2_OF_5.next() );
        Assert.assertEquals("box 3.next", BoxType.BOX_4_OF_5, BoxType.BOX_3_OF_5.next() );
        Assert.assertEquals("box 4.next", BoxType.BOX_5_OF_5, BoxType.BOX_4_OF_5.next() );
        Assert.assertEquals("box 5.next", BoxType.BOX_5_OF_5, BoxType.BOX_5_OF_5.next() );
    }

}
