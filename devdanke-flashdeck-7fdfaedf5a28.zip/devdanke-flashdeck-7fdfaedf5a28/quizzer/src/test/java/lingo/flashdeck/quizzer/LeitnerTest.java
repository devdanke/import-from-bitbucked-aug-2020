package lingo.flashdeck.quizzer;

import com.google.common.collect.Lists;
import lingo.flashdeck.common.deck.BoxItem;
import lingo.flashdeck.common.deck.BoxType;
import lingo.flashdeck.quizzer.xmlgen.lesson.Item;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

/**
 */
public class LeitnerTest
{
    private static final int ITEM_COUNT_3 =3;
    private final DateTime _dateTaken = new DateTime();
    private static final int BOX_COUNT = BoxType.values().length;
    private static final int LAST_BOX_POS = BOX_COUNT -1;

    @Test
    public void whenAllItemsCorrectAllMoveToNextBox()
    {
        String testName = "whenAllItemsCorrectAllMoveToNextBox";
        QuizDeck quizDeck = makeSavedDeck(testName, ITEM_COUNT_3);

        List<ItemResult> allCorrect = makeAnswersAll(true, quizDeck.getLesson().getItem());

        //starting with a new quizDeck, take quiz and get all items correct.
        //then all items must move to next box
        for(int i = 1; i < BOX_COUNT; i++)
        {
            List<BoxItem> nextBoxItemsPos = Leitner.calcNextBoxPositions(quizDeck.getId(),
                quizDeck.getBoxItems(), allCorrect, _dateTaken);

            List<Integer> expect = makeIntListWithValueAtPos(ITEM_COUNT_3, i);
            quizDeck.getDeck().setBoxItems(nextBoxItemsPos);
            List<Integer> actual = quizDeck.getBoxCounts();

            Assert.assertEquals("boxCounts after (all correct) quiz " + i, expect, actual);
        }
    }


    @Test
    public void whenWrongAnswerAlwaysGoBox0()
    {
        String testName = "whenWrongAnswerAlwaysGoBox0";
        QuizDeck quizDeck = makeSavedDeck(testName, ITEM_COUNT_3);

        List<Item> items = quizDeck.getLesson().getItem();

        //if all items in box 0, and answer quiz all incorrect
        //then all stay in box 0
        List<ItemResult> allIncorrect = makeAnswersAll(false, items);

        List<Integer> ALL_IN_BOX0 = makeIntListWithValueAtPos(ITEM_COUNT_3, 0);//expect all in box 0


        for(int i=0; i< BOX_COUNT; i++)
        {
            //items start in box i
            quizDeck.getDeck().setBoxItems(makeAllItemsInBoxPos(quizDeck.getId(),items, i));
            //pretend learner took quiz and got all answers  wrong
             List<BoxItem> nextBoxItemsPos = Leitner.calcNextBoxPositions(quizDeck.getId(),
                 quizDeck.getBoxItems(), allIncorrect, _dateTaken);
            quizDeck.getDeck().setBoxItems(nextBoxItemsPos);

            //verify all in box0
            Assert.assertEquals("items in box[" + i + "], then all incorrect answers",
                ALL_IN_BOX0, quizDeck.getBoxCounts());
        }
    }


    @Test
    public void whenCorrectItemsInLastBoxTheyStayThere()
    {
        String testName = "whenCorrectItemsInLastBoxTheyStayThere";
        QuizDeck quizDeck = makeSavedDeck(testName, ITEM_COUNT_3);
        List<Item> items = quizDeck.getLesson().getItem();

        //if all items in box 0, and answer quiz all incorrect
        //then all stay in box 0
        List<ItemResult> allCorrect = makeAnswersAll(true, items);

        List<Integer> ALL_IN_LAST_BOX = makeIntListWithValueAtPos(ITEM_COUNT_3, LAST_BOX_POS);


        //items start in last box
        quizDeck.getDeck().setBoxItems(makeAllItemsInBoxPos(quizDeck.getId(), items, LAST_BOX_POS));
        //verify all items in last box
        Assert.assertEquals("items are starting in last box (box[4])",
            ALL_IN_LAST_BOX, quizDeck.getBoxCounts());

        //simulate learner took quiz and got all answers right
        Leitner.calcNextBoxPositions(quizDeck.getId(), quizDeck.getBoxItems(), allCorrect,
            _dateTaken);

        //verify all still in last box
        Assert.assertEquals("items stayed in box[4]",
            ALL_IN_LAST_BOX, quizDeck.getBoxCounts());
    }


    /*
    have 3 item lesson.
    start all in 4th box (box[3])
    quiz only two items.
    get one right and one wrong.
    afterward, 1 should be in 1st box, one should stay in 4th box, and 1 should be in last box.
     */
    @Test
    public void whenQuizOnlySomeOfItemsAfterwardAllStillHaveBoxItems()
    {
        String testName = "whenCorrectItemsInLastBoxTheyStayThere";
        QuizDeck quizDeck = makeSavedDeck(testName, ITEM_COUNT_3);

        //start all items in 2nd to last (i.e. 4th box, box[3])
        List<Item> items = quizDeck.getLesson().getItem();
        quizDeck.getDeck().setBoxItems(makeAllItemsInBoxPos(quizDeck.getId(), items, 3));

        //simulate quiz on 2 of the 3 items
        List<ItemResult> itemResults = Lists.newArrayList();
        itemResults.add(new ItemResult(items.get(0).getId(),true));
        itemResults.add(new ItemResult(items.get(1).getId(),false));
        List<BoxItem> nextBoxItemsPos = Leitner.calcNextBoxPositions(quizDeck.getId(),
            quizDeck.getBoxItems(), itemResults, _dateTaken);
        quizDeck.getDeck().setBoxItems(nextBoxItemsPos);

        //verify expected result
        Assert.assertEquals("1 in 1st, 1 in 4th, 1 in last box",
            Lists.newArrayList(1,0,0,1,1), quizDeck.getBoxCounts());

    }


    /*
    the date param in isReadyForReview is date question was last answered, i.e. data quiz taken
    b1=1d, b2=3d, b3=7d, b4=14d, b5=28d
     */
    @Test
    public void knowWhenItsTimeToReviewItem()
    {
        for(BoxType bt : BoxType.values())
        {
            testIsItemReadyForReview(bt.getReviewDelayDays(), bt);
        }
    }


    //////////////////////////////////////////////////////////////////////////////////////
    // utils & generic tests
    //////////////////////////////////////////////////////////////////////////////////////

    private List<ItemResult> makeAnswersAll(boolean isCorrect, List<Item> items)
    {
        List<ItemResult> itemResults = Lists.newArrayList();
        for(Item item : items)
        {
            itemResults.add(new ItemResult(item.getId(),isCorrect));
        }
        return itemResults;
    }


    private List<BoxItem> makeAllItemsInBoxPos(Long deckId, List<Item> items, int pos)
    {
        DateTime dateTaken = new DateTime();
        List<BoxItem> boxItems = Lists.newArrayList();
        for(int i = 0; i < items.size(); i++)
        {
            boxItems.add(
                new BoxItem(deckId, BoxType.values()[pos], items.get(i).getId(), dateTaken));
        }
        return boxItems;
    }


    /*
    create times just before and just after n days ago.
    verify that when taken just after n days ago, leitner engine says isReady=false
    verify that when taken more than n days ago, leitner engine says isReady=true
     */
    private void testIsItemReadyForReview(int delayDays, BoxType boxType)
    {
        DateTime now = new DateTime();

        DateTime justAfterNDaysAgo = now.minusDays(delayDays).plusMinutes(1);

        DateTime justBeforeNDaysAgo = now.minusDays(delayDays).minusMinutes(1);

        Assert.assertFalse( "should Not review a "+boxType+" item taken < "+delayDays+" day(s) ago",
            Leitner.isReadyForReview(justAfterNDaysAgo, boxType, now) );

        Assert.assertTrue( "should review a "+boxType +" item taken >= "+delayDays+" day(s) ago",
            Leitner.isReadyForReview(justBeforeNDaysAgo, boxType, now) );
    }


    private List<Integer> makeIntListWithValueAtPos(int value, int position)
    {
        List<Integer> list = Lists.newArrayList(0,0,0,0,0);
        list.add(position, value);//now there's 6. but i only want 1st 5
        list.remove(list.size()-1);//remove last
        return list;
    }


    public static QuizDeck makeSavedDeck(String testName, int itemCount)
    {
        Lesson lesson = TestDataUtil.makeLesson(testName,itemCount);
        return QuizDeckTest.makeQuizDeck( testName.hashCode(), lesson);
    }
}
