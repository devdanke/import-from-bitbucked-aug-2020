package lingo.flashdeck.quizzer;

import com.google.common.collect.Lists;
import junit.framework.Assert;
import lingo.flashdeck.common.deck.Deck;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;
import org.junit.Test;

import java.util.List;

/**
 */
public class QuizManagerTest
{

    @Test
    public void testCtor()
    {
        String testName = "testCtor";

        Long deckId = new Long( testName.hashCode() );
        Long learnerId = deckId + 100;

        Lesson lsn1 = TestDataUtil.makeLesson(testName+"-1");
        Lesson lsn2 = TestDataUtil.makeLesson(testName+"-2");
        List<Lesson> lessons = Lists.newArrayList(lsn1, lsn2);

        Deck d1 = QuizDeckTest.makeDeck(deckId, learnerId, lsn1);
        Deck d2 = QuizDeckTest.makeDeck(deckId+1, learnerId, lsn2);
        List<Deck> decks = Lists.newArrayList(d1,d2);

        QuizManager qm = new QuizManager(lessons, decks);

        Assert.assertEquals("qm deck count", decks.size(), qm.getDecks().size());

        //decks mapped correctly?
        for(Deck deck : decks)
        {
            Assert.assertNotNull("qm has deck for deckId="+deck.getId(),
                qm.getDeck(deck.getId()));
        }

        //lessons mapped correctly?
        for(Lesson lsn : lessons)
        {
            Assert.assertNotNull("qm has lesson for lessonId="+lsn.getId(),
                qm.getDeckByLessonId(lsn.getId()));
        }
    }


    //TODO write test for case where there's no lesson for a deck.lessonId
}
