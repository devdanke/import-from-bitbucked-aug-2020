package lingo.flashdeck.quizzer;

import com.google.common.collect.Lists;
import lingo.flashdeck.quizzer.xmlgen.lesson.Item;
import lingo.flashdeck.quizzer.xmlgen.lesson.Fact;
import lingo.flashdeck.quizzer.xmlgen.lesson.Lesson;
import lingo.flashdeck.quizzer.xmlgen.lesson.RepType;

import java.util.List;

/**
 */
public class TestDataUtil
{
    
    /**
     * @param testName
     * @param count
     * @return
     */
    public static List<Item> makeItems(String testName, int count)
    {
        List<Item> items = Lists.newArrayList();
        int baseId = testName.hashCode();
        for(int i=0; i<count; i++)
        {
            Fact fact1 = new Fact();
            fact1.setValue(testName+"_fact1_" + baseId);
            fact1.setRepType(RepType.TEXT);

            Fact fact2 = new Fact();
            fact2.setValue(testName+"_fact2_" + baseId);
            fact2.setRepType(RepType.TEXT);

            Item item = new Item();
            item.setFact1(fact1);
            item.setFact2(fact2);

            item.setId(baseId);
            items.add(item);
            baseId++;
        }
        return items;
    }


    public static Lesson makeLesson(String testName, int itemCount)
    {
        Lesson lesson = new Lesson();
        lesson.setName(testName);
        lesson.setId(testName.hashCode());
        for(int i=0; i<itemCount;i++)
        {
            Item item = new Item();
            item.setId(i);
            lesson.getItem().add(item);
        }
        return lesson;
    }


    public static Lesson makeLesson(String testName)
    {
        return makeLesson(testName, 3);
    }

}
