package lingo.flashdeck.datasvc_client;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import com.google.common.collect.Lists;
import junit.framework.Assert;
import lingo.flashdeck.common.deck.BoxItem;
import lingo.flashdeck.common.deck.BoxType;
import lingo.flashdeck.common.deck.Deck;
import lingo.flashdeck.common.util.print;
import org.joda.time.DateTime;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;


import java.util.List;

/**

 */
//@Ignore
public class ClientTest_IT
{
    private static DeckManagerJsonProxy _proxy;
    private static Long ME_LEARNER_ID = 7L;
    private static Long DEFAULT_LEARNER_ID = 666L;

    @BeforeClass
    public static void setup()
    {
        //_proxy = new DeckManagerJsonProxy("http://localhost:6050/decksvc/app"); //tomcat
        //_proxy = new DeckManagerJsonProxy("http://localhost:6050/app"); //local gae
        _proxy = new DeckManagerJsonProxy("http://decksvc.appspot.com/app"); //remote gae
    }

    
    @Test
    public void showDeckCounts()
    {
        List<Deck> decks = _proxy.findDecksByLearner(ME_LEARNER_ID);
        print.out("learnerId=7 deck count: " + decks.size());

        //assertThat("deck count > 10", decks.size(), greaterThan(20));
        decks = _proxy.findDecksByLearner(DEFAULT_LEARNER_ID);
        print.out("learnerId=666 deck count: " + decks.size());
    }


    @Test
    public void whenGivenUnsavedDeckThenSaveIt()
    {
        Long learnerId = DEFAULT_LEARNER_ID;
        Long lessonId = System.currentTimeMillis();
        Long itemId = lessonId + 1;
        
        BoxItem boxItem = new BoxItem(itemId);
        List<BoxItem> boxItems = Lists.newArrayList(boxItem);
        Deck deck = new Deck(learnerId, lessonId, boxItems);

        assertThat("pre-save, deck has no id", deck.getId(), is(nullValue()) );
        assertThat("pre-save, boxItem has no id", boxItem.getId(), is(nullValue()) );
        assertThat("pre-save, boxItem has no deckId", boxItem.getDeckId(), is(nullValue()) );

        _proxy.save(deck);

        assertThat("post-save, deck has id", deck.getId(), is(notNullValue()) );
        assertThat("post-save, boxItem has id", boxItem.getId(), is(notNullValue()) );
        assertThat("post-save, boxItem.deckId == deck.id", boxItem.getDeckId(), is(deck.getId()) );
    }


    //@Test
    public void whenSendDelMethoAndDeckIdThenDeleteDeck()
    {
        //get a deck to delete
        List<Deck> decks = _proxy.findDecksByLearner(DEFAULT_LEARNER_ID);
        if(decks.isEmpty())
        {
            Assert.fail("no deck to delete");
        }
        Long deckId = decks.get(0).getId();
        print.out("will delete deckId="+deckId);
        _proxy.delete(deckId);

        //assertThat("deck count > 20", decks.size(), greaterThan(20));
    }


    @Test
    public void afterUpdateDeckTheEachBoxItemsHasNewId()
    {
        List<Deck> decks = _proxy.findDecksByLearner(DEFAULT_LEARNER_ID);
        if(decks.isEmpty())
        {
            Assert.fail("no deck to update");
        }

        Deck deck = decks.get(0);
        Long deckId = deck.getId();

        if(deck.getBoxItems().size() != 1)
        {
            Assert.fail("must only be one boxItem in deck.id="+deckId);
        }

        //create new boxItem (just as if I'd taken a quiz) and put into deck.
        BoxItem boxItemA = deck.getBoxItems().get(0);
        Long itemId = System.currentTimeMillis();
        BoxItem boxItemB = new BoxItem(deckId, BoxType.BOX_5_OF_5, itemId, new DateTime() );
        deck.getBoxItems().clear();
        deck.getBoxItems().add(boxItemB);

        assertThat("pre-update, new boxItem has no id", boxItemB.getId(), is(nullValue()) );

        print.out("will update deckId="+deckId);

        _proxy.update(deck);

        BoxItem boxItemC = deck.getBoxItems().get(0);
        assertThat("post-update, new boxItem has id", boxItemC.getId(), is(notNullValue()) );
        assertThat("post-update, boxItemA.id != boxItemC.id",
            boxItemA.getId(), is(not(boxItemC.getId())) );
    }



}


