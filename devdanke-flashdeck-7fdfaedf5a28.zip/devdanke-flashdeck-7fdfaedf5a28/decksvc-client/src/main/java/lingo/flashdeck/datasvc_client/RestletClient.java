package lingo.flashdeck.datasvc_client;


import ch.qos.logback.core.status.Status;
import com.google.common.collect.Lists;
import lingo.flashdeck.common.util.MyAssert;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.DeleteMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.restlet.data.CharacterSet;
import org.restlet.data.ClientInfo;
import org.restlet.data.MediaType;
import org.restlet.data.Preference;
import org.restlet.representation.Representation;
import org.restlet.representation.StringRepresentation;
import org.restlet.resource.ClientResource;

import java.util.List;


/**
 * *************************************************************
 * *************************************************************
 */

public class RestletClient
    implements IRestClient
{
    private final ClientInfo _clientInfo;

    public RestletClient()
    {
        _clientInfo = new ClientInfo();

        _clientInfo.setAcceptedMediaTypes(
            Lists.newArrayList(new Preference<MediaType>(MediaType.APPLICATION_JSON)));

        _clientInfo.setAcceptedCharacterSets(
            Lists.newArrayList(new Preference<CharacterSet>(CharacterSet.UTF_8)));

    }

    
    public String doGet(String url)
    {
        ClientResource resource = createClientResource(url);
        Representation reply = null;

        try
        {
            reply = resource.get();
            String result = reply.getText();

            checkForAndHandleError(resource.getStatus().getCode());

            return result;
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            close(reply);
        }
    }


    public String doPost(String url, String body)
    {
        ClientResource resource = createClientResource(url);
        Representation reply = null;

        try
        {
            reply = resource.post(toStrRep(body));
            String result = reply.getText();

            checkForAndHandleError(resource.getStatus().getCode());

            return result;
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            close(reply);
        }
    }


    public void doDelete(String url)
    {
        ClientResource resource = createClientResource(url);
        Representation reply = null;

        try
        {
            reply = resource.delete();
            checkForAndHandleError(resource.getStatus().getCode());
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            close(reply);
        }
    }


    public String doPut(String url, String body)
    {
        ClientResource resource = createClientResource(url);
        Representation reply = null;

        try
        {
            reply = resource.put(toStrRep(body));
            String result = reply.getText();

            checkForAndHandleError(resource.getStatus().getCode());

            return result;
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            close(reply);
        }
    }


    //////////////////////////////////////////////////////////////////////////////////////
    // private support methods
    //////////////////////////////////////////////////////////////////////////////////////


    private Representation toStrRep(String str)
    {
        Representation strRep = new StringRepresentation(str, MediaType.APPLICATION_JSON);
        strRep.setCharacterSet(CharacterSet.UTF_8);
        return strRep;
    }

    private void checkForAndHandleError(int statusCode)
    {
        if(statusCode != 200)
        {
            throw new RuntimeException("http="+statusCode);
        }
    }

    private void close(Representation rep)
    {
        try
        {
            if(rep!=null)
            {
                rep.release();
            }
        }
        catch(Exception e)
        {

        }
    }

    private ClientResource createClientResource(String url)
    {
        ClientResource resource = new ClientResource(url);
        resource.setClientInfo(_clientInfo);
        return resource;
    }

}
