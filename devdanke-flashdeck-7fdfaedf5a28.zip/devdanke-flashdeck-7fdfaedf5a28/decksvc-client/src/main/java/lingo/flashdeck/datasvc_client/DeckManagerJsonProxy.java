package lingo.flashdeck.datasvc_client;


import com.google.common.collect.Lists;
import lingo.flashdeck.common.deck.BoxItem;
import lingo.flashdeck.common.deck.Deck;
import lingo.flashdeck.common.deck.IDeckManager;
import lingo.flashdeck.common.util.MyAssert;


import lingo.flashdeck.common.util.obj;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.codehaus.jackson.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

import static java.lang.String.format;

/**

 */
public class DeckManagerJsonProxy
    implements IDeckManager
{
    private static final String FIND_LEARNER_DECKS_URL = "decks/learner/%s";
    private static final String SAVE_OR_UPDATE_DECK_URL = "deck";
    private static final String DEL_DECK_URL = "deck/%s";
    
    private static final String DECK = "deck";
    private static final String DECKS = "decks";

    private Logger _log = LoggerFactory.getLogger(DeckManagerJsonProxy.class);
    private final String _baseUrl;
    private final IRestClient _httpClient;


    public DeckManagerJsonProxy(String baseUrl)
    {
        MyAssert.notNull("baseUrl", baseUrl);
        String urlEnd = "";
        if(!baseUrl.endsWith("/"))
        {
            urlEnd = "/";
        }
        _baseUrl = baseUrl + urlEnd;
        //_httpClient = new ApacheHttpClient31("application/json");
        _httpClient = new RestletClient();

        _log.info("INIT PARAM: baseUrl='{}'", baseUrl);
        _log.info("INIT success");
    }


    public List<Deck> findDecksByLearner(Long learnerId )
    {
        MyAssert.notNull("learnerId", learnerId);
        String url = _baseUrl + format(FIND_LEARNER_DECKS_URL, learnerId);
        _log.info("svc url={}", url);

        try
        {

            String reply = _httpClient.doGet(url);

            ObjectMapper jack = createObjectMapper();

            Map<String,List<Deck>> result = jack.readValue(reply,
                new TypeReference<Map<String,List<Deck>>>() { });

            List<Deck> decks = Lists.newArrayList();
            decks.addAll(result.get(DECKS));
            _log.info("return {} decks for learnerId={}", decks.size(), learnerId);
            return decks;
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    
    /**
     * serialize deck
     * send to server
     * get deck back (which will have ids for deck & boxItems
     */
    public void save(Deck unsavedDeck)
    {
        MyAssert.notNull("deck", unsavedDeck);
        String url = _baseUrl + SAVE_OR_UPDATE_DECK_URL;
        _log.info("svc url={}", url);

        try
        {

            ObjectMapper jack = createObjectMapper();
            String unsavedDeckJson = jack.writeValueAsString(unsavedDeck);

            //send to server to be saved
            String reply = _httpClient.doPost(url, unsavedDeckJson);

            //convert server response back into Deck object
            Map<String,Deck> result = jack.readValue(reply,
                new TypeReference<Map<String,Deck>>() { });

            Deck savedDeck = result.get(DECK);

            _log.info("new deckId={}", savedDeck.getId());
            
            //write the IDs from DB into the local Deck & BoxItem objects
            unsavedDeck.setId(savedDeck.getId());

            //TODO just copy incoming boxItems over top existing ones if possible.
            int i =0;
            for(BoxItem unsavedBi : unsavedDeck.getBoxItems())
            {
                BoxItem sbi = savedDeck.getBoxItems().get(i++);
                unsavedBi.setId(sbi.getId());
                unsavedBi.setDeckId(sbi.getDeckId());
            }
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    
    /*
    In this case, only the boxItems will change, so we'll copy the ones from
    the server into the local boxItems or just replace them.
     */
    public void update(Deck localDeck)
    {
        MyAssert.notNull("localDeck", localDeck);
        String url = _baseUrl + SAVE_OR_UPDATE_DECK_URL;
        _log.info("svc url={}", url);

        try
        {
            ObjectMapper jack = createObjectMapper();
            String localDeckJson = jack.writeValueAsString(localDeck);

            //send to server to be saved
            _log.debug("SEND: DEST='{}'\nBODY='{}'", obj.arr(url,localDeckJson));
            String reply = _httpClient.doPut(url, localDeckJson);
            _log.debug("RECV: REPLY='{}'", reply);

            //convert server response back into Deck object
            Map<String,Deck> result = jack.readValue(reply,
                new TypeReference<Map<String,Deck>>() { });

            Deck updatedDeck = result.get(DECK);

            //replace local boxItems with update list from server.
            localDeck.setBoxItems(updatedDeck.getBoxItems());
            _log.info("updated deck.  {} boxItems", updatedDeck.getBoxItems().size() );
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    
    /**
     * the caller is responsible for deleting any local copy of the deck, such as if held in quiz
     * manager
     */
    public void delete(Long deckId)
    {
        MyAssert.notNull("deckId", deckId);
        String url = _baseUrl + format(DEL_DECK_URL, deckId);
        _log.info("svc url={}", url);

        _httpClient.doDelete(url);
        _log.info("no exception, so success likely");
    }

    
    public void cleanup()
    {

    }

    ///////////////////////////////////////////////////////////////////////////////////////
    //
    ///////////////////////////////////////////////////////////////////////////////////////

    private ObjectMapper createObjectMapper()
    {
        ObjectMapper jack = new ObjectMapper();
        jack.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        jack.configure(SerializationConfig.Feature.INDENT_OUTPUT, true);

        return jack;
    }


}
