package lingo.flashdeck.datasvc_client;

/**
 * *************************************************************
 * *************************************************************
 */
public interface IRestClient
{
    String doGet(String url);

    String doPost(String url, String body);

    void doDelete(String url);

    String doPut(String url, String body);
}
