package lingo.flashdeck.datasvc_client;


import lingo.flashdeck.common.util.MyAssert;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.DeleteMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;


/**
 * *************************************************************
 * *************************************************************
 */

public class ApacheHttpClient31
    implements IRestClient
{
    private final String _mimeType;

    public ApacheHttpClient31(String mimeType)
    {
        MyAssert.notNullOrEmpty("mimeType", mimeType);
        _mimeType = mimeType;
    }

    public String doGet(String url)
    {
        // Create an instance of HttpClient.
        HttpClient client = new HttpClient();

        // Create a method instance.
        GetMethod method = new GetMethod(url);
        method.addRequestHeader("Accept", _mimeType);

        try
        {
          // Execute the method.
          int statusCode = client.executeMethod(method);

          if (statusCode != 200)
          {
              throw new RuntimeException("http code= " + statusCode);
          }

          // Read the response body.
          byte[] responseBody = method.getResponseBody();

           return new String(responseBody);
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
          method.releaseConnection();
        }
    }


    public String doPost(String url, String body)
    {
        PostMethod post = new PostMethod(url);
        try
        {
            post.addRequestHeader("Accept", _mimeType);
            RequestEntity entity = new StringRequestEntity(body, _mimeType, "utf8");
            post.setRequestEntity(entity);
            HttpClient httpclient = new HttpClient();

            int result = httpclient.executeMethod(post);
            if(result != 200)
            {
                throw new RuntimeException("http code=" + result);
            }

            return post.getResponseBodyAsString();
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            // Release current connection to the connection pool once you are done
            post.releaseConnection();
        }
    }


    public void doDelete(String url)
    {
        DeleteMethod method = new DeleteMethod(url);
        try
        {
            method.addRequestHeader("Accept", _mimeType);
            HttpClient httpclient = new HttpClient();

            int result = httpclient.executeMethod(method);
            if(result != 200)
            {
                throw new RuntimeException("http code=" + result);
            }
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            // Release current connection to the connection pool once you are done
            method.releaseConnection();
        }
    }


    public String doPut(String url, String body)
    {
        PutMethod method = new PutMethod(url);
        try
        {
            method.addRequestHeader("Accept", _mimeType);
            RequestEntity entity = new StringRequestEntity(body, _mimeType, "utf8");
            method.setRequestEntity(entity);
            HttpClient httpclient = new HttpClient();

            int result = httpclient.executeMethod(method);
            if(result != 200)
            {
                throw new RuntimeException("http code=" + result);
            }

            return method.getResponseBodyAsString();
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
        finally
        {
            // Release current connection to the connection pool once you are done
            method.releaseConnection();
        }
    }

}
