package lingo.flashdeck.data_db;

import lingo.flashdeck.common.data.IBoxItemEntity;
import lingo.flashdeck.common.deck.BoxType;
import lingo.flashdeck.common.util.MyAssert;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import javax.persistence.*;


@Entity
@Table(name = "box_item")
@NamedQueries
({
    @NamedQuery
    (
        name="findBoxItemsByDeck",
        query="SELECT bid FROM BoxItemDb bid WHERE bid._deckId = :deckId"
    ),

    @NamedQuery
    (
        name="deleteBoxItemsByDeck",
        query="DELETE FROM BoxItemDb bid WHERE bid._deckId = :deckId"
    )
})
public class BoxItemDb
    implements IBoxItemEntity
{
    @Id
    @GeneratedValue
    @Column(name = "id")
    private Long _id;

    @Column(name = "deck_id")
    private Long _deckId;

    @Column(name = "box_type", nullable = false )
    @Enumerated(value = EnumType.STRING)
    private BoxType _boxType;

    @Column(name = "item_id", nullable = false )
    private Long _itemId;

    @Column(name = "date_taken", nullable = true ) //can be null if never taken before
    @Type(type="org.joda.time.contrib.hibernate.PersistentDateTime")
    private DateTime _dateTaken;


    public BoxItemDb(){}

    /*
    Use this when creating boxItems for new deck.
    These have not taken date.
     */
    public BoxItemDb(Long itemId)
    {
        this(null,BoxType.BOX_1_OF_5,itemId,null);
    }

    
    public BoxItemDb(Long deckId, BoxType boxType, Long itemId)
    {
        MyAssert.notNull("boxType", boxType);
        MyAssert.notNull("itemId", itemId);

        _deckId = deckId;
        _boxType = boxType;
        _itemId = itemId;
    }


    /*
    Use this when creating new BoxItems after a quiz was taken.
     */
    public BoxItemDb(Long deckId, BoxType boxType, Long itemId, DateTime dateTaken)
    {
        this(deckId,boxType,itemId);
        _dateTaken = dateTaken;
    }

    public Long getId()
    {
        return _id;
    }

    public Long getDeckId()
    {
        return _deckId;
    }

    /**
     * Need this method when saving a deck and it's box items the first time.
     * BoxItemDtos are created before deckDto.id is known.  After DeckDb is
     * saved then its id is added to the BoxItemDb via this setter.
     * @param deckId
     */
    public void setDeckId(Long deckId)
    {
        MyAssert.notNull("deckId", deckId);
        _deckId = deckId;
    }

    public DateTime getDateTaken()
    {
        if(_dateTaken != null) return _dateTaken.toDateTime();
        else return null;
    }

    public BoxType getBoxType()
    {
        return _boxType;
    }

    public Long getItemId()
    {
        return _itemId;
    }


    public boolean isSame(IBoxItemEntity that)
    {
        if (_boxType != that.getBoxType()) return false;
        if (_dateTaken != null ? !_dateTaken.equals(that.getDateTaken()) : that.getDateTaken() != null)
            return false;
        if (_deckId != null ? !_deckId.equals(that.getDeckId()) : that.getDeckId() != null) return false;
        if (_id != null ? !_id.equals(that.getId()) : that.getId() != null) return false;
        if (_itemId != null ? !_itemId.equals(that.getItemId()) : that.getItemId() != null) return false;

        return true;
    }
    
    @Override
    public String toString()
    {
        return "BoxItemDb{" +
            "_id=" + _id +
            ", _deckId=" + _deckId +
            ", _boxType=" + _boxType +
            ", _itemId=" + _itemId +
            ", _dateTaken=" + _dateTaken +
            '}';
    }
}
