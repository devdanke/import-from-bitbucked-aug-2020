package lingo.flashdeck.data_db;

import lingo.flashdeck.common.data.AbsDeckManager;
import lingo.flashdeck.common.data.IBoxItemEntity;
import lingo.flashdeck.common.data.IDao;
import lingo.flashdeck.common.data.IDeckEntity;
import lingo.flashdeck.common.deck.BoxType;
import org.joda.time.DateTime;

/**
 */

public class DeckManagerDb
    extends AbsDeckManager
{

    public DeckManagerDb(IDao dao)
    {
        super(dao);
    }


    @Override
    protected IDeckEntity createDeckEntity(Long learnerId, Long lessonId)
    {
        return new DeckDb(learnerId, lessonId);
    }

    @Override
    protected IBoxItemEntity createBoxItemEntity(Long itemId)
    {
        return new BoxItemDb(itemId);
    }

    @Override
    protected IBoxItemEntity createBoxItemEntity(Long deckId, BoxType boxType, Long itemId,
        DateTime dateTaken)
    {
        return  new BoxItemDb(deckId,boxType,itemId,dateTaken);
    }


/*
    private DaoDb _dao;

    public DeckManagerDb(DaoDb dataMgr)
    {
        MyAssert.notNull("dataMgr", dataMgr);
        _dao = dataMgr;
    }

    */
/**
     * First, load deckDtos from DB. Second, load related BoxItemDtos.  Finally, put them together.
     *
     *//*

    public List<Deck> findDecksByLearner(Long learnerId)
    {
        List<Deck> decks = Lists.newArrayList();

        List<DeckDb> deckDtos = _dao.findDecksByLearner(learnerId);
        if(!deckDtos.isEmpty())
        {
            List<BoxItemDb> boxItemDtos = _dao.findBoxItemsForDecks(deckDtos);
            List<BoxItem> boxItems = Lists.newArrayList();
            for(BoxItemDb bid : boxItemDtos)
            {
                boxItems.add(new BoxItem(bid.getId(), bid.getDeckId(), bid.getBoxType(),
                    bid.getItemId(), bid.getDateTaken()));
            }

            Multimap<Long,BoxItem> boxItemsByDeckId = CommonMapper.mapKidsByOwenerId(boxItems);

            for(DeckDb dd : deckDtos)
            {
                decks.add(new Deck(dd.getId(), learnerId, dd.getLessonId(),
                    boxItemsByDeckId.get(dd.getId())));
            }
        }

        return decks;
    }


    public void save(Deck deck)
    {
        if(deck.getId() != null)
        {
            throw new IllegalArgumentException("deck id must be null");
        }

        DeckDb dd = new DeckDb(deck.getLearnerId(), deck.getLessonId());

        List<IBoxItemEntity> bids = Lists.newArrayList();
        for(BoxItem bi : deck.getBoxItems())
        {
            if(bi.getId() != null)
            {
                throw new IllegalArgumentException("boxItem id must be null");
            }

            bids.add( new BoxItemDb(bi.getItemId()) );
        }

        _dao.save(dd, bids);

        //now associate the DB ids with the Deck
        deck.setId(dd.getId());

        int i=0;
        for(IBoxItemEntity bid : bids)
        {
            BoxItem bi = deck.getBoxItems().get(i++);
            bi.setId(bid.getId());
            bi.setDeckId(bid.getDeckId());
        }

    }

    
    public void update(Deck deck)
    {
        //TODO verify incoming boxItems have valid deckId and other required fields.

        List<IBoxItemEntity> bids = Lists.newArrayList();
        DateTime now = new DateTime();
        for(BoxItem bi: deck.getBoxItems())
        {
            bids.add(new BoxItemDb(deck.getId(), bi.getBoxType(), bi.getItemId(), now));
        }

        _dao.saveNewBoxPositions(deck.getId(), bids);


        int i=0;
        for(IBoxItemEntity bid : bids)
        {
            BoxItem bi = deck.getBoxItems().get(i++);
            bi.setId(bid.getId());
        }
    }


    public void delete(Long deckId)
    {
        _dao.deleteDeck(deckId);
    }

    
    public void cleanup()
    {
        _dao.cleanup();
    }
*/
}
