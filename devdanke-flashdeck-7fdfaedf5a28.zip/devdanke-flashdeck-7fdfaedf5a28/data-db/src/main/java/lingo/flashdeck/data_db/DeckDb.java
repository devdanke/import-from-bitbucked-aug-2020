package lingo.flashdeck.data_db;


import com.google.common.annotations.VisibleForTesting;
import lingo.flashdeck.common.data.IDeckEntity;
import lingo.flashdeck.common.util.MyAssert;

import javax.persistence.*;


/**
 * A QuizDeck in the DB just associates a learner and a lesson.
 *
 * It's main purposes are to
 * 1) lookup all decks by learner
 * 2) help lookup/save box item positions before/after a quiz
 * 
 *
    id         INTEGER NOT NULL IDENTITY,
    lesson_id  INTEGER NOT NULL,
    learner_id    INTEGER NOT NULL,
    CONSTRAINT d_to_lrn_fk FOREIGN KEY (learner_id) REFERENCES learner(id)
    uk on lesson_id and learner_id
 */
@Entity
@Table(name = "deck", uniqueConstraints = @UniqueConstraint(columnNames={"lesson_id","learner_id"}))
@NamedQueries
({
    @NamedQuery(
        name="findDecksByLearner",
        query="SELECT dd FROM DeckDb dd WHERE dd._learnerId = :learnerId"
    ),
    @NamedQuery
    (
        name="deleteDeck",
        query="DELETE FROM DeckDb dd WHERE dd._id = :id"
    )


})
public class DeckDb
    implements IDeckEntity
{
    @Id
    @GeneratedValue
    @Column(name = "id")
    private Long _id;

    @Column(name = "lesson_id")
    private Long _lessonId;

    @Column(name = "learner_id")
    private Long _learnerId;


    public DeckDb(){} //for hib/jpa

    /*
    jpa won't use this ctor
     */
    public DeckDb(Long learnerId, Long lessonId)
    {
        MyAssert.notNull("learnerId", learnerId);
        MyAssert.notNull("lessonId", lessonId);

        _learnerId = learnerId;
        _lessonId = lessonId;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // getters & setters
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public Long getId()
    {
        return _id;
    }

    @VisibleForTesting
    public void setId(Long id)
    {
        _id = id;
    }

    public Long getLessonId()
    {
        return _lessonId;
    }

    public Long getLearnerId()
    {
        return _learnerId;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////
    // util methods
    ////////////////////////////////////////////////////////////////////////////////////////////////

    public boolean isSame(IDeckEntity that)
    {
        return (_id.equals(that.getId())) &&
            (_learnerId.equals(that.getLearnerId())) &&
            (_lessonId.equals(that.getLessonId()));
    }

    @Override
    public String toString()
    {
        return "DeckDb{" +
            "_id=" + _id +
            ", _lessonId=" + _lessonId +
            ", _learnerId=" + _learnerId +
            '}';
    }
}
