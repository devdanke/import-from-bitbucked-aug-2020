package lingo.flashdeck.data_db;


import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;
import lingo.flashdeck.common.data.IBoxItemEntity;
import lingo.flashdeck.common.data.IDao;
import lingo.flashdeck.common.data.IDeckEntity;
import lingo.flashdeck.common.util.MyAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**

 */
public class DaoDb
    implements IDao
{
    public static final String PU_NAME = "MyPU";

    private Logger _log = LoggerFactory.getLogger(DaoDb.class);

    @VisibleForTesting
    protected EntityManagerFactory _emf;

    public DaoDb(EntityManagerFactory emf)
    {
        _emf = emf;
    }


    /*
    Used by mvcweb when it uses DeckManagerDb to connect directly.
     */
    public DaoDb(String driver, String connStr, String user, String pass)
    {
        Map<String, Object> jpaCfg = new HashMap<String, Object>();

        jpaCfg.put("javax.persistence.jdbc.driver",   driver);
        jpaCfg.put("javax.persistence.jdbc.url",      connStr);
        jpaCfg.put("javax.persistence.jdbc.user",     user);
        jpaCfg.put("javax.persistence.jdbc.password", pass);

        _emf = Persistence.createEntityManagerFactory(DaoDb.PU_NAME, jpaCfg);
    }


    @SuppressWarnings("unchecked")
    public List<IDeckEntity> findDecksByLearner(Long learnerId)
    {
        EntityManager em = _emf.createEntityManager();
        em.getTransaction().begin();
        Query q = em.createNamedQuery("findDecksByLearner");
        q.setParameter("learnerId", learnerId);
        List<IDeckEntity> deckDtos = q.getResultList();

        em.getTransaction().commit();
        em.close();
        return deckDtos;
    }


    public List<IBoxItemEntity> findBoxItemsForDecks(List<IDeckEntity> deckDtos)
    {
        MyAssert.notNullOrEmpty("deckDtos", deckDtos);

        List<Long> deckIds = Lists.newArrayList();
        for(IDeckEntity deckDto : deckDtos){ deckIds.add(deckDto.getId()); }
        return findBoxItemsForDeckIds(deckIds);
    }

    private List<IBoxItemEntity> findBoxItemsForDeckIds(List<Long> deckIds)
    {
        MyAssert.notNullOrEmpty("deckDto IDs", deckIds);

        EntityManager em = _emf.createEntityManager();
        em.getTransaction().begin();

        List<IBoxItemEntity> boxiItems = Lists.newArrayList();

        for(Long deckDtoId : deckIds)
        {
            boxiItems.addAll( findBoxItemsByDeck(em, deckDtoId) );
        }

        em.getTransaction().commit();
        em.close();
        return boxiItems;
    }


    public void save(IDeckEntity deckDto, List<IBoxItemEntity> boxItemsDtos)
    {
        MyAssert.mustHaveNullIdForAdd(deckDto.getId());

        EntityManager em = _emf.createEntityManager();
        em.getTransaction().begin();

        em.persist(deckDto);

        for(IBoxItemEntity bid: boxItemsDtos)
        {
            bid.setDeckId(deckDto.getId());
            em.persist(bid);
        }
        em.getTransaction().commit();
        em.close();
    }


    /*
    Replace existing box items with these new ones.
     */
    public void saveNewBoxPositions(Long deckId, List<IBoxItemEntity> newBoxItems)
    {
        MyAssert.notNull("deckId", deckId);
        MyAssert.notNullOrEmpty("newBoxItems", newBoxItems);

        try
        {
            EntityManager em = _emf.createEntityManager();
            em.getTransaction().begin();

            //delete old ones
            int delCount = deleteBoxItemsByDeck(em, deckId);
            _log.debug("{} boxItems deleted for deck {}", new Object[]{delCount, deckId});
            

            //save new ones
            for(IBoxItemEntity newBoxItem : newBoxItems)
            {
                em.persist(newBoxItem);
            }

            em.getTransaction().commit();
            em.close();
        }
        catch(Exception e)
        {
            _log.error("save quiz results failed", e);
            throw new RuntimeException(e);
        }
    }


    public void deleteDeck(Long deckId)
    {
        EntityManager em = _emf.createEntityManager();
        em.getTransaction().begin();

        //first delete it's box items
        int delCount = deleteBoxItemsByDeck(em, deckId);
        _log.debug("{} boxItems deleted for deck {}", new Object[]{delCount, deckId});

        //then delete deck
        Query q = em.createNamedQuery("deleteDeck");
        q.setParameter("id", deckId);
        delCount = q.executeUpdate();
        _log.debug("{} deck deleted for id {}", new Object[]{delCount, deckId});

        em.getTransaction().commit();
        em.close();
    }

    public void cleanup()
    {
        if((_emf != null) && _emf.isOpen()) _emf.close();
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // support methods
    ////////////////////////////////////////////////////////////////////////////////////////////////

    protected  void persist(Object obj)
    {
        EntityManager em = _emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(obj);
        em.getTransaction().commit();
        em.close();
    }

    /**
     * Extracted into sep method because used in two places.
     * Assumes txn already started by caller.
     *
     */
    @SuppressWarnings("unchecked")
    private List<BoxItemDb> findBoxItemsByDeck(EntityManager em, Long deckId)
    {
        Query q = em.createNamedQuery("findBoxItemsByDeck");
        q.setParameter("deckId", deckId);
        List<BoxItemDb> boxiItems = q.getResultList();

        return boxiItems;
    }

    /**
     * Extracted into sep method because used in two places.
     * Assumes txn already started by caller.
     *
     * @return count of rows deleted
     */
    @SuppressWarnings("unchecked")
    private int deleteBoxItemsByDeck(EntityManager em, Long deckId)
    {
        Query q = em.createNamedQuery("deleteBoxItemsByDeck");
        q.setParameter("deckId", deckId);
        return q.executeUpdate();
    }


}
