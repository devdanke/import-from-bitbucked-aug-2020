package lingo.flashdeck.data_db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.HashMap;
import java.util.Map;

/**
 */
public class JpaUtil
{
    public enum DbPrep{ RECREATE, VALIDATE}

    public static final String CORE_DB = "flashdeck_core";

    private static final Logger LOG = LoggerFactory.getLogger(JpaUtil.class);

    public static EntityManagerFactory createEmf()
    {
        return createEmf(CORE_DB, DbPrep.RECREATE);
    }

    public static EntityManagerFactory createEmf(String dbName, DbPrep dbPrep)
    {
        LOG.info("in");
        Map<String, Object> jpaCfg = new HashMap<String, Object>();

        switch(dbPrep)
        {
            case RECREATE:
                LOG.info("recreate db: {}", dbName);
                jpaCfg.put("hibernate.hbm2ddl.auto", "create");
                break;
            case VALIDATE:
                LOG.info("only validate db: {}", dbName);
                jpaCfg.put("hibernate.hbm2ddl.auto", "validate");
                break;
            default:
                //defualt nothing
        }


        jpaCfg.put("javax.persistence.jdbc.driver",   "com.mysql.jdbc.Driver");
        jpaCfg.put("javax.persistence.jdbc.url",      "jdbc:mysql://localhost:3306/"+dbName);
        jpaCfg.put("javax.persistence.jdbc.user",     "lingo");
        jpaCfg.put("javax.persistence.jdbc.password", "x");

        EntityManagerFactory emf =
            Persistence.createEntityManagerFactory(DaoDb.PU_NAME, jpaCfg);

        return emf;
    }

}
