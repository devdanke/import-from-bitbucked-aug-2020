package lingo.flashdeck.data_db;

import lingo.flashdeck.common.data.IBoxItemEntity;
import lingo.flashdeck.common.data.IDeckEntity;
import lingo.flashdeck.common.deck.BoxType;
import lingo.flashdeck.data.AbsDaoTest;
import org.joda.time.DateTime;
import org.junit.AfterClass;
import org.junit.BeforeClass;


/**
 * See super class, AbsDaoTest for tests common to all Daos.
 */
public class DaoDbTest
    extends AbsDaoTest
{

    @BeforeClass
    public static void setup()
    {
        _dao = new DaoDb(JpaUtil.createEmf());
    }


    @AfterClass
    public static void cleanup()
    {
        _dao.cleanup();
    }

    protected IBoxItemEntity createBoxItemEntity(long itemId)
    {
        return new BoxItemDb(itemId);
    }

    protected IBoxItemEntity createBoxItemEntity(long deckId, BoxType boxType, long itemId,
        DateTime dateTaken)
    {
        return new BoxItemDb(deckId, boxType, itemId, dateTaken);
    }

    protected IDeckEntity createDeckEntity(long learnerId, long lessonId)
    {
        return new DeckDb(learnerId, lessonId);
    }

}