package lingo.flashdeck.data;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import com.google.common.collect.Lists;
import lingo.flashdeck.common.data.IBoxItemEntity;
import lingo.flashdeck.common.data.IDao;
import lingo.flashdeck.common.data.IDeckEntity;
import lingo.flashdeck.common.deck.BoxType;
import org.joda.time.DateTime;
import org.junit.Test;

import java.util.*;


public abstract class AbsDaoTest
{
    protected static IDao _dao;


    /////////////////////////////////////////////////////////////////////////
    // Tests
    /////////////////////////////////////////////////////////////////////////


    @Test
    public void canSaveAndGetDeckEntity()
    {
        String testName = "canSaveAndGetDeckEntity";

        //create stuff to save
        long baseId = testName.hashCode();
        List<IBoxItemEntity> bies1 = makeBoxItemEntities(baseId++,1);
        IDeckEntity de1 = makeDeckEntity(baseId);

        //assert learner has no decks
        Long learnerId = de1.getLearnerId();
        assertThat("learner has no decks", _dao.findDecksByLearner(learnerId).isEmpty());

        //call method under test
        _dao.save(de1, bies1);

        //post save asserts

        //learner has 1 deck
        List<IDeckEntity> des = _dao.findDecksByLearner(learnerId);
        assertThat("learner has 1 deck", des.size(), is(1));

        IDeckEntity de2 = des.get(0);
        assertThat("retrieved deck id", de1.isSame(de2));

        List<IBoxItemEntity> bies2 = _dao.findBoxItemsForDecks(des);
        assertThat("boxItems size is 1", bies2.size(), is(1));

        assertThat("retrieved BoxItemGae same as orig", bies1.get(0).isSame(bies2.get(0)));
    }


    /*
    add a deck.
    verify it's there.
    delete it.
    verify it's gone.
    */
    @Test
    public void afterDeleteDeckThenItAndItsBoxItemsAreGoneGoneGone()
    {
        String testName = "afterDeleteDeckThenItAndItsBoxItemsAreGoneGoneGone";

        //create stuff to save & save it
        long baseId = testName.hashCode();
        int bieCount = 3;
        List<IBoxItemEntity> bies1 = makeBoxItemEntities(baseId++,bieCount);
        IDeckEntity de1 = makeDeckEntity(baseId);
        long learnerId = de1.getLearnerId();
        _dao.save(de1, bies1);

        //assert deck & boxItems exists
        List<IDeckEntity> des = _dao.findDecksByLearner(learnerId);
        assertThat("learner has 1 deck", des.size(), is(1));
        assertThat("deck has boxItem  count", _dao.findBoxItemsForDecks(des).size(), is(bieCount));

        //call method under test
        _dao.deleteDeck(des.get(0).getId());

        //verify results
        assertThat("learner has no decks", _dao.findDecksByLearner(learnerId).isEmpty());
        assertThat("deck has no boxItems", _dao.findBoxItemsForDecks(des).isEmpty());
    }


    /*
    add deck & boxItems
    verify boxItems
    update boxItems
    verify new boxItems
     */
     @Test
    public void canUpdateBoxItemsPositions()
    {
        String testName = "canUpdateBoxItemsPositions";

        //create stuff to save & save it
        long baseId = testName.hashCode();
        int bieCount = 3;
        List<IBoxItemEntity> bies1 = makeBoxItemEntities(baseId++,bieCount);
        IDeckEntity de1 = makeDeckEntity(baseId++);
        long learnerId = de1.getLearnerId();
        _dao.save(de1, bies1);

        //assert deck & boxItems exists
        List<IDeckEntity> des1 = _dao.findDecksByLearner(learnerId);
        List<IBoxItemEntity> bies2 = _dao.findBoxItemsForDecks(des1);

        for(IBoxItemEntity bie : bies2)
        {
            assertThat("bies2.boxItem pos is 1", bie.getBoxType(), is(BoxType.BOX_1_OF_5));
        }

        //create post quiz boxItems
        List<IBoxItemEntity> bies3 = Lists.newArrayList();
        for(int i=0; i<bieCount; i++)
        {
            bies3.add( createBoxItemEntity( des1.get(0).getId(), BoxType.BOX_3_OF_5, baseId++,
                new DateTime()));
        }

        //call method under test
        _dao.saveNewBoxPositions(de1.getId(), bies3);

        //verify results
        for(IBoxItemEntity bie : _dao.findBoxItemsForDecks(_dao.findDecksByLearner(learnerId)) )
        {
            assertThat("post quiz boxItems pos is 3", bie.getBoxType(), is(BoxType.BOX_3_OF_5));
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////
    // private support methods
    ////////////////////////////////////////////////////////////////////////////////////////////////


    private IDeckEntity makeDeckEntity(long baseId)
    {
        //create stuff to save
        long aLearnerId = baseId++;
        long aLessonId = baseId;

        IDeckEntity de = createDeckEntity(aLearnerId, aLessonId);
        assertThat("deckEntity  has no id", de.getId(), is(nullValue()));
        return de;
    }


    private List<IBoxItemEntity> makeBoxItemEntities(long baseId, int itemCount)
    {
        long anItemId = baseId;
        List<IBoxItemEntity> list = Lists.newArrayList();

        for(int i=0; i<itemCount; i++)
        {
            IBoxItemEntity bie = createBoxItemEntity(anItemId++);
            assertThat("boxItemEntity has no id", bie.getId(), is(nullValue()));
            list.add( bie );
        }

        return list;
    }

    protected abstract IBoxItemEntity createBoxItemEntity(long itemId);
    protected abstract IBoxItemEntity createBoxItemEntity(long deckId, BoxType boxType, long itemId,
        DateTime dateTaken);
    protected abstract IDeckEntity createDeckEntity(long learnerId, long lessonId);

}
