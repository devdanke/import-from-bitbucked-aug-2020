package com.menlospark.lingo.subthaitle;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.menlospark.lingo.subthaitle.dict.Dict;
import com.menlospark.lingo.subthaitle.dict.TempAddNewDefsToDict;
import com.menlospark.lingo.subthaitle.dict.Word;
import com.menlospark.lingo.subthaitle.super_cue.SplitForce;
import com.menlospark.lingo.subthaitle.super_cue.SplitUndo;
import com.menlospark.lingo.subthaitle.super_cue.SuperCueMaker;
import com.menlospark.lingo.subthaitle.utils.Const;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.vtt.VttOutputter;

import static com.menlospark.lingo.subthaitle.MyApp.makeSuperCueVtt;
import static org.junit.Assert.*;

import lombok.extern.slf4j.Slf4j;
import org.junit.Ignore;
import org.junit.Test;

import java.io.File;
import java.time.LocalTime;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Ignore
@Slf4j
public class MyAppTest {

    // Use script!
    //@Test
    public void addNewDefs() {

        String newDefs = "/Users/me/_dev/film-study/content-meta-data/my-phonetic-translit-data.txt";
        String curDefs = "/Users/me/_dev/film-study/content-meta-data/_dict/my.dict.json";

        TempAddNewDefsToDict.process(newDefs, curDefs);
    }

    @Test
    public void testSuperCueMaker() {

        /*  a & b are always split
            x & y will be joined
            splitme will be split to split me.
        */
        Cue inThaiWordCue = new Cue();
        inThaiWordCue.setItemNumber(88);
        inThaiWordCue.setTimeRange(LocalTime.MIN, LocalTime.MAX);
        inThaiWordCue.addLine("a b x y splitme");
        inThaiWordCue.addLine("2nd line");
        inThaiWordCue.addLine("  มา   เด   ลีนส์  ");  // mā   de  līns̄̒

        Cue inEnMachTransCue = new Cue();
        inEnMachTransCue.addLine("my 1st ML sentence.");
        inEnMachTransCue.addLine("my 2nd ML sentence.");
        inEnMachTransCue.addLine("my 3rd ML sentence.");

        // int id, String th, String en, String phonetic
        Word w1 = new Word(1, "a",     "enA",     "fonA");
        Word w2 = new Word(2, "b",     "enB",     "fonB");
        Word w3 = new Word(3, "x-y",   "enXy",    "fonXy");
        Word w4 = new Word(4, "split", "enSplit", "fonSplit");
        Word w5 = new Word(5, "me",    "enMe",    "fonMe");
        Dict dict = new Dict(Lists.newArrayList(w1, w2, w3, w4, w5));

        //   {"wordsToJoin":["มา","เด", "ลีนส์" ], "note":"mā-de-līns̄̒ madeleines - transporter.quiet.5" },
        List<SplitUndo> splitUndos = Lists.newArrayList(new SplitUndo(Lists.newArrayList("x","y")),
            new SplitUndo(Lists.newArrayList("มา","เด", "ลีนส์")));
        List<SplitForce> splitForces = Lists.newArrayList(new SplitForce(Lists.newArrayList("split","me")));

        List<Cue> outCues = SuperCueMaker.makeSuperCues(
            Lists.newArrayList(inThaiWordCue),
            Lists.newArrayList(inEnMachTransCue),
            dict,
            splitUndos,
            splitForces);

        assertEquals(1, outCues.size());

        VttOutputter.makeVttFile(new File("./target/newsupercue.vtt"), outCues);
    }

    @Test
    public void testMakeSuperCue()
    {
        makeSuperCueVtt("transporter");
    }

    @Test
    public void testLoadStoreSplitForceUndo() throws  Exception {

        String splitUndosFilePath = "./target/splitUndos.json";
        List<SplitUndo> splitUndos = Lists.newArrayList(new SplitUndo(Lists.newArrayList("a","b")));
        SplitUndo.save(splitUndosFilePath, splitUndos);

        List<SplitUndo> splitUndos2 = SplitUndo.load(splitUndosFilePath);


        String splitForcesFilePath = "./target/splitForces.json";
        List<SplitForce> splitForces = Lists.newArrayList(new SplitForce( Lists.newArrayList("x","yz")));
        SplitForce.save(splitForcesFilePath, splitForces);

        List<SplitForce> splitForces2 = SplitForce.load(splitForcesFilePath);
    }


    @Test
    public void fixGt() {

        String dictDir = "/Users/me/_dev/film-study/content-meta-data/_dict";
        Dict dict = Dict.load(dictDir + "/gootran-latest.dict.json");

        AtomicInteger i= new AtomicInteger(0);
        final int maxLen = 10;
        List<Word> nextData = dict.getData().values().stream()
            .filter( w -> !yesRemoveIt(w.getEn(),maxLen) )
            .map( w -> cleanEn(w))
            .sorted((w1, w2) -> w1.getEn().compareTo(w2.getEn()))
            .collect(Collectors.toList());

        Dict.save(dictDir + "/gootran-maybe-next.dict.json", nextData);
    }

    Word cleanEn(Word w) {

        String result = w.getEn().replace(".", "");
        result = result.toLowerCase();
        result = result.replace(",","");
        if(result.endsWith("tions")) {
            result.replace("tions", "tion");
        }

        w.setEn(result);
        return w;
    }

    boolean yesRemoveIt(String en, int maxLen) {

        if (en.length() >= maxLen) {
            return true;
        }

        if(en.contains(Const.SPACE)) {
            return true;
        }

        if(en.contains("'")) {
            return true;
        }

        return false;
    }


}
