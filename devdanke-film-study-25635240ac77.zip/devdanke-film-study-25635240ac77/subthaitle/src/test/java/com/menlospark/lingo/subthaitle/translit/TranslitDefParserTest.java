package com.menlospark.lingo.subthaitle.translit;

import com.menlospark.lingo.subthaitle.utils.MyPropFileParser;
import org.junit.Test;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import static junit.framework.TestCase.assertTrue;

/**
 * Created by me on 2/26/17.
 */
public class TranslitDefParserTest {

    private TranslitDefParser parser = new TranslitDefParser();

    @Test
    public void testParseToConsonants() {


        Map<String,Collection<String>> stuff = MyPropFileParser.parseSections("src/main/resources/t2e.translit.txt");

        List<Consonant> consonants = parser.parseConsonants(stuff.get("consonants"), stuff.get("final consonants"));

        assertTrue(true);
    }
}
