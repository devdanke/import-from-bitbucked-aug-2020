package com.menlospark.lingo.subthaitle.utils;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.common.io.Files;
import com.menlospark.lingo.subthaitle.translit.Consonant;
import com.menlospark.lingo.subthaitle.translit.ConsonantChar;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;


/*
Parse files with layout:
[foo]
ddf
fddfd
fdfdf

[bar]
ytyty
344rrt
trtrt

Result is Map of
    foo -> [ddf, fddfd, fdfdf]
    bar -> [ytyty, 344rrt, trtrt]


 */
@Slf4j
public class MyPropFileParser {

    public static Map<String, Collection<String>> parseSections(String filePath) {

        Multimap<String,String> result = ArrayListMultimap.create();

        try {
            List<String> lines = Files.readLines(new File(filePath), Charset.defaultCharset());

            String curSectionName = null;
            for(String line : lines ){

                line = line.trim();
                if(!line.isEmpty() && !line.startsWith("#")) {

                    // Line isn't empty or comment. Must be data or section header.
                    if(line.startsWith("[") && line.endsWith("]")) {

                        curSectionName = line.substring(1, line.length()-1).trim().toLowerCase();
                        if(curSectionName.isEmpty()) {
                            throw new IllegalArgumentException(
                                    "A file line like [ *** ] was empty. line:" + line);
                        }
                        log.debug("New section name: {}", curSectionName);
                    }
                    else {
                        if(curSectionName == null) {
                            throw new RuntimeException("Section header was null for line: " + line);
                        }
                        result.put(curSectionName, line);
                    }
                }
            }
        }
        catch(Exception e) {
            throw new RuntimeException(e);
        }

        return result.asMap();
    }


    /*
    [Foo] => 'foo'
     */
    static String extractSectionHeaderName(String header) {

        if(header.trim().startsWith("[") && header.endsWith("]")) {
            return header.substring(1, header.length()-1).trim().toLowerCase();
        }
        else {
            throw new RuntimeException("Not a section header: " + header);
        }
    }


}
