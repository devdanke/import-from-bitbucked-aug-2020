package com.menlospark.lingo.subthaitle.utils;

public class Const {
    public static final String SPACE = " ";
}
