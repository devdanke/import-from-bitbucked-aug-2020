package com.menlospark.lingo.subthaitle.super_cue;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
class SuperTable {

    private List<SuperRow> rows = Lists.newArrayList();

    public SuperTable add(SuperRow superRow) {
        rows.add(superRow);
        return this;
    }

    /*
    Includes count of spaces that will be added between words.
    This is needed for meaningful compare to sentence length.
     */
    public int calcMaxRowSize() {

        int charCountOfRowAsIfItHeldLongestWordInEachCol = 0;
        for(int n : calcEachWordColumnsMaxSize()){
            charCountOfRowAsIfItHeldLongestWordInEachCol += n;
        }
        int wordCount = rows.get(0).getCells().size();
        int spacesBetweenWordsCount = wordCount - 1;

        charCountOfRowAsIfItHeldLongestWordInEachCol += spacesBetweenWordsCount;
        int charCountOfSentenceRow = rows.get(rows.size()-1).getTotalColCountForCells();
        return Math.max(charCountOfRowAsIfItHeldLongestWordInEachCol, charCountOfSentenceRow );
    }

    public List<Integer> calcEachWordColumnsMaxSize() {

        List<Integer> maxWidthOfEachCol = Lists.newArrayList();

        for(int i=0; i< rows.get(1).getCells().size(); i++) {
            maxWidthOfEachCol.add(getCharCountOfWidestWordCellInColumn(i));
        }

        return maxWidthOfEachCol;
    }


    public int getCharCountOfWidestWordCellInColumn(int colIndex) {
        int maxWidth = 0;

        for(SuperRow row : rows) {
            if(row.isWordRow()) {
                maxWidth = Math.max(maxWidth, row.getCells().get(colIndex).getCharCount());
            }
        }

        return maxWidth;
    }

}

