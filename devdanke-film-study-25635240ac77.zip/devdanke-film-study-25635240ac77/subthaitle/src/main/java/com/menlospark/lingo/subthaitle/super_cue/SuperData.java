package com.menlospark.lingo.subthaitle.super_cue;

import com.google.common.collect.Lists;
import com.menlospark.lingo.subthaitle.MyIcu;
import com.menlospark.lingo.subthaitle.TextCleaner;
import com.menlospark.lingo.subthaitle.dict.Dict;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.menlospark.lingo.subthaitle.utils.Const.SPACE;

/**
 * Given a thai sentence and an english sentence.
 * Make it ready to be rendered.
 */
@Data
@AllArgsConstructor
public class SuperData {

    public static final String NOT_FOUND_TOKEN = "?";


    public static List<List<String>> makeDataWordLines(String origThaiLine, Dict dict,
        List<SplitUndo> splitUndos, List<SplitForce> splitForces) {

        List<String> thaiWords = makeThaiLineData(origThaiLine, splitUndos, splitForces);

        List<List<String>> dataWordLines = Lists.newArrayList();
        dataWordLines.add(thaiWords);
        dataWordLines.add(makePhoneticLineData(thaiWords, dict));
        dataWordLines.add(makeDefinitionLineData(thaiWords, dict));

        return dataWordLines;
    }

    /*
    Correctly means,
    1) split with ICU
    2) Join things (probably with hyphen) ICU split that I don't like. eg. kit-wa or ma-jak
    3) Split things that ICU didn't split but that I want to split.
     */
     static List<String> makeThaiLineData(String unsplitThaiLine, List<SplitUndo> splitUndos,
        List<SplitForce> splitForces) {

        List<String> icuSepWords = MyIcu.separateThaiWords(unsplitThaiLine);

        List<String> maybeWithCleanerWords = TextCleaner.cleanup(icuSepWords);
        // TODO: use as list of words instead of splitting repeatedly.
        //List<String> thWords = Arrays.asList(maybeWithCleanerWords.split(SPACE));
        List<String> maybeWithRejoinedWords = unSplit(maybeWithCleanerWords, splitUndos);
        List<String> maybeWithForcedSplitWords = forceSplit(maybeWithRejoinedWords, splitForces);

        return maybeWithForcedSplitWords;
    }


    /*
    Look up thai words (even the compound ones) in my dict, t2e dict, movie dict.
     */
     static List<String> makePhoneticLineData(List<String> thWords, Dict dict) {
        return thWords.stream().map(word -> findBestPhonetic(word,dict)).collect(Collectors.toList());
    }


    public static List<String> makeDefinitionLineData(List<String> thWords, Dict dict) {
        return thWords.stream().map(word -> findBestDefinition(word,dict)).collect(Collectors.toList());
    }

    /*
    dicts is organized as most important prefered dict is on top.
    Iterate throught dicts.  Return as soon as word is found.
    If not found, return emtpy.
     */
    static String findBestPhonetic(String input, Dict dict) {

        String phonetic = dict.getPhoneticByTh(input);
        if(phonetic != null) {
            return phonetic;
        }
        else {
            return NOT_FOUND_TOKEN;
        }
    }


    static String findBestDefinition(String input, Dict dict) {

        String en = dict.getEnByTh(input);
        if(en != null) {
            return en;
        }
        else {
            return NOT_FOUND_TOKEN;
        }
    }


    // split words that I want split but that icu didn't split.
    static List<String>  forceSplit(List<String> thWords, List<SplitForce> splitForces) {

        List<String> resultWords = Lists.newArrayList(thWords);

        for(SplitForce splitForce : splitForces) {
            Pair<Boolean,Integer> findResult = splitForce.findMatch(resultWords);
            if(findResult.getLeft()==true) {
                resultWords = splitForce.split(findResult.getRight(), resultWords);
            }
        }

        return resultWords;
    }

    // for things like ma-jak and kit-wa
    static List<String> unSplit(List<String> thWords, List<SplitUndo> splitUndos) {

        List<String> resultWords = Lists.newArrayList(thWords);

        for(SplitUndo splitUndo : splitUndos) {

            Pair<Boolean,Integer> findResult = splitUndo.findMatch(resultWords);
            if(findResult.getLeft()==true) {
                resultWords = splitUndo.unSplit(findResult.getRight(), resultWords);
            }
        }

        return resultWords;
    }




}
