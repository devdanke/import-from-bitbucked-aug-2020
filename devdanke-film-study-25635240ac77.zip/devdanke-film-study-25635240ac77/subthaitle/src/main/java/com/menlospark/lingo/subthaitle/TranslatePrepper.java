package com.menlospark.lingo.subthaitle;

import com.google.common.base.Joiner;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.parse.SubsParser;
import com.menlospark.lingo.subtility.vtt.VttOutputter;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class TranslatePrepper {

    /*
    Input is flattened and word separated lines.

    Prepare to write cues to file with only item number and lines, for manual google translate.
     */
    public String process(List<Cue> cues) {

        StringBuilder sb = new StringBuilder();
        cues.forEach( cue -> {

            sb.append(cue.getItemNumber()).append("\n");
            cue.getLines().forEach(line -> { sb.append(line).append("\n"); });
            sb.append("\n");
        });

        return sb.toString();
    }

}
