package com.menlospark.lingo.subthaitle.translit;

import java.util.HashMap;
import java.util.Map;

/**
 * Places to get characters and learn how to convert phonetic to thai transliterations
 * https://en.wikipedia.org/wiki/Pronunciation_respelling_for_English
 */
public class MyWordlyTransliterator {

    private static final Map<String,String> m = new HashMap<>();

    public MyWordlyTransliterator() {

        m.put("bxk","bawk");

        m.put("ca","juh");  // or maybe juh? like 'just'
        m.put("cā","juh");  //are both these right?
        m.put("chxb","chawp");

        m.put("dein","dehrn");
        m.put("dī","dee");

        m.put("h̄ı̂","hai");

        m.put("kẁā","gwa");
        m.put("khn","khōn");
        m.put("kảlạng","gahmlahng");
        m.put("kin","gin");
        m.put("kāfæ","cafe");
        m.put("kạn","gahn");
        m.put("khır","krai");

        m.put("p̄hm","pōm");
        m.put("pị","bai");
        m.put("phūd","phūt");
        m.put("pạỵh̄ā","bahnha");

        m.put("mậy","mai");

        m.put("nī̂","nee");
        m.put("n̂xy","noi");
        m.put("nxk","nawk");
        m.put("n̂ả","nahm");

        m.put("rt̄h","rōt");
        m.put("reā","rao");

        m.put("s̄i","see");  // most likey an icu mistake.  i don't hear them say it.  and it has no meaning.

        m.put("thả","tahm");
        m.put("tāy","dai");

        m.put("xyū̀","u");
        m.put("xyāk","yahk");
        m.put("xarị","arai");

        m.put("xx","yy");
    }

    public String ipaToSomeKindOfThai(String ipa) {
        String thTranslit = m.get(ipa);

        return (thTranslit != null) ? thTranslit : "-";
    }
}
