package com.menlospark.lingo.subthaitle.translit;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ConsonantChar {

    private Character thChar;
    private String symbol;
    private String exampleSound;
}
