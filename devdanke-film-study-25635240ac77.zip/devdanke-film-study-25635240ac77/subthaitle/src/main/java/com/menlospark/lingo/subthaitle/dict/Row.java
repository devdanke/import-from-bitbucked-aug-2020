package com.menlospark.lingo.subthaitle.dict;


import lombok.Data;

@Data
class Row {

    Integer id;
    String text;

    Row(String line) {
        String[] parts = line.split(" \\| ");

       // System.out.print("line="+line);
       // System.out.println(", p0="+parts[0]+", p1="+parts[1]);

        id = Integer.parseInt(parts[0]);
        text = parts[1].trim();
    }

}
