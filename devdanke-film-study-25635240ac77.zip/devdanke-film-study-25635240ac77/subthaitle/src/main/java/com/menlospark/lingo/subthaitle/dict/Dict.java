package com.menlospark.lingo.subthaitle.dict;


import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.common.collect.Lists;
import lombok.Data;

import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Data
public class Dict {

    // The only reason I have getter for this is to do merges
    // with other dicts.
    private final Map<String,Word> data;

    public Dict(Map<String,Word> data) {
        this.data = data;
    }

    public Dict(List<Word> data) {
        this.data = data.stream().collect(Collectors.toMap(Word::getTh,
            Function.identity()));;
    }

    public String getEnByTh(String thai) {

        Word w = data.get(thai);
        return (w!=null) ? w.getEn() : null;
    }

    public String getPhoneticByTh(String thai) {

        Word w = data.get(thai);
        return (w!=null) ? w.getPhonetic() : null;
    }

    /*
    Merge dicts so that first in list overrides later ones.
     */
    public static Dict merge(List<Dict> dicts) {

        Map<String,Word> result = new HashMap<>();

        for(Dict dict : Lists.reverse(dicts)) {
            result.putAll(dict.getData());
        }

        return new Dict(result);
    }


    private static final ObjectMapper JOM = new ObjectMapper();
    static {
        JOM.enable(JsonParser.Feature.ALLOW_COMMENTS);
        JOM.enable(SerializationFeature.INDENT_OUTPUT);
    }

    private static final TypeReference<List<Word>> TYPE_REF = new TypeReference<List<Word>>(){};

    public static Dict load(String filePath)  {

        try {
            List<Word> words = JOM.readValue(new File(filePath), TYPE_REF);

            Map<String,Word> wordsByThai = new HashMap<>();
            words.forEach(word -> { wordsByThai.put(word.getTh(), word); });

            return new Dict(wordsByThai);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    public static void   save(String filePath, List<Word> words) {
        try {
            JOM.writeValue(new File(filePath), words);
        }
        catch(Exception e) {
            throw new RuntimeException(e);
        }
    }


}
