package com.menlospark.lingo.subthaitle;

import com.google.common.collect.Lists;
import com.menlospark.lingo.subthaitle.dict.Dict;
import com.menlospark.lingo.subthaitle.dict.DictBuilder;
import com.menlospark.lingo.subthaitle.super_cue.SplitForce;
import com.menlospark.lingo.subthaitle.super_cue.SplitUndo;
import com.menlospark.lingo.subthaitle.super_cue.SuperCueMaker;
import com.menlospark.lingo.subthaitle.translit.MyWordlyTransliterator;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.parse.SubsParser;
import com.menlospark.lingo.subtility.vtt.VttOutputter;
import com.menlospark.lingo.subtility.vtt.VttParser;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

import static java.lang.String.format;

@Slf4j
public class MyApp {

    public static void makeSuperCueVtt(String movieName) {

        String dictDir = "/Users/me/_dev/film-study/content-meta-data/_dict";
        List<String> dictFilePaths = Lists.newArrayList(
            dictDir + "/my.dict.json",
            dictDir + "/gootran-latest.dict.json"
        );

        String splitUndosFilePath = dictDir + "/splitUndos.json";
        String splitForcesFilePath = dictDir + "/splitForces.json";

        String cmsContentRoot = "/Users/me/_content/film-study";

        makeSuperCueVtt(movieName, dictFilePaths, splitUndosFilePath, splitForcesFilePath, cmsContentRoot);
    }


    public static void makeSuperCueVtt(String movieName, List<String> dictFilePaths, String splitUndosFilePath,
        String splitForcesFilePath, String cmsContentRoot ) {

        String mtEnVttFilePath =   format("%s/%s/%s.mt.vtt", cmsContentRoot, movieName, movieName);
        String thVttFilePath =     format("%s/%s/%s.th.vtt", cmsContentRoot, movieName, movieName);
        String outputVttFilePath = format("%s/%s/%s.sc.vtt", cmsContentRoot, movieName, movieName);

        try {

            List<Cue> mtEnCues = SubsParser.parse(new File(mtEnVttFilePath));
            List<Cue> thCues = SubsParser.parse(new File(thVttFilePath));

            List<Dict> dicts = dictFilePaths.stream().map(fp -> Dict.load(fp)).collect(Collectors.toList());
            Dict mergedDict = Dict.merge(dicts);

            List<SplitUndo> splitUndos = SplitUndo.load(splitUndosFilePath);
            List<SplitForce> splitForces = SplitForce.load(splitForcesFilePath);

            List<Cue> outCues = SuperCueMaker.makeSuperCues(
                thCues,
                mtEnCues,
                mergedDict,
                splitUndos,
                splitForces);

            VttOutputter.makeVttFile(new File(outputVttFilePath), outCues);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
