package com.menlospark.lingo.subthaitle.utils;

import lombok.extern.slf4j.Slf4j;

import java.text.BreakIterator;

import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.repeat;

/**
 * Using the default charset etc on my USA computer, Java does not correctly count the length of
 * Thai or IPA chars that have associated vowel(s) or symbol.
 *
 * Stackoverflow has an article on counting graphenes.  That helped a lot.
 * Then I used that length calc in all Apache StringUtils
 * needed to center a column of th,phonetic,en words.
 *
 *     https://stackoverflow.com/questions/7704426/java-length-of-string-when-using-unicode-overline-to-display-square-roots

 */
@Slf4j
public class ThaiStringUtils {

    public enum  AlignType { L, R, C}

    public static String myCenter(String str, int size, String padStr) {

        if(str != null && size > 0) {
            if(isEmpty(padStr)) {
                padStr = " ";
            }

            int strLen = calcGraphemeCount(str); // CHANGED
            int pads = size - strLen;
            if(pads <= 0) {
                return str;
            } else {
                str = myLeftPad(str, strLen + pads / 2, padStr);
                str = myRightPad(str, size, padStr);
                return str;
            }
        } else {
            return str;
        }
    }

    public static String myLeftPad(String str, int size, String padStr) {
        if(str == null) {
            return null;
        } else {
            if(isEmpty(padStr)) {
                padStr = " ";
            }

            int padLen = padStr.length();
            //int strLen = str.length();
            int strLen = calcGraphemeCount(str);// CHANGED
            int pads = size - strLen;
            if(pads <= 0) {
                return str;
            } else if(padLen == 1 && pads <= 8192) {
                return myLeftPad(str, size, padStr.charAt(0));// CHANGED
            } else if(pads == padLen) {
                return padStr.concat(str);
            } else if(pads < padLen) {
                return padStr.substring(0, pads).concat(str);
            } else {
                char[] padding = new char[pads];
                char[] padChars = padStr.toCharArray();

                for(int i = 0; i < pads; ++i) {
                    padding[i] = padChars[i % padLen];
                }

                return (new String(padding)).concat(str);
            }
        }
    }

    public static String myPad(AlignType alignType, String str, int size) {
        switch (alignType) {
            case L:
                return myRightPad(str, size, ' ');
            case R:
                return myLeftPad(str, size, ' ');
            case C:
                return myCenter(str, size, " ");
        }
        throw new RuntimeException("Unknown align type: " + alignType);
    }

    public static String myLeftPad(String str, int size, char padChar) {
        if(str == null) {
            return null;
        } else {
            //int pads = size - str.length();
            int pads = size - calcGraphemeCount(str); // CHANGED
//            return pads <= 0 ? str : (pads > 8192 ? leftPad(str, size, String.valueOf(padChar)) : repeat(padChar, pads).concat(str));
            return pads <= 0 ? str : (pads > 8192 ? myLeftPad(str, size, String.valueOf(padChar)) : repeat(padChar, pads).concat(str));// CHANGED
        }
    }

    public static String myRightPad(String str, int size, String padStr) {
        if(str == null) {
            return null;
        } else {
            if(isEmpty(padStr)) {
                padStr = " ";
            }

            int padLen = padStr.length();
            //int strLen = str.length();
            int strLen = calcGraphemeCount(str); // CHANGED
            int pads = size - strLen;
            if(pads <= 0) {
                return str;
            } else if(padLen == 1 && pads <= 8192) {
                return myRightPad(str, size, padStr.charAt(0)); // CHANGED
            } else if(pads == padLen) {
                return str.concat(padStr);
            } else if(pads < padLen) {
                return str.concat(padStr.substring(0, pads));
            } else {
                char[] padding = new char[pads];
                char[] padChars = padStr.toCharArray();

                for(int i = 0; i < pads; ++i) {
                    padding[i] = padChars[i % padLen];
                }

                return str.concat(new String(padding));
            }
        }
    }

    public static String myRightPad(String str, int size, char padChar) {
        if(str == null) {
            return null;
        } else {
            //int pads = size - str.length();
            int pads = size - calcGraphemeCount(str);// CHANGED
            //return pads <= 0?str:(pads > 8192 ? rightPad(str, size, String.valueOf(padChar)):str.concat(repeat(padChar, pads)));
            return pads <= 0 ? str : (pads > 8192 ? myRightPad(str, size, String.valueOf(padChar)):str.concat(repeat(padChar, pads)));// CHANGED
        }
    }

    public static int myLength(String s) {
        return calcGraphemeCount(s);
        //return s.codePointCount(0, s.length());
        //return s.length();
    }

    static int xcountCharsTh(String s) {
        log.debug("str: {}, len: {}, gc: {}, cpc: {}", s, s.length(), calcGraphemeCount(s), s.codePointCount(0, s.length()));
        //return calcGraphemeCount(s);
        return s.length();//s.codePointCount(0, s.length());
    }
    /*
    https://stackoverflow.com/questions/7704426/java-length-of-string-when-using-unicode-overline-to-display-square-roots
     */
    public static int calcGraphemeCount(String text) {

        int graphemeCount = 0;
        BreakIterator graphemeCounter = BreakIterator.getCharacterInstance();
        graphemeCounter.setText(text);
        while (graphemeCounter.next() != BreakIterator.DONE)
            graphemeCount++;
        return graphemeCount;
    }
}
