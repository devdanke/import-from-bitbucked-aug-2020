package com.menlospark.lingo.subthaitle.super_cue;

import com.menlospark.lingo.subthaitle.utils.ThaiStringUtils;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
class SuperCell {

    private String text;
    private int colCount;
    private ThaiStringUtils.AlignType align;

    public SuperCell(String text) {
        this.text = text;
        colCount = 1;
        align = ThaiStringUtils.AlignType.C;
    }

    public String getPaddedAlignedText(int width) {
        return ThaiStringUtils.myPad(align, text, width);
    }

    public int getCharCount() {
        return ThaiStringUtils.calcGraphemeCount(text);
    }
}

