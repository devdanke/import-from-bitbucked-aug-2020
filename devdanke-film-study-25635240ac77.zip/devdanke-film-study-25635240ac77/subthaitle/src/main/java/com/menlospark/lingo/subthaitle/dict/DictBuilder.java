package com.menlospark.lingo.subthaitle.dict;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

public class DictBuilder {

    static final ObjectMapper JsonMapper = new ObjectMapper();

    public void foo() throws Exception {

        //System.out.println( "GUID: " + new ObjectMapper().writeValueAsString(UUID.randomUUID()));
        parsemble();
    }

        /*
    remove line 728 from uberCon=0214.indexed.txt because it was empty.  it had # and pipe, but no thai word.

    public void separateAndFlattenSubtitleFiles() throws Exception {

        String baseDir = "/Users/me/_content/film-study";
        List<String> inputs = Lists.newArrayList();
        //inputs.add(baseDir + "./src/test/resources/transporter-1.th.vtt");
        inputs.add(baseDir + "/transporter-1/transporter-1.th.vtt");
        inputs.add(baseDir + "/american-sniper/american-sniper.th.vtt");
        inputs.add(baseDir + "/age-of-adaline/age-of-adaline.th.vtt");

        MyApp myApp = new MyApp();
        Map<String,Integer> uberCon = new HashMap<>();
        SortedSet muviWordsIntersect = new TreeSet();

        inputs.forEach(input -> {
            Map<String,Integer> muviConcord = myApp.process(input);
            uberCon.putAll(muviConcord);
            if(muviWordsIntersect.isEmpty()) {
                muviWordsIntersect.addAll(muviConcord.keySet());
            }
            else {
                muviWordsIntersect.retainAll(muviConcord.keySet());
            }
        });

        Map<String,Integer> uberConSorted = Concordinator.sortByValueDesc(uberCon);

        String baseFilePath = "./target/uberCon-" + MMDD.format(LocalDate.now());
        Concordinator.writeToFile(uberConSorted, baseFilePath);
        Concordinator.writeToIndexedFile(uberConSorted, baseFilePath);
        Concordinator.writeToFile(muviWordsIntersect, baseFilePath+".intersect");
    }
    */


    void parsemble() throws Exception {

        String baseDir = "analysis";
        List<Row> thRows = readIntoRows(baseDir + "/uberCon-0214.indexed.txt");
        List<Row>  enRows = readIntoRows(baseDir + "/uberCon-0214.gtEn.txt");
        List<Row>  ipaRows = readIntoRows(baseDir + "/uberCon-0214.phonetic.txt");

        Map<Integer,Word> combined = new HashMap<>();

        if((thRows.size() != enRows.size()) ) {
            throw new RuntimeException("idx rows != en rows");
        }

        if((thRows.size() != ipaRows.size()) ) {
            throw new RuntimeException("idx rows != phonetic rows");
        }


        List<Word> words = Lists.newArrayList();
        for(int i=0; i< thRows.size(); i++) {

            Word w = new Word(i+1, thRows.get(i).getText(), enRows.get(i).getText(),
                    ipaRows.get(i).getText());
            words.add(w);
        }

        //System.out.println("words: " + words.toString());

        //System.out.println(new ObjectMapper().writeValueAsString(words));

        JsonMapper.writeValue(new File(baseDir + "/uberCon-0214.words.json"), words);
    }


    List<Row> readIntoRows(String filePath) throws IOException {

        List<String> idxLines = IOUtils.readLines(new FileInputStream(filePath));

        idxLines = removeBlankLines(idxLines);
        assertNoDupeLines(idxLines);

        List<Row> rows = Lists.newArrayList();
        for(int i=0; i<idxLines.size(); i++) {

            Row row = new Row(idxLines.get(i));

            int ii = i+1;
            if(ii != row.id) {
                throw new RuntimeException("for line row i and id not same: i=" + i + ", id="+row.getId());
            }
            rows.add(row);
        }

        return rows;
    }


    List<String> removeBlankLines(List<String> lines) {
        List<String> result = Lists.newArrayList();

        lines.forEach( line -> {
            if(line.trim().length()!=0) {
                result.add(line.trim());
            }
        });

        return result;
    }

    void assertNoDupeLines(List<String> lines) {
        Set<String> set = new HashSet<>();

        lines.forEach( line -> {

            if(set.contains(line)) {
                throw new IllegalStateException("duplicate line: " + line);
            }
            else {
                set.add(line);
            }
        });
    }


}
