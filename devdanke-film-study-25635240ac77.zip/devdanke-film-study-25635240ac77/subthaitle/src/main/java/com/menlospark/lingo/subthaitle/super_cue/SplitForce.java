package com.menlospark.lingo.subthaitle.super_cue;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.tuple.Pair;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;

/**
 * ICU doesn't split all the words I want it to.
 */
@Data
@NoArgsConstructor
public class SplitForce
{
    public static final String NO_SPACE = "";
    @JsonIgnore
    private String wordToSplit;

    private List<String> replacementParts = Lists.newArrayList();
    private String note;

    /*
    Almost obviously, wordToSplit can be derived from joining replacementParts.
     */
    public SplitForce(List<String> replacementParts) {
        setReplacementParts(replacementParts);
    }

    public void setReplacementParts(List<String> replacementParts) {

        if(CollectionUtils.isEmpty(replacementParts)) {
            throw new IllegalArgumentException("replacement parts can't be empty.");
        }

        this.replacementParts.addAll(replacementParts.stream().map(String::trim).collect(Collectors.toList()));
        this.wordToSplit = Joiner.on("").join(replacementParts);
    }

    public Pair<Boolean,Integer> findMatch( List<String> thWords) {

        int pos = thWords.indexOf(wordToSplit);
        return (pos > -1) ? Pair.of(true, pos) : Pair.of(false, null);
    }

    public List<String> split(int replacePos, List<String> thWords) {

        List<String> result = Lists.newArrayList();

        for(int i=0; i<thWords.size(); i++) {
            if(i == replacePos) {
                result.addAll(replacementParts);
            }
            else {
                result.add(thWords.get(i));
            }
        }

        return result;
    }

    private static final ObjectMapper JOM = new ObjectMapper();
    static {
        JOM.enable(JsonParser.Feature.ALLOW_COMMENTS);
        JOM.enable(SerializationFeature.INDENT_OUTPUT);
    }

    private static final TypeReference<List<SplitForce>> TYPE_REF = new TypeReference<List<SplitForce>>(){};

    public static List<SplitForce> load(String filePath)  {

        try {
            return JOM.readValue(new File(filePath),TYPE_REF );
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void save(String filePath, List<SplitForce> splitForce) {
        try {
            JOM.writeValue(new File(filePath), splitForce);
        }
        catch(Exception e) {
            throw new RuntimeException(e);
        }
    }
}
