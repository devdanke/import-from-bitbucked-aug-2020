package com.menlospark.lingo.subthaitle;

import com.google.common.io.Files;
import com.menlospark.lingo.subtility.model.Cue;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static com.menlospark.lingo.subthaitle.utils.MyStrUtils.isNumberOrPunc;

@Slf4j
public class Concordinator {

    static final int WORD_SEGMENTED_LINE_IDX = 1;
    static final String SPACE = " ";
    static final String FLAT_LINE_SEP = " | ";

    public Map<String,Integer> process(List<Cue> cues) {

        Map<String,Integer> concordance = new HashMap<>();

        cues.forEach(cue -> {
            Arrays.stream(cue.getLines().get(WORD_SEGMENTED_LINE_IDX).split(SPACE)).forEach(word -> {
                addTo(word,concordance);});
        });

        removeNonWords(concordance);
        return sortByValueDesc(concordance);
    }

    public static void writeToFile(Map<String,Integer> concordance, String filePath) throws IOException {

        StringBuilder sb = new StringBuilder();
        concordance.forEach((word,count) -> { sb.append(word).append(" : ").append(count).append("\n");  });

        Files.write(sb.toString(), new File(filePath+".concord.txt"), Charset.defaultCharset());
    }

    public static void writeToIndexedFile(Map<String,Integer> concordance, String filePath) throws IOException {
        StringBuilder sb = new StringBuilder();

        AtomicInteger i = new AtomicInteger(0);
        concordance.forEach((word,count) -> { sb.append(i.addAndGet(1)).append(FLAT_LINE_SEP).append(word).append("\n");});

        Files.write(sb.toString(), new File(filePath+".indexed.txt"), Charset.defaultCharset());
    }

    public static void writeToIndexedFile(Set<String> set, String filePath) throws IOException {

        StringBuilder sb = new StringBuilder();

        AtomicInteger i = new AtomicInteger(0);
        set.forEach((word) -> { sb.append(i.addAndGet(1)).append(FLAT_LINE_SEP).append(word).append("\n");});

        Files.write(sb.toString(), new File(filePath+".indexed-set.txt"), Charset.defaultCharset());
    }

    public static void writeToFile(Set<String> set, String filePath) throws IOException {

        StringBuilder sb = new StringBuilder();

        set.forEach((word) -> { sb.append(word).append("\n");});

        Files.write(sb.toString(), new File(filePath+".set.txt"), Charset.defaultCharset());
    }

    // SAVE: https://stackoverflow.com/questions/109383/sort-a-mapkey-value-by-values-java
    public static Map<String,Integer> sortByValueDesc(Map<String,Integer> map) {

        List<Map.Entry<String,Integer>> list = map.entrySet().stream()
            .sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
            .collect(Collectors.toList());  // TODO: Make stream put into LinkedListMap?

        return backToMap(list);
    }

    private static void addTo(String word, Map<String,Integer> concordance) {

        if(concordance.containsKey(word)) {
            concordance.put(word, concordance.get(word)+1);
        }
        else {
            concordance.put(word,1);
        }
    }

    /*
    Remove any entry where the key is a punctuation or number.
     */
    private static void removeNonWords(Map<String,Integer> concordance) {

        concordance.entrySet().removeIf(entry -> isNumberOrPunc(entry.getKey()) );
    }


    private static Map<String,Integer> backToMap(List<Map.Entry<String,Integer>> entries) {

        Map<String,Integer> map = new LinkedHashMap<>();// keeps keys in insert order

        for(Map.Entry<String,Integer> entry : entries)
        {
            map.put(entry.getKey(), entry.getValue());
        }

        //log.debug("BackToMap: {}", map.toString());
        return map;
    }

}
