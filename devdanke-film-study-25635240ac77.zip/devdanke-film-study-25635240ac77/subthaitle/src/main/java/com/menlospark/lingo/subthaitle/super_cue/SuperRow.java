package com.menlospark.lingo.subthaitle.super_cue;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
class SuperRow {

    public static final boolean WORD = true;
    public static final boolean SENTENCE = false;
    private List<SuperCell> cells = Lists.newArrayList();
    private final boolean isWordRow;

    public int getTotalColCountForCells() {
        return cells.stream()
                .mapToInt(SuperCell::getCharCount)
                .sum();
    }

}

