package com.menlospark.lingo.subthaitle;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.menlospark.lingo.subthaitle.utils.MyStrUtils;
import com.menlospark.lingo.subtility.model.Cue;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class FlatSep {

    static final String LINE_DELIM = " | ";

    public static List<Cue> flattenLines(List<Cue> cues) {

        return cues.stream()
                .map( cue -> {

                    List<String> cleanLines = cue.getLines().stream()
                            .map(MyStrUtils::trimLeadingDash)
                            .collect(Collectors.toList());

                    cue.setLines( Lists.newArrayList(Joiner.on(LINE_DELIM).join(cleanLines)) );
                    return cue;
                })
                .collect(Collectors.toList());
    }


    public static List<Cue> separateThaiWords(List<Cue> cues) {

        return cues.stream()
                .map( cue -> {
                    cue.setLines(MyIcu.separateThaiWords(cue.getLines()));
                    return cue;
                })
                .collect(Collectors.toList());
    }

    /*
    TODO: Try this as one big, two stage (flatten & separate) lambda.
     */
    public static List<Cue> flattenAndSeparateThaiLines(List<Cue> thaiCues) {

        return separateThaiWords(flattenLines(thaiCues));
    }

}
