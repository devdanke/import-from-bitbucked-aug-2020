package com.menlospark.lingo.subthaitle.dict;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.common.collect.Lists;
import com.menlospark.lingo.subthaitle.dict.Word;
import com.menlospark.lingo.subthaitle.utils.MyPropFileParser;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Add entries to my dict.  This dict will be used to overrides google translate defs
 * when creating movie super subtitles.
 *
 * Given an input file of new definitions and a file of the existing mydict, do the following:
 *
 * Put the new defs into Word objects.
 *
 * If the word is already in the dict,
 *   then add the new def as an additional meaning to
 *   the notes: section as ##newDef##
 * Else
 *   add the new Word.
 *
 */
@Slf4j
public class TempAddNewDefsToDict {

    public static final String NEW_DEFS_SECTION_HEADER = "mydict";
    public static final ObjectMapper JSON = new ObjectMapper();
    static {
        JSON.enable(SerializationFeature.INDENT_OUTPUT);
    }

    public static void process(String newDefsFilePath, String curDefsFilePath) {


        //int parseDttmStamp = 20170301;
        int parseDttmStamp = Integer.parseInt(LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE));

        try {

            Map<String,Collection<String>> fileSections = MyPropFileParser.parseSections(newDefsFilePath);
            Collection<String> rawNewDefs = fileSections.get(NEW_DEFS_SECTION_HEADER);
            Collection<Word> newDefs = parseToWords(parseDttmStamp, rawNewDefs);

            File curDefsFile = new File(curDefsFilePath);

            FileUtils.copyFile(curDefsFile, new File(curDefsFile.getAbsolutePath()+"_backup_"+System.currentTimeMillis()));

            List<Word> curDefs = JSON.readValue(curDefsFile, new TypeReference<List<Word>>(){});
            log.debug("counts newDefs: {}, curDefs: {}", newDefs.size(), curDefs.size());

            Map<String,Word> curDefByThai = curDefs.stream().collect(Collectors.toMap(Word::getTh, Function.identity()));

            newDefs.stream().forEach(newDef -> {
                Word curDef = curDefByThai.get(newDef.getTh());
                if(curDef == null) {
                    curDefs.add(newDef);
                    log.debug("Added: {}", newDef);
                }
                else {

                    String moreNotes = " ##" + newDef.getEn() + "##";
                    moreNotes += (newDef.getNote() != null) ? " " + newDef.getNote() : "";

                    curDef.setNote(StringUtils.defaultString(curDef.getNote()) + moreNotes );
                    log.debug("appended: {}", newDef);
                }
            });

            log.debug("counts AFTER MERGE curDefs: {}", curDefs.size());

            //Lambda expression with type information removed.
            Collections.sort(curDefs, (p1, p2) -> p1.getEn().compareTo(p2.getEn()));
            JSON.writeValue( curDefsFile, curDefs);
        }
        catch (Exception e) {
            new RuntimeException(e);
        }
    }

    /*
 new t2e format
 th = phonetic = eng1;eng2 = note
 same as copy/paste from t2e dict
     */
    static Collection<Word> parseToWords(int dateNum, Collection<String> rawFileLines) {

        return rawFileLines.stream().map(line -> {

          String[] parts = line.split("=");

          String th = parts[0].trim();
          String phonetic = parts[1].trim();
          String enRaw = parts[2].trim();
          String note = (parts.length > 3) ? parts[3].trim() : "";

          String[] enParts = enRaw.split(";");
          String en = enParts[0];

          for(int i=1; i<enParts.length; i++) {
            note += " ##" + enParts[i].trim() + "## ";
          }

          return new Word(dateNum, th, en, phonetic, note);
        }).collect(Collectors.toList());
    }

}
