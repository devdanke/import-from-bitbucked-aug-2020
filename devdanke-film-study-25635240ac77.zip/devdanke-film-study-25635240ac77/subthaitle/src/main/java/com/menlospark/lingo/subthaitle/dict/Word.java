package com.menlospark.lingo.subthaitle.dict;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Word {

    public Word(int id, String th, String en, String phonetic){
        this(id,th,en, phonetic,null);
    }

    public Word(int id, String th, String en){
        this(id,th,en,null,null);
    }

    int id;
    String th;
    String en;
    String phonetic;
    String note;
}
