package com.menlospark.lingo.subthaitle.super_cue;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.menlospark.lingo.subthaitle.dict.Dict;
import com.menlospark.lingo.subthaitle.utils.ThaiStringUtils;
import com.menlospark.lingo.subtility.model.Cue;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

import static java.lang.Math.max;

@Slf4j
public class SuperCueMaker {

    private static String SPACE = " ";
    private static String FLAT_LINE_DELIM = "| ";

    // use to start/end cue lines to avoid html trimming/centering.
    // by start/ending super cue lines with this, it prevents browser trim and and misaligned centering.
    private static String NBSP = "&nbsp;";


    public static List<Cue> makeSuperCues(
        List<Cue> inputThCues,
        List<Cue> inputEnCues,
        Dict dict,
        List<SplitUndo> splitUndos,
        List<SplitForce> splitForces) {

        List<Cue> outputCues = Lists.newArrayList();

        for(int i=0; i < inputThCues.size(); i++)  {


            Cue thCue = inputThCues.get(i);
            Cue enCue = inputEnCues.get(i);

            log.info("cue[{}]", thCue.getItemNumber());

            List<SuperTable> superTables = cueLinesToTables(
                thCue.getLines(),
                enCue.getLines(),
                dict, splitUndos, splitForces);

            String superCueLine = concatSuperTablesIntoSuperLine(superTables);
            superCueLine = flagTooLongLines(superCueLine);

            Cue outCue = new Cue(thCue);
            outCue.setLines(Lists.newArrayList(superCueLine));

            outputCues.add(outCue);
        }

        return outputCues;
    }

    // @param origThaiLines not flat or sep.
    static List<SuperTable> cueLinesToTables(
        List<String> thLines,
        List<String> enLines,
        Dict dict,
        List<SplitUndo> splitUndos,
        List<SplitForce> splitForces) {

        List<SuperTable> tables = Lists.newArrayList();

        for(int i = 0; i < thLines.size(); i++) {

            List<List<String>> dataWordLines = SuperData.makeDataWordLines(thLines.get(i), dict, splitUndos,
                splitForces);

            SuperTable table = convertDataWordLinesToSuperTable(dataWordLines, enLines.get(i));
            tables.add(table);
        }

        return tables;
    }


    /*
    These dataWordLines don't include the english sentence.
     */
    static SuperTable convertDataWordLinesToSuperTable(List<List<String>> dataWordLines, String enSentence) {

        List<SuperRow> superRows = Lists.newArrayList();
        int wordCount = dataWordLines.get(0).size();

        for(int i=0; i < dataWordLines.size(); i++) {

            List<SuperCell> superCells = Lists.newArrayList();
            for(String word : dataWordLines.get(i)) {

                superCells.add( new SuperCell(word, 1, ThaiStringUtils.AlignType.C) );
            }
            superRows.add( new SuperRow(superCells, SuperRow.WORD) );
        }

        // add the en line as a whole sentence.
        SuperCell sentenceCell = new SuperCell(enSentence, wordCount, ThaiStringUtils.AlignType.L);
        superRows.add(new SuperRow(Lists.newArrayList(sentenceCell), SuperRow.SENTENCE));

        return new SuperTable(superRows);
    }


    /*
    Each original thai line will become a superTable.
    This method concatenates them to create the full flattened super subtitle.

    TODO: Is this the best place to attach NBSP? Hint: I don't think so.
     */
    static String concatSuperTablesIntoSuperLine(List<SuperTable> tables) {

        String almostSuperSub = Joiner.on(NBSP + "\n" + NBSP)
                .join(
                    tables.stream()
                          .map(st -> layoutCueLineTable(st, 1))
                          .reduce((stl1, stl2) -> joinSuperTables(stl1, stl2, FLAT_LINE_DELIM) ).get()
                );
        return NBSP + almostSuperSub + NBSP;
    }


    static List<String> joinSuperTables(List<String> stl1, List<String> stl2, String joinToken) {

        if(stl1.size() != stl2.size()) {
            throw new IllegalArgumentException("super table lines from stl1 and stl2 must be same");
        }

        List<String> result = Lists.newArrayList();

        for(int i=0; i<stl1.size(); i++) {
            result.add(Joiner.on(joinToken).join(stl1.get(i),stl2.get(i)));
        }

        return result;
    }


    /*
    ISimilar to an html table.
    But alignment is enforced with padding spaces.
     */
    static List<String> layoutCueLineTable(SuperTable table, int spacesBetweenCells) {

        // char count of longest row.  This row size is used for all rows.
        int rowSize = table.calcMaxRowSize();
        List<Integer> maxSizeEachColumn = table.calcEachWordColumnsMaxSize();

        List<String> result = Lists.newArrayList();
        for(SuperRow row : table.getRows()) {

            if(row.isWordRow()) {
                result.add(layoutWordRow(row, maxSizeEachColumn, rowSize));
            }
            else {
                result.add(layoutSentenceRow(row, rowSize));
            }
        }

        return result;
    }


    static String layoutSentenceRow(SuperRow row, int rowLength) {

        return row.getCells().get(0).getPaddedAlignedText(rowLength);
    }


    static String layoutWordRow(SuperRow row, List<Integer> maxColCharCount, int rowSize) {

        List<String> laidedOutWords = Lists.newArrayList();

        for(int i=0; i<row.getCells().size(); i++) {

            laidedOutWords.add(row.getCells().get(i).getPaddedAlignedText(maxColCharCount.get(i)));
        }

        return ThaiStringUtils.myCenter( Joiner.on(SPACE).join(laidedOutWords), rowSize, SPACE);
    }


    /*
    Add variable element wrapper to long subtitles.
    These elements are styled by vtt-cues.css.
    It makes them fit in the viewport (at least for transporter's aspect ratio).

    The particular char length correspond to how many chars fit a subtitle line
    for particualr font-size "vw" values.
     */
    static String flagTooLongLines(String renderedTable) {

        int estLineLength = renderedTable.indexOf('\n') - (2 * "&nbsp".length()) + 2;

        if( estLineLength > 75) {
            //log.warn("{}) BIG LINE. len={}, \n \tline={} \n", badCount++, thLen, thSb.toString());

            if(estLineLength < 86 ) {
                return "<i>" + renderedTable + "</i>";
            }
            else if(estLineLength < 91) {
                return "<b>" + renderedTable + "</b>";
            }
            else {
                return "<u>" + renderedTable + "</u>";
            }
        }
        else {
            return renderedTable;
        }
    }

}
