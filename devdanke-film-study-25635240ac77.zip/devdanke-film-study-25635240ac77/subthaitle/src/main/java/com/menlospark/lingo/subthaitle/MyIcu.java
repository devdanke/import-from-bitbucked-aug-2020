package com.menlospark.lingo.subthaitle;


import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.ibm.icu.text.BreakIterator;
import com.menlospark.lingo.subthaitle.utils.Const;

import java.util.List;
import java.util.stream.Collectors;


public class MyIcu {

    /*
    Given a string containing one or more thai words.
    Get back a string where all the ICU splitable words are split and have a space between them.
     */
    public static List<String> separateThaiWords(String thaiCueLine) {

        BreakIterator boundary = BreakIterator.getWordInstance();
        boundary.setText(thaiCueLine);

        return extractIcuTokensIntoWordList(boundary, thaiCueLine);
    }


    /*
    Given a string containing one or more thai words.
    Get back a string where all the ICU splitable words are split and have a space between them.
     */
    static String separateThaiWordsAsStr(String thaiCueLine) {

        return Joiner.on(Const.SPACE).join(separateThaiWords(thaiCueLine));
    }

    static List<String> separateThaiWords(List<String> thaiCueLines) {

        return thaiCueLines.stream().map(line ->  separateThaiWordsAsStr(line)).collect(Collectors.toList());
    }

    private static List<String> extractIcuTokensIntoWordList(BreakIterator boundary, String source) {

        List<String> words = Lists.newArrayList();

        int start = boundary.first();
        for (int end = boundary.next(); end != BreakIterator.DONE; start = end, end = boundary.next()) {

             words.add(source.substring(start,end));
        }

        return words;
    }

}
