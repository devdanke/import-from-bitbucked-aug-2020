package com.menlospark.lingo.subthaitle.super_cue;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.menlospark.lingo.subthaitle.utils.Const.SPACE;

/**
 * When these n words are found split, together, and in order, the unSplit them.
 */
@Slf4j
@Data
@NoArgsConstructor
public class SplitUndo
{
    public static final String HYPEN = "-";

    //private final boolean hyphenate;
    private List<String> wordsToJoin;
    private String note;

    @JsonIgnore
    private String replacement;


    public SplitUndo(List<String> wordsToJoin) {

        setWordsToJoin(wordsToJoin);
    }

    // using setter like this because of jackson probaby only using setter.
    public void setWordsToJoin(List<String> wordsToJoin) {

        if(wordsToJoin.size() < 2) {
            throw new IllegalArgumentException("splitUndo requires 2+ words.");
        }
        this.wordsToJoin = wordsToJoin;

        this.replacement = Joiner.on( HYPEN ).join(wordsToJoin);
    }


    public Pair<Boolean,Integer> findMatch(List<String> thWords) {

        int index = findSubList(thWords, wordsToJoin);
        return Pair.of((index > -1), index);
    }

    public List<String> unSplit(int replaceStartPos, List<String> thWords) {

        List<String> result = Lists.newArrayList();

        if(replaceStartPos != 0) {
            result.addAll(thWords.subList(0, replaceStartPos));
        }
        result.add(replacement);

        int resumePos = replaceStartPos + wordsToJoin.size();
        if(resumePos < thWords.size()) {
            result.addAll(thWords.subList(resumePos, thWords.size()));
        }

        return result;
    }


    private static final ObjectMapper JOM = new ObjectMapper();
    static {
        JOM.enable(JsonParser.Feature.ALLOW_COMMENTS);
        JOM.enable(SerializationFeature.INDENT_OUTPUT);
    }
    private static final TypeReference<List<SplitUndo>> TYPE_REF = new TypeReference<List<SplitUndo>>(){};

    public static List<SplitUndo> load(String filePath)  {

        try {
            return JOM.readValue(new File(filePath),TYPE_REF );
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void save(String filePath, List<SplitUndo> splitUndos) {
        try {
            JOM.writeValue(new File(filePath), splitUndos);
        }
        catch(Exception e) {
            throw new RuntimeException(e);
        }
    }

    /*
    todo: Move to utils
     */
    public int findSubList(List<String> list, List<String> target) {

        for(int i=0; i<= (list.size()-target.size()); i++) {

            for(int j=0, k=i; j < target.size(); j++, k++) {

                if( target.get(j).equals(list.get(k))) {
                    if (j==target.size()-1) {
                        return i;
                    }
                }
                else {
                    break;
                }
            }
        }

        return -1;
    }

}
