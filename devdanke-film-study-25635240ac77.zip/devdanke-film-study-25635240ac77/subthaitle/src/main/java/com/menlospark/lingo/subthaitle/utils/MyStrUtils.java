package com.menlospark.lingo.subthaitle.utils;

import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.regex.Pattern;

@Slf4j
public class MyStrUtils {

    static final List<Character> MYPUNC = Lists.newArrayList('.','-',',','?','"','\'');

    public static boolean isNumberOrPunc(String s) {

        boolean isNumeric = StringUtils.isNumeric(s);
        boolean isPunc = Pattern.matches("\\p{Punct}", s);// Cool!
        return ( isNumeric || isPunc);
        //boolean remove =  ( isNumeric || isPunc);
     //   if(remove) {
            //     log.info("Will remove: {} because isNum: {}, isPunc: {}.", s, isNumeric, isPunc);
       // }
        //return remove;
    }

    public static boolean isNumberOrPunc(char ch) {

        boolean isNumeric = Character.isDigit(ch);
        boolean isPunc = MYPUNC.contains(ch);// Less cool!
        return ( isNumeric || isPunc);
    }


    /*
    Exclude leading digit or punc chars.
     */
    private static String removeLeadingDigitOrPuncs(String s) {

        StringBuilder sb = new StringBuilder();

        boolean pastUnwantedLeadChars = false;
        for(char ch : s.toCharArray()) {

            if(!isNumberOrPunc(ch) || pastUnwantedLeadChars) {
                sb.append(ch);
            }
            else {
                pastUnwantedLeadChars = true;
            }
        }

        return sb.toString();
    }

    /*
    Exclude trailing digit or punc chars.
     */
    private static String removeTrailingDigitOrPuncs(String s) {

        StringBuilder sb = new StringBuilder();

        boolean pastUnwantedLeadChars = false;
        for(char ch : StringUtils.reverse(s).toCharArray()) {

            if(!isNumberOrPunc(ch) || pastUnwantedLeadChars) {
                sb.append(ch);
            }
            else {
                pastUnwantedLeadChars = true;
            }
        }

        String result = StringUtils.reverse( sb.toString() );

        return result;
    }

    /*
    If it's a word with leading or trailing numbers or punctuation, then strip them off.
    If it's a number, then pass it through as is.
     */
    public static String trimDigitsOrPuncs(String s, String vttSourceLine) {

        String result = null;
        if(StringUtils.isNumeric(s) || isQuoted(s)) {
            result = s;
        }
        else {
            result = removeLeadingDigitOrPuncs(removeTrailingDigitOrPuncs(s));
        }

        if(result.trim().equals("")) {
            log.warn("Trimmed to nothing! input: '{}', output: '{}', srcLine: '{}'.", s, result, vttSourceLine);
        }

        return result;
    }

    public static boolean isQuoted(String s) {
        return (s.charAt(0)=='"') && (s.charAt(s.length()-1)=='"');
    }

    public static String trimLeadingDash(String s) {
        char ch0 = s.trim().charAt(0);
        if(ch0 == '-') {
            //log.info("*********** YES I WAS CALLED");
            return s.substring(1).trim();
        }
        else return s;
    }

}
