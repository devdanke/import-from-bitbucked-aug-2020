package com.menlospark.lingo.subthaitle;

import com.menlospark.lingo.subthaitle.utils.Const;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Central place for all clean up of thai or english subtitle text.
 * Some cleanups are for ICU artifacts.
 * Others aimed at subtitles, such as removing the leading "-" that many lines have.
 * Mainly this is aimed a cleanup of Thai text for now.
 */
public class TextCleaner {

    // TODO: single regex
    public static String filterElipses(String s) {
        return s.replace("...", " ").replace("..", " ");
    }


    /**
     * If ICU4J found a space in the original input, then it'll be a space item in the result.
     * Which I don't want.
     * @param lines
     * @return
     */
    public static List<String> removeSpaceWords(List<String> words) {

        return words.stream()
            .filter(candidateWord -> !Const.SPACE.equals(candidateWord))
            .collect(Collectors.toList());
    }

    /*
    Remove things like quotes and question marks.
    */
    public static String removeRemainingTroublesomeChars(String line) {
        return line.replace("\"", "").replace("?", "");
    }


    public static List<String> cleanup(List<String> words) {
        return words.stream()
            .map(w -> w.replaceAll("\\.\\.\\.",""))
            .map(w -> w.replaceAll("\\.\\.",""))
            .map(w -> w.replaceAll("\\.",""))
            .map(w -> w.replaceAll("\\-",""))
            .map(w -> w.replace("\"", ""))
            .map(w -> w.replace("\\?", ""))
            .map(w -> w.trim())  // doesn't work well with thai chars.  it deletes all chars but the last
            //.map(w -> w.trim())
            .filter( w -> (w.length() > 0))
//            .filter( w -> (!Const.SPACE.equals(w)))
            .collect(Collectors.toList());
    }
}
