/**
 *
 * This util depends on numbered word list from FlattenSeparator.
 * And the output of manually translating the numbered thai word list in Google.
 * foo.index.txt, foo.concord.txt, foo.phonetic.txt.
 *
 * This code loads and assembles those three files into a JSON formatted dictionary of Word objects.
 * I plan to use this dictionary to lookup thai words and include the english meaning and phonetic
 * pronounciation.  Then create a subtitle track from this.
 *
 */
package com.menlospark.lingo.subthaitle.dict;