package com.menlospark.lingo.subthaitle.translit;

import com.google.common.collect.Lists;
import com.google.common.io.Files;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
public class TranslitDefParser {

    List<ConsonantChar> parseConsonantChars(Collection<String> anyConsonantLines) {

        List<ConsonantChar> result = Lists.newArrayList();

        anyConsonantLines.forEach(line -> {

            // log.debug("line: '{}'", line);
            String[] parts = line.split("\\|");
            result.add(new ConsonantChar(parts[1].trim().charAt(0), parts[0].trim(), parts[2].trim()));
         });

        return result;
    }

    List<Consonant> parseConsonants(Collection<String> consonantLines, Collection<String> finalConsonantLines) {

        final List<ConsonantChar> consonantChars = parseConsonantChars(consonantLines);
        final Map<Character,ConsonantChar> finalConsonantChars = parseConsonantChars(finalConsonantLines)
                .stream().collect(Collectors.toMap(ConsonantChar::getThChar, Function.identity()));

        return consonantChars.stream()
                .map( cc -> new Consonant(cc.getThChar(), cc, finalConsonantChars.get(cc.getThChar())))
                .collect(Collectors.toList());
    }

}
