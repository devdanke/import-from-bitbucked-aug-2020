#!/usr/bin/env ruby

require 'webrick'

puts "ruby version: #{RUBY_VERSION}"

root = File.expand_path './web-ui/web'

mime_types = WEBrick::HTTPUtils::DefaultMimeTypes

mime_types.store 'js', 'application/javascript'
mime_types.store 'json', 'application/json'
mime_types.store 'mp4', 'video/mp4'
mime_types.store 'vtt', 'text/vtt'


server = WEBrick::HTTPServer.new :Port => 8888, :DocumentRoot => root

server.mount_proc '/ping' do |request, response|
  response.body = 'pong'
end

#The following command will provide a hook to shutdown the server (often done with Ctrl+C)
trap('INT') {server.shutdown}

#Start the server
server.start