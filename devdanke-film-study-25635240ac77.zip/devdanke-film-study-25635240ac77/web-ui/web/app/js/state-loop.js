
// Keep all app state in one place (like React Redux)
function LoopState() {}


// TODO: this scene data is not loop state.  Remove to it's own file.  Then put loopState and loopBoundState together.
// 1 based.  same as scene id in scenes.json.
LoopState._curSceneId;

LoopState.getCurSceneId = function() {
    return LoopState._curSceneId;
}

LoopState.setCurSceneId = function(sceneId) {
    console.log("setCurSceneId() sceneId:", sceneId)
    return LoopState._curSceneId = sceneId;
}

// 1 based.  same as scene id in scenes.json.
LoopState._maxSceneId;

LoopState.getMaxSceneId = function() {
    return LoopState._maxSceneId;
}

LoopState.setMaxSceneId = function(sceneId) {
    console.log("setMaxSceneId() sceneId:", sceneId)
    return LoopState._maxSceneId = sceneId;
}


LoopState.LOOP_OFF =   "LOOP_OFF"
LoopState.LOOP_CUE =   "LOOP_CUE"
LoopState.LOOP_SCENE = "LOOP_SCENE"

LoopState._loopModeChangeListener = null
LoopState._loopMode = LoopState.LOOP_OFF

LoopState.getLoopMode = function() {
    return LoopState._loopMode
}

LoopState.cueLoopEnabled = function() {
    return LoopState._loopMode === LoopState.LOOP_CUE
}

LoopState.sceneLoopEnabled = function() {
    return LoopState._loopMode === LoopState.LOOP_SCENE
}


LoopState.setLoopModeOff = function() {
    LoopState._loopMode = LoopState.LOOP_OFF
    LoopState.notifyLoopChangeListener()
}

/*
 listener callback   takes param of state loop mode changed to.
 */
LoopState.setLoopModeChangeListener = function(loopModeChangeListener) {
    LoopState._loopModeChangeListener = loopModeChangeListener
}

LoopState.notifyLoopChangeListener = function() {
    if(LoopState._loopModeChangeListener != null) {
        LoopState._loopModeChangeListener(LoopState.getLoopMode())
    }
}


LoopState.goToNextLoopMode = function() {
    var loopMode = LoopState.getLoopMode()

    if(loopMode === LoopState.LOOP_OFF) {
        LoopState._loopMode = LoopState.LOOP_CUE
    }
    else if (loopMode == LoopState.LOOP_CUE) {
        LoopState._loopMode = LoopState.LOOP_SCENE
    }
    else {
        LoopState._loopMode = LoopState.LOOP_OFF
    }

    LoopState.notifyLoopChangeListener()
}

