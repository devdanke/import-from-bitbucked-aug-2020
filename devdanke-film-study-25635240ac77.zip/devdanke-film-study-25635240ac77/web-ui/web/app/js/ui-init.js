

function initVideoPlayer() {

    var player = document.querySelector("#vPlayer");
    MyPlayer.setVideoPlayerRef(player)

    player.addEventListener('ended', handleDonePlayingSceneEvent, false);

    MyPlayer.setPlayPauseListener(showPlayBtnIcon)

    player.ontimeupdate = handlePositionChangeEvent
    player.onvolumechange = volListener
}

/*
 Comes from client-conf.json for default global value.
 In the future, it could be overriden by each movie.

 Cleanest and single way to set playback rate is to always go through rate slider ui.
 Then have slider's handler method do the other 2 things: 1) update rate % display, 2) update player.
 */
function processClientConf(clientConf) {

    setPlaybackRate(clientConf.defaultPlaybackRate)
}

/**
 * Initial ui setup, happens once at about page load time. Called once, at page load.
 * @param moviesData is a simple list of movie names (cannonical)
 *
 * TODO: Maybe move this to mvc-controller.js
 */
function handleAjaxReplyToPopulateMovieList(moviesData) {

    console.log("movieData:", moviesData.movies)
    var movieDropdownJq = $("#movieDropdown")
    MyUtils.removeElemKids(movieDropdown)

    _.forEach(moviesData.movies, function(movieData) {

        movieDropdownJq.append("<option value='"+movieData.dir+"'>"+movieData.title+"</option>")
    })

    handleMovieChange(moviesData.movies[0].dir) //populates scenes for this movie
}






