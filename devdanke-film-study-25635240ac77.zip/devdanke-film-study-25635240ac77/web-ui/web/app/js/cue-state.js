/**
 * Operations on the CueTime json struct: {id,start,end}
 * Also, keep track of the cues, and which is current.
 * Provide easy way to move between them.
 */

function CueState() {
    // cue times for current scene
    this._cueTimes = null

    // used to avoid refreshing current cue button when it's already correct.
    // this is used only for ui display purposes.
    // it's not used for actual time position finding etc.
    // mainly because, most of the time, there is no current cue.
    this.currentCue = null
}

/*
From the generated scene-n.??.cueTimes.json files, with entries like this:
  {"end":7451,"id":1,"start":5744}.  Each of these objects is a cueTime.
This method called everytime scene changes.
 */
CueState.initForScene = function(cueTimes) {
    CueState._cueTimes = cueTimes
}

/*
 Go through list of cues.
 Find the first that contains the given fracSec.
 Sequentially increasing list of CueTime objects.
 */
CueState._cueContains = function(cueTime, milli) {
    var containsCue = ((cueTime.start <= milli) && (cueTime.end >= milli) )
    return containsCue
}

/*
CueState._cueStartsBefore = function(cueTime, milli) {
    return (cueTime.start < milli)
}
*/
CueState._cueStartsAfter = function(cueTime, milli) {
    return (cueTime.start > milli)
}

CueState._cueEndsBefore = function(cueTime, milli) {
    return (cueTime.end < milli)
}

CueState._cueEndsAfter = function(cueTime, milli) {
    return (cueTime.end > milli)
}

/*
For touch flicking
 */
CueState.findCueContainingThisMilli = function (targMilli) {

    var len = CueState._cueTimes.length;
    var resultCue = null

    for (var i = 0; i < len; i++) {

        var cueTime = CueState._cueTimes[i]

        if(CueState._cueContains(cueTime, targMilli)) {
            resultCue = cueTime
            break
        }

        if(CueState._cueStartsAfter(cueTime, targMilli)) {
            // quit when targMilli is not inside any cue.
            break
        }
    }
    return resultCue
}

/*
 For touch flicking. Help find the cue to jump to.
 */
CueState.findCueContainingThisFracSec = function (fracSec) {
    return CueState.findCueContainingThisMilli(MyUtils.fracSecToMilli(fracSec))
}

/*
Assume this milli is not in a cue.
Find cue immeidately before this milli.
If there isn't one before this time, then return 1st cue.
 */
CueState.findCueJustBefore = function (targMilli) {

    var len = CueState._cueTimes.length;
    var result = CueState._cueTimes[0] // default

    for (var i = (len-1); i >= 0; i--) {

        var cueTime = CueState._cueTimes[i]

        if(CueState._cueEndsBefore(cueTime, targMilli)) {
            result = cueTime
            break
        }
    }
    return result
}

/*
 Find the 1st cue that starts after this milli.
 If there isn't one, then return last cue.
 */
CueState.findCueJustAfter = function (targMilli) {

    var len = CueState._cueTimes.length;
    var result = CueState._cueTimes[len-1]

    for (var i = 0; i < len; i++) {

        var cueTime = CueState._cueTimes[i]

        if(CueState._cueStartsAfter(cueTime, targMilli)) {
            result = cueTime
            break
        }
    }
    return result
}


/*
Return true if the give milli is before half way of the cue's duration.
 */
CueState.beforeHalfWay = function(cueTime, targMilli) {
    return targMilli < parseInt(((cueTime.end - cueTime.start)/2)+cueTime.start);
}
