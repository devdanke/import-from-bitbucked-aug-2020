function createCueNavTable(cueTimesWrapper) {

    var cueTimes = cueTimesWrapper.cueTimes
    CueState.initForScene(cueTimes)

    var cueCount = cueTimes.length

    // TODO: Move to loop-bounds-slider.js type of file.
    drawLoopBoundsSlider("loopBoundsSection", cueCount)

    updateMyPlayerWithLoopBounds()

    var btnRow = $('#cueNavBtnRow')
    btnRow.empty()

    _.forEach(cueTimes, function(cueTime, index) {

        // button row
        var btnId = "cue-" + cueTime.id
        btnRow.append(
            '<td style="text-align:center; align: center;">' +
            '<button style="font-size: 0.7em; flex-grow: 1; flex-shrink: 3;" ' +
            '  title="'+cueTime.start+' - '+cueTime.end+'" ' +
            '  class="cue-btn" id="'+btnId+'">'+cueTime.id+
            '</button>' +
            '</td>' )

        var btn = $("#"+btnId)
        btn.click( function(){
            // +1 ensures that rounding error is never make new pos less than targCue.start.
            MyPlayer.player().currentTime = MyUtils.milliToFracSec(cueTime.start+1)
            var cue = cueTime
            showActiveCueBtn(cue)
        })
    })
}

/*
 Go through list of cues.
 Find the first that contains the given fracSec.
 */
function makeCueBtnShowActiveCue(curTimeFracSec) {

    var activeCue = CueState.findCueContainingThisFracSec(curTimeFracSec)
    if(activeCue != null) {
        if((CueState.currentCue==null) || (CueState.currentCue !== activeCue)) {
            showActiveCueBtn(activeCue);
        }
    }
    else {
       deselectAnyActiveCueBtns()
    }
}

function showActiveCueBtn(cue) {

    deselectAnyActiveCueBtns()

    var cueBtnId = "#cue-" + cue.id;
    $("#cue-" + cue.id).addClass("activeBtn-cue")
    CueState.currentCue = cue
}

function deselectAnyActiveCueBtns() {
    $("#cueNavBtnRow > td > button").removeClass("activeBtn-cue")
}

