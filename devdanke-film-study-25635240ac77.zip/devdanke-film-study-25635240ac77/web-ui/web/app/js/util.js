
function MyUtils() {}

/*
 given an elem, remove all it's children
 */
MyUtils.removeElemKids = function(elem) {
    while (elem.firstChild) {
        elem.removeChild(elem.firstChild);
    }
}

MyUtils.milliToFracSec = function(milli) {
    return (milli / 1000)
}

MyUtils.fracSecToMilli = function(fracSec) {
    return parseInt(fracSec * 1000)
}


MyUtils.calcNextCircArray1BasedPos = function(curPos, maxPos) {
    var nextPos = curPos + 1
    return (nextPos > maxPos) ? 1 : nextPos
}

MyUtils.calcPrevCircArray1BasedPos = function(curPos, maxPos) {
    var nextPos = curPos - 1
    return (nextPos < 1) ? maxPos : nextPos
}




MyUtils.formatCurSecForDisplay = function (curSec) {

    var PAD_SAFE_NBSP = '\xa0'

    var parts = _.split(curSec.toString(), ".")
    var wholePart = parts[0]
    return _.padStart(_.trim(wholePart), 5, PAD_SAFE_NBSP)
}