
function initTouch() {

    var touchy = document.querySelector("#touchDiv")
    var myOptions = {}

    var hammertime = new Hammer(touchy, myOptions);

    hammertime.get('swipe').set({ direction: Hammer.DIRECTION_HORIZONTAL });
    hammertime.on('swipe', function(ev) {
        var direction = (ev.deltaX >= 0) ? "RIGHT" : "LEFT";

       // console.log("onSwipe() direction:", direction)//, "event:", ev);

        if(direction === "LEFT") {
            handleLeftSwipe()
        }
        else if (direction === "RIGHT") {
            handleRightSwipe()
        }
    });

    hammertime.on('tap', function(ev) {
        console.log("tapping:", ev);
        MyPlayer.togglePlayPause()
    });

    /*
     hammertime.get('pan').set({ direction: Hammer.DIRECTION_ALL });
     hammertime.on('pan', function(ev) {
     console.log("panning:", ev);
     });

    hammertime.on('press', function(ev) {
        console.log("pressing:", ev);
    });

     */
}

/*
 if there is current cue, then
     if current time is > 50% through it, then
         go to beginning of this cue
     else
        go to prev cue
 else no current cue
    switch to cue just before current position
 */
function handleLeftSwipe() {

    var player = MyPlayer.player()
    var curTimeFracSec = player.currentTime
    var activeCue = CueState.findCueContainingThisFracSec(curTimeFracSec)
    var curTimeMilli = CueState.fracSecToMilli(curTimeFracSec)

    var nextPosMilli = 0
    if(activeCue !== null) {

        var activeCueIndex = parseInt(activeCue.id) - 1

        if(CueState.beforeHalfWay(activeCue, curTimeMilli) && (activeCueIndex > 0)) {
            // go to prev cue
            nextPosMilli = CueState._cueTimes[activeCueIndex-1].start
        }
        else {
            // past half way of some cue OR in the 1st cue
            // in either case, go to start of this cue.
            nextPosMilli = activeCue.start
        }
    }
    else {
        // between cues
        nextPosMilli = CueState.findCueJustBefore(curTimeMilli).start
    }

    player.currentTime = MyUtils.milliToFracSec(nextPosMilli)
}



/*
 if there is current cue, then
    go to next cue (or do nothing if this is last cue)
 else no current cue
     switch to cue just after current position
 */
function handleRightSwipe() {
    var player = document.querySelector("#vPlayer")
    var curTimeFracSec = player.currentTime
    var activeCue = CueState.findCueContainingThisFracSec(curTimeFracSec)

    var nextPosMilli = 0
    if(activeCue !== null) {

        var activeCueIndex = parseInt(activeCue.id) - 1

        if( (activeCueIndex < CueState._cueTimes.length)) {
            nextPosMilli = CueState._cueTimes[activeCueIndex+1].start
        }
        else {
            // we're in last cue.
            nextPosMilli = activeCue.end + 1
        }
    }
    else {
        // not in cue.  find next cue if exist
        var cueAfter = CueState.findCueJustAfter(curTimeMilli)
        if(cueAfter != null) {
            nextPosMilli = cueAfter.start
        }
        else {
            // beyond last cue.
            nextPosMilli = CueState._cueTimes[len-1].end + 1
        }
    }
    player.currentTime = MyUtils.milliToFracSec(nextPosMilli)
}
