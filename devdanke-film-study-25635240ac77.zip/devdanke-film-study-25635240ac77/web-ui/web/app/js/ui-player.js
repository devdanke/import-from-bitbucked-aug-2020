
function setPlaybackRate(rate1to100) {
    //console.log("setPlaybackRate(): rate:", rate1to100)
    $("#rateSlider").val(rate1to100)
    $("#rateSlider").trigger("input")
}


/*
 - Update play/pause btn icon.
 - When the video is playing, show the pause icon
 - When the video is paused, show the play icon
 */
function showPlayBtnIcon(isPlaying) {

    var playBtnIcon = document.querySelector("#playBtnIcon");
    if(isPlaying) {
        playBtnIcon.classList.add("fa-pause")
        playBtnIcon.classList.remove("fa-play")
    }
    else {
        playBtnIcon.classList.add("fa-play")
        playBtnIcon.classList.remove("fa-pause")
    }
}