
//TODO move to js with loop bound slider only stuff
function drawLoopBoundsSlider(parentElem, cueCount) {

    if(gLoopBoundsSlider == null) {
        gLoopBoundsSlider = document.getElementById(parentElem);
    }
    else {
        gLoopBoundsSlider.noUiSlider.destroy()
    }

    noUiSlider.create(gLoopBoundsSlider,
        {
            start: [1, cueCount],
            connect: true,
            step: 1,
            range: {
                'min': [1],
                'max': [cueCount]
            },
         /*   pips: {
                mode: 'values',
                values: makePipArray(1, cueCount),
                density: 100  // it's a %.  100 means minor pips only at major unit locations, ie no minor pips.
            }
            */
        }
    );

    gLoopBoundsSlider.noUiSlider.on('change', function(){
        updateMyPlayerWithLoopBounds();
    });

    gLoopBoundsSlider.querySelectorAll('.noUi-connect')[0].classList.add('loopBoundsSliderBar');
}

/*
Slider bar black when looping enabled, and grey otherwise.
 */
function toggleLoopBoundsSliderBarColor() {
    var sliderBarClasses = gLoopBoundsSlider.querySelectorAll('.noUi-connect')[0].classList;
    sliderBarClasses.toggle('loopBoundsSliderBar')
    sliderBarClasses.toggle('loopBoundsSliderBarActive')
}

function makeLoopBoundsSliderBarLookActive() {
    var sliderBarClasses = gLoopBoundsSlider.querySelectorAll('.noUi-connect')[0].classList;

    if(sliderBarClasses) {
        sliderBarClasses.remove('loopBoundsSliderBar')
        sliderBarClasses.add('loopBoundsSliderBarActive')
    }
}

function makeLoopBoundsSliderBarLookInactive() {
    var sliderBarClasses = gLoopBoundsSlider.querySelectorAll('.noUi-connect')[0].classList;

    if(sliderBarClasses) {
        sliderBarClasses.add('loopBoundsSliderBar')
        sliderBarClasses.remove('loopBoundsSliderBarActive')
    }
}

function makePipArray(min,max) {
    var arr = []

    for (i = min; i <= max; i++) {
        arr.push(i);
    }

    return arr;
}


function updateMyPlayerWithLoopBounds() {
    var bounds = gLoopBoundsSlider.noUiSlider.get();
    //console.log("updateMyPlayerWithLoopBounds() bounds:", bounds)

    LoopBoundState.setLoopStartMilli(CueState._cueTimes[bounds[0]-1].start)
    LoopBoundState.setLoopEndMilli(CueState._cueTimes[bounds[1]-1].end)
}
