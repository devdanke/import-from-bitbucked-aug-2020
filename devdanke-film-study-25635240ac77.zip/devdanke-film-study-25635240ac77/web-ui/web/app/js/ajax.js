/*
You give it a url and handler function.
It calls your handler and gives it the entire "responseText" json -> js object.
 */
function ajaxGet(resourceUrl, payloadHandler)
{
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

            var payload = eval('(' + this.responseText + ')')
            //console.log("ajaxGet: url:", resourceUrl, ", response:", this.responseText )

            payloadHandler(payload)
        }
    };
    xhttp.open("GET", resourceUrl, true);
    xhttp.send();
}