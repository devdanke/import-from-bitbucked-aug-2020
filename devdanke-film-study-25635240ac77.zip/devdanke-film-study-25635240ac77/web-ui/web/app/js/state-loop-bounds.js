
function LoopBoundState() {}

/*
TODO: All these loop bound things should probably be prefixed with cueLoopStart and cueLoopEnd.
 */

LoopBoundState.LOOP_BOUND_EXTRA_MILLIS = 10// i forget what this was for.

/* ****************************************************************************************** */
LoopBoundState._loopModeEnabled = false
LoopBoundState.getLoopModeEnabled = function() { return LoopBoundState._loopModeEnabled }
LoopBoundState.setLoopModeEnabled = function(loopModeEnabled) { LoopBoundState._loopModeEnabled = loopModeEnabled }

/* ****************************************************************************************** */
LoopBoundState._loopStartMilli = 0
LoopBoundState.getLoopStartMilli = function() { return LoopBoundState._loopStartMilli }

LoopBoundState.setLoopStartMilli = function(milli) {
    var widerBoundMilli = milli - LoopBoundState.LOOP_BOUND_EXTRA_MILLIS
    LoopBoundState._loopStartMilli = (widerBoundMilli >= 0) ? widerBoundMilli : milli
}

/* ****************************************************************************************** */
LoopBoundState._loopEndMilli = 0
LoopBoundState.getLoopEndMilli = function() { return LoopBoundState._loopEndMilli }
LoopBoundState.setLoopEndMilli = function(loopEndMilli) { LoopBoundState._loopEndMilli = loopEndMilli }


LoopBoundState.atOrBeyondLoopEnd = function(curPosFracSec) {
    return MyUtils.fracSecToMilli(curPosFracSec) >= LoopBoundState._loopEndMilli
}

LoopBoundState.positionOutsideLoopBounds = function(position) {
    var posMilli = MyUtils.fracSecToMilli(position)
    return (posMilli < LoopBoundState._loopStartMilli) || (posMilli > LoopBoundState._loopEndMilli)
}

/*
 AppState.getFoo = function() { return AppState._foo }
 AppState.getFoo = function(foo) { AppState._foo = foo }
 AppState._foo
 */
