// one place for my player logic/wrapper, which is called by several other files.


function MyPlayer() {

    this._player = null
    this._isPlaying = false
    this._playPauseChangeListenerCallback = null

    // If I ever see this in the UI, it probably means something is broken.
    this._playbackRate = 0.5
}

MyPlayer.setPlaybackRate = function(rate50to100) {

    var playbackRate = (rate50to100/100)

    MyPlayer._player.playbackRate = playbackRate
    MyPlayer._playbackRate = playbackRate
}

MyPlayer.player = function() {
    return MyPlayer._player
}

MyPlayer.setPlayingState = function(isPlaying) {
    MyPlayer._isPlaying = isPlaying;
}

MyPlayer.goBackToBeginningOfLoop = function() {

    // go back to begining of loop if we're in loop mode and playing.
    MyPlayer._player.currentTime = MyUtils.milliToFracSec(LoopBoundState.getLoopStartMilli())
}


MyPlayer.isPlaying = function() {
    return MyPlayer._isPlaying
}

MyPlayer.isPlayingInCueLoop = function () {
    return (MyPlayer._isPlaying && LoopState.cueLoopEnabled())
}


// TODO: Get rid of or use it everywhere. 2/24
MyPlayer.currentTime = function() {
    return MyPlayer._player.currentTime
}


MyPlayer.goPrevCue = function() {

    var curMilli = MyUtils.fracSecToMilli(MyPlayer._player.currentTime)
    var nextCue = CueState.findCueJustBefore(curMilli)
    var nextStartFracSec = MyUtils.milliToFracSec(nextCue.start+1) // +1 avoids round down below cue start.

    MyPlayer._player.currentTime = nextStartFracSec
    showActiveCueBtn(nextCue)
}

MyPlayer.goNextCue = function() {

    var curMilli = MyUtils.fracSecToMilli(MyPlayer._player.currentTime)
    var nextCue = CueState.findCueJustAfter(curMilli)
    var nextStartFracSec = MyUtils.milliToFracSec(nextCue.start+1) // +1 avoids round down below cue start.

    MyPlayer._player.currentTime = nextStartFracSec
    showActiveCueBtn(nextCue)
}

MyPlayer.decPlaybackRate = function() {
    var curRate0to1 = MyPlayer._player.playbackRate
    if(curRate0to1 >= 0.525) {
        setPlaybackRate((curRate0to1 - 0.025 ) * 100)
    }
}

MyPlayer.incPlaybackRate = function() {
    var curRate0to1 = MyPlayer._player.playbackRate
    if(curRate0to1 <= 0.975) {
        setPlaybackRate((curRate0to1 + 0.025 ) * 100)
    }
}

MyPlayer.stop = function() {

    MyPlayer.pause()
    MyPlayer._player.currentTime = 0
}

MyPlayer.pause = function() {

    MyPlayer._player.pause()
    MyPlayer._isPlaying = false
    MyPlayer._playPauseChangeListenerCallback(MyPlayer._isPlaying)
}

MyPlayer.play = function() {

    // if curPos is inside loop bounds, then just start playing.
    // otherwise movie to begining of loop
    if(LoopState.cueLoopEnabled() && LoopBoundState.positionOutsideLoopBounds(MyPlayer._player.currentTime)) {
        MyPlayer._player.currentTime = MyUtils.milliToFracSec(LoopBoundState.getLoopStartMilli())
    }

    if(MyPlayer._player.playbackRate != MyPlayer._playbackRate) {
        // Surprisingly, MUST HAVE THIS CHECK HERE, because even onratechange is not called
        // for all possible ratechange events.
        console.log("MyPlayer.play() " +
            "MyPlayer._player.playbackRate:", MyPlayer._player.playbackRate,
            "MyPlayer._playbackRate:", MyPlayer._playbackRate)
        MyPlayer._player.playbackRate = MyPlayer._playbackRate
    }

    if(MyPlayer._player.currentTime >= MyPlayer._player.duration) {
        MyPlayer._player.currentTime = 0
    }

    MyPlayer._playPauseChangeListenerCallback(MyPlayer._isPlaying)
    MyPlayer._player.play()
}

MyPlayer.setVideoPlayerRef = function(htmlVideoElem) {

    MyPlayer._player = htmlVideoElem // not jquery elem

    MyPlayer._player.onratechange = function() {

        // Because some changes to player (or in an unexpected order) can cause playbackRate to reset to 1
        if(MyPlayer._player.playbackRate != MyPlayer._playbackRate) {

            MyPlayer._player.playbackRate = MyPlayer._playbackRate
        }
    }
}


MyPlayer.setPlayPauseListener = function (togglePlayPauseListener) {
    MyPlayer._playPauseChangeListenerCallback = togglePlayPauseListener
}


MyPlayer.togglePlayPause =  function() {

    this._isPlaying = !this._isPlaying

    if(this._isPlaying) {
        MyPlayer.play()
    }
    else {
        MyPlayer.pause()
    }
}

