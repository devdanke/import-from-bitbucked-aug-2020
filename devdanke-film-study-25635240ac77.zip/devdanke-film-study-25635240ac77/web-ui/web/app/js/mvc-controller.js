/*
For whenever movie or scene changes.

This is/will become the Controller that cooridinates between Model and UI.
Also it wants to keep Model and UI from knowing about each other.
 */

function initialControllerAppSetup() {
   LoopState.setLoopModeChangeListener(handleLoopModeChange)
}


function handleMovieChange(movieDirName) {

    console.info("Switch to movie:", movieDirName)
    var sceneDataForMovieUrl = getContentRootRelativeToAppIndex() +"content/" + movieDirName + "/_scenes.json";
    ajaxGet(sceneDataForMovieUrl, _initUiForMovieChangeWithAjaxResp);
}

/*
 recreate and init the scene buttons list.

 reset
 - re-choose default subtitle lang based on subs in new movie
 - volume to global default? [not happening yet]
 - playback rate to global default? [not happening yet]

 choose 1st scene in movie to be current movie
 */
function _initUiForMovieChangeWithAjaxResp(sceneData) {

    var contentRoot = getContentRootRelativeToAppIndex()

    LoopState.setMaxSceneId(sceneData.scenes.length)

    _recreateSceneNavButtons(sceneData.scenes, contentRoot)

    // TODO: In the future, get vtt types from movie.json. Let server prefigure this.
    SubCueManager.fillSubtitlesList(sceneData.scenes[0].subs);

    // make 1st scene ready to play
    $($SCENE_NAV_BTN_PREFIX+'1').click()

    // Defaults to super cue 'sc'.  Then 'en'
    SubCueManager.setDefaultSubtitleLang();
    console.info("Movie switch done")
}


/**
 * Initial ui setup, happens once at about page load time. Also gets called whenever movie selector changes.
 *
 * @param scenesData is contents of the movie's scenes.json file.
 */
function _recreateSceneNavButtons(scenes, contentRoot) {

    sceneListDivJq = $( "#sceneListDiv" )
    sceneListDivJq.empty()

    _.forEach(scenes, function(scene, index) {

        // create scene nav button
        var btnId = SCENE_NAV_BTN_PREFIX+(index+1);
        var $btnId = $SCENE_NAV_BTN_PREFIX+(index+1);
        sceneListDivJq.append("<button id='"+btnId+"' name='"+SCENE_NAV_BTN_NAME +"' class='scene-btn'>" +
            scene.title + "</button>")

        document.querySelector($btnId).onclick =  _createOnClickSceneHandler($btnId, scene, contentRoot)
    })
}

function _createOnClickSceneHandler($btnId, sceneData, contentRoot) {
    return function() {

        if($($btnId).hasClass(ACTIVE_BTN_CLASS)) {
            return // do nothing
        }
        console.info("Switch to scene:", sceneData.title)

        LoopState.setCurSceneId(sceneData.id)

        handleSceneChange(sceneData, contentRoot)

        // make all other scene nav buttons not active
        $("[name="+SCENE_NAV_BTN_NAME+"]").removeClass(ACTIVE_BTN_CLASS)

        // then make this button active
        $($btnId).addClass(ACTIVE_BTN_CLASS)
    }
}

/*
Only called by click on a sceneNavBtn. Not called programatically.

when a scene changes:

    - video
        - load new video into player

    - video location:
        - video position goes to 0
        - player stats -> current pos -> to 0

    - subtitle tracks
        - load new text tracks into player
        - make the new track that is the same as currentSubLang be active

    - cue nav buttons
        - recreate and wire up cue nav buttons
        - recreate and wire up loop bound slider
        - ui play state is set to 'not playing'
        - currently selected cue is set to null

    - looping
        - ui: looping button not active
        - model: looping goes to 'not looping'
        - loop bounds go to default, start & end time of new scene.

    - NOTES:
        - Don't change: volume, playback rate, subtitle lang
 */
function handleSceneChange(sceneData, contentRoot) {

    // TODO: Try to move some/all of this into MyPlayer.
    // TODO: I don't think the guts (src elem) of video player should be exposed like this.
    var srcElem = document.querySelector($VIDEO_SRC_ELEM_ID)
    srcElem.src = contentRoot + sceneData.vids[0].file
    MyPlayer.player().load()

    // recreate cue nav buttons for new scene.  Must load cueTimes via Ajax.
    // TODO: I may need to get these everytime subtitle lang changes.
    ajaxGet(contentRoot + sceneData.subs[0].cueTimes, createCueNavTable)

    /*
    Keep all user controls the same: playbackRate, volume, loopEnabled
    Reset: loopBounds to start/end of new scene.
     */
    onRateSliderChange($("#rateSlider").val())
    onVolumeSliderChange($("#volSlider").val())

    // reset counters & sliders
    MyPlayer.player().currentTime = 0  // todo: move into player

    showPlayBtnIcon(true)
    MyPlayer.stop()

    // todo: do as one step inside SubCueManager.
    SubCueManager.removeAllSubtitles(MyPlayer.player())
    SubCueManager.addTextTracks($($VIDEO_ELEM_ID), sceneData.subs, contentRoot)
    SubCueManager.setSubtitleLang(SubCueManager.getCurrentSubtitleLang())

    // if this is called too soon, some calls to slider bar fail because it's not yet create.  so wait a little.
    if(LoopState.cueLoopEnabled()) {
        window.setTimeout(LoopState.setLoopModeOff, 500);
    }

    console.log("Scene switch done.")
}


function goNextScene() {

    var nextSceneId = MyUtils.calcNextCircArray1BasedPos(LoopState.getCurSceneId(), LoopState.getMaxSceneId())
    LoopState.setCurSceneId(nextSceneId)
    $($SCENE_NAV_BTN_PREFIX+nextSceneId).click()
}


function goPrevScene() {

    var prevSceneId = MyUtils.calcPrevCircArray1BasedPos(LoopState.getCurSceneId(), LoopState.getMaxSceneId())
    LoopState.setCurSceneId(prevSceneId)
    $($SCENE_NAV_BTN_PREFIX+prevSceneId).click()
}


function onClickLoopMode() {

    LoopState.goToNextLoopMode()
}


var CUE_LOOP_ICON =   "fa-retweet"
var SCENE_LOOP_ICON = "fa-refresh"

function handleLoopModeChange(newLoopMode) {

    console.info("new loopMode:", newLoopMode)

    if( newLoopMode === LoopState.LOOP_OFF ) {

        makeLoopBoundsSliderBarLookInactive()

        $("#loopModeBtn").removeClass(ACTIVE_BTN_CLASS)

        $("#loopModeBtnIcon").removeClass(SCENE_LOOP_ICON)
        $("#loopModeBtnIcon").addClass(CUE_LOOP_ICON)
    }
    else if ( newLoopMode === LoopState.LOOP_CUE ) {

        makeLoopBoundsSliderBarLookActive()

        $("#loopModeBtn").addClass(ACTIVE_BTN_CLASS)

        $("#loopModeBtnIcon").removeClass(SCENE_LOOP_ICON)
        $("#loopModeBtnIcon").addClass(CUE_LOOP_ICON)
    }
    else if (newLoopMode === LoopState.LOOP_SCENE) {

        makeLoopBoundsSliderBarLookActive()
// TODO: Reset loop boundaries to min and max.  That makes the active slider bar look correct.

        // TODO: Maybe go to darker button shade or black to extra signify state change.
        $("#loopModeBtn").addClass(ACTIVE_BTN_CLASS)

        $("#loopModeBtnIcon").removeClass(CUE_LOOP_ICON)
        $("#loopModeBtnIcon").addClass(SCENE_LOOP_ICON)
    }
    else {
        console.error("Unknown loop mode:", newLoopMode)
    }
}

function handleDonePlayingSceneEvent() {

    if(LoopState.cueLoopEnabled()) {

        MyPlayer.goBackToBeginningOfLoop()
        //window.setTimeout(MyPlayer.play, 5000);
        MyPlayer.play()
    }
    else if (LoopState.sceneLoopEnabled()) {

        console.info("Finished playing video and in scene loop mode. Impl me.")

        goNextScene()
        window.setTimeout(MyPlayer.play, 1500);
    }
    else {
        console.info("Finished playing video and not in loop mode.  So I'll just wait for something to happen.")
        showPlayBtnIcon(false)//not playing, so show play icon
        MyPlayer.setPlayingState(false)
    }
}


/*
 Recieves continuous stream of pos change events from player.  For each:
 1) when we're at or beyond end of active cue loop, then go back to start of loop.
 2) update display of current time in video.

 */
function handlePositionChangeEvent(event) {

    var curTimeFracSec = MyPlayer.currentTime() // current time is a fractional second, e.g. 1.2
   // console.log("handlePositionChangeEvent() curTime:", curTimeFracSec, "event:", event)

    if(MyPlayer.isPlayingInCueLoop() && LoopBoundState.atOrBeyondLoopEnd(curTimeFracSec)) {

        // go back to begining of loop if we're in loop mode and playing.
        MyPlayer.goBackToBeginningOfLoop()
    }

    // This if-stmt protects against when makeCueBtnShowActiveCue() is called while video loads.
    if(curTimeFracSec > 0.1) {
        makeCueBtnShowActiveCue(curTimeFracSec)
    }

    // update display of current time
    // TODO: add this method to PlaybackStats.
    $("#curPos").text(MyUtils.formatCurSecForDisplay(parseInt(curTimeFracSec)))
}