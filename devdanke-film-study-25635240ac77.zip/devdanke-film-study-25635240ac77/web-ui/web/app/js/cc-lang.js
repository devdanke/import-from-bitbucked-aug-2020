// set from movie.json whenever movie selector changes.

function SubCueManager() {

    this._subtitleLangs = [CC_LANG_CODE]
    this._currentSubtitleLang = null
}

/*
 Works when there are exactly two languages.
 */
SubCueManager.setSubtitleLang = function(langCode) {

    SubCueManager._currentSubtitleLang = langCode

    _.forEach(MyPlayer.player().textTracks, function(track) {
        track.mode = (track.label == langCode) ? "showing" : "hidden"
    });

    // set button label to current lang.  must be called here, because this method is called by js.
    $("#langCodeText").text(langCode)
}

SubCueManager.getCurrentSubtitleLang = function() {
    return SubCueManager._currentSubtitleLang;
}


/*
Find the next subtitle language to use from the multi-value toggle languages source array.
TODO: maybe move this to a util func for iterating circular array.
 */
SubCueManager._calcNextSubtitleLang = function() {

    // get val of strong elem id=langCodeText
    var langCode = $("#langCodeText").text()

    // find it's pos in ciruclar array
    var curIndex = SubCueManager._subtitleLangs.indexOf(langCode)

    // use next elem in the array unless it would be past the end.
    var nextIndex = curIndex + 1
    if(nextIndex >= (SubCueManager._subtitleLangs.length)) {
        nextIndex = 0;
    }

    //console.log("langCode:", langCode)
    var nextLangCode = SubCueManager._subtitleLangs[nextIndex]
    return nextLangCode
}

SubCueManager.onClickSubtitleLang = function() {

    var langCode = SubCueManager._calcNextSubtitleLang()
    SubCueManager.setSubtitleLang(langCode)
}

/*
Do before loading new ones when scene/movie changes.
 */
SubCueManager.removeAllSubtitles = function(player) {

    // remove any current text tracks
    if(player.textTracks.length > 0) {

        SubCueManager._subtitleLangs.forEach(function(lang) {

            var targElem = document.querySelector("#"+lang+"SubTrack")
            if(targElem != null) {
                player.removeChild(targElem)
            }
        });
    }
}

/*
Called whenever meta data for new movie is loaded.
 */
SubCueManager.fillSubtitlesList = function (subs) {

    SubCueManager._subtitleLangs = [CC_LANG_CODE]

    _.forEach(subs, function(sub) {
        SubCueManager._subtitleLangs.push(sub.lang)
    })
}


SubCueManager.addTextTracks = function (jqPlayer, subsLangDataArray, contentRoot) {

    subsLangDataArray.forEach(function(subLangData) {

        jqPlayer.append( "<track " +
            "id='"+subLangData.lang+"SubTrack' " +
           // "class='myVttTrack' " +
            "kind='subtitles' " +
            "label='"+subLangData.lang+"' " +
            "src='"+(contentRoot + subLangData.file)+"' " +
            "srclang='"+subLangData.lang+"'>" +
            "</track>")
    });
}

SubCueManager.setDefaultSubtitleLang = function () {

    if(SubCueManager._subtitleLangs.indexOf(SUPER_CUE_LANG_CODE) >= 0) {
        SubCueManager.setSubtitleLang(SUPER_CUE_LANG_CODE)
    }
    else {
        SubCueManager.setSubtitleLang('en') // default for the default;-)
    }
}

