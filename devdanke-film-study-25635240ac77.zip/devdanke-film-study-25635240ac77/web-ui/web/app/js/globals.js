// todo: move into slider ui component
var gLoopBoundsSlider = null

var SCENE_NAV_BTN_PREFIX = "sceneNavBtn-";
var $SCENE_NAV_BTN_PREFIX = "#sceneNavBtn-";
var SCENE_NAV_BTN_NAME = "sceneNavBtnName";

// Leading $ means it has pound symbol
// Mainly used for jquery lookup.
var $VIDEO_SRC_ELEM_ID = "#vSrc";
var $VIDEO_ELEM_ID = "#vPlayer";

var SUPER_CUE_LANG_CODE = "sc";
var CC_LANG_CODE = "cc";

var ACTIVE_BTN_CLASS = "activeBtn";

