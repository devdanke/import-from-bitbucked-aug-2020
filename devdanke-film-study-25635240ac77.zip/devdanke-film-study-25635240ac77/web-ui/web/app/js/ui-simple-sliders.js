
/*
param val is float.
 */
function onRateSliderChange(val50to100) {

    //console.log("Sliders.onRateSliderChange(): val:", val)
    MyPlayer.setPlaybackRate(val50to100)
    PlaybackStats.updateRateDisplay(val50to100)
}

function onVolumeSliderChange(val1to100) {
    MyPlayer.player().volume = (val1to100/100)
}


function volListener() {
    var vol = MyPlayer.player().volume
    var volX100 = Math.round(100*vol)
    var volInt = parseInt(volX100)
    var volPad = _.padStart(volInt, 5)

    //console.log("volListener() vol:", vol, "volX100:", volX100, "volInt:", volInt)
    $("#curVol").text(volPad)
}

