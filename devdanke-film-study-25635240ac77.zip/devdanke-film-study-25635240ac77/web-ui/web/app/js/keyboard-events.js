/*
 space bar to start and stop video playback.
 */
var KEY_SPACE_BAR =   32
var KEY_LEFT_ARROW =  37
var KEY_RIGHT_ARROW = 39
var KEY_UP_ARROW =    38
var KEY_DOWN_ARROW =  40


function checkKeyPressed(evt) {

    //console.log("kevent:", evt)

    var handled = false

    if ( evt.keyCode == KEY_SPACE_BAR) {

        MyPlayer.togglePlayPause()
        handled = true
    }

    else if(evt.keyCode == KEY_LEFT_ARROW && evt.altKey) {
        goPrevScene()
        handled = true
    }
    else if(evt.keyCode == KEY_RIGHT_ARROW && evt.altKey) {
        goNextScene()
        handled = true
    }

    else if(evt.keyCode == KEY_LEFT_ARROW && evt.metaKey) {
        console.log("ignore Cmd left")
        handled = true
    }
    else if(evt.keyCode == KEY_RIGHT_ARROW && evt.metaKey) {
        console.log("ignore Cmd right")
        handled = true
    }

    else if(evt.keyCode == KEY_LEFT_ARROW && evt.ctrlKey) {
        console.log("ignore ctrl left")
        handled = true
    }
    else if(evt.keyCode == KEY_RIGHT_ARROW && evt.ctrlKey) {
        console.log("ignore ctrl right")
        handled = true
    }

    else if(evt.keyCode == KEY_LEFT_ARROW) {
        console.log("go to Prev cue")
        MyPlayer.goPrevCue()
        handled = true
    }
    else if(evt.keyCode == KEY_RIGHT_ARROW) {
        console.log("go to Next cue")
        MyPlayer.goNextCue()
        handled = true
    }

    else if(evt.keyCode == KEY_UP_ARROW) {
        MyPlayer.incPlaybackRate()
        handled = true
    }
    else if(evt.keyCode == KEY_DOWN_ARROW) {
        MyPlayer.decPlaybackRate()
        handled = true
    }

    if(handled) {
        //console.log("evt=" , evt.type, "target", evt.currentTarget)
        evt.stopPropagation()
        evt.preventDefault()
        return false
    }
    else {
        return true
    }
}


function initKeys() {
    window.addEventListener("keydown", checkKeyPressed);
}