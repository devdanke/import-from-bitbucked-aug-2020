
function PlaybackStats() {}

/*
newRate: a float convertable to percent with css 1 decimal place, 100.0% to 50.0%,
eg 0.5 or 1.0 or 0.775 or 0.65
 */
PlaybackStats.updateRateDisplay = function (newRate) {
    //console.log("PlaybackStats.updateRateDisplay() newRate:", newRate)
    $("#curRate").text(_.padStart(parseFloat(newRate).toFixed(1),5))
}

