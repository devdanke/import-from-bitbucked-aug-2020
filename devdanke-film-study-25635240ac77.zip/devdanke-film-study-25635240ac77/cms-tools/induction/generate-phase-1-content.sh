#!/bin/bash
set -e

#
# Takes 1 param: movie name, e.g. american-schniper
#

#CONTENT_BASE_DIR=/Users/me/_content/film-study/1-ready-basic-prep
CONTENT_BASE_DIR=/Users/me/_content/film-study/
CONTENT_BASE_DIR=
/Users/me/_content/film-study/fan-chan-1/fan-chan-1.srt
/Users/me/_content/film-study/fan-chan-1

movieName=$1
echo "Generate phase 1 content for: $movieName"

movieDir=$CONTENT_BASE_DIR/${movieName}
inMkvFile=$movieDir/${movieName}.mkv
outMp4File=$movieDir/${movieName}.mp4
outThAacFile=$movieDir/${movieName}-th.aac

# extract mp4 with en & th audio
./bin/vid-basic/extract-av-from-mkv.sh $inMkvFile $outMp4File

# the most valuable part of the video.
./bin/vid-basic/extract-th-audio.sh $inMkvFile $outThAacFile

# convert srt to vtt
#./bin/subs/convert.gy $movieDir/$movieName.en.srt $movieDir
#./bin/subs/convert.gy $movieDir/$movieName.th.srt $movieDir

#touch $movieDir/scene-defs.csv