#!/bin/bash

#
# There are several ways to get media info.
# ffprobe, mediainfo, and ffmpeg
#

set -e

targVideoFile=$1
echo ""
echo ""
echo "********** ffmpeg *************"
echo ""
ffmpeg -i $targVideoFile ffmpeg -i file.mp4 2>&1 | grep Stream
echo ""


# echo ""
# echo "********* ffprobe ************"
# echo ""
# ffprobe $targVideoFile -hide_banner