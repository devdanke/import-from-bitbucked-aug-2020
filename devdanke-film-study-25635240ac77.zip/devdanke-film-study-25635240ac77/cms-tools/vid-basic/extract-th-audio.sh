#!/bin/bash
set -e

if [[ $# -ne 2 ]] ; then
    echo 'usage: extract-th-audio <input mkv file path> <output acc file path>'
    exit -665
fi

echo "NOTE: Assumes Thai audio is 3rd item in mkv (aka -map 0:2)."

inMkv=$1
outAudio=$2

ffmpeg -i $inMkv -map 0:2 -c copy $outAudio

