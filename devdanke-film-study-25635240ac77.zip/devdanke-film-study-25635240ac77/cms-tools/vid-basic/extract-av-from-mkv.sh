#!/bin/bash
set -e

#
# Extract video and both audio tracks
#
# Notes:
#   Try to extract English into audio position #1
#   Currently, this extracts 1st two audio tracks.
#   If there are more, then I must add more mapping statements.
#   I could write a script to count the audio tracks.
#   http://stackoverflow.com/questions/32922226/extract-every-audio-and-subtitles-from-a-video-with-ffmpeg
#

if [[ $# -ne 2 ]] ; then
    echo 'usage: extract-av-from-mkv <input mkv file path> <output mp4 file path>'
    exit 665
fi

IN_FILE=$1
OUT_FILE=$2


NAME_AUDIO_TRACKS="-metadata:s:a:0 language=tha -metadata:s:a:1 language=eng"
MAKE_EN_DEFAULT_TRACK="  -disposition:a:0 default   -disposition:a:1 none"
EXCLUDE_CHAPTER_TRACK="-sn  -map_metadata -1 -map_chapters -1"
MISC_FLAGS=" -hide_banner -y " # Hide banner and yes do overwrite

ffmpeg -i $IN_FILE ${debugVidSample} ${EXCLUDE_CHAPTER_TRACK} -map 0:0 -map 0:2 -map 0:1 ${NAME_AUDIO_TRACKS} ${MAKE_EN_DEFAULT_TRACK} -c copy $OUT_FILE $MISC_FLAGS


# obsolete feb 10: This is how to change audio track position.
# ffmpeg -i $IN_FILE ${debugVidSample} ${EXCLUDE_CHAPTER_TRACK} -map 0:0 -map 0:2 -map 0:1 ${NAME_AUDIO_TRACKS} ${MAKE_EN_DEFAULT_TRACK} -c copy $OUT_FILE $MISC_FLAGS


# This is how to do small transform for debugging.
# debugVidSample="-ss 00:10:00 -t 00:20:00"
# ffmpeg -i $IN_FILE ${debugVidSample} ${EXCLUDE_CHAPTER_TRACK} -map 0:0 -map 0:2 -map 0:1 ${NAME_AUDIO_TRACKS} ${MAKE_EN_DEFAULT_TRACK} -c copy $OUT_FILE $MISC_FLAGS

