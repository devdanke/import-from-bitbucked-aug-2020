package foo.util;

import foo.db.CsvImporter;
import foo.db.DbHelper;
import foo.db.SqlHelper;
import lombok.extern.slf4j.Slf4j;

import javax.sql.DataSource;

@Slf4j
public class CreateAndLoadDb {

    public static void main(String[] args) throws Exception {
/*
        String dbDir = "/Users/me/_dev/film-study/dictionary/db";
        String dbName = "ThaiDictDb";
        String dbSchema = "t2e";

        DataSource ds = DbHelper.createDsAndSchema(dbDir, dbName, dbSchema);

        CsvImporter.importCsvIntoTable(ds,
            "/Users/me/_dev/film-study/dictionary/data/t2e-2008-dict-20170329.csv",
            dbSchema+".t2e_2008_dict_20170329");

        ds = DbHelper.createDsOnlyIfDbExists(dbDir, dbName, dbSchema);

        SqlHelper.showTableNames(ds, dbSchema);

*/
    }
}
