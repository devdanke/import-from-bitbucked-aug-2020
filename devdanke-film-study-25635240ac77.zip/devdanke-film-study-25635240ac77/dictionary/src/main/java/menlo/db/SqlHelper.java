package foo.db;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.ArrayHandler;
import org.apache.commons.dbutils.handlers.ArrayListHandler;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import static java.lang.String.format;
import static java.util.Arrays.asList;

@Slf4j
public class SqlHelper {

    public static void runCommand(DataSource ds, String sql) {

        try ( Connection con = ds.getConnection();
            Statement stmt = con.createStatement() ) {

            stmt.executeUpdate(sql);
        }
        catch (SQLException se) {
            throw new RuntimeException(se);
        }
    }


    public static List<String> getAllTables(DataSource ds, String schemaName) {

        List<String> tableNames = Lists.newArrayList();

        try (Connection con = ds.getConnection();
            Statement stmt = con.createStatement()) {

            ResultSet rs = stmt.executeQuery(
                "SELECT TABLE_SCHEMA, TABLE_NAME " +
                    "FROM INFORMATION_SCHEMA.TABLES " +
                    "WHERE TABLE_SCHEMA = '" + schemaName.toUpperCase() + "' " +
                    "ORDER BY TABLE_SCHEMA, TABLE_NAME;"
            );

            while (rs.next()) {

                //String fullTableName = format("%s.%s", rs.getString(1), rs.getString(2));
                String tableName = rs.getString(2);
                tableNames.add(tableName);
                log.debug("Found table: {}", tableName);
            }

            stmt.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return tableNames;
    }

    public static void showTableNames(DataSource ds, String schemaName) {

       List<String> tableNames = getAllTables(ds, schemaName);
       log.info("Count of tables in {} schema {}.", schemaName, tableNames.size());
       tableNames.stream().forEach(System.out::println);
    }

    public static void showTableRows(DataSource ds, String tableName) {

        try {
            QueryRunner run = new QueryRunner(ds);

            ResultSetHandler<List<Object[]>> arrayHandler = new ArrayListHandler();

            // Execute the query and get the results back from the handler
            List<Object[]> results = run.query("select * from " + tableName, arrayHandler);

            results.stream().forEach( row -> {

                log.debug(Joiner.on(" | ").useForNull("null").join(row));
            });

        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static List<String> getAllRowsAsStrings(DataSource ds, String tableName) {

        List<String> rows = Lists.newArrayList();

        try {
            QueryRunner run = new QueryRunner(ds);

            ResultSetHandler<List<Object[]>> arrayHandler = new ArrayListHandler();

            // Execute the query and get the results back from the handler
            List<Object[]> results = run.query("select * from " + tableName, arrayHandler);

            results.stream().forEach( row -> {

                rows.add(Joiner.on(" | ").useForNull("null").join(row));
            });
            return  rows;
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /*
    Create ResultSetHandler to convert first row into an Object[].
    Create a QueryRunner that will use connections from the given DataSource
     */
    public static String resultSetToString(DataSource ds, String sqlSelect) throws SQLException {

        QueryRunner run = new QueryRunner(ds);

        ResultSetHandler<Object[]> arrayHandler = new ArrayHandler();

        // Execute the query and get the results back from the handler
        Object[] result = run.query(sqlSelect, arrayHandler);

        StringBuilder sb = new StringBuilder();

        List list = asList(result);

        for (Object obj : list) {
            if(obj != null) {
                sb.append(obj.toString());
            }
            else {
                sb.append("null");
            }
            sb.append("|");
        }

        return sb.toString();
    }

}
