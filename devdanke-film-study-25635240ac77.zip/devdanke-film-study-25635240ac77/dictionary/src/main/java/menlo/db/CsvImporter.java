package foo.db;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.sql.DataSource;
import java.io.File;

import static foo.db.SqlHelper.runCommand;
import static java.lang.String.format;

@Slf4j
@Data
public class CsvImporter {

    /*
        Given a csv file path, import the file into h2.
     */
    public static void importAllCsvInDirIntoSchema(DataSource ds, String csvDirPath, String schemaName,
        String destRelDbDir) {

        try {
            File dir = new File(csvDirPath);
            String[] listOfFiles = dir.list();

            for(String fileName : listOfFiles) {
                log.debug("File: {}", fileName);

                if(fileName.toLowerCase().endsWith(".csv")) {

                    String csvFilePath = csvDirPath + "/" + fileName;
                    importCsvIntoTable(ds, csvFilePath, convertFileNameToFullTableName(fileName, schemaName));
                }
            }
        }
        catch(Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void importCsvIntoTable(DataSource ds, String csvFilePath, String tableNameFull) {

        runCommand(ds, "DROP TABLE IF EXISTS " + tableNameFull + ";" );
        runCommand(ds, "CREATE TABLE " + tableNameFull + " AS SELECT * FROM CSVREAD('" + csvFilePath + "');" );
        log.info("Created and loaded table {} from file {}.", tableNameFull, csvFilePath);
    }

    public static String convertFileNameToFullTableName(String fileName, String schemaName) {

        //log.debug("fileName: {}", fileName);
        String tableName = fileName.toLowerCase();
        tableName = tableName.substring(0, tableName.indexOf(".csv"));
        tableName = tableName.replace("-", "_");
        return schemaName + "." + tableName;
    }



}
