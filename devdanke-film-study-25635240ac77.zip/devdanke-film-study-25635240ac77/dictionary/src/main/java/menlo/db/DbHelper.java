package foo.db;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.h2.jdbcx.JdbcDataSource;

import javax.sql.DataSource;
import java.io.File;

import static foo.db.SqlHelper.runCommand;
import static java.lang.String.format;

@Slf4j
@Data
public class DbHelper {


    public static JdbcDataSource createDs(String dbDirPath, String dbName, String dbSchemaName) {

        JdbcDataSource ds = new JdbcDataSource();
        ds.setURL(format("jdbc:h2:%s/%s;SCHEMA=%s", dbDirPath, dbName, dbSchemaName));
        return ds;
    }

    /**
     * For when DB and schema don't yet exist.
     */
    public static JdbcDataSource createDsAndSchema(String dbDirPath, String dbName, String dbSchemaName) {

        JdbcDataSource ds = new JdbcDataSource();
        ds.setURL(format("jdbc:h2:%s/%s", dbDirPath, dbName));
        SqlHelper.runCommand(ds, "CREATE SCHEMA IF NOT EXISTS " + dbSchemaName + ";" );
        return ds;
    }


    public static JdbcDataSource createDsOnlyIfDbExists(String dbDirPath, String dbName, String dbSchemaName) {

        JdbcDataSource ds = new JdbcDataSource();
        ds.setURL(format("jdbc:h2:%s/%s;SCHEMA=%s;IFEXISTS=TRUE", dbDirPath, dbName, dbSchemaName));
        log.info("dbConnStr: {}", ds.getUrl());
        return ds;
    }

    //
}
