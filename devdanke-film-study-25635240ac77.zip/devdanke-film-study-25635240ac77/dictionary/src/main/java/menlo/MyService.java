package foo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.List;

@Component
public class MyService {

    private MyDao dao;

    @Autowired
    public MyService(MyDao dao) {
        this.dao = dao;
    }

    public List<String> getAllTables() {

        return dao.getAllTableNames();
    }


    public List<Object[]> getAllRows(String tableName) {

        return dao.getAllRows(tableName);
    }
}
