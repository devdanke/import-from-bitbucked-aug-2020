package foo;


import foo.db.DbHelper;
import foo.db.SqlHelper;
import lombok.extern.slf4j.Slf4j;
import org.h2.jdbcx.JdbcDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.sql.DataSource;
import java.io.File;

import static java.lang.String.format;

@EnableAutoConfiguration
@SpringBootApplication
@Slf4j
public class MyApp {

    @Value("${db.dirPath}")
    private String dbDirPath;

    @Value("${db.name}")
    private String dbName;

    @Value("${db.schemaName}")
    private String dbSchemaName;

    @Value("${csvDirPath}")
    private String csvDirPath;


    @Autowired
    private DataSource ds;

    public static void main(String[] args) throws Exception {
        SpringApplication.run(MyApp.class, args);
    }

    /*
    If DB doesn't exist create it.
    If DB created, then load all tables.
     */
    @PostConstruct
    public void init() {

        String dbFilePath = format("%s/%s", dbDirPath, dbName);

        if(!(new File(dbFilePath)).exists()) {

            log.info("DB {} not found. Will create.", dbFilePath);

            SqlHelper.runCommand(ds, "CREATE SCHEMA IF NOT EXISTS " + dbSchemaName + ";" );

            //CsvImporter.importAllCsvInDirIntoSchema(ds, csvDirPath, dbSchemaName);
            log.info("DB created and csv files importer.");
        }
    }

    @PreDestroy
    public void cleanup() {
        log.info("Shutting down......... .... .... ... ...  .. . .   .   .");
    }

    @Bean
    public JdbcDataSource dataSource() {

        return DbHelper.createDsOnlyIfDbExists(dbDirPath, dbName, dbSchemaName);
    }

    /*
    TOOD:
    - Load or find DB (or both)
    - add endpoints
        GET /tables -> list of tables as json
        GET /tables/name -> all rows in that table as json
        Add freemarker page to show the list of tables
        Add freemaker page to show the table contents in an html table.
     */

}
