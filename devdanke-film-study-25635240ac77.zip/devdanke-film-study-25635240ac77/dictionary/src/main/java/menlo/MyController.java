package foo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MyController {

    private MyService myService;

    @Autowired
    public MyController(MyService myService) {
        this.myService = myService;
    }

    @RequestMapping("/")
    @ResponseBody
    String home() {
        return "Hello World!";
    }

    @RequestMapping(method= RequestMethod.GET, path="/tables" )
    @ResponseBody
    List<String> getAllTables() {

        return myService.getAllTables();
    }

    @RequestMapping(method= RequestMethod.GET, path="/tables/{tableName}/rows" )
    @ResponseBody
    List<Object[]> getAllRows(@PathVariable String tableName) {

        return myService.getAllRows(tableName);
    }

}
