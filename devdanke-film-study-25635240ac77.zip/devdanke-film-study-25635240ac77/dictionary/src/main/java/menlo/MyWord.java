package foo;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MyWord {

    private static final Joiner COMMA_JOINER = Joiner.on(",");
    private static final Joiner SEMICOLON_JOINER = Joiner.on(";");

    private String th;
    private String phonetic;
    private List<String> meanings; // in english, most popular first
    private String notes;


    // Get 1st item in meanings.
    public String getEn() {
        return meanings.get(0);
    }

    public String toCsv() {
       return COMMA_JOINER.join(Lists.newArrayList(th, phonetic, SEMICOLON_JOINER.join(meanings),
           notes));
    }

    public static final MyWord fromCsvParsedLine(String[] myWordParts) {

        return new MyWord(myWordParts[0], myWordParts[1], Arrays.asList(myWordParts[2].split(";")),
            myWordParts[3]);
    }
}
