package foo;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.ArrayHandler;
import org.apache.commons.dbutils.handlers.ArrayListHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import static java.util.Arrays.asList;

@Component
@Slf4j
public class MyDao {


    @Value("${db.schemaName}")
    private String dbSchemaName;

    private final DataSource ds;

    @Autowired
    public MyDao(DataSource ds) {
        this.ds = ds;
    }


    public List<String> getAllTableNames() {

        List<String> tableNames = Lists.newArrayList();

        try (Connection con = ds.getConnection();
            Statement stmt = con.createStatement()) {

            ResultSet rs = stmt.executeQuery(
                "SELECT TABLE_SCHEMA, TABLE_NAME " +
                    "FROM INFORMATION_SCHEMA.TABLES " +
                    "WHERE TABLE_SCHEMA = '" + dbSchemaName.toUpperCase() + "' " +
                    "ORDER BY TABLE_SCHEMA, TABLE_NAME;"
            );

            while (rs.next()) {

                //String fullTableName = format("%s.%s", rs.getString(1), rs.getString(2));
                String tableName = rs.getString(2);
                tableNames.add(tableName);
                log.debug("Found table: {}", tableName);
            }

            stmt.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return tableNames;
    }

    public List<Object[]> getAllRows(String tableName) {

        try {
            QueryRunner run = new QueryRunner(ds);

            ResultSetHandler<List<Object[]>> arrayHandler = new ArrayListHandler();

            // Execute the query and get the results back from the handler
            return run.query("select * from " + tableName, arrayHandler);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    private void runCommand(DataSource ds, String sql) {

        try ( Connection con = ds.getConnection();
            Statement stmt = con.createStatement() ) {

            stmt.executeUpdate(sql);
        }
        catch (SQLException se) {
            throw new RuntimeException(se);
        }
    }

}
