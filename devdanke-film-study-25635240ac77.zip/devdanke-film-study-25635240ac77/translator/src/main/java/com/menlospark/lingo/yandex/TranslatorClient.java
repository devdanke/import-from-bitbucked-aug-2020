package com.menlospark.lingo.yandex;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.vtt.VttOutputter;
import com.menlospark.lingo.subtility.vtt.VttParser;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.http.Consts;
import org.apache.http.HttpHeaders;
import org.apache.http.NameValuePair;
import org.apache.http.client.fluent.Content;
import org.apache.http.client.fluent.Form;
import org.apache.http.client.fluent.Request;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
public class TranslatorClient {

    static final int BATCH_SIZE = 100; // subtitles per batch
    static final String ITEM_PREFIX_TOKEN = "@@@"; // distinguish item # from number at start of text line.
    static final ObjectMapper JSON = new ObjectMapper();
    static final String YANDEX_URL = "https://translate.yandex.net/api/v1.5/tr.json/translate";


    public static void main(String[] args) throws Exception {
/*
        System.setProperty("org.apache.commons.logging.Log","org.apache.commons.logging.impl.SimpleLog");
        System.setProperty("org.apache.commons.logging.simplelog.showdatetime", "true");
        System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http.wire", "DEBUG");
        System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http.impl.conn", "DEBUG");
        System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http.impl.client", "DEBUG");
        System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http.client", "DEBUG");
        System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http", "DEBUG");
*/
        String CONTENT_ROOT_DIR = "/Users/me/_content/film-study";

//        translateThaiToEnglish(CONTENT_ROOT_DIR, "age-of-adaline");
  //      translateThaiToEnglish(CONTENT_ROOT_DIR, "transporter");
      //  translateThaiToEnglish(CONTENT_ROOT_DIR, "american-sniper");
        translateThaiToEnglish(CONTENT_ROOT_DIR, "avatar");
    }


    /*
    This method read from an writes to same dir.
    Movie dir is assumed to be contentRootDir/movieName.
    Input and output files are movieName.th.vtt and movieName.mt.vtt.
    "mt" means "machine translation".
     */
    static void translateThaiToEnglish(String contentDirRoot, String movieName) {
        try {
            File contentBaseDir = new File(contentDirRoot);
            File movieDir = new File(contentBaseDir, movieName);
            File thVttFile = new File(movieDir, movieName+".th.vtt");
            File outputFile = new File(movieDir, movieName+".mt.vtt");

            if(!thVttFile.exists()) {
                throw new Exception("Can't find file: " + thVttFile.getAbsolutePath());
            }

            List<Cue> cues = new VttParser().parse(FileUtils.readLines(thVttFile));

            List<String> translatedLines = translateInBatches(cues);

            List<Cue> translatedCues = copyTranslationsIntoCues(translatedLines, cues);

            VttOutputter.makeVttFile(outputFile, translatedCues);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    static List<Cue> copyTranslationsIntoCues(List<String> translatedLines, List<Cue> cues) {

        Map<Integer,List<String>> transLinesByItemNum = convertToCueishMap(translatedLines);

        List<Cue> translatedCues = cues.stream().map(cue -> {
            cue.setLines(transLinesByItemNum.get(cue.getItemNumber()));
            return cue;
        }).collect(Collectors.toList());

        return cues;
    }

    /*
    Stay under Yandex translate API's max character count limit per post request.
     */
    static List<String> translateInBatches(List<Cue> cues) {

        List<String> translatedLines = Lists.newArrayList();

        int lastCueIndex = cues.size() - 1;
        int fromIndex = 0;
        int toIndex = (cues.size() > BATCH_SIZE) ? BATCH_SIZE : lastCueIndex;
        List<Cue> subCues = null;

        while(!(subCues = cues.subList(fromIndex, toIndex + 1)).isEmpty()) {

            List<String> lines = convertToLines(subCues);
            translatedLines.addAll(translate(lines));

            fromIndex += BATCH_SIZE;
            if(fromIndex > (lastCueIndex - 1)) {
                break;
            }
            int candidateToIndex = toIndex + BATCH_SIZE;
            toIndex = (candidateToIndex > cues.size()) ? lastCueIndex : candidateToIndex ;
        }

        return translatedLines;
    }


    static List<String> convertToLines(List<Cue> cues) {

        List<String> lines = Lists.newArrayList();

        cues.stream().forEach(cue -> {
            lines.add(ITEM_PREFIX_TOKEN +cue.getItemNumber());
            lines.addAll(cue.getLines());
        });

        return lines;
    }

    static Map<Integer,List<String>> convertToCueishMap(List<String> lines) {

        Map<Integer,List<String>> map = Maps.newHashMap();

        int i = 0;
        while(i < lines.size()) {

            Integer curItemNumber = parseItemNumber(lines.get(i++));

            List<String> cueLines = Lists.newArrayList();
            while((i < lines.size()) && !lines.get(i).startsWith(ITEM_PREFIX_TOKEN)) {
               cueLines.add(lines.get(i++));
            }
            map.put(curItemNumber, cueLines);
        }

        return map;
    }

    static Integer parseItemNumber(String s) {
        return Integer.parseInt(s.substring(ITEM_PREFIX_TOKEN.length()));
    }


    static List<String> translate(List<String> lines) {

        Form form = Form.form();
        form.add("lang", "th-en");
        form.add("key", "trnsl.1.1.20170305T040137Z.c7cf0dc125ad6511.7eac5bf5040470466d78cae95415bdb396ebb0f1");

        lines.stream().forEach( line -> form.add("text", line));
        List<NameValuePair> formData = form.build();
        log.debug("\nBODY: {}\n", formData.toString());

        try {
            Request request = Request.Post(YANDEX_URL)
                    .addHeader("Content-Type","application/x-www-form-urlencoded")
                    .addHeader("Accept","*/*")
                    .bodyForm(formData, Consts.UTF_8);

            Content content = request.execute().returnContent();

            return (List<String>) JSON.readValue(content.asString(Consts.UTF_8), Map.class).get("text");
        }
        catch (Exception e) {
            e.fillInStackTrace();
            throw new RuntimeException(e);
        }
    }

}
