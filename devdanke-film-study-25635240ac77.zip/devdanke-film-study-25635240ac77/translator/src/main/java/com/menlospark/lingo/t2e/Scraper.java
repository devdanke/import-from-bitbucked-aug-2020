package com.menlospark.lingo.t2e;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;




import java.util.List;

/**
 * Created by me on 3/20/17.
 */
public class Scraper {

    public static void scrape(List<String> targets) {

        java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
        java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);

        try {
            WebClient webClient = new WebClient();
            webClient.getOptions().setThrowExceptionOnScriptError(false);



            final HtmlPage page = webClient.getPage("http://www.thai2english.com/");

            HtmlElement elem = page.getHtmlElementById("unspacedText");

            elem.setTextContent(Joiner.on(' ').join(targets));

            page.getHtmlElementById("submitMainForm").click();
            webClient.waitForBackgroundJavaScript(6000);


            String resultHtml = page.asXml();

            Document doc = Jsoup.parseBodyFragment(resultHtml);

            Element meaningsDiv = doc.getElementsByClass("t2e_lineMeanings").first();


            int i=1;
        }
        catch(Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {
        scrape(Lists.newArrayList("ยาก","จะ","สังหาร"));
    }
}
