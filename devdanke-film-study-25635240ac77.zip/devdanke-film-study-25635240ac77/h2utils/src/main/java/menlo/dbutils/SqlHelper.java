package menlo.dbutils;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.ArrayHandler;
import org.apache.commons.dbutils.handlers.ArrayListHandler;

import javax.sql.DataSource;
import java.sql.*;
import java.util.List;
import java.util.stream.Collectors;

import static java.lang.String.format;
import static java.util.Arrays.asList;

@Slf4j
public class SqlHelper {

    public static List<String> getTableColNames(DataSource ds, String fullyQualifiedTableName) {

        try ( Connection con = ds.getConnection();
            Statement stmt = con.createStatement() ) {

            ResultSet rs = stmt.executeQuery("SELECT * FROM " + fullyQualifiedTableName);
            ResultSetMetaData rsmd = rs.getMetaData();
            List<String> colNames = Lists.newArrayList();
            for(int i=0; i<rsmd.getColumnCount(); i++) {
                colNames.add(rsmd.getColumnName(i+1));
            }
            return colNames;
        }
        catch (SQLException se) {
            throw new RuntimeException(se);
        }
    }

    public static void runCommand(DataSource ds, String sql) {

        try ( Connection con = ds.getConnection();
            Statement stmt = con.createStatement() ) {

            stmt.executeUpdate(sql);
        }
        catch (SQLException se) {
            throw new RuntimeException(se);
        }
    }

    public static boolean exactlyOneExists(DataSource ds, String tableName, String whereCriteria) {

        try ( Connection con = ds.getConnection();
            Statement stmt = con.createStatement() ) {

            String sql = "SELECT count(*) FROM " + tableName + " WHERE " + whereCriteria;
            log.info(sql);
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            return (rs.getInt(1) > 0);
        }
        catch (SQLException se) {
            throw new RuntimeException(se);
        }
    }

    /*
    This looks to rely on JDBC, so it's cross db.
    SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'name';
     */
    public static boolean schemaExists(DataSource ds, String schemaName) {
        return exactlyOneExists(ds, "information_schema.schemata", "schema_name = '" + schemaName + "'");
    }

    /*
    if list is [ a, b ]
    return " 'a', 'b' "
     */
    private static String convertSchemaNamesForWhereInCondition(List<String> schemaNames) {

        return Joiner.on(",").join(schemaNames.stream().map(sn -> "'"+sn+"'").collect(Collectors.toList()));
    }


    public static List<String> getAllTables(DataSource ds, List<String> schemaNames) {

        List<String> tableNames = Lists.newArrayList();

        try (Connection con = ds.getConnection();
            Statement stmt = con.createStatement()) {

            ResultSet rs = stmt.executeQuery(
                "SELECT TABLE_SCHEMA, TABLE_NAME " +
                    "FROM INFORMATION_SCHEMA.TABLES " +
                    "WHERE TABLE_SCHEMA IN ( " + convertSchemaNamesForWhereInCondition(schemaNames) + " ) " +
                    "ORDER BY TABLE_SCHEMA, TABLE_NAME;"
            );

            while (rs.next()) {

                String fullTableName = format("%s.%s", rs.getString(1), rs.getString(2));
                //String tableName = rs.getString(2);
                tableNames.add(fullTableName);
                log.debug("Found table: {}", fullTableName);
            }

            stmt.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return tableNames;
    }
/*
    public static void showTableNames(DataSource ds, String schemaName) {

       List<String> tableNames = getAllTables(ds, schemaName);
       log.info("Count of tables in {} schema {}.", schemaName, tableNames.size());
       tableNames.stream().forEach(System.out::println);
    }
*/
    public static void showTableRows(DataSource ds, String tableName) {

        try {
            QueryRunner run = new QueryRunner(ds);

            ResultSetHandler<List<Object[]>> arrayHandler = new ArrayListHandler();

            // Execute the query and get the results back from the handler
            List<Object[]> results = run.query("select * from " + tableName, arrayHandler);

            results.stream().forEach( row -> {

                log.debug(Joiner.on(" | ").useForNull("null").join(row));
            });

        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static List<String> getAllRowsAsStrings(DataSource ds, String tableName) {

        List<String> rows = Lists.newArrayList();

        try {
            QueryRunner run = new QueryRunner(ds);

            ResultSetHandler<List<Object[]>> arrayHandler = new ArrayListHandler();

            // Execute the query and get the results back from the handler
            List<Object[]> results = run.query("select * from " + tableName, arrayHandler);

            results.stream().forEach( row -> {

                rows.add(Joiner.on(" | ").useForNull("null").join(row));
            });
            return  rows;
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /*
    Create ResultSetHandler to convert first row into an Object[].
    Create a QueryRunner that will use connections from the given DataSource
     */
    public static String resultSetToString(DataSource ds, String sqlSelect) throws SQLException {

        QueryRunner run = new QueryRunner(ds);

        ResultSetHandler<Object[]> arrayHandler = new ArrayHandler();

        // Execute the query and get the results back from the handler
        Object[] result = run.query(sqlSelect, arrayHandler);

        StringBuilder sb = new StringBuilder();

        List list = asList(result);

        for (Object obj : list) {
            if(obj != null) {
                sb.append(obj.toString());
            }
            else {
                sb.append("null");
            }
            sb.append("|");
        }

        return sb.toString();
    }

}
