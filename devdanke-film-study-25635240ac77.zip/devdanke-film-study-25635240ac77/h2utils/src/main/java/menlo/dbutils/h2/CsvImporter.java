package menlo.dbutils.h2;

import com.google.common.collect.Lists;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import menlo.dbutils.SqlHelper;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.lang3.tuple.Triple;

import javax.sql.DataSource;
import java.io.File;
import java.io.FilenameFilter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Data
public class CsvImporter {

    private static FilenameFilter CSV_FILTER = new FilenameFilter() {
        @Override
        public boolean accept(File dir, String name) {
            return name.toLowerCase().endsWith(".csv");
        }
    };

    /*
        Given a csv file path, import the file into h2.
     */
    public static List<Pair<String,String>> importAllCsvInDirIntoSchema(DataSource ds, String csvDirPath, String schemaName) {

        List<Pair<String,String>>  csvImportInfos =  Lists.newArrayList();

        try {
            File dir = new File(csvDirPath);
            String[] csvFileList = dir.list(CSV_FILTER);

            for(String fileName : csvFileList) {

                log.debug("File: {}", fileName);
                String csvFilePath = csvDirPath + "/" + fileName;
                String tableName = convertFileNameToTableName(fileName);
                importCsvIntoTable(ds, csvFilePath, schemaName +"."+ tableName);

                csvImportInfos.add(Pair.of(tableName,fileName));
            }
            return csvImportInfos;
        }
        catch(Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void importCsvIntoTable(DataSource ds, String csvFilePath, String tableNameFull) {

        SqlHelper.runCommand(ds, "DROP TABLE IF EXISTS " + tableNameFull + ";" );
        SqlHelper.runCommand(ds, "CREATE TABLE " + tableNameFull + " AS SELECT * FROM CSVREAD('" + csvFilePath + "');" );
        log.info("Created and loaded table {} from file {}.", tableNameFull, csvFilePath);
    }

    public static String convertFileNameToTableName(String fileName) {

        String tableName = fileName.toLowerCase();
        tableName = tableName.substring(0, tableName.indexOf(".csv"));
        return tableName.replace("-", "_");
    }



}
