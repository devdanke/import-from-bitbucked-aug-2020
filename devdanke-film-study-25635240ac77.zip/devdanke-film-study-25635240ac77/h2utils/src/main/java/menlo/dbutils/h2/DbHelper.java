package menlo.dbutils.h2;

import lombok.extern.slf4j.Slf4j;
import org.h2.jdbcx.JdbcDataSource;

import static java.lang.String.format;

@Slf4j
public class DbHelper {

    public static JdbcDataSource createDsForTcp(String jdbcUrl) {

        JdbcDataSource ds = new JdbcDataSource();
        ds.setURL(jdbcUrl);

        log.info("DataSource: {}", ds.getUrl());

        return ds;
    }


    public static JdbcDataSource createDsForEmbedded(String dbDirPath, String dbName) {

        JdbcDataSource ds = new JdbcDataSource();
        ds.setURL(format("jdbc:h2:%s/%s", dbDirPath, dbName));

        log.info("DataSource: {}", ds.getUrl());

        return ds;
    }

    public static JdbcDataSource createDsForEmbedded(String dbDirPath, String dbName, String dbSchemaName) {

        JdbcDataSource ds = new JdbcDataSource();
        ds.setURL(format("jdbc:h2:%s/%s;SCHEMA=%s", dbDirPath, dbName, dbSchemaName));
        return ds;
    }

    /**
     * For when DB and schema don't yet exist.
     *
     * NOTE:  H2 specific!
     */
    public static JdbcDataSource createH2DsAndSchemaIfNotExists(String dbDirPath, String dbName, String dbSchemaName) {

        JdbcDataSource ds = new JdbcDataSource();

        ds.setURL(format("jdbc:h2:%s/%s;INIT=CREATE SCHEMA IF NOT EXISTS %s\\;SET SCHEMA %s",
            dbDirPath, dbName, dbSchemaName, dbSchemaName));

        return ds;
    }


    public static JdbcDataSource createH2DsOnlyIfDbExists(String dbDirPath, String dbName, String dbSchemaName) {

        JdbcDataSource ds = new JdbcDataSource();
        ds.setURL(format("jdbc:h2:%s/%s;SCHEMA=%s;IFEXISTS=TRUE", dbDirPath, dbName, dbSchemaName));
        log.info("dbConnStr: {}", ds.getUrl());
        return ds;
    }

    //
}
