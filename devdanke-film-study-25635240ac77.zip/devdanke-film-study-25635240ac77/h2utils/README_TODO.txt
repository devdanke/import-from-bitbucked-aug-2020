rename this project to db tools.

create class for h2 specific stuff.  make the maven dep optional.

18 apr 2015

