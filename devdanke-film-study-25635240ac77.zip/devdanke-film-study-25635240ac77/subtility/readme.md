## Purpose ##

Mainly this is to convert srt to vtt.
Once in vtt, can also to basic operations:

* time shift
* split

## How to Use ##

* see unit tests
* also see bin dir groovy scripts that use these classes.


## To Do ##

* convert action: convert srt to vtt
    args: infile, outdir
* shift action:   shift srt or vtt
    args: infile, outdir, offset secs
* split action:   create new file with only subs from this range.  
                  shift time to be relative to zero or offset seconds 
                  when given.
    args: infile (srt|vtt), start time, end time, and optional offset secs.              

## Problems/Questions/Issues ##