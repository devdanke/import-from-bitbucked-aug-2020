package com.menlospark.lingo.subtility;


import com.menlospark.lingo.subtility.features.runner.Main;
import org.junit.Test;

public class MainTest {

    String infile = "./target/test-classes/test-data/dear-galileo.srt";
    String infile2 = "./src/test/resources/test-data/MainTest.srt";
    String outdir = "./target";

    @Test
    public void testConvert()
    {
        String[] args = {
                "-a", "convert",
                "-i", infile,
                "-o", outdir};
        Main.main(args);
    }

    @Test
    public void testShift()
    {
        String[] args = {
                "--action", "shift",
                "--infile", infile,
                "--outdir", outdir,
                "--millis",  "1570"};
        Main.main(args);
    }

    /*
    def ranges="-r 00:01:00-00:11:00 -r 00:30:00.200-00:34:00.800"
    cmd =     "java -jar ./target/uber.jar --action split   --infile ${inFile} --outdir ${outDir} ${ranges}"
    output = cmd.execute().text
    println "OUTPUT--3--::::: ${output}"
     */
    @Test
    public void testSplitWithMoreThanOne()
    {
        String[] args = {
                "--action", "split",
                "--infile", infile2,
                "--outdir", outdir,
                "--range",  "00:01:00-00:11:00",
                "--range",  "00:30:00.200-00:34:00.800"
        };
        Main.main(args);
    }

    @Test
    public void testSplitWithOnlyOne()
    {
        String[] args = {
                "--action", "split",
                "--infile", infile2,
                "--outdir", outdir,
                "--range",  "00:01:00-00:11:00"
        };
        Main.main(args);
    }

}
