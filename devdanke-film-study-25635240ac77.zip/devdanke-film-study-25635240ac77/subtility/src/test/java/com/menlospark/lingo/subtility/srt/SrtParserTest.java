package com.menlospark.lingo.subtility.srt;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.srt.SrtParser;
import org.junit.Assert;
import org.junit.Test;


import java.net.URL;
import java.util.List;

public class SrtParserTest
{
    @Test
    public void testParse()
        throws Exception
    {
        URL url = Resources.getResource("test-data/parse-test-input.srt");
        List<String> lines = Resources.readLines(url, Charsets.UTF_8);
        List<Cue> subtitles = new SrtParser().parse(lines);

        Assert.assertEquals("cues count", subtitles.size(), 3);
    }

}
