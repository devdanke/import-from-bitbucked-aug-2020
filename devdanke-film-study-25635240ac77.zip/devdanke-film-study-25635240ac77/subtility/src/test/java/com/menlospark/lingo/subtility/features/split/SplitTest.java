package com.menlospark.lingo.subtility.features.split;


import com.google.common.collect.Lists;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.model.TimeRange;
import org.junit.Assert;
import org.junit.Test;

import java.time.LocalTime;
import java.util.List;

public class SplitTest {

    /*
    Give file name and time range(s) to splitter.
    See if I get same crazy results as:
        scenes:

     */
    @Test
    public void whyIs1stStraddleCueBroken() {

        Cue straddleCue = new Cue();
        straddleCue.addLine("a line");
        straddleCue.setTimeRange(LocalTime.of(0,0,5),LocalTime.of(0,0,15));

        TimeRange sceneTimeRange = new TimeRange(LocalTime.of(0,0,7),LocalTime.of(0,0,20));

        List<List<Cue>> actual = Splitter.split(Lists.newArrayList(straddleCue), Lists.newArrayList(sceneTimeRange));

        Cue actualCue = actual.get(0).get(0);

        Assert.assertEquals("start", LocalTime.of(0,0), actualCue.getTimeRange().getStart());
        Assert.assertEquals("end", LocalTime.of(0,0,8), actualCue.getTimeRange().getEnd());
    }

}
