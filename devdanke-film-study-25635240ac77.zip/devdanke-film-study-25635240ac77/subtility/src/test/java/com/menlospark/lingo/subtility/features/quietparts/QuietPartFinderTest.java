package com.menlospark.lingo.subtility.features.quietparts;

import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.model.TimeRange;
import com.menlospark.lingo.subtility.srt.SrtParser;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;


public class QuietPartFinderTest
{
    /*
    Find the quietparts part.
     */
    @Test
    public void testFindOneQuietPart()
    {
        //setup
        List<Cue> subtitles = new ArrayList<>();
        subtitles.add(makeSubtitle("00:00:01,000","00:00:02,000"));
        subtitles.add(makeSubtitle("00:10:00,000","00:11:00,000")); // time between is 9:58 mm:ss.

        //exercise
        List<QuietPart> quietParts = QuietPartFinder.findQuietParts(subtitles, QuietPartFinder.MINUTE);

        //verify
        Assert.assertNotNull("part list", quietParts );
        Assert.assertEquals("part count", quietParts.size(),1);
        Assert.assertEquals("seconds", quietParts.get(0).getSeconds(), ((9*60)+58));
    }


    @Test
    public void testFindManyQuietParts()
    {
        //setup
        List<Cue> subtitles = new ArrayList<>();
        subtitles.add(makeSubtitle("00:00:01,000","00:00:02,000"));
        subtitles.add(makeSubtitle("00:10:00,000","00:11:00,000")); // time between is 9:58 mm:ss.
        subtitles.add(makeSubtitle("00:12:01,000","00:20:00,000")); // time between is 1:01 mm:ss.

        //exercise
        List<QuietPart> quietParts = QuietPartFinder.findQuietParts(subtitles, QuietPartFinder.MINUTE);

        //verify
        Assert.assertNotNull("part list", quietParts);
        Assert.assertEquals("part count", quietParts.size(),2);
        Assert.assertEquals("part 1 seconds", quietParts.get(0).getSeconds(), ((9*60)+58));
        Assert.assertEquals("part 2 seconds", quietParts.get(1).getSeconds(), 61);
    }


    @Test
    public void testFindNoQuietParts()
    {
        //setup
        List<Cue> subtitles = new ArrayList<>();
        subtitles.add(makeSubtitle("00:00:01,000","00:00:02,000"));
        subtitles.add(makeSubtitle("00:00:20,000","00:00:25,000")); // time between is 18 seconds.

        //exercise
        List<QuietPart> quietParts = QuietPartFinder.findQuietParts(subtitles, QuietPartFinder.MINUTE);

        //verify
        Assert.assertNotNull("part list", quietParts );
        Assert.assertEquals("part count", quietParts.size(),0);
    }


    private Cue makeSubtitle(String startTimeStr, String endTimeStr)
    {
        Cue subtitle = new Cue();

        subtitle.setTimeRange(new TimeRange(SrtParser.parseLocalTime(startTimeStr),
                SrtParser.parseLocalTime(endTimeStr)));

        return subtitle;
    }

}
