package com.menlospark.lingo.subtility.features.shift;

import com.menlospark.lingo.subtility.model.Cue;
import org.junit.Assert;
import org.junit.Test;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ShiftTest
{
    @Test
    public void testTimeShift()
    {
        List<Cue> cues = new ArrayList<>();
        cues.add(makeCue(10,20));
       // cues.addLine(makeCue(33,44));

        // exercise
        List<Cue> actualCues = TimeShifter.shift(cues, 5);

        // verify
        List<Cue> expectSubs = new ArrayList<>();
        expectSubs.add(makeCue(15,25));
     //   expectSubs.addLine(makeCue(38,49));

        for(int i=0; i<expectSubs.size(); i++)
        {
            Cue expect = expectSubs.get(i);
            Cue actual = actualCues.get(i);

            Assert.assertEquals("item["+i+"] start", expect.getStart(), actual.getStart());
            Assert.assertEquals("item["+i+"] end",   expect.getEnd(),   actual.getEnd());
        }
    }


    private Cue makeCue(long startMilli, long endMilli)
    {
        Cue subtitle = new Cue();
        subtitle.setTimeRange(LocalTime.ofNanoOfDay(TimeUnit.MILLISECONDS.toNanos(startMilli)),
                LocalTime.ofNanoOfDay(TimeUnit.MILLISECONDS.toNanos(endMilli)));

        return subtitle;
    }

}
