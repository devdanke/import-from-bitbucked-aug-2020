package com.menlospark.lingo.subtility;


import com.menlospark.lingo.subtility.features.runner.Main;
import org.junit.Test;

public class TroubleShooter {

    String infile = "/Users/me/_dev/lingo/vtt_util/src/test/resources/test-data/american-sniper_thai-1116077-for-test.srt";
    String outdir = "/Users/me/_dev/lingo/vtt_util/target";

    @Test
    public void testConvert()
    {
        String[] args = {
                "-a", "convert",
                "-i", infile,
                "-o", outdir};
        Main.main(args);
    }

    @Test
    public void testShift()
    {
        String[] args = {
                "--action", "shift",
                "--infile", infile,
                "--outdir", outdir,
                "--millis",  "1570"};
        Main.main(args);
    }

}
