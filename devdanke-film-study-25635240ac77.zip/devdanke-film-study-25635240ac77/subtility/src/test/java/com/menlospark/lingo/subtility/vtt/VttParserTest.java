package com.menlospark.lingo.subtility.vtt;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.vtt.VttParser;
import org.junit.Assert;
import org.junit.Test;

import java.net.URL;
import java.util.List;

public class VttParserTest
{
    @Test
    public void testParse()
        throws Exception
    {
        URL url = Resources.getResource("test-data/parse-test-input.vtt");
        List<String> lines = Resources.readLines(url, Charsets.UTF_8);
        List<Cue> subtitles = new VttParser().parse(lines);

        Assert.assertEquals("cues count", subtitles.size(), 3);
    }

}
