package com.menlospark.lingo.subtility.features.quietparts;


import com.google.common.io.Resources;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.model.SubFormat;
import com.menlospark.lingo.subtility.parse.SubsParser;
import com.menlospark.lingo.subtility.vtt.VttOutputter;
import org.apache.commons.io.FileUtils;
import org.junit.Test;

import java.io.File;
import java.util.List;


public class QuietDriverTest
{
    // TODO make all tests work against vtt only.
    @Test
    public void runAnalyze()
    {
        QuietDriver.readAndProcess(new File("./src/test/resources/analyze/subs.en.srt"));
    }

    @Test
    public void genVttAndQuietParts()
        throws Exception
    {
        String inputDir = "test-data/";
        String baseFileName = "an-ordinary-love-story-รัก.360p";
        String inputFileExt = ".srt";

        File outputDir = new File("./target/");

        StringBuilder sb = new StringBuilder();
        sb.append("Start with srt file.  Shift it ahead 15.98 seconds.");

        // parse
        List<Cue> subtitles = SubsParser.parse(Resources.getResource(inputDir + baseFileName + inputFileExt));

        // quietparts parts
        QuietPartsOutputter.makeQuietPartsFile(outputDir, baseFileName, subtitles);

        // vtt
        VttOutputter.makeVttFile(new File(outputDir, baseFileName), subtitles);

        FileUtils.write(new File(outputDir, "subtitle-processing-notes.txt"), sb.toString());
    }


}
