package com.menlospark.lingo.subtility.features.quietparts;

import org.junit.Assert;
import org.junit.Test;

import java.time.LocalTime;

/**
 * Created by me on 7/12/14.
 */
public class QuietPartTest
{
    @Test
    public void testCanonicalFormat()
    {
        QuietPart quietPart = new QuietPart(LocalTime.of(0,1),LocalTime.of(23,59,59,999000000));

        Assert.assertEquals(  "psv format", quietPart.toPsv(), "60 | 86399");
        Assert.assertEquals( "json format", quietPart.toJson(), "[ 60 , 86399 ]");
    }
}
