package com.menlospark.lingo.subtility.model;

public enum SubFormat
{
    SRT, VTT
}
