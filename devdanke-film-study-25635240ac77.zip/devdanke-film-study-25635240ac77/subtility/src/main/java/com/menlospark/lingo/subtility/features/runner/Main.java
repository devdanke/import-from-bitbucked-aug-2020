package com.menlospark.lingo.subtility.features.runner;

import com.google.common.collect.Lists;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.model.SubFormat;
import com.menlospark.lingo.subtility.model.TimeRange;
import com.menlospark.lingo.subtility.features.cuetimes.CueTimesOutputter;
import com.menlospark.lingo.subtility.parse.SubsParser;
import com.menlospark.lingo.subtility.features.shift.ShiftDriver;
import com.menlospark.lingo.subtility.features.split.SplitDriver;
import com.menlospark.lingo.subtility.vtt.VttOutputter;
import org.apache.commons.cli.*;
import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.util.List;


public class Main
{
    private static boolean HAS_ARG =true;

    public static final String MILLIS = "millis";

    public static void main(String[] args)
    {
        Options options = new Options();

        // for any action
        Option actionOpt = OptionBuilder.withArgName("action")
                .hasArg()
                .withDescription("convert (srt->vtt), shift time, or split (extract time range chunks)")
                .isRequired()
                .withLongOpt("action")
                .create('a');
        options.addOption(actionOpt);

        Option infileOpt = OptionBuilder.withArgName("infile")
                .hasArg()
                .withDescription("input srt or vtt file")
                .isRequired()
                .withLongOpt("infile")
                .create('i');
        options.addOption(infileOpt);

        Option outdirOpt = OptionBuilder.withArgName("outdir")
                .hasArg()
                .withDescription("output directory")
                .isRequired()
                .withLongOpt("outdir")
                .create('o');
        options.addOption(outdirOpt);

        // for shift time action.
        options.addOption("m", "millis", HAS_ARG, "shift time +/- milliseconds");

        // for split
        options.addOption("r", "range", HAS_ARG, "time range as hh:MM:ss.mmm-hh:MM:ss.mmm"); // 1 or more

        out("vtt util");
        try
        {
            CommandLine cmd = new DefaultParser().parse( options, args);
            String action = cmd.getOptionValue("action");

            File inputSubsFile = new File(cmd.getOptionValue("infile"));
            if(!inputSubsFile.exists())
            {
                throw new RuntimeException("Can't find input file: " + inputSubsFile.getAbsolutePath());
            }
            out("INPUT:  " + inputSubsFile.getAbsolutePath());
            String baseName = FilenameUtils.getBaseName(inputSubsFile.getName());
            String langCode = getLangCode(baseName);


      //      SubFormat format = (inputSubsFile.getName().endsWith(SubFormat.VTT.name().toLowerCase())) ? SubFormat.VTT : SubFormat.SRT;
            List<Cue> subs = SubsParser.parse(inputSubsFile);

            File outputDir = new File(cmd.getOptionValue("outdir"));
            if(!inputSubsFile.exists()) {
                throw new RuntimeException("Can't find output dir: " + outputDir.getAbsolutePath());
            }
            out("OUTPUT: " + outputDir.getAbsolutePath());

            switch (action)
            {
                case "convert":
                    out("action -> convert (srt -> vtt)");
                    VttOutputter.makeVttFile(new File(outputDir, baseName), subs);
                    CueTimesOutputter.makeCueTimesFile(outputDir, baseName, subs);
                    break;

                case "shift":

                    out("action -> shift");
                    Long offsetSeconds = Long.parseLong(cmd.getOptionValue(MILLIS));
                    ShiftDriver.shiftCues(subs, offsetSeconds, outputDir,  baseName);
                    break;

                case "split":

                    out("action -> split");
                    String[] rawRanges = cmd.getOptionValues("range");
                    List<TimeRange> ranges = Lists.newArrayList();

                    for(String rawRange: rawRanges) {
                        String[] parts = rawRange.split("-");
                        out("part0="+parts[0]+", part1="+parts[1]);
                        ranges.add(new TimeRange(parts[0], parts[1]));
                    }

                    out("ranges count="+ranges.size() + ", rawRanges count="+rawRanges.length);
                    SplitDriver.split(subs, ranges, outputDir, langCode);
                    break;

                default:
                    throw new RuntimeException("what the heck? action='" + action + "'");
            }
            Thread.sleep(1000);
            out("DONE");
        }
        catch(Exception e)
        {
            out("error=" + e.getMessage() + ", type=" + e.getClass().getSimpleName());
            e.printStackTrace();
            System.exit(-1);
        }
    }

    public static void out(String msg)
    {
        System.out.println(">>> " + msg);
    }


    private static final String getLangCode(String baseFileName)
    {
        int suffixPos = baseFileName.lastIndexOf(".");
        if(suffixPos != -1) {
            String langCode = baseFileName.substring(suffixPos + 1);
            out("Main.getLangCode(): langCode="+langCode);
            return langCode;
        }
        else {
            return null;
        }
    }

}

