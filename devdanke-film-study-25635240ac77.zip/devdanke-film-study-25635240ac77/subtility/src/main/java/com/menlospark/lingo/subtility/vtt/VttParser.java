package com.menlospark.lingo.subtility.vtt;

import com.google.common.annotations.VisibleForTesting;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.model.TimeRange;
import com.menlospark.lingo.subtility.parse.IParseSubtitles;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static com.menlospark.lingo.subtility.model.SubFormat.VTT;

@Slf4j
public class VttParser
    implements IParseSubtitles
{
    private enum LineType {FILE_HEADER,EMPTY,ITEM_NUM,TIME,TEXT}

    private static final String FILE_HEADER_SYMBOL = "WEBVTT";
    private static final String TIME_SEPARATOR_SYMBOL = "-->";

    private static DateTimeFormatter VTT_TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss.SSS"); // 22:00:59,001

    @Override
    public boolean canParse(String filePath)
    {
        return filePath.toUpperCase().endsWith(VTT.name());
    }

    public List<Cue> parse(List<String> lines)
    {
        List<Cue> subtitles = new ArrayList<>();
        boolean inSubtitle = false;
        Cue subtitle = null;
        int srcFileLineNum = 0;

        for(String line : lines)
        {
            srcFileLineNum++;
            line = line.trim();

            switch (determineLineType(line)) {
                case FILE_HEADER:
                    // ignore it
                    break;

                case ITEM_NUM:

                    if (inSubtitle) {
                       // log.warn("LINE: {}, VALUE: '{}', was interpreted as an item #, but we're in a sub. " +
                       //         "Will treat it as subtitle text.", srcFileLineNum, line);
                        //throw new IllegalStateException("Should not already be in a subtitle. Src file line# "+srcFileLineNum+", line value: '" + line + "'");
                        subtitle.addLine(line);
                    }
                    else {
                        inSubtitle = true;
                        subtitle = new Cue();
                        subtitles.add(subtitle); // gotta addLine it here, due to maybe no blank line at end of file.
                        subtitle.setItemNumber(Integer.parseInt(line));
                    }
                    break;

                case TIME:

                    String[] timeStr = parseTimeStrings(line);
                    subtitle.setTimeRange(new TimeRange(parseLocalTime(timeStr[0]),parseLocalTime(timeStr[1])));
                    break;

                case TEXT:

                    subtitle.addLine(line);
                    break;

                case EMPTY:

                    if (inSubtitle) {
                        
                        subtitle = null;  // make it null to cause NPE (fail fast)
                        inSubtitle = false;
                    }

                    break;
                default:
                    throw new IllegalStateException("File anyOverlap line type that doesn't look like it belongs in " +
                       "VTT file.\nLine: '" + line + "'");
            }
        }

        return subtitles;
    }

    @VisibleForTesting
    public static LocalTime parseLocalTime(String timeStr)
    {
        return LocalTime.parse(timeStr.trim(), VTT_TIME_FORMATTER);
    }


    /*
    Although the time line can contain positioning info, for now I only want the times.
     */
    static String[] parseTimeStrings(String line)
    {
        String[] timeStr = line.split(TIME_SEPARATOR_SYMBOL);
        if(timeStr[1].contains("X1"))
        {
            timeStr[1] = timeStr[1].trim().split(" ")[0];  // in case: 00:00:10.500 --> 00:00:13.000 X1:63 X2:223 Y1:43 Y2:58
        }

        return timeStr;
    }

    /**
     * @param line a trimmed, non-null line.
     */
    @VisibleForTesting
    static LineType determineLineType(String line)
    {
        if(line.length()==0)
        {
            return LineType.EMPTY;
        }
        if(line.contains(FILE_HEADER_SYMBOL))
        {
            return LineType.FILE_HEADER;
        }
        else if(line.contains(TIME_SEPARATOR_SYMBOL))
        {
            return LineType.TIME;
        }
        else if(StringUtils.isNumeric(line))
        {
            return LineType.ITEM_NUM;
        }
        else
        {
            return LineType.TEXT;
        }
    }
}
