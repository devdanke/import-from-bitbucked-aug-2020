package com.menlospark.lingo.subtility.features.quietparts;

import com.menlospark.lingo.subtility.model.Cue;

import static java.time.temporal.ChronoUnit.SECONDS;
import java.util.ArrayList;
import java.util.List;


public class QuietPartFinder
{
    public static final int MINUTE = 60;

    public static List<QuietPart> findQuietParts(List<Cue> cues, int minQuietPartSeconds)
    {
        List<QuietPart> quietParts = new ArrayList<>();

        for(int i=0; i< (cues.size()-1); i++)
        {
            Cue s1 = cues.get(i);
            Cue s2 = cues.get(i+1);

            if(SECONDS.between(s1.getTimeRange().getEnd(),s2.getTimeRange().getStart()) > minQuietPartSeconds )
            {
                quietParts.add(new QuietPart(s1.getTimeRange().getEnd(),s2.getTimeRange().getStart()));
            }
        }

        return quietParts;
    }

}
