package com.menlospark.lingo.subtility.parse;


import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;

@Slf4j
public class BomFixer {
    /*
I think Java should remove the UTF BOM, but I see it gets left on for some downloaded srt files.
AFAIK, the BOM char should be char0 of line0.  If I find it there, I'll delete it.
*/
    public static void stripBrokenUtfBom(List<String> lines) {

        if( (lines.size() > 0) &&
                (lines.get(0).length() > 0) &&
                (lines.get(0).charAt(0)== '\uFEFF')) {

            log.info("Attempt to remove broken UTF-8 bom char.");
            lines.set(0, lines.get(0).substring(1));
        }
    }

    public static String getFileCharsetStr(File f) {

        try {
            FileInputStream fis = new FileInputStream(f);

            BOMInputStream bomIn = new BOMInputStream(fis,
                    ByteOrderMark.UTF_16LE, ByteOrderMark.UTF_16BE,
                    ByteOrderMark.UTF_32LE, ByteOrderMark.UTF_32BE
            );

            if (bomIn.hasBOM() ||
                    bomIn.hasBOM(ByteOrderMark.UTF_16LE) ||
                    bomIn.hasBOM(ByteOrderMark.UTF_16BE) ||
                    bomIn.hasBOM(ByteOrderMark.UTF_32LE) ||
                    bomIn.hasBOM(ByteOrderMark.UTF_32BE)) {
                return bomIn.getBOMCharsetName();
            }
            else {
                return Charset.defaultCharset().name();
            }
        }
        catch(IOException ioe) {
            throw new RuntimeException(ioe);
        }
    }
}
