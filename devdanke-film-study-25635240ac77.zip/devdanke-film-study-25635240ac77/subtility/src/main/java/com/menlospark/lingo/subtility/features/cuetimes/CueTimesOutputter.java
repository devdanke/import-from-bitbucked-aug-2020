package com.menlospark.lingo.subtility.features.cuetimes;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.io.Files;
import com.menlospark.lingo.subtility.model.Cue;

import java.io.File;
import java.time.temporal.ChronoField;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class CueTimesOutputter {

    private static final ObjectMapper jackson = new ObjectMapper();


    /*
    Create file of cue start and end times.
    It uses VTT time format.
    cue-times.json
    Web UI will use to create buttons to repeat play a cue or range of cues.
    {
        "cueTimes":[
            { "id":"#","start":"hh:mm:ss.SSS","end":"hh:mm:ss.SSS" },
            { "id":"#","start":"hh:mm:ss.SSS","end":"hh:mm:ss.SSS" }
        ]
    }
     */
    public static void makeCueTimesFile(File outDir, String baseFileName, List<Cue> cues)
    {
        List<Map<String,Object>> cueTimes = Lists.newArrayList();
        Map<String,Object> cueTime;
        for(Cue cue : cues)
        {
            cueTime = new TreeMap<>();

            cueTime.put("id",   cue.getItemNumber());
            cueTime.put("start", cue.getStart().get(ChronoField.MILLI_OF_DAY));
            cueTime.put("end", cue.getEnd().get(ChronoField.MILLI_OF_DAY));

            cueTimes.add(cueTime);
        }

        Map<String,Object> cueTimesMap = new HashMap<>();
        cueTimesMap.put("cueTimes", cueTimes);
        try
        {
            File f = new File(outDir, baseFileName+".cueTimes.json");
            Files.write(jackson.writeValueAsString(cueTimesMap), f, Charsets.UTF_8 );
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


}
