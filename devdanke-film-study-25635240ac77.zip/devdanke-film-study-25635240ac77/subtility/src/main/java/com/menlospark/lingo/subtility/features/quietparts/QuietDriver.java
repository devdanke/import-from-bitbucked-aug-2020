package com.menlospark.lingo.subtility.features.quietparts;

import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.parse.SubsParser;
import lombok.extern.java.Log;

import java.io.File;
import java.util.List;
import java.util.StringJoiner;

@Log
public class QuietDriver
{

    public static Subtitles readAndProcess(File subtitleFile)
    {
        try
        {
            List<Cue> cues = SubsParser.parse(subtitleFile);

            // find quietparts parts >= 10 seconds
            List<QuietPart> quietParts = QuietPartFinder.findQuietParts(cues, 10);

            Subtitles container = new Subtitles();

            container.setCues(cues);
            container.setQuietParts(quietParts);

            log.info("report: \n" + container.report());
            Thread.sleep(1000);

            return container;
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }
}
