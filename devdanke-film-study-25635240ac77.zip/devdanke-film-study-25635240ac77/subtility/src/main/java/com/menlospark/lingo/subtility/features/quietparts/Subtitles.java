package com.menlospark.lingo.subtility.features.quietparts;

import com.google.common.collect.Lists;
import com.menlospark.lingo.subtility.model.Cue;
import lombok.Data;
import org.apache.commons.collections.CollectionUtils;

import java.time.LocalTime;
import java.util.List;

/**
 * Created by me on 9/16/14.
 */
@Data
public class Subtitles
{
    private List<Cue> cues;
    private List<QuietPart> quietParts;


    public int totalQuietPartSeconds()
    {
        if(CollectionUtils.isNotEmpty(quietParts))
        {
            int sum = 0;
            for(QuietPart qp: quietParts)
            {
                sum += qp.getSeconds();
            }
            return sum;
        }
        else
        {
            return -1;
        }
    }

    public int totalMovieSeconds()
    {
        return cues.get(cues.size()-1).getEnd().toSecondOfDay();
    }

    public int totalTalkSeconds()
    {
        return cues.stream()
            .mapToInt(cue -> cue.getTimeRange().getDurationSeconds())
            .sum();
    }


    public int movieHalfwaySecond()
    {
        return totalMovieSeconds() / 2;
    }


    public int findSubtitleIndexJustAfter(int halfOfTalkTime)
    {
        int talkSeconds = 0;
        for(Cue cue : cues)
        {
            talkSeconds += cue.getTimeRange().getDurationSeconds();
            if(talkSeconds > halfOfTalkTime)
            {
                System.out.println(">>> talkSeconds=" + talkSeconds);
                return cue.getItemNumber();
            }
        }
        return -9;
    }

    public List<Integer> howNearArePrevAndNextQuietPartsTo(int indexOfMidSubtitle )
    {
        LocalTime midSubStartTime = cues.get(indexOfMidSubtitle).getStart();
        LocalTime midSubEndTime = cues.get(indexOfMidSubtitle).getEnd();

        Integer qpPrev = null;
        Integer qpNext = null;

        for(int i=0; i<quietParts.size(); i++)
        {
            QuietPart quietPart = quietParts.get(i);
            if((qpPrev == null) && quietPart.getStartTime().isAfter(midSubEndTime))
            {
                qpPrev = i-1;
                qpNext = i;
                break;
            }
        }

        return Lists.newArrayList(qpPrev,qpNext);
    }


    public String report()
    {
        StringBuilder sb = new StringBuilder();

        int movieSeconds = totalMovieSeconds();
        sb.append("movieSeconds: ").append(movieSeconds).append(toPeriod(movieSeconds));
        int qpSeconds = totalQuietPartSeconds();
        sb.append("quietPartSeconds: ").append(qpSeconds).append(toPeriod(qpSeconds));

        int talkSeconds = totalTalkSeconds();
        sb.append("talkSeconds: ").append(talkSeconds).append(toPeriod(talkSeconds));

        sb.append("movieMidPointSec: ").append(movieHalfwaySecond()).append(toTime(movieHalfwaySecond()));

        int halfTalkSeconds = talkSeconds / 2;
        sb.append("halfOfTalkSeconds: ").append(halfTalkSeconds).append(toTime(halfTalkSeconds));

        int indexOfSubtitleJustAfterHalfTalk = findSubtitleIndexJustAfter(halfTalkSeconds);
        sb.append("indexOfSubtitleJustAfterHalfTalk: ").append(indexOfSubtitleJustAfterHalfTalk).append("\n");

        List<Integer> indexOfPrevAndNextQuietParts = howNearArePrevAndNextQuietPartsTo(indexOfSubtitleJustAfterHalfTalk);
        int prevQpIndex = indexOfPrevAndNextQuietParts.get(0);
        int nextQpIndex = indexOfPrevAndNextQuietParts.get(1);
        sb.append("indexOfPrevAndNextQuietParts: ").append(indexOfPrevAndNextQuietParts).append("\n");

        Cue midSub = cues.get(indexOfSubtitleJustAfterHalfTalk);

        int prevQpEndSec = quietParts.get(prevQpIndex).getEndTime().toSecondOfDay();
        int secBetweenPrevQpAndMidSub = midSub.getStart().minusSeconds(prevQpEndSec).toSecondOfDay();

        int nextQpStartSec = quietParts.get(nextQpIndex).getStartTime().toSecondOfDay();
        int secBetweenMidSubAndNextQp = nextQpStartSec - midSub.getEnd().toSecondOfDay();

        sb.append("secBetweenPrevQpAndMidSub: ").append(secBetweenPrevQpAndMidSub).append(toPeriod(secBetweenPrevQpAndMidSub));
        sb.append("secBetweenMidSubAndNextQp: ").append(secBetweenMidSubAndNextQp).append(toPeriod(secBetweenMidSubAndNextQp));

        // TODO: what are the start/end times of the boundary quietparts periods?
        QuietPart prevQp = quietParts.get(prevQpIndex);
        sb.append("prevQp: start: ").append(prevQp.getStartTime()).append(", end: ").append(prevQp.getEndTime()).append("\n");
        QuietPart nextQp = quietParts.get(nextQpIndex);
        sb.append("nextQp: start: ").append(nextQp.getStartTime()).append(", end: ").append(nextQp.getEndTime()).append("\n");

        // TODO: define a good cut point.
        // 1) in or around a quietparts part.
        // 2) beginning, mid, end?
        // hey, after looking 44:16 is good cut point.  all the analysis wasn't that helpful.
        // i think this means, i'll need to shift 2nd part subs by that much.
        // what are sub indexes around 44:16? 255 256

        // TODO: given a cutPoint, split cues into two lists.
        // TODO: determine a shift seconds amount for the 2nd subs list.
        // TODO: create vtt file from each list.
        // TODO: do qpSecs + talkSeconds = movieSecs?

        return sb.toString();
    }

    private String toTime(int seconds)
    {
        StringBuilder sb = new StringBuilder();
        sb.append(", ").append("time: ").append(LocalTime.ofSecondOfDay(seconds)).append("\n");
        return sb.toString();
    }
    private String toPeriod(int seconds)
    {
        StringBuilder sb = new StringBuilder();
        sb.append(", ").append("period: ").append(LocalTime.ofSecondOfDay(seconds)).append("\n");
        return sb.toString();
    }

}
