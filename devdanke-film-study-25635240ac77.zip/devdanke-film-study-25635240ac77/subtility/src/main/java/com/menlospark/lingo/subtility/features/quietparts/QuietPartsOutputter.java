package com.menlospark.lingo.subtility.features.quietparts;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.io.Files;
import com.menlospark.lingo.subtility.model.Cue;

import java.io.File;
import java.time.temporal.ChronoField;
import java.util.*;

public class QuietPartsOutputter {

    private static final ObjectMapper jackson = new ObjectMapper();


    /*
     *
     * @param outFileDir ends with /
     * @param baseFileName
     * @param cues
     */
    public static void makeQuietPartsFile(File outFileDir, String baseFileName, List<Cue> subtitles)
    {
        try
        {
            List<QuietPart> quietParts = QuietPartFinder.findQuietParts(subtitles, 10);// n seconds

            StringJoiner sj = new StringJoiner(",\n", "[\n", "\n]");
            for(QuietPart quietPart : quietParts)
            {
                sj.add(quietPart.toJson());
            }

            File outfile = new File(outFileDir, baseFileName+".quietparts-parts.txt");
            //File f = new File("./target/"+baseFileName+"-quietparts-parts.txt");
            Files.write(sj.toString(), outfile, Charsets.UTF_8 );
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


}
