package com.menlospark.lingo.subtility.features.split;

import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.model.TimeRange;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.util.List;

import static com.menlospark.lingo.subtility.features.cuetimes.CueTimesOutputter.makeCueTimesFile;
import static com.menlospark.lingo.subtility.vtt.VttOutputter.makeVttFile;

@Slf4j
public class SplitDriver
{
    /*
    @param lang the language, e.g. "en" or "th".
     */
    public static void split(List<Cue> cues, List<TimeRange> ranges, File outDir, String lang) {
        if((lang==null) || (lang.length()!=2)) {
            log.warn("lang was null or length!=2");
        }
        List<List<Cue>> chunks = Splitter.split(cues, ranges);

        for(int i=0; i<chunks.size(); i++) {

            String fileName = "scene-"+(i+1);
            if(lang != null) { fileName += ("." + lang);}
            makeVttFile(new File(outDir, fileName), chunks.get(i));
            makeCueTimesFile(outDir, fileName, chunks.get(i));
        }
    }
}
