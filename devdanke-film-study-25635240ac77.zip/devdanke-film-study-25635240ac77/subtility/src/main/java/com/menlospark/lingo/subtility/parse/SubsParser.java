package com.menlospark.lingo.subtility.parse;

import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.io.Resources;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.model.SubFormat;
import com.menlospark.lingo.subtility.srt.SrtParser;
import com.menlospark.lingo.subtility.vtt.VttParser;
import lombok.extern.java.Log;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import static com.menlospark.lingo.subtility.model.SubFormat.VTT;

@Log
public class SubsParser
{
// TODO: Handle case of empty subtitles file?
/*
    private static final List<IParseSubtitles> parsers = Lists.newArrayList(
            new SrtParser(),
            new VttParser());
  */
    /**
     * @param fileDir probably fully qualified path, but not file name.
     * @param fileName including extension.  e.g. foo.vtt or bar.srt
     * @return
     * @throws java.io.IOException
     */
    public static List<Cue> parse(URL classpathResource)
    {
        try
        {
            String fileName = classpathResource.getFile();
            List<String> lines = Resources.readLines(classpathResource, Charsets.UTF_8);
            return parse(lines, fileName);
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    public static List<Cue> parse(File file)
    {
        try
        {
            if(file.exists())
            {
                List<String> lines = FileUtils.readLines(file);
                return parse(lines, file.getPath());
            }
            else
            {
                log.info(file.getAbsolutePath() + " DNE");
                return null;
            }
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    /**
     *
     * @param lines
     * @param filePath full file or resource path, including extension.
     * @return
     */
    public static List<Cue> parse(List<String> lines, String filePath) {
        try
        {
            if(filePath.toLowerCase().endsWith("vtt")) {
                return new VttParser().parse(lines);
            }
            else if(filePath.toLowerCase().endsWith("srt")){
                return new SrtParser().parse(lines);
            }
            else {
                throw new RuntimeException("No parser found for file: " + filePath);
            }
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }

}
