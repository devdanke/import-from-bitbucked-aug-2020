package com.menlospark.lingo.subtility.parse;

import com.menlospark.lingo.subtility.model.Cue;

import java.util.List;

/**
 * Created by me on 8/29/14.
 */
public interface IParseSubtitles {

    List<Cue> parse(List<String> lines);
    boolean canParse(String filePath);
}
