package com.menlospark.lingo.subtility.features.shift;

import com.menlospark.lingo.subtility.model.Cue;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.util.List;

import static com.menlospark.lingo.subtility.features.cuetimes.CueTimesOutputter.makeCueTimesFile;
import static com.menlospark.lingo.subtility.vtt.VttOutputter.makeVttFile;

@Slf4j
public class ShiftDriver
{
    public static void shiftCues(List<Cue> cues, long offsetMillis, File outDir,
                                 String outfileBaseName) {

        List<Cue> shiftedCues = TimeShifter.shift(cues, offsetMillis);
        makeVttFile(new File(outDir, outfileBaseName), shiftedCues);
        makeCueTimesFile(outDir, outfileBaseName, shiftedCues);
    }
}
