package com.menlospark.lingo.subtility.model;

import lombok.Data;
import lombok.NonNull;

import java.time.LocalTime;
import java.time.temporal.ChronoField;

import static java.time.temporal.ChronoUnit.MILLIS;

/*
Consider using Google's time range class. 1/2017
 */
@Data
public class TimeRange
    implements Comparable<TimeRange> {

    private final LocalTime start;
    private final LocalTime end;

    public TimeRange(@NonNull LocalTime start, @NonNull LocalTime end) {

        if(end.isBefore(start)) {
            throw new IllegalArgumentException("end cannot be before start. start: " + start +
            ", end: " + end);
        }
        this.start = start;
        this.end = end;
    }

    /*
    Does/could this work for SRT and VTT time format strings?
    Would be nice if this could parse most LocalTime strings: srt, vtt, and split range.
     */
    public TimeRange(String start, String end) {
        this(LocalTime.parse(start), LocalTime.parse(end));
    }

    public TimeRange(long startMilli, long endMilli) {

        this(LocalTime.ofNanoOfDay(startMilli * 1_000_000), LocalTime.ofNanoOfDay(endMilli  * 1_000_000));
    }

    public TimeRange(TimeRange range, long shiftMillis) {
        this(range.start.plus(shiftMillis, MILLIS), range.end.plus(shiftMillis, MILLIS));
    }

    public int getDurationSeconds() {
        return end.toSecondOfDay() - start.toSecondOfDay();
    }

    public long getDurationSeconds(LocalTime startTime, LocalTime endTime) {
        return endTime.toSecondOfDay() - startTime.toSecondOfDay();
    }

    public int getDurationMillis() {
        return end.get(ChronoField.MILLI_OF_DAY) - start.get(ChronoField.MILLI_OF_DAY);
    }

    @Override
    public int compareTo(TimeRange that) {
        return this.start.compareTo(that.end);
    }

    public boolean anyOverlap(LocalTime subStart, LocalTime subEnd) {
        return isBetween(subStart, start, end) || isBetween(subEnd, start, end);
    }

    public boolean anyOverlap(TimeRange timeRange) {
        return anyOverlap(timeRange.start, timeRange.end);
    }

    boolean isBetween(LocalTime t, LocalTime start, LocalTime end) {
        return !t.isBefore(start) && !t.isAfter(end);
    }

    public boolean isAfter(TimeRange range) {
        return start.isAfter(range.end);
    }


}
