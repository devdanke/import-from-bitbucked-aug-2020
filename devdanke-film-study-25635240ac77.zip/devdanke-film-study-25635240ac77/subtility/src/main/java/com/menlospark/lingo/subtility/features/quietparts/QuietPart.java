package com.menlospark.lingo.subtility.features.quietparts;

import com.menlospark.lingo.subtility.vtt.VttOutputter;
import lombok.Data;
import lombok.NonNull;

import static java.time.temporal.ChronoUnit.SECONDS;
import java.time.LocalTime;


@Data
public class QuietPart
{
    @NonNull
    private LocalTime startTime;
    @NonNull
    private LocalTime endTime;

    public int getSeconds()
    {
        return (int) SECONDS.between(startTime,endTime);
    }

    public String toString()
    {
        return VttOutputter.WEBVTT_TIME_FORMATTER.format(startTime) + "|" +
                VttOutputter.WEBVTT_TIME_FORMATTER.format(endTime) + "|" + getSeconds();
    }

    public String toPsv()
    {
        return startTime.toSecondOfDay() + " | " + endTime.toSecondOfDay();
    }

    public String toJson()
    {
        return String.format( "[ %s , %s ]", startTime.toSecondOfDay(), endTime.toSecondOfDay() );
    }
}
