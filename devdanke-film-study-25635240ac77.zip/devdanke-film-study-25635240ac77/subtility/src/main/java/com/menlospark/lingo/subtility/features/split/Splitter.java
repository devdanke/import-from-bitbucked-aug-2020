package com.menlospark.lingo.subtility.features.split;

import com.google.common.collect.Lists;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.model.TimeRange;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalTime;
import java.time.temporal.ChronoField;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import static java.time.temporal.ChronoUnit.MILLIS;

@Slf4j
public class Splitter
{
    /**
     *
     *  From the whole cues list, extract sublits, each of which will contain
     *  cues within the given time ranges.
     *
     *  @return shifted cues (cloned from input cues)
     */
    public static List<List<Cue>> split(List<Cue> cues, List<TimeRange> ranges)
    {
        List<List<Cue>> chunks = Lists.newArrayList();// rename to rangeOfCuesList?
        Collections.sort(ranges);
        Iterator<Cue> cuesIterator = cues.iterator();

        ranges.stream().forEach( range -> {

            int itemCount = 1;
            List<Cue> chunk = Lists.newArrayList();

            // Subtract start time of time range from each cue in the range.
            LocalTime offset = range.getStart();

            while(cuesIterator.hasNext()) {

                Cue cue = cuesIterator.next();

                if(cue.getTimeRange().isAfter(range)) {
                    // We found all the cues in this time range.
                    // Exit while loop, to move to next time range.
                    break;
                }

                if (range.anyOverlap(cue.getTimeRange())) {
                    chunk.add(copyShiftBackInTimeAndRenumber(cue, itemCount++, offset));
                }
            }

            if(!chunk.isEmpty()) { chunks.add(chunk); }
        });

        return chunks;
    }


    /*
    Used to fix cues that are out of time with video.
    Also used to shift subs, corresponding to a video scene, backward in time.

    @param defaultOffset probably, the lower bound of the split range.
     */
    static Cue copyShiftBackInTimeAndRenumber(Cue cue, int count, LocalTime defaultOffset) {

        Cue newOne = new Cue(cue);
        newOne.setItemNumber(count);

        long offsetMillis = defaultOffset.getLong(ChronoField.MILLI_OF_DAY);

        // subtract time of 1st sub from all others to make the chunk subs start at/near zero.
        if(defaultOffset.isAfter(cue.getStart())) {

            // case: shifted time would make result cue's negative (aka startTime in the previous day) :-(
            //
            // log warning and prevent that from happening.
            //
            // This case only occurs for first cue in range, where there was a que that
            // crossed the range boundary, and i wanted to grab that cue.
            //
            // Only allow it to be shifted back to zero.
            log.warn("Prevented a cue shift back to the previous day.  Probably was 1st cue in time range and it " +
                    "crossed range boundary.  This should only happen in cases where cue times are significantly " +
                    "incorrect.  Cue: {}.  'defaultOffset: {} for copyShiftBackInTimeAndRenumber() call.",
                    cue, defaultOffset);

            // A straddle cue does not keep it's original duration.
            long newStartMilli = 0;
            // Reduce its duration by the number of millis the cue starts before the offset time.
            long millisBeforeOffsetToCutFromCue = MILLIS.between(cue.getStart(), defaultOffset);
            long newEndMilli = cue.getTimeRange().getDurationMillis() - millisBeforeOffsetToCutFromCue;

            log.info("startMilli: {}, endMilli: {}, truncLengthMillis: {}", newStartMilli, newEndMilli, millisBeforeOffsetToCutFromCue);
            newOne.setTimeRange(new TimeRange(newStartMilli, newEndMilli));
        }
        else {
            newOne.shiftByMillis( -1 * offsetMillis );
        }

        return newOne;
    }

}
