package com.menlospark.lingo.subtility.model;

import lombok.Data;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Data
public class Cue
{
    private Integer x1;
    private Integer x2;
    private Integer y1;
    private Integer y2;
    private Integer itemNumber;
    private TimeRange timeRange;
    private List<String> lines = new ArrayList<>();
    
    public Cue(){}

    public Cue(Cue that)
    {
        this.x1 = that.x1;
        this.x2 = that.x2;
        this.y1 = that.y1;
        this.y2 = that.y2;
        this.itemNumber = that.itemNumber;
        this.timeRange = that.timeRange; // immutable
        this.lines.addAll(that.lines);
    }

    public void addLine(String text)
    {
        lines.add(text);
    }

    public void shiftBySeconds(int sec)
    {
        shiftByMillis(sec * 1000);
    }

    public Cue shiftByMillis(long millis)
    {
        timeRange = new TimeRange(timeRange, millis);
        return this;
    }

    public LocalTime getStart(){
        return timeRange.getStart();
    }

    public LocalTime getEnd(){
        return timeRange.getEnd();
    }

    public void setTimeRange(LocalTime start, LocalTime end) {
        timeRange = new TimeRange(start, end);
    }
}
