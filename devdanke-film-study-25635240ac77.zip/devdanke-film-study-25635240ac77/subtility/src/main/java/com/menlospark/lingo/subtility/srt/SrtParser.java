package com.menlospark.lingo.subtility.srt;

import com.google.common.annotations.VisibleForTesting;
import com.menlospark.lingo.subtility.model.Cue;
import com.menlospark.lingo.subtility.model.TimeRange;
import com.menlospark.lingo.subtility.parse.BomFixer;
import com.menlospark.lingo.subtility.parse.IParseSubtitles;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static com.menlospark.lingo.subtility.model.SubFormat.SRT;

@Slf4j
public class SrtParser implements IParseSubtitles
{
    private enum LineType {EMPTY,ITEM_NUM,TIME,TEXT}

    private static final String TIME_SYMBOL = "-->";

    private static DateTimeFormatter SRT_TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss,SSS"); // 22:00:59,001

    @Override
    public boolean canParse(String filePath)
    {
        return filePath.toUpperCase().endsWith(SRT.name());
    }


    @Override
    public List<Cue> parse(List<String> lines)
    {
        // some dloaded thai srt files have bom char in wrong position.
        BomFixer.stripBrokenUtfBom(lines);

        List<Cue> subtitles = new ArrayList<>();
        boolean inSubtitle = false;
        Cue subtitle = null;
        int srcFileLineNum = 0;

        try {
            for(String line : lines)
            {
                srcFileLineNum++;
                line = line.trim();

                switch (determineLineType(line)) {
                    case ITEM_NUM:

                        if (inSubtitle) {
                            log.warn("LINE: {}, VALUE: '{}', was interpreted as an item #, but we're in a sub. " +
                                    "Will treat it as subtitle text.", srcFileLineNum, line);
                            //throw new IllegalStateException("Should not already be in a subtitle. Src file line# "+srcFileLineNum+", line value: '" + line + "'");
                            subtitle.addLine(line);
                        }
                        else {
                            inSubtitle = true;
                            subtitle = new Cue();
                            subtitles.add(subtitle); // gotta addLine it here, due to maybe no blank line at end of file.
                            subtitle.setItemNumber(Integer.parseInt(line));
                        }
                        break;

                    case TIME:

                        String[] timeStr = parseTimeStrings(line);
                        subtitle.setTimeRange(new TimeRange(parseLocalTime(timeStr[0]), parseLocalTime(timeStr[1])));
                        break;

                    case TEXT:

                        subtitle.addLine(line);
                        break;

                    case EMPTY:

                        if (inSubtitle) {

                            subtitle = null;  // make it null to cause NPE (fail fast)
                            inSubtitle = false;
                        }

                        break;
                    default:
                        throw new IllegalStateException("File should only contain known SRT lines. line: '" + line + "'");
                }
            }
        }
        catch(IllegalStateException ise) {
            throw ise;
        }
        catch(Exception e) {
            throw new RuntimeException("Error on input file line " + srcFileLineNum, e);
        }

        return subtitles;
    }

    @VisibleForTesting
    public static LocalTime parseLocalTime(String timeStr)
    {
        return LocalTime.parse(timeStr.trim(), SRT_TIME_FORMATTER);
    }


    /*
    Although the time line can contain positioning info, for now I only want the times.
     */
    String[] parseTimeStrings(String line)
    {
        String[] timeStr = line.split(TIME_SYMBOL);
        if(timeStr[1].contains("X1"))
        {
            timeStr[1] = timeStr[1].trim().split(" ")[0];  // in case: 00:00:10,500 --> 00:00:13,000 X1:63 X2:223 Y1:43 Y2:58
        }

        return timeStr;
    }

    /**
     * @param line a trimmed, non-null line.
     */
    @VisibleForTesting
    LineType determineLineType(String line )
    {
        if(line.length()==0)
        {
            return LineType.EMPTY;
        }
        else if(line.contains(TIME_SYMBOL))
        {
            return LineType.TIME;
        }
        else if(StringUtils.isNumeric(line))
        {
            /*
            This could be wrong.
            In american sniper thai subs, there was a line with just a number.  It was interpreted
            as an item number, but it was valid sub text.
            Because it was interpreted as an item, the parser threw an illegal state exception.
             */
            return LineType.ITEM_NUM;
        }
        else
        {
            return LineType.TEXT;
        }
    }
}
