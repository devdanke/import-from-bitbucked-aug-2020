package com.menlospark.lingo.subtility.features.shift;

import com.google.common.collect.Lists;
import com.menlospark.lingo.subtility.model.Cue;

import java.util.List;


public class TimeShifter
{
    /**
     * NOTE: 0 milli seconds shift is allowed, because sometimes, just want to rerun processing to pickup
     * new features/format etc.
     *
     * @param cues
     * @param shiftSeconds +/- to shift time forward or backward. by milliseconds.
     */
    public static List<Cue> shift(List<Cue> cues, long shiftMillis)
    {
        List<Cue> result = Lists.newArrayList();
                
        if(cues.size() == 0) return cues;

        int i = 1;
        for(Cue cue : cues)
        {
            Cue newCue = new Cue(cue).shiftByMillis(shiftMillis);
            newCue.setItemNumber(i++);
            result.add(newCue);
        }
        
        return result;
    }
}
