package com.menlospark.lingo.subtility.vtt;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.io.Files;
import com.menlospark.lingo.subtility.model.Cue;

import java.io.File;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class VttOutputter {

    public static DateTimeFormatter WEBVTT_TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss.SSS"); // 22:00:59.001

    private static final ObjectMapper jackson = new ObjectMapper();

    public static void makeVttFile(String outputFilePath, List<Cue> cues)
    {
        makeVttFile(new File(outputFilePath), cues);
    }

    public static void makeVttFile(File outfile, List<Cue> cues)
    {
        if(!outfile.getName().toLowerCase().endsWith("vtt")) {
            outfile = new File(outfile.getParentFile(), outfile.getName()+".vtt");
        }

        StringBuilder sb = new StringBuilder("WEBVTT\n\n");
        for(Cue cue : cues)
        {
            sb.append(toWebVtt(cue)).append("\n");
        }

        try
        {
            Files.write(sb.toString(), outfile, Charsets.UTF_8 );
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    static String toWebVtt(Cue cue)
    {
        StringBuilder sb = new StringBuilder();

        sb.append(cue.getItemNumber()).append("\n");
        sb.append(WEBVTT_TIME_FORMATTER.format(cue.getStart())).append(" --> ")
                .append(WEBVTT_TIME_FORMATTER.format(cue.getEnd())).append("\n");
        for(String line : cue.getLines())
        {
            sb.append(line).append("\n");
        }
        sb.append("\n");
        return sb.toString();
    }

}
