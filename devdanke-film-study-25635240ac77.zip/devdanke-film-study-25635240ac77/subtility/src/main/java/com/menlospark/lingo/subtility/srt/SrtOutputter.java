package com.menlospark.lingo.subtility.srt;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.io.Files;
import com.menlospark.lingo.subtility.model.Cue;

import java.io.File;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class SrtOutputter {

    public static DateTimeFormatter SRT_TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss,SSS"); // 22:00:59,001

    private static final ObjectMapper jackson = new ObjectMapper();


    public static void makeSrtFile(File outDir, String baseFileName, List<Cue> cues)
    {
        StringBuilder sb = new StringBuilder("\n");
        for(Cue cue : cues)
        {
            sb.append(toSrt(cue)).append("\n");
        }

        File f = new File(outDir, baseFileName+".srt");

        try
        {
            f.createNewFile();
            Files.write(sb.toString(), f, Charsets.UTF_8 );
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }


    public static String toSrt(Cue cue)
    {
        StringBuilder sb = new StringBuilder();

        sb.append(cue.getItemNumber()).append("\n");
        sb.append(SRT_TIME_FORMATTER.format(cue.getStart())).append(" --> ")
                .append(SRT_TIME_FORMATTER.format(cue.getEnd())).append("\n");
        for(String line : cue.getLines())
        {
            sb.append(line).append("\n");
        }
        sb.append("\n");
        return sb.toString();
    }

}
