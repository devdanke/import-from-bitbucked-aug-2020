## Overview ##

This project is mainly to create a video player 
customized to assist with learning a foreign language.
The video and subtitles files are made from
multi-language dvds.  The videos have a foreign audio
 track (the target language) and have subtitles for 
 both the target native language.
 
### projects 
* content-tools
* vtt
* web-ui 


