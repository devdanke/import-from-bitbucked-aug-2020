# TODO
- move source code to github

- create not verified page.  and go to it.
    - revise logins buttons to be either for unverified or verified
    - for unverified_landing, have button to go to login verified page       

- access any google api

- signin with another provider (github etc)

- signin with yahoo





---
- reset password
- enable each login type of page to show an error.                    
- add feature, login/verify by phone (verify new account email)
- while logged in, enable photo upload to bucket?
- have page for delete account

----
- add feature, safely send login status to server (probably encrypted jwt)
- what is rest api for my company's admin to reset/disable/delete account?

--- nice ---
- show onAuthChange in snack bar
- enable username change, while keeping other things the same.


## Done
- may want to inherit login and register page from common parent
- add feature, login/verify by email (verify new account email)
- show fuller info on login page 
- after create acct, go to landing
- create user class that can logout and show info.
- show gsignin login info (from the Future)
- sign into app via googleSignIn    
- import google signin in pubspec.yml 
- get debug sha hash (password default is 'android')

    me3:flutter_auth_demo me$ keytool -exportcert -list -v -alias androiddebugkey -keystore ~/.android/debug.keystore
        Enter keystore password:  
        Alias name: androiddebugkey
        Creation date: Dec 8, 2018
        Entry type: PrivateKeyEntry
        Certificate chain length: 1
        Certificate[1]:
        Owner: C=US, O=Android, CN=Android Debug
        Issuer: C=US, O=Android, CN=Android Debug
        Serial number: 1
        Valid from: Sat Dec 08 22:16:09 PST 2018 until: Mon Nov 30 22:16:09 PST 2048
        Certificate fingerprints:
                 MD5:  02:65:BD:F4:EB:E3:AA:A4:B2:A4:3B:D0:4F:F8:74:96
                 SHA1: 1E:6A:D9:85:81:00:D5:B2:61:C2:B5:90:3F:24:2B:62:90:D6:72:94
                 SHA256: 36:2E:44:0D:47:EF:DE:A8:79:A2:B0:50:DD:5B:9E:74:22:C7:E8:6E:76:43:92:55:81:DB:B5:F0:56:1B:A3:A8
                 Signature algorithm name: SHA1withRSA
                 Version: 1
- refactor app so i can do each of these as separately as possible.
- add feature: create user 
- add feature: login 


- [Cookbook: Useful Flutter samples](https://flutter.io/docs/cookbook)
- [online documentation](https://flutter.io/docs)