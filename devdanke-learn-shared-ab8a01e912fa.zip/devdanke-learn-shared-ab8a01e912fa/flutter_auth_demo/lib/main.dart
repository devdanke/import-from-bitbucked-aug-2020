import 'package:flutter/material.dart';
import 'package:flutter_auth_demo/pages/menu_page.dart';
import 'package:flutter_auth_demo/pages/login_page.dart';
import 'package:flutter_auth_demo/pages/register_page.dart';
import 'package:flutter_auth_demo/pages/register_email_verify_page.dart';
import 'package:flutter_auth_demo/pages/gsignin_page.dart';
import 'package:flutter_auth_demo/pages/goodbye_page.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext ctx) {

    print("**********************************************");
    print("************ init app ************************");
    print("**********************************************");

    return MaterialApp(

      initialRoute: '/',
      routes: {
        '/': (context) => HomePage(),
        '/login': (context) => LoginPage(),
        '/register': (context) => RegisterPage(),
        '/register_email_verify': (context) => RegisterEmailVerifyPage(),
        '/gsignin': (context) => GoogleSignInPage(),
        '/goodbye': (context) => GoodbyePage(),
      },

    );
  }
}
