import 'package:google_sign_in/google_sign_in.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:collection';


abstract class AbstractUser {

  void logout();
  String getDisplayName();
  Map<String,String> getInfo();
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

class FbaseUser extends AbstractUser {

  FirebaseUser _fbaseUser;
  FirebaseAuth _fbaseAuth;

  FbaseUser(FirebaseUser fbaseUser, FirebaseAuth fbaseAuth) {
    this._fbaseUser = fbaseUser;
    this._fbaseAuth = fbaseAuth;
    FirebaseAuth.instance.onAuthStateChanged.listen((user) {
      print("FbaseUser: authStateChanged: ${user.toString()}");
      print(".");
    });
    _logInfo();
  }

  Map<String,String> getInfo(){
    var info =  mapify(_fbaseUser);

    //info['fba.toString'] = _fbaseAuth.toString() ;

    return info;
  }

  void _logInfo() {
    print("FbaseUser: _fbaseUser: ${_fbaseUser.toString()}");
    print("FbaseUser: _fbaseAuth: ${_fbaseAuth.toString()}");
    print(".");
  }

  String getDisplayName() {
    return _fbaseUser.email;
  }

  void logout() async {
    await _fbaseAuth.signOut();
    _logInfo();
  }
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

class GoogSigninUser extends AbstractUser {

  FirebaseUser _fbaseUser;
  FirebaseAuth _fbaseAuth;
  GoogleSignIn _googSignin;

  GoogSigninUser(FirebaseUser fbaseUser, FirebaseAuth fbaseAuth, GoogleSignIn googSignin) {
    this._fbaseUser = fbaseUser;
    this._fbaseAuth = fbaseAuth;
    this._googSignin = googSignin;

    FirebaseAuth.instance.onAuthStateChanged.listen((user) {
      print("GoogSigninUser: authStateChanged: ${user.toString()}");
      print(".");
    });
    _logInfo();
  }

  Map<String,String> getInfo(){

    var info =  mapify(_fbaseUser);

    //info['fba.toString'] = _fbaseAuth.toString() ;

    info['gsi.toString'] = _googSignin.toString() ;
    info['gsi.domain'] = _googSignin.hostedDomain ;
    info['gsi.scopes'] = _googSignin.scopes.toString() ;

    return info;
  }

  void _logInfo() {
    print("GoogSigninUser: _fbaseUser: ${_fbaseUser.toString()}");
    print("GoogSigninUser: _fbaseAuth: ${_fbaseAuth.toString()}");
    print("GoogSigninUser: _googSignin: ${_googSignin.toString()}");
    print(".");
  }

  String getDisplayName() {
    return _fbaseUser.displayName;
  }

  void logout() async {
    await _googSignin.signOut();
    _logInfo();
  }
}

Map<String,String> mapify(FirebaseUser fbaseUser) {
  var info =  SplayTreeMap<String,String>();

  fbaseUser.getIdToken().then((value) => info['idToken'] = value ) ;
  //info['fbu.toString'] = fbaseUser.toString();
  info['email'] = fbaseUser.email ;
  info['dispName'] = fbaseUser.displayName ;
  info['isAnon'] = fbaseUser.isAnonymous.toString() ;
  info['isEmailVerify'] = fbaseUser.isEmailVerified.toString() ;
  info['metadata'] = fbaseUser.metadata.toString() ;
  info['phone'] = fbaseUser.phoneNumber ;
  info['photo'] = fbaseUser.photoUrl ;
  info['provider'] = fbaseUser.providerId ;
  info['uid'] = fbaseUser.uid ;

  return info;
}


