import 'package:flutter/material.dart';
import 'package:flutter_auth_demo/konst.dart';


class LoginData {
  String email;
  String password;
  LoginData(this.email, this.password);
}


class LoginWidget extends StatefulWidget {

  Function btnPressHandler; // will be given buildContext and LoginData.
  String btnText;

  LoginWidget(Function onPressHandler, String btnText){
    this.btnPressHandler = onPressHandler;
    this.btnText = btnText;
  }

  @override
  State<StatefulWidget> createState() => _LoginWidgetState();
}


class _LoginWidgetState extends State<LoginWidget> {
  
  final formKey = GlobalKey<FormState>();
  String _email;
  String _password;

  @override
  Widget build(BuildContext ctx) {
    return Container(
            padding: EDGE_STYLE,
            child: Form(
              key: formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TextFormField(
                    decoration: InputDecoration(labelText: "Email"),
                    validator: (value) => value.isEmpty ? "Email can't be empty": null,
                    onSaved: (value) => _email = value,
                  ),
                  TextFormField(
                    decoration: InputDecoration(labelText: "Password"),
                    obscureText: true,
                    validator:  (value) => value.isEmpty ? "Password can't be empty": null,
                    onSaved: (value) => _password = value,
                  ),
                  RaisedButton(
                    child: Text(widget.btnText , style: MY_TEXT_STYLE),
                    onPressed: () => validateAndSave(ctx),
                  ),
                ],
              ),
            )
        );
  }


  void validateAndSave(BuildContext ctx) {

    final form = formKey.currentState;

    if(form.validate()) {
      form.save();
      print("Form is valid! email: $_email, pass: $_password");
      widget.btnPressHandler(ctx, LoginData(_email, _password));
    }
    else {
      print("Form Not valid :-(  email: $_email, pass: $_password");
    }
  }

}