import 'package:flutter/material.dart';

String runTime = DateTime.now().toIso8601String().substring(5,16).replaceFirst("T", " ");
final APP_NAME = Text("Auth Demo $runTime");

const MY_TEXT_STYLE = TextStyle(fontSize: 20.0);
const SMALLER_TEXT_STYLE = TextStyle(fontSize: 15.0);
const EDGE_STYLE = EdgeInsets.all(15.0);
