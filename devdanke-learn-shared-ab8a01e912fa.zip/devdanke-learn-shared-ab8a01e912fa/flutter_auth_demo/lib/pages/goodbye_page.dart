import 'package:flutter/material.dart';
import '../konst.dart';


class GoodbyePage extends StatelessWidget {
  @override
  Widget build(BuildContext ctx) {
    return Scaffold(
      appBar: AppBar(title: APP_NAME),
      body: Container(
        padding: EDGE_STYLE,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text("You're logged out.  Good bye!", style: MY_TEXT_STYLE,),
            RaisedButton(
              child: Text("Menu", style: MY_TEXT_STYLE),
              onPressed: () => Navigator.pushNamed(ctx, '/'),
            ),
          ],
        ),
      )
    );
  }
}





