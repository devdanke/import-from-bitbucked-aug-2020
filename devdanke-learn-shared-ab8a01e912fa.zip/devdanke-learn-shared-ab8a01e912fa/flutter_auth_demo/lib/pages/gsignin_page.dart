import 'package:flutter/material.dart';
import '../konst.dart';
import '../user.dart';
import 'landing_page.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'dart:async';


class GoogleSignInPage extends StatefulWidget {

  @override
  State<StatefulWidget> createState() => _GoogleSignInPageState();
}

class _GoogleSignInPageState extends State<GoogleSignInPage> {

  @override
  Widget build(BuildContext ctx) {
    return Scaffold(
        appBar: AppBar(title: APP_NAME),
        body: Container(
            padding: EDGE_STYLE,
            child: Form(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  RaisedButton(
                    child: Text("Google Signin!", style: MY_TEXT_STYLE,),
                    onPressed: () => tryGoogSignIn(ctx),
                  ),
                ],
              ),
            )
        )
    );
  }


   void tryGoogSignIn(BuildContext ctx) async {

    final Future<GoogSigninUser> future = doLogin();

    if(future != null) {
      future.then((user) {
        print("Google signin success: ${user.toString()}");
        Navigator.push(context, MaterialPageRoute(builder: (context) => LandingPage(user)));
      });
    }
    else {
      print("Google signin fail");
    }
  }


  Future<GoogSigninUser> doLogin() async {

    final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
    final GoogleSignIn _googleSignIn = GoogleSignIn();

    final GoogleSignInAccount googAcct = await _googleSignIn.signIn();
    final GoogleSignInAuthentication googleAuth = await googAcct.authentication;

    final FirebaseUser googUser = await _firebaseAuth.signInWithGoogle(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    assert(googUser.email != null);
    assert(googUser.displayName != null);
    assert(await googUser.getIdToken() != null);

    // TODO: why compare?  what is relationship between curUser and googUser?
    final FirebaseUser currentUser = await _firebaseAuth.currentUser();
    assert(googUser.uid == currentUser.uid);

    print("googUser: ${googUser.toString()}");
    print("curUser: ${currentUser.toString()}");

    return GoogSigninUser(googUser, _firebaseAuth, _googleSignIn);
  }
}






