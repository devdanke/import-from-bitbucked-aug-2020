import 'package:flutter/material.dart';
import '../konst.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext ctx) {
    
    return Scaffold(
      appBar: AppBar(title: APP_NAME),
      body: Container(
        padding: EDGE_STYLE,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            RaisedButton(
              child: Text("Login", style: MY_TEXT_STYLE,),
              onPressed: () => Navigator.pushNamed(ctx, '/login'),
            ),
            RaisedButton(
              child: Text("Create Account", style: MY_TEXT_STYLE),
              onPressed: () => Navigator.pushNamed(ctx, '/register'),
            ),
            RaisedButton(
              child: Text("Create Account with Email Verify", style: MY_TEXT_STYLE),
              onPressed: () => Navigator.pushNamed(ctx, '/register_email_verify'),
            ),
            RaisedButton(
              child: Text("Google Sign-in", style: MY_TEXT_STYLE),
              onPressed: () => Navigator.pushNamed(ctx, '/gsignin'),
            ),
          ],
        ),
      )
    );
  }
}





