import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:flutter_auth_demo/konst.dart';
import 'package:flutter_auth_demo/user.dart';
import 'package:flutter_auth_demo/compo/login_widget.dart';
import 'landing_page.dart';

class RegisterPage extends StatelessWidget {

  @override
  Widget build(BuildContext ctx) {
    return Scaffold(
        appBar: AppBar(title: APP_NAME),
        body: LoginWidget(validateAndSubmit, "Register")
        );
  }

  void validateAndSubmit(BuildContext ctx, LoginData loginData) async {
    try {
        FirebaseAuth firebaseAuth = FirebaseAuth.instance;
        FirebaseUser firebaseUser =
          await firebaseAuth.createUserWithEmailAndPassword(
              email: loginData.email, password: loginData.password);
        print("Registered user: ${firebaseUser.uid}");

        FbaseUser fbaseUser = FbaseUser(firebaseUser, firebaseAuth);
        Navigator.push(ctx, MaterialPageRoute(builder: (context) => LandingPage(fbaseUser)));
    }
    catch (e) {
      print("Login error: ${e.toString()}");
    }
  }

}