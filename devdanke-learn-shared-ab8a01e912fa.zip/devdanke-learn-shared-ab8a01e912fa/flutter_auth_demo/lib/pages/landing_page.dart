import 'package:flutter/material.dart';
import '../konst.dart';
import 'package:flutter_auth_demo/user.dart';

class LandingPage extends StatelessWidget {

  AbstractUser _user;


  LandingPage(this._user);

  @override
  Widget build(BuildContext ctx) {

    var header = [text("Congrats ${_user.getDisplayName()}, you're logged in!")];

    var infoTexts = List<Text>();
    _user.getInfo().forEach((k,v) => infoTexts.add(text('${k} = ${v}')));

    var btn = [ RaisedButton(
      child: Text("Logout", style: MY_TEXT_STYLE),
      onPressed: () => logout(ctx),
    )];

    List<Widget> kids = [blankLine()];
    kids.addAll(header);
    kids.addAll(blankLines());
    kids.addAll(infoTexts);
    kids.addAll(blankLines());
    kids.addAll(btn);

    return Scaffold(
      appBar: AppBar(title: APP_NAME),
      body: Container(
        padding: EDGE_STYLE,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: kids,
        ),
      )
    );
  }

  void logout(BuildContext ctx) {
    _user.logout();
    Navigator.pushNamed(ctx, '/goodbye');
  }

  Text text(String value) {
    return Text(value, style: SMALLER_TEXT_STYLE);
  }

  Text blankLine() {
    return text("");
  }

  List<Text> blankLines(){
    return [blankLine(),blankLine(),blankLine()];
  }
}





