import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:flutter_auth_demo/konst.dart';
import 'package:flutter_auth_demo/user.dart';
import 'package:flutter_auth_demo/compo/login_widget.dart';
import 'package:flutter_auth_demo/pages/landing_page.dart';

class RegisterEmailVerifyPage extends StatelessWidget {

  @override
  Widget build(BuildContext ctx) {
    return Scaffold(
        appBar: AppBar(title: APP_NAME),
        body: LoginWidget(submit, "Register Email Verify")
    );
  }

  Future<void> submit(BuildContext ctx, LoginData loginData) async {

    final Future<FbaseUser> future = doLogin(ctx, loginData);

    if(future != null) {
      future.then((user) {
        print("Firebase login success: ${user.toString()}");
        Navigator.push(ctx, MaterialPageRoute(builder: (context) => LandingPage(user)));
      });
    }
    else {
      print("Firebase login fail");
    }
  }


  Future<FbaseUser> doLogin(BuildContext ctx, LoginData loginData) async {

    FirebaseAuth fbaseAuth = FirebaseAuth.instance;
    FirebaseUser firebaseUser = await fbaseAuth.createUserWithEmailAndPassword(
      email: loginData.email, password: loginData.password);
    firebaseUser.sendEmailVerification();
    print("verification email sent");

    return FbaseUser(firebaseUser, fbaseAuth);
  }
}