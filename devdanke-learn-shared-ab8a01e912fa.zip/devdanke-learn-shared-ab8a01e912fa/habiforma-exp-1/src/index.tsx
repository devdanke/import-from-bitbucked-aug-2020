import * as React from 'react';
import * as ReactDOM from 'react-dom';

import { Provider } from 'react-redux';

import * as injectTapEventPlugin from 'react-tap-event-plugin'; // for material-ui

import './index.css';
import App from './App';

import registerServiceWorker from './registerServiceWorker';
import stateMgr from "./state/MyStateManager";

injectTapEventPlugin();  // for material-ui

let store: object = stateMgr.initAppDbStore()
console.log("in index.tsx render()")

ReactDOM.render(
    <Provider store={store}>
        <App />
    </Provider>
    ,
    document.getElementById('root'));

registerServiceWorker();

