"use strict";
exports.__esModule = true;
var React = require("react");
var ReactDOM = require("react-dom");
var react_redux_1 = require("react-redux");
var injectTapEventPlugin = require("react-tap-event-plugin"); // for material-ui
require("./index.css");
var App_1 = require("./App");
var registerServiceWorker_1 = require("./registerServiceWorker");
var MyStateManager_1 = require("./state/MyStateManager");
injectTapEventPlugin(); // for material-ui
var store = MyStateManager_1["default"].initAppDbStore();
console.log("in index.tsx render()");
ReactDOM.render(React.createElement(react_redux_1.Provider, { store: store },
    React.createElement(App_1["default"], null)), document.getElementById('root'));
registerServiceWorker_1["default"]();
