"use strict";
exports.__esModule = true;
/* eslint-disable */
var MyUtils = /** @class */ (function () {
    function MyUtils() {
    }
    MyUtils.exists = function (thing) {
        return (typeof thing !== 'undefined');
    };
    // https://stackoverflow.com/questions/34401098/remove-a-property-in-an-object-immutably
    MyUtils.removeProperty = function (deleteKey, obj) {
        return Object.assign({}, obj, {
            c: Object.keys(obj).reduce(function (result, key) {
                if (key !== deleteKey) {
                    result[key] = obj[key];
                }
                return result;
            }, {})
        });
    };
    MyUtils.genHashCode = function (s) {
        return s.split("").reduce(function (a, b) { a = ((a << 5) - a) + b.charCodeAt(0); return a & a; }, 0);
    };
    // rand int between 0 and Number.MAX_SAFE_INTEGER
    MyUtils.genRandInt = function () {
        //return Math.random() *  Math.random() * (Number.MAX_SAFE_INTEGER - 1) + 1;  //this causes ts2339
        return Math.random() * Math.random() * (Number.MAX_VALUE - 1) + 1;
    };
    MyUtils.isNullOrEmpty = function (val) {
        var result = ((val == null) || (val.trim().length == 0));
        //console.log("isNullOrEmpty(): result=", result )
        return result;
    };
    /*
    removeItem item from array.
    return nothing
     */
    MyUtils.removeItem = function (arr, item) {
        var index = arr.indexOf(item);
        if (index > -1) {
            arr.splice(index, 1);
        }
    };
    return MyUtils;
}());
exports["default"] = MyUtils;
