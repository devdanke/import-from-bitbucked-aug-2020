/* eslint-disable */
export default class MyDateUtils {

    private static MONTHS_1ST_CHAR: string[] = ['J','F','M','A','M','J','J','A','S','O','N','D']


    public static toYyyymmdd(aDate: Date): string {

        const m = aDate.getMonth()+1
        const mm = (m > 9) ? m.toString() : '0'+m
        //console.log("toYyyymmdd() m type:", (typeof m), "mm type:", (typeof mm), "mm:", mm)

        const d = aDate.getDate()
        const dd = (d > 9) ? d.toString() : '0'+d

        const yyyy = aDate.getFullYear().toString();

        const result = yyyy+mm+dd;
        //console.log("toYyyymmdd() aDate:", aDate, "result:", result)

        return result
    }

    public static month1stChar(yyyymmdd: string): string {

        return MyDateUtils.MONTHS_1ST_CHAR[parseInt(yyyymmdd.substr(4,2))-1]
    }
}

