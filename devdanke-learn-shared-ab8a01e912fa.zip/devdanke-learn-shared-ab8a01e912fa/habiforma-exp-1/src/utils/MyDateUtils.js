"use strict";
exports.__esModule = true;
/* eslint-disable */
var MyDateUtils = /** @class */ (function () {
    function MyDateUtils() {
    }
    MyDateUtils.toYyyymmdd = function (aDate) {
        var m = aDate.getMonth() + 1;
        var mm = (m > 9) ? m.toString() : '0' + m;
        //console.log("toYyyymmdd() m type:", (typeof m), "mm type:", (typeof mm), "mm:", mm)
        var d = aDate.getDate();
        var dd = (d > 9) ? d.toString() : '0' + d;
        var yyyy = aDate.getFullYear().toString();
        var result = yyyy + mm + dd;
        //console.log("toYyyymmdd() aDate:", aDate, "result:", result)
        return result;
    };
    MyDateUtils.month1stChar = function (yyyymmdd) {
        return MyDateUtils.MONTHS_1ST_CHAR[parseInt(yyyymmdd.substr(4, 2)) - 1];
    };
    MyDateUtils.MONTHS_1ST_CHAR = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'];
    return MyDateUtils;
}());
exports["default"] = MyDateUtils;
