/* eslint-disable */
export default class MyUtils {

    public static exists(thing: any): boolean {
        return (typeof thing !== 'undefined')
    }

    // https://stackoverflow.com/questions/34401098/remove-a-property-in-an-object-immutably
    static removeProperty(deleteKey: string, obj: object): object {

        return (<any>Object).assign({} as object, obj, {

            c: Object.keys(obj).reduce((result, key) => {

                if (key !== deleteKey) {
                    result[key] = obj[key];
                }

                return result;
            }, {})
        });
    }


    static genHashCode(s): string {
        return s.split("").reduce(function(a,b){a=((a<<5)-a)+b.charCodeAt(0);return a&a},0);
    }

    // rand int between 0 and Number.MAX_SAFE_INTEGER
    static genRandInt(): number {
        //return Math.random() *  Math.random() * (Number.MAX_SAFE_INTEGER - 1) + 1;  //this causes ts2339
        return Math.random() *  Math.random() * (Number.MAX_VALUE - 1) + 1;
    }

    static isNullOrEmpty(val: string): boolean {
        let result = ((val == null) || (val.trim().length == 0))
        //console.log("isNullOrEmpty(): result=", result )
        return result
    }

    /*
    removeItem item from array.
    return nothing
     */
    static removeItem(arr: any[], item: any): void {
        let index = arr.indexOf(item);
        if (index > -1) {
            arr.splice(index, 1);
        }
    }

}

