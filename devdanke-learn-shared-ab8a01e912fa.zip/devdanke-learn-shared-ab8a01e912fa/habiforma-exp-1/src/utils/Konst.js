"use strict";
exports.__esModule = true;
// better if module?
var Konst = /** @class */ (function () {
    function Konst() {
    }
    Konst.HABITS_BY_ID = "habitsById";
    Konst.ADD_HABIT = "ADD_HABIT";
    Konst.REPLACE_HABIT = "REPLACE_HABIT";
    Konst.DELETE_HABIT = "DELETE_HABIT";
    Konst.HABIT_ADD_DONE_DATE = "HABIT_ADD_DONE_DATE";
    Konst.HABIT_DELETE_DONE_DATE = "HABIT_DELETE_DONE_DATE";
    Konst.HAB_ID = "id";
    Konst.HAB_NAME = "name";
    Konst.HAB_HIST = "hist";
    return Konst;
}());
exports["default"] = Konst;
