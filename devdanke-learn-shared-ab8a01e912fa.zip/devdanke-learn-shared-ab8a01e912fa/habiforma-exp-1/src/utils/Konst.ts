
// better if module?
export default class Konst {
    static readonly HABITS_BY_ID: string = "habitsById";

    static readonly ADD_HABIT: string =     "ADD_HABIT";
    static readonly REPLACE_HABIT: string = "REPLACE_HABIT";
    static readonly DELETE_HABIT: string =  "DELETE_HABIT";

    static readonly HABIT_ADD_DONE_DATE: string =  "HABIT_ADD_DONE_DATE";
    static readonly HABIT_DELETE_DONE_DATE: string =  "HABIT_DELETE_DONE_DATE";


    static readonly HAB_ID: string = "id";
    static readonly HAB_NAME: string = "name";
    static readonly HAB_HIST: string = "hist";
}
