"use strict";
exports.__esModule = true;
/* eslint-disable */
var redux_1 = require("redux");
var Konst_1 = require("../utils/Konst");
var MyUtils_1 = require("../utils/MyUtils");
var MyStateManager = /** @class */ (function () {
    function MyStateManager() {
    }
    /*
    A way to get just the data needed to render front page habits list.
    To be used with connect() for more fine grained access to appDb contents.
     */
    MyStateManager.getHabitListState = function (state) {
        console.log("getHabitListState()");
        return Object.values(state[Konst_1["default"].HABITS_BY_ID]);
    };
    MyStateManager.getHabitById = function (state, habId) {
        console.log("getHabitsByIdMapState()");
        return state[Konst_1["default"].HABITS_BY_ID][habId];
    };
    MyStateManager.getHabitNames = function (state) {
        console.log("getHabitNames()");
        return Object.values(MyStateManager.getHabitListState(state)).map(function (habit) { return habit[Konst_1["default"].HAB_NAME]; });
    };
    MyStateManager.isDupHabitName = function (state, candidateHabitName) {
        console.log("isDupHabitName()");
        return MyStateManager.getHabitNames(state).indexOf(candidateHabitName) > -1;
    };
    MyStateManager._replaceHabit2 = function (state, replacementHabit) {
        console.log("myStateManager._replaceHabit2() replacementHabit:", replacementHabit);
        var replacementHabitId = replacementHabit[Konst_1["default"].HAB_ID];
        var replaceNewHabitsById = Object.assign({}, state[Konst_1["default"].HABITS_BY_ID], (_a = {}, _a[replacementHabitId] = replacementHabit, _a));
        var result = Object.assign({}, state, (_b = {}, _b[Konst_1["default"].HABITS_BY_ID] = replaceNewHabitsById, _b));
        console.log("_replacementHabit2() result:", result);
        return result;
        var _a, _b;
    };
    MyStateManager._replaceHabit = function (state, action) {
        console.log("myStateManager._replaceHabit(state,action)");
        var replacementHabit = action["targetHabit"];
        return MyStateManager._replaceHabit2(state, replacementHabit);
    };
    /*
    This is the official state changer function that I register with redux to do all state transformations.
    All state is contained in my AppDb object tree.  Only this function changes that state.

    actionObject has TODO: make typescript interface for action param type
    - a type field
    - a text field

    stateObject a state object that has fields that my app knows how to read from.
     */
    MyStateManager.myStateMangerFunc = function (state, action) {
        console.log("myStateManager() action:", action);
        var targetHabitId = null;
        var targetHabit = null;
        var doneDates = null;
        switch (action.type) {
            case Konst_1["default"].ADD_HABIT:
                targetHabitId = "hab-" + MyUtils_1["default"].genRandInt();
                var newHabit = Object.assign({}, action["targetHabit"], { "id": targetHabitId });
                console.log("adding newHabit=", newHabit);
                var addNewHabitsById = Object.assign({}, state[Konst_1["default"].HABITS_BY_ID], (_a = {}, _a[targetHabitId] = newHabit, _a));
                console.log("myStateManager(): ADD_HABIT");
                return Object.assign({}, state, (_b = {}, _b[Konst_1["default"].HABITS_BY_ID] = addNewHabitsById, _b));
            case Konst_1["default"].REPLACE_HABIT:
                return MyStateManager._replaceHabit(state, action);
            case Konst_1["default"].DELETE_HABIT:
                targetHabitId = action[Konst_1["default"].HABITS_BY_ID];
                var deleteNewHabitsById = MyUtils_1["default"].removeProperty(targetHabitId, state[Konst_1["default"].HABITS_BY_ID]);
                console.log("myStateManager(): DELETE_HABIT");
                return Object.assign({}, state, (_c = {}, _c[Konst_1["default"].HABITS_BY_ID] = deleteNewHabitsById, _c));
            case Konst_1["default"].HABIT_ADD_DONE_DATE:
                targetHabit = MyStateManager.getHabitById(state, action.habId);
                // TODO: should i use Object apply to change the habit?
                // TODO: Would that restirct notifications to dependent ui components just to the doneDates array?
                if (targetHabit.hist.indexOf(action.targetDate) == -1) {
                    targetHabit.hist.push(action.targetDate);
                }
                else {
                    console.error("ILLEGAL STATE: TARGET DONE DATE WAS ALREADY IN HABIT HISTORY !!! ");
                }
                console.log("myStateManager(): HABIT_ADD_DONE_DATE, targetHaibt:", targetHabit);
                return MyStateManager._replaceHabit2(state, targetHabit);
            case Konst_1["default"].HABIT_DELETE_DONE_DATE:
                targetHabit = MyStateManager.getHabitById(state, action.habId);
                MyUtils_1["default"].removeItem(targetHabit.hist, action.targetDate);
                console.log("myStateManager(): HABIT_DELETE_DONE_DATE, targetHaibt:", targetHabit);
                return MyStateManager._replaceHabit2(state, targetHabit);
            case "@@redux/INIT":
                console.log("myStateManager(): normal redux app start up");
                return state;
            default:
                console.error("ERROR myStateManager(): unknown action.type", action.type);
                return state;
        }
        var _a, _b, _c;
    };
    MyStateManager.initAppDbStore = function () {
        var initialHabitDb = (_a = {},
            _a[Konst_1["default"].HABITS_BY_ID] = {
                "hab-1": (_b = {}, _b[Konst_1["default"].HAB_ID] = "hab-1", _b[Konst_1["default"].HAB_NAME] = "BOT LO < 11:30", _b[Konst_1["default"].HAB_HIST] = ["20171030", "20171109", "20171113"], _b),
                "hab-2": (_c = {}, _c[Konst_1["default"].HAB_ID] = "hab-2", _c[Konst_1["default"].HAB_NAME] = "nang samatee", _c[Konst_1["default"].HAB_HIST] = ["20171101", "20171102", "20171103", "20171114"], _c),
                "hab-3": (_d = {}, _d[Konst_1["default"].HAB_ID] = "hab-3", _d[Konst_1["default"].HAB_NAME] = "exercise", _d[Konst_1["default"].HAB_HIST] = [], _d),
                "hab-4": (_e = {}, _e[Konst_1["default"].HAB_ID] = "hab-4", _e[Konst_1["default"].HAB_NAME] = "work-relaxed", _e[Konst_1["default"].HAB_HIST] = ["20171109", "20171113"], _e)
            },
            _a);
        var appDb = redux_1.createStore(MyStateManager.myStateMangerFunc, initialHabitDb);
        console.log("appDb store initialized:", appDb.getState());
        return appDb;
        var _a, _b, _c, _d, _e;
    };
    return MyStateManager;
}());
exports["default"] = MyStateManager;
/*
export function testAppDb() {
    let appDb = createStore(myStateMangerFunc, initialHabitDb)

    appDb.dispatch({
        type: Konst.ADD_HABIT,
        newHabit: {[Konst.HAB_ID]: "hab-665", [Konst.HAB_NAME]: "my-new-habit", [Konst.HAB_HIST]: "--o--"}
    })

    console.log(appDb.getState())
}
*/
