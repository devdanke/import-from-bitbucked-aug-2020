

export interface IHabitData {
    id: string,
    name: string,
    hist: string[]
}


/*
This is expected to hold more than just habits.
Eventually, it (or added properties) would hold UI state for app pages.
*/
export interface IAppDb {
    habitsById: Map<string,IHabitData>
}




