/* eslint-disable */
import {createStore, Store} from 'redux';

import Konst from '../utils/Konst'
import MyUtils from '../utils/MyUtils'
import {IAppDb, IHabitData} from './IAppDb'

export default class MyStateManager {

    /*
    A way to get just the data needed to render front page habits list.
    To be used with connect() for more fine grained access to appDb contents.
     */
    static getHabitListState(state: IAppDb): IHabitData[] {
        console.log("getHabitListState()")
        return (<any> Object).values(state[Konst.HABITS_BY_ID])
    }

    static getHabitById(state: IAppDb, habId:string): IHabitData {
        console.log("getHabitsByIdMapState()")
        return state[Konst.HABITS_BY_ID][habId]
    }


    public static getHabitNames(state: IAppDb): Array<string> {
        console.log("getHabitNames()")
        return (<any> Object).values( MyStateManager.getHabitListState(state)).map(function(habit){ return habit[Konst.HAB_NAME] } )
    }

    public static isDupHabitName(state: IAppDb, candidateHabitName: string): boolean {
        console.log("isDupHabitName()")
        return MyStateManager.getHabitNames(state).indexOf(candidateHabitName) > -1
    }

    static _replaceHabit2(state: IAppDb, replacementHabit: IHabitData): object {

        console.log("myStateManager._replaceHabit2() replacementHabit:", replacementHabit)

        let replacementHabitId: string = replacementHabit[Konst.HAB_ID]
        let replaceNewHabitsById: string = (<any> Object).assign({}, state[Konst.HABITS_BY_ID], {[replacementHabitId]:replacementHabit})

        let result = (<any> Object).assign({}, state, {[Konst.HABITS_BY_ID]:replaceNewHabitsById})

        console.log("_replacementHabit2() result:", result)

        return result
    }

    static _replaceHabit(state: IAppDb, action: any): object {

        console.log("myStateManager._replaceHabit(state,action)")

        let replacementHabit: IHabitData = action["targetHabit"]

        return MyStateManager._replaceHabit2(state, replacementHabit)
    }


    /*
    This is the official state changer function that I register with redux to do all state transformations.
    All state is contained in my AppDb object tree.  Only this function changes that state.

    actionObject has TODO: make typescript interface for action param type
    - a type field
    - a text field

    stateObject a state object that has fields that my app knows how to read from.
     */
    public static myStateMangerFunc(state: IAppDb, action: any)
    {
        console.log("myStateManager() action:", action)

        let targetHabitId: string = null;
        let targetHabit: IHabitData = null
        let doneDates: string[] = null

        switch (action.type) {

            case Konst.ADD_HABIT:

                targetHabitId = "hab-" + MyUtils.genRandInt()

                const newHabit: string = (<any> Object).assign({}, action["targetHabit"], {"id":targetHabitId})
                console.log("adding newHabit=", newHabit)
                let addNewHabitsById: string = (<any> Object).assign({}, state[Konst.HABITS_BY_ID], {[targetHabitId]:newHabit})

                console.log("myStateManager(): ADD_HABIT")
                return (<any> Object).assign({}, state, {[Konst.HABITS_BY_ID]:addNewHabitsById})

            case Konst.REPLACE_HABIT:

                return MyStateManager._replaceHabit(state,action)

            case Konst.DELETE_HABIT:

                targetHabitId = action[Konst.HABITS_BY_ID];
                let deleteNewHabitsById: object = MyUtils.removeProperty(targetHabitId, state[Konst.HABITS_BY_ID])

                console.log("myStateManager(): DELETE_HABIT")
                return (<any> Object).assign({},  state, {[Konst.HABITS_BY_ID]:deleteNewHabitsById})

            case Konst.HABIT_ADD_DONE_DATE:

                targetHabit = MyStateManager.getHabitById(state, action.habId)

                // TODO: should i use Object apply to change the habit?
                // TODO: Would that restirct notifications to dependent ui components just to the doneDates array?

                if(targetHabit.hist.indexOf(action.targetDate)== -1) {
                    targetHabit.hist.push(action.targetDate)
                }
                else {
                    console.error("ILLEGAL STATE: TARGET DONE DATE WAS ALREADY IN HABIT HISTORY !!! ")
                }

                console.log("myStateManager(): HABIT_ADD_DONE_DATE, targetHaibt:", targetHabit)
                return MyStateManager._replaceHabit2(state, targetHabit)

            case Konst.HABIT_DELETE_DONE_DATE:

                targetHabit = MyStateManager.getHabitById(state, action.habId)

                MyUtils.removeItem(targetHabit.hist, action.targetDate)
                console.log("myStateManager(): HABIT_DELETE_DONE_DATE, targetHaibt:", targetHabit)
                return MyStateManager._replaceHabit2(state, targetHabit)

            case "@@redux/INIT":

                console.log("myStateManager(): normal redux app start up")
                return state

            default:

                console.error("ERROR myStateManager(): unknown action.type", action.type)
                return state
        }
    }


    public static initAppDbStore(): Store<any> {

        let initialHabitDb = {

            [Konst.HABITS_BY_ID]:{
                "hab-1": {[Konst.HAB_ID]: "hab-1", [Konst.HAB_NAME]: "BOT LO < 11:30",
                    [Konst.HAB_HIST]: ["20171030","20171109","20171113"] },

                "hab-2": {[Konst.HAB_ID]: "hab-2", [Konst.HAB_NAME]: "nang samatee",
                    [Konst.HAB_HIST]: ["20171101","20171102","20171103","20171114"]},


                "hab-3": {[Konst.HAB_ID]: "hab-3", [Konst.HAB_NAME]: "exercise",
                    [Konst.HAB_HIST]: []},

                "hab-4": {[Konst.HAB_ID]: "hab-4", [Konst.HAB_NAME]: "work-relaxed",
                    [Konst.HAB_HIST]: ["20171109","20171113"]}
            }
        };

        let appDb = createStore(MyStateManager.myStateMangerFunc, initialHabitDb)

        console.log("appDb store initialized:", appDb.getState())

        return <Store<any>> appDb;
    }

}




/*
export function testAppDb() {
    let appDb = createStore(myStateMangerFunc, initialHabitDb)

    appDb.dispatch({
        type: Konst.ADD_HABIT,
        newHabit: {[Konst.HAB_ID]: "hab-665", [Konst.HAB_NAME]: "my-new-habit", [Konst.HAB_HIST]: "--o--"}
    })

    console.log(appDb.getState())
}
*/

