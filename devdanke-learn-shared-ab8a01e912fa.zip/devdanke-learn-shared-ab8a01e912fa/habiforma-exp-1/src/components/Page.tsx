/* eslint-disable */

import * as React from 'react';
import {Component, ReactElement} from 'react';

import AppBar from 'material-ui/AppBar';
import Toolbar from "material-ui/Toolbar";
import ToolbarGroup from "material-ui/Toolbar/ToolbarGroup";
import IconButton from "material-ui/IconButton";
import ActionSettings from "material-ui/svg-icons/action/settings";
import {Link} from "react-router-dom";


interface PageProps {
    className: string,
    body: React.ReactNode,

    headerTitle: string,
    leftButton: ReactElement<any>,
    rightButton?: ReactElement<any>,
    showFooter?: boolean,
}

export default class Page extends Component <PageProps, object>{

  render() {

    const myAppBar = () => (
      <AppBar
          title={this.props.headerTitle}
          iconElementLeft={this.props.leftButton}
          iconElementRight={this.props.rightButton}
      />
    );

    return (
      <div className={this.props.className}>
          {myAppBar()}

          {this.props.body}

          { this.props.showFooter==true &&
              <Toolbar className="footerStyle">
                  <ToolbarGroup firstChild={true} />

                  <ToolbarGroup lastChild={true}>
                      <IconButton containerElement={<Link to="/settings"/>}>
                          <ActionSettings />
                      </IconButton>
                  </ToolbarGroup>
              </Toolbar>

          }

      </div>
    );
  }
}


