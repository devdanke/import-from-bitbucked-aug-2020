"use strict";
/* eslint-disable */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var React = require("react");
var react_1 = require("react");
var AppBar_1 = require("material-ui/AppBar");
var Toolbar_1 = require("material-ui/Toolbar");
var ToolbarGroup_1 = require("material-ui/Toolbar/ToolbarGroup");
var IconButton_1 = require("material-ui/IconButton");
var settings_1 = require("material-ui/svg-icons/action/settings");
var react_router_dom_1 = require("react-router-dom");
var Page = /** @class */ (function (_super) {
    __extends(Page, _super);
    function Page() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Page.prototype.render = function () {
        var _this = this;
        var myAppBar = function () { return (React.createElement(AppBar_1["default"], { title: _this.props.headerTitle, iconElementLeft: _this.props.leftButton, iconElementRight: _this.props.rightButton })); };
        return (React.createElement("div", { className: this.props.className },
            myAppBar(),
            this.props.body,
            this.props.showFooter == true &&
                React.createElement(Toolbar_1["default"], { className: "footerStyle" },
                    React.createElement(ToolbarGroup_1["default"], { firstChild: true }),
                    React.createElement(ToolbarGroup_1["default"], { lastChild: true },
                        React.createElement(IconButton_1["default"], { containerElement: React.createElement(react_router_dom_1.Link, { to: "/settings" }) },
                            React.createElement(settings_1["default"], null))))));
    };
    return Page;
}(react_1.Component));
exports["default"] = Page;
