/* eslint-disable */

import * as React from 'react';
import { Component } from 'react';
import {connect} from 'react-redux'
import { Redirect } from 'react-router-dom'

import Konst from '../utils/Konst';
import stateMgr from '../state/MyStateManager';
import MyUtils from "../utils/MyUtils";
import {IAppDb, IHabitData} from "../state/IAppDb";


interface AddHabitFormProps {
    appDb: IAppDb;
    reduxedAddEditHabit: Function;
    habId: string;
    action: string;
}

interface AddHabitFormState {
    habId: string;
    habName: string;
    habHist: string;
    submitSuccess: boolean;
}

class AddHabitForm extends Component<AddHabitFormProps, AddHabitFormState> {

    constructor(props) {
        super(props);

        let habitId = null
        let habitName = ""
        let habitHist = "-----"

        if(this.props.action == 'EDIT') {

            let habitData = stateMgr.getHabitById(this.props.appDb, this.props.habId)

            habitId = habitData[Konst.HAB_ID]
            habitName = habitData[Konst.HAB_NAME]
            habitHist = habitData[Konst.HAB_HIST]
        }

        this.state = {habId: habitId, habName: habitName, habHist:habitHist, submitSuccess: false };

        this.handleNameChange = this.handleNameChange.bind(this);
        this.handleHistChange = this.handleHistChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleNameChange(event) {

        this.setState({habName: event.target.value});
    }

    handleHistChange(event) {
        this.setState({habHist: event.target.value});
    }

    handleSubmit(event) {
        let me = "AddHabitForm.handleSubmit()"

        console.log(me, "IN", "this.props=", this.props, "localState=", this.state)

        try {

            // this bool is only be used in ADD mode.
            // in EDIT mode, habit name is not sent to model manager.
            let duplicateHabitName = ((this.props.action == 'EDIT') ||
                stateMgr.isDupHabitName( this.props.appDb, this.state.habName ) )

            console.log(me, "duplicateHabitName=", duplicateHabitName)

            let nullOrEmpty = MyUtils.isNullOrEmpty(this.state.habName)

            console.log(me, "nullOrEmpty=", nullOrEmpty, "this.state.habName=", this.state.habName)

            if(!duplicateHabitName && !nullOrEmpty) {
                this.props.reduxedAddEditHabit(this.state.habId, this.state.habName, this.state.habHist);
                this.setState({submitSuccess: true});
            }
            else {
                // todo: put red line around habit name box
                console.log(me, "add new habit rejected because duplicate|null|empty habit name:", this.state.habName)
            }

        }
        catch (e) {
            console.error(me)
        }
        finally {
            console.log(me, "OUT")

            event.preventDefault();

        }

    }



    render() {

        if (this.state.submitSuccess) {
            return (
                <Redirect to="/"/>
            )
        }

        return (

            <form onSubmit={this.handleSubmit}>
                <br />

                <label>
                    Name:&nbsp;&nbsp;
                    <input type="text" value={this.state.habName} onChange={this.handleNameChange} />
                </label>
                <br />

                <label>
                    History:&nbsp;
                    <input type="text" value={this.state.habHist} onChange={this.handleHistChange} />
                </label>
                <br /><br />

                <input type="submit" value="Submit" /><br />
            </form>
        );
    }
}


// container house keeping below here


function mapStateToProps(state) {
    return {
        appDb: state
    }
}


function mapDispatchToProps(dispatch) {

    return({ reduxedAddEditHabit: function(habId, habName, habHist) {

        let habit = {
            [Konst.HAB_ID]: habId,
            [Konst.HAB_NAME]: habName,
            [Konst.HAB_HIST]: habHist }

        console.log("reduxAddEditHabit(): habit=", habit)
        let dispatchArg = {
            type: (habId==null) ? Konst.ADD_HABIT : Konst.REPLACE_HABIT,
            targetHabit: habit
        };


        console.log("reduxAddEditHabit(): habit=", habit, "submitMode=", dispatchArg.type)

        dispatch(dispatchArg)
    } })
}


export default connect(mapStateToProps, mapDispatchToProps)(AddHabitForm);