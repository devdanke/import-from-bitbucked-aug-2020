"use strict";
/* eslint-disable */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var React = require("react");
var react_1 = require("react");
var react_redux_1 = require("react-redux");
var react_router_dom_1 = require("react-router-dom");
var Konst_1 = require("../utils/Konst");
var MyStateManager_1 = require("../state/MyStateManager");
var MyUtils_1 = require("../utils/MyUtils");
var AddHabitForm = /** @class */ (function (_super) {
    __extends(AddHabitForm, _super);
    function AddHabitForm(props) {
        var _this = _super.call(this, props) || this;
        var habitId = null;
        var habitName = "";
        var habitHist = "-----";
        if (_this.props.action == 'EDIT') {
            var habitData = MyStateManager_1["default"].getHabitById(_this.props.appDb, _this.props.habId);
            habitId = habitData[Konst_1["default"].HAB_ID];
            habitName = habitData[Konst_1["default"].HAB_NAME];
            habitHist = habitData[Konst_1["default"].HAB_HIST];
        }
        _this.state = { habId: habitId, habName: habitName, habHist: habitHist, submitSuccess: false };
        _this.handleNameChange = _this.handleNameChange.bind(_this);
        _this.handleHistChange = _this.handleHistChange.bind(_this);
        _this.handleSubmit = _this.handleSubmit.bind(_this);
        return _this;
    }
    AddHabitForm.prototype.handleNameChange = function (event) {
        this.setState({ habName: event.target.value });
    };
    AddHabitForm.prototype.handleHistChange = function (event) {
        this.setState({ habHist: event.target.value });
    };
    AddHabitForm.prototype.handleSubmit = function (event) {
        var me = "AddHabitForm.handleSubmit()";
        console.log(me, "IN", "this.props=", this.props, "localState=", this.state);
        try {
            // this bool is only be used in ADD mode.
            // in EDIT mode, habit name is not sent to model manager.
            var duplicateHabitName = ((this.props.action == 'EDIT') ||
                MyStateManager_1["default"].isDupHabitName(this.props.appDb, this.state.habName));
            console.log(me, "duplicateHabitName=", duplicateHabitName);
            var nullOrEmpty = MyUtils_1["default"].isNullOrEmpty(this.state.habName);
            console.log(me, "nullOrEmpty=", nullOrEmpty, "this.state.habName=", this.state.habName);
            if (!duplicateHabitName && !nullOrEmpty) {
                this.props.reduxedAddEditHabit(this.state.habId, this.state.habName, this.state.habHist);
                this.setState({ submitSuccess: true });
            }
            else {
                // todo: put red line around habit name box
                console.log(me, "add new habit rejected because duplicate|null|empty habit name:", this.state.habName);
            }
        }
        catch (e) {
            console.error(me);
        }
        finally {
            console.log(me, "OUT");
            event.preventDefault();
        }
    };
    AddHabitForm.prototype.render = function () {
        if (this.state.submitSuccess) {
            return (React.createElement(react_router_dom_1.Redirect, { to: "/" }));
        }
        return (React.createElement("form", { onSubmit: this.handleSubmit },
            React.createElement("br", null),
            React.createElement("label", null,
                "Name:\u00A0\u00A0",
                React.createElement("input", { type: "text", value: this.state.habName, onChange: this.handleNameChange })),
            React.createElement("br", null),
            React.createElement("label", null,
                "History:\u00A0",
                React.createElement("input", { type: "text", value: this.state.habHist, onChange: this.handleHistChange })),
            React.createElement("br", null),
            React.createElement("br", null),
            React.createElement("input", { type: "submit", value: "Submit" }),
            React.createElement("br", null)));
    };
    return AddHabitForm;
}(react_1.Component));
// container house keeping below here
function mapStateToProps(state) {
    return {
        appDb: state
    };
}
function mapDispatchToProps(dispatch) {
    return ({ reduxedAddEditHabit: function (habId, habName, habHist) {
            var habit = (_a = {},
                _a[Konst_1["default"].HAB_ID] = habId,
                _a[Konst_1["default"].HAB_NAME] = habName,
                _a[Konst_1["default"].HAB_HIST] = habHist,
                _a);
            console.log("reduxAddEditHabit(): habit=", habit);
            var dispatchArg = {
                type: (habId == null) ? Konst_1["default"].ADD_HABIT : Konst_1["default"].REPLACE_HABIT,
                targetHabit: habit
            };
            console.log("reduxAddEditHabit(): habit=", habit, "submitMode=", dispatchArg.type);
            dispatch(dispatchArg);
            var _a;
        } });
}
exports["default"] = react_redux_1.connect(mapStateToProps, mapDispatchToProps)(AddHabitForm);
