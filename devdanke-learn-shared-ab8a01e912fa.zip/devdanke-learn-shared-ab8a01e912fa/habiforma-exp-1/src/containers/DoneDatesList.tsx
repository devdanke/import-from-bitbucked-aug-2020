/* eslint-disable */
import * as React from 'react';
import {Component, ReactElement} from 'react';
import {connect} from 'react-redux'

import stateMgr from "../state/MyStateManager";

import {IHabitData} from "../state/IAppDb";
import Checkbox from "material-ui/Checkbox";

import {
    Table,
    TableBody,
    TableRow,
    TableRowColumn,
} from 'material-ui/Table';

import MyDateUtils from "../utils/MyDateUtils";
import Konst from "../utils/Konst";


interface IDoneDatesListProps {
    habitDataList: IHabitData[],
    lookbackDaysCount: number,
    redux_prepForDispatch_updateHabitDoneDate: Function
}

interface IGridCellData {
    habId: string;
    isDone: boolean;
    yyyymmdd: string;
}

interface IDoneDatesListState {

    uiRowHeight: string;
    uiDateRowLabels: string[];
    gridData: Array<Array<IGridCellData>>;
}


class DoneDatesList extends Component<IDoneDatesListProps,IDoneDatesListState> {

    constructor(props){
        super(props)

        this.handleCboxChange = this.handleCboxChange.bind(this);

        this.makeCboxRow = this.makeCboxRow.bind(this);
        this.makeCompleteDoneDatesGrid = this.makeCompleteDoneDatesGrid.bind(this);
        this.makeCbox = this.makeCbox.bind(this);

        this.extractDayOfMonthOr1CharInMonthName = this.extractDayOfMonthOr1CharInMonthName.bind(this);
        this.makeRowData = this.makeRowData.bind(this);
        this.makeGridData = this.makeGridData.bind(this);

        this.initStateFromProps = this.initStateFromProps.bind(this);

        this.initStateFromProps(props)

        console.log("DoneDatesList.ctor() state:", this.state)
    }

    initStateFromProps(props: IDoneDatesListProps) {
        let startDate = new Date()
        let dateRowValues = DoneDatesList.makeYyyymmddDateRangeValues(startDate, props.lookbackDaysCount)

        this.state = {
            uiRowHeight: '53px',
            uiDateRowLabels: dateRowValues.map((yyyymmdd)=> this.extractDayOfMonthOr1CharInMonthName(yyyymmdd) ),
            gridData: this.makeGridData(this.props.habitDataList, dateRowValues)
        }
    }

    componentWillReceiveProps(props) {
        // i think this is not called in ctor, but on every state change after that.
        this.initStateFromProps(props)
    }

    makeGridData(habitDataList: IHabitData[], days: string[]): Array<Array<IGridCellData>> {

        return habitDataList.map((habitData): Array<IGridCellData> => {

            return this.makeRowData(habitData, days)
        });
    }

    makeRowData(habitData: IHabitData, days: string[]): Array<IGridCellData> {

        return days.map((targetDate): IGridCellData => {

            return {
                habId: habitData.id,
                isDone: (habitData.hist.indexOf(targetDate) > -1),
                yyyymmdd: targetDate
            }
        });
    }


    handleCboxChange(event: any, isInputChecked: boolean) {

        // get the cbox compo
        let cbox = event.target
        let cboxData = cbox.dataset
        console.log("handleCboxChange() target:", cbox.tagName,
            "isInputChecked:", isInputChecked,
            "targetDate:", cboxData.doneDate,
            "habId:", cboxData.habitId)
        this.props.redux_prepForDispatch_updateHabitDoneDate(cboxData.habitId, cboxData.doneDate, isInputChecked)
    }



    //style={{width: '4%'}}
    makeCbox(gridCellData: IGridCellData, colNum: number): ReactElement<TableRowColumn> {

        return <TableRowColumn
            key={"gridCellKey-".concat(gridCellData.habId).concat("-").concat(colNum.toString())}
            style={{paddingLeft: 0, paddingRight: 0, textAlign: 'center'}}>

            <Checkbox
                data-done-date={gridCellData.yyyymmdd}
                data-habit-id={gridCellData.habId}
                checked={gridCellData.isDone}
                onCheck={this.handleCboxChange}
                label=""/>

        </TableRowColumn>
    }

    makeCboxRow(gridRowData: Array<IGridCellData>): ReactElement<TableRowColumn>[] {

        return gridRowData.map((gridCellData, colNum)=>{
            return this.makeCbox(gridCellData, colNum)
        })
    }

    /*
    Put all the habit doneDone data and date labels into UI componenents.
    First items in the result are checkbox rows.
    Last item is date labels.
    All are put into Grid column compoenents.

    Data comes from DoneDatesList state.
     */
     makeCompleteDoneDatesGrid(myState: IDoneDatesListState): ReactElement<TableRow>[] {

        let cboxRows: ReactElement<TableRow>[] = myState.gridData.map((gridRow, i) => {
            return <TableRow
                key={"doneDateGridCboxRow-".concat("-"+i)}
                style={{height: myState.uiRowHeight, overflowX: 'auto'}}>

                {this.makeCboxRow(gridRow)}

            </TableRow>
        });

         let dateLabelCols =  myState.uiDateRowLabels.map((dateLabel, colNum)=> {
            return <TableRowColumn
                key={"gridDateLable-".concat(colNum.toString())}
                style={{paddingLeft: 0, paddingRight: 0, textAlign: 'center'}}>

                {dateLabel}

            </TableRowColumn>
         });

         let dateLabelRow =
             <TableRow
                 key={"doneDateGridFooter"}
                 style={{height: myState.uiRowHeight, backgroundColor: 'lightgray', overflowX: 'auto'}}>
                {dateLabelCols}
             </TableRow>;

        //return allRows
        return cboxRows.concat( dateLabelRow)
    }


    extractDayOfMonthOr1CharInMonthName(yyyymmdd): string {

        let dayNum = parseInt(yyyymmdd.substr(6,2))
        if(dayNum==1) {
            return MyDateUtils.month1stChar(yyyymmdd)
        }
        else {
            return dayNum.toString()
        }
    }

    static makeYyyymmddDateRangeValues(today: Date, prevDayCount: number): string[] {

        let result: string[] =[]

        // start at current date minus prevDayCount
        let curDate = new Date(today.getTime());
        curDate.setDate(curDate.getDate()-(prevDayCount-1))
        for(let i=0; i < prevDayCount; i++) {

            result.push(MyDateUtils.toYyyymmdd(curDate))
            curDate.setDate( curDate.getDate() + 1);
        }

        return result
    }



    render() {

        console.log("DoneDatesList.render()", this.props.habitDataList )

        return (

            <Table selectable={false} >
                <TableBody displayRowCheckbox={false} style={{ overflowX: 'auto'}}>
                    {this.makeCompleteDoneDatesGrid(this.state)}
                </TableBody>
            </Table>
        );
  }
}


function mapStateToProps(state) {
    return {
        habitDataList: stateMgr.getHabitListState(state),
        appDb: state
    }
}

/*
Submit a list of dates and a habit id to model manager.
 */
function mapDispatchToProps(dispatch) {

    return({
        redux_prepForDispatch_updateHabitDoneDate: function(habId: string, doneDate: string, isDone: boolean) {

        console.log("redux_prepForDispatch_updateHabitDoneDate(): habid:", habId, "doneDate:", doneDate, "isDone:", isDone)
        let dispatchArg = {
            type: isDone ? Konst.HABIT_ADD_DONE_DATE : Konst.HABIT_DELETE_DONE_DATE,
            habId: habId,
            targetDate: doneDate,
        };

        dispatch(dispatchArg)
    } })
}

export default connect(mapStateToProps, mapDispatchToProps)(DoneDatesList);

