"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
/* eslint-disable */
var React = require("react");
var react_1 = require("react");
var react_redux_1 = require("react-redux");
var MyStateManager_1 = require("../state/MyStateManager");
var svg_icons_1 = require("material-ui/svg-icons");
var List_1 = require("material-ui/List");
var Divider_1 = require("material-ui/Divider");
var material_ui_1 = require("material-ui");
var react_router_dom_1 = require("react-router-dom");
var HabitList = /** @class */ (function (_super) {
    __extends(HabitList, _super);
    function HabitList() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    HabitList.prototype.render = function () {
        console.log("habitDataList:", this.props.habitDataList);
        console.log("habitDataListFromConnect:", this.props.habitDataListFromConnect);
        var listItems = this.props.habitDataList.map(function (habitDataItem) {
            var listItem = React.createElement(List_1.ListItem, { key: habitDataItem.id, primaryText: habitDataItem.name, rightIconButton: React.createElement(material_ui_1.IconButton, { containerElement: React.createElement(react_router_dom_1.Link, { to: {
                            pathname: '/habit',
                            state: {
                                action: "EDIT",
                                habId: habitDataItem.id
                            }
                        } }) },
                    " ",
                    React.createElement(svg_icons_1.AvPlayArrow, null),
                    " ") });
            return listItem;
        });
        //    let divIdBase: number = 1;
        // add divider between list items
        var dividedListItems = [].concat.apply([], listItems.map(function (e) { return [(React.createElement(Divider_1["default"], { key: Math.random() })), e]; })).slice(1);
        //  const dividedListItems: ReactElement<any>[] = [].concat(...listItems.map(e => [(<Divider key={(divIdBase++)}/>), e])).slice(1)
        return (React.createElement(List_1.List, null, dividedListItems));
    };
    return HabitList;
}(react_1.Component));
function mapStateToProps(state) {
    return { habitDataList: MyStateManager_1["default"].getHabitListState(state) };
}
exports["default"] = react_redux_1.connect(mapStateToProps)(HabitList);
