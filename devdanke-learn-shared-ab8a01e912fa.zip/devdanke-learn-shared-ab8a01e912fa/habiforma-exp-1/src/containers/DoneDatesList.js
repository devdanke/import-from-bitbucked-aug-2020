"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
/* eslint-disable */
var React = require("react");
var react_1 = require("react");
var react_redux_1 = require("react-redux");
var MyStateManager_1 = require("../state/MyStateManager");
var Checkbox_1 = require("material-ui/Checkbox");
var Table_1 = require("material-ui/Table");
var MyDateUtils_1 = require("../utils/MyDateUtils");
var Konst_1 = require("../utils/Konst");
var DoneDatesList = /** @class */ (function (_super) {
    __extends(DoneDatesList, _super);
    function DoneDatesList(props) {
        var _this = _super.call(this, props) || this;
        _this.handleCboxChange = _this.handleCboxChange.bind(_this);
        _this.makeCboxRow = _this.makeCboxRow.bind(_this);
        _this.makeCompleteDoneDatesGrid = _this.makeCompleteDoneDatesGrid.bind(_this);
        _this.makeCbox = _this.makeCbox.bind(_this);
        _this.extractDayOfMonthOr1CharInMonthName = _this.extractDayOfMonthOr1CharInMonthName.bind(_this);
        _this.makeRowData = _this.makeRowData.bind(_this);
        _this.makeGridData = _this.makeGridData.bind(_this);
        _this.initStateFromProps = _this.initStateFromProps.bind(_this);
        _this.initStateFromProps(props);
        console.log("DoneDatesList.ctor() state:", _this.state);
        return _this;
    }
    DoneDatesList.prototype.initStateFromProps = function (props) {
        var _this = this;
        var startDate = new Date();
        var dateRowValues = DoneDatesList.makeYyyymmddDateRangeValues(startDate, props.lookbackDaysCount);
        this.state = {
            uiRowHeight: '53px',
            uiDateRowLabels: dateRowValues.map(function (yyyymmdd) { return _this.extractDayOfMonthOr1CharInMonthName(yyyymmdd); }),
            gridData: this.makeGridData(this.props.habitDataList, dateRowValues)
        };
    };
    DoneDatesList.prototype.componentWillReceiveProps = function (props) {
        // i think this is not called in ctor, but on every state change after that.
        this.initStateFromProps(props);
    };
    DoneDatesList.prototype.makeGridData = function (habitDataList, days) {
        var _this = this;
        return habitDataList.map(function (habitData) {
            return _this.makeRowData(habitData, days);
        });
    };
    DoneDatesList.prototype.makeRowData = function (habitData, days) {
        return days.map(function (targetDate) {
            return {
                habId: habitData.id,
                isDone: (habitData.hist.indexOf(targetDate) > -1),
                yyyymmdd: targetDate
            };
        });
    };
    DoneDatesList.prototype.handleCboxChange = function (event, isInputChecked) {
        // get the cbox compo
        var cbox = event.target;
        var cboxData = cbox.dataset;
        console.log("handleCboxChange() target:", cbox.tagName, "isInputChecked:", isInputChecked, "targetDate:", cboxData.doneDate, "habId:", cboxData.habitId);
        this.props.redux_prepForDispatch_updateHabitDoneDate(cboxData.habitId, cboxData.doneDate, isInputChecked);
    };
    //style={{width: '4%'}}
    DoneDatesList.prototype.makeCbox = function (gridCellData, colNum) {
        return React.createElement(Table_1.TableRowColumn, { key: "gridCellKey-".concat(gridCellData.habId).concat("-").concat(colNum.toString()), style: { paddingLeft: 0, paddingRight: 0, textAlign: 'center' } },
            React.createElement(Checkbox_1["default"], { "data-done-date": gridCellData.yyyymmdd, "data-habit-id": gridCellData.habId, checked: gridCellData.isDone, onCheck: this.handleCboxChange, label: "" }));
    };
    DoneDatesList.prototype.makeCboxRow = function (gridRowData) {
        var _this = this;
        return gridRowData.map(function (gridCellData, colNum) {
            return _this.makeCbox(gridCellData, colNum);
        });
    };
    /*
    Put all the habit doneDone data and date labels into UI componenents.
    First items in the result are checkbox rows.
    Last item is date labels.
    All are put into Grid column compoenents.

    Data comes from DoneDatesList state.
     */
    DoneDatesList.prototype.makeCompleteDoneDatesGrid = function (myState) {
        var _this = this;
        var cboxRows = myState.gridData.map(function (gridRow, i) {
            return React.createElement(Table_1.TableRow, { key: "doneDateGridCboxRow-".concat("-" + i), style: { height: myState.uiRowHeight, overflowX: 'auto' } }, _this.makeCboxRow(gridRow));
        });
        var dateLabelCols = myState.uiDateRowLabels.map(function (dateLabel, colNum) {
            return React.createElement(Table_1.TableRowColumn, { key: "gridDateLable-".concat(colNum.toString()), style: { paddingLeft: 0, paddingRight: 0, textAlign: 'center' } }, dateLabel);
        });
        var dateLabelRow = React.createElement(Table_1.TableRow, { key: "doneDateGridFooter", style: { height: myState.uiRowHeight, backgroundColor: 'lightgray', overflowX: 'auto' } }, dateLabelCols);
        //return allRows
        return cboxRows.concat(dateLabelRow);
    };
    DoneDatesList.prototype.extractDayOfMonthOr1CharInMonthName = function (yyyymmdd) {
        var dayNum = parseInt(yyyymmdd.substr(6, 2));
        if (dayNum == 1) {
            return MyDateUtils_1["default"].month1stChar(yyyymmdd);
        }
        else {
            return dayNum.toString();
        }
    };
    DoneDatesList.makeYyyymmddDateRangeValues = function (today, prevDayCount) {
        var result = [];
        // start at current date minus prevDayCount
        var curDate = new Date(today.getTime());
        curDate.setDate(curDate.getDate() - (prevDayCount - 1));
        for (var i = 0; i < prevDayCount; i++) {
            result.push(MyDateUtils_1["default"].toYyyymmdd(curDate));
            curDate.setDate(curDate.getDate() + 1);
        }
        return result;
    };
    DoneDatesList.prototype.render = function () {
        console.log("DoneDatesList.render()", this.props.habitDataList);
        return (React.createElement(Table_1.Table, { selectable: false },
            React.createElement(Table_1.TableBody, { displayRowCheckbox: false, style: { overflowX: 'auto' } }, this.makeCompleteDoneDatesGrid(this.state))));
    };
    return DoneDatesList;
}(react_1.Component));
function mapStateToProps(state) {
    return {
        habitDataList: MyStateManager_1["default"].getHabitListState(state),
        appDb: state
    };
}
/*
Submit a list of dates and a habit id to model manager.
 */
function mapDispatchToProps(dispatch) {
    return ({
        redux_prepForDispatch_updateHabitDoneDate: function (habId, doneDate, isDone) {
            console.log("redux_prepForDispatch_updateHabitDoneDate(): habid:", habId, "doneDate:", doneDate, "isDone:", isDone);
            var dispatchArg = {
                type: isDone ? Konst_1["default"].HABIT_ADD_DONE_DATE : Konst_1["default"].HABIT_DELETE_DONE_DATE,
                habId: habId,
                targetDate: doneDate
            };
            dispatch(dispatchArg);
        }
    });
}
exports["default"] = react_redux_1.connect(mapStateToProps, mapDispatchToProps)(DoneDatesList);
