"use strict";
/* eslint-disable */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var React = require("react");
var react_1 = require("react");
var react_router_dom_1 = require("react-router-dom");
var MuiThemeProvider_1 = require("material-ui/styles/MuiThemeProvider");
require("./App.css");
var HabitListPage_1 = require("./pages/HabitListPage");
var HabitDetailPage_1 = require("./pages/HabitDetailPage");
var SettingsPage_1 = require("./pages/SettingsPage");
var App = /** @class */ (function (_super) {
    __extends(App, _super);
    function App() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /* i am so cool */
    App.prototype.render = function () {
        console.log("in my app.tsx");
        return (React.createElement(MuiThemeProvider_1["default"], null,
            React.createElement(react_router_dom_1.BrowserRouter, null,
                React.createElement("div", { className: "App" },
                    React.createElement(react_router_dom_1.Route, { path: "/", exact: true, component: HabitListPage_1["default"] }),
                    React.createElement(react_router_dom_1.Route, { path: "/habit", exact: true, component: HabitDetailPage_1["default"] }),
                    React.createElement(react_router_dom_1.Route, { path: "/settings XXX", exact: true, component: SettingsPage_1["default"] })))));
    };
    return App;
}(react_1.Component));
exports["default"] = App;
