/* eslint-disable */

import * as React from 'react';
import {Component} from 'react';

import { BrowserRouter, Route } from 'react-router-dom'
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';


import './App.css';
import HabitListPage from "./pages/HabitListPage";
import HabitDetailPage from "./pages/HabitDetailPage";
import SettingsPage from "./pages/SettingsPage";

export default class App extends Component {
    /* i am so cool */
  render() {

      console.log("in my app.tsx")
    return (
        <MuiThemeProvider>
            <BrowserRouter>
                <div className="App">
                    <Route path="/" exact component={HabitListPage}/>
                    <Route path="/habit" exact component={HabitDetailPage}/>
                    <Route path="/settings XXX" exact component={SettingsPage}/>
                </div>
            </BrowserRouter>
        </MuiThemeProvider>

    );
  }
}


