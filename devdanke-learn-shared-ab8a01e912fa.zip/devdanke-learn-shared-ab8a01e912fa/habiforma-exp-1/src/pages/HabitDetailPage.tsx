import * as React from 'react';
import { Component } from 'react';

import AddHabitForm from "../containers/AddHabitForm"

import './CommonPage.css';
import Page from '../components/Page'

import IconButton from "material-ui/IconButton";
import NavigationArrowBack from "material-ui/svg-icons/navigation/arrow-back";
import {Link} from "react-router-dom";


export default class HabitDetailPage extends Component {

    constructor(props) {
        super(props);
        console.log("habitDetailPage.ctor() location.state:", props.location.state);
    }

    render() {
        const backBtn = <IconButton containerElement={<Link to="/"/>}> <NavigationArrowBack /> </IconButton>;
        //console.log("habitDetailPage.render(): about to render page.", new Date().toISOString());

        return (

            <Page className="commonPage" body={
                <AddHabitForm
                    habId={this.props.location.state.habId}
                    action={this.props.location.state.action} />}

                  headerTitle="Habit"
                  leftButton={backBtn}

            />
        );
    }
}

