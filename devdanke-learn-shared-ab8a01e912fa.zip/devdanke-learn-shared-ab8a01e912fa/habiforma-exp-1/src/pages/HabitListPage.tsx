import * as React from 'react';
import { Component } from 'react';
import {Link} from 'react-router-dom'

import './CommonPage.css';

import Page from '../components/Page'
import HabitList from '../containers/HabitList'
import ContentAdd from "material-ui/svg-icons/content/add";
import IconButton from "material-ui/IconButton";
import EditorModeEdit from "material-ui/svg-icons/editor/mode-edit";
import AppBar from "material-ui/AppBar";
import Drawer from "material-ui/Drawer";
import {NavigationClose} from "material-ui/svg-icons";
import DoneDatesList from "../containers/DoneDatesList";




interface HabitListPageState {
    drawerOpen: boolean
}

export default class HabitListPage extends Component <any,HabitListPageState>{

    constructor(props) {
        super(props);
        console.log("in my habitListPage ctor props:", props)
        this.state = {drawerOpen: false};
    }


    render() {
console.log("in HabitListPage render()")
        const addHabitBtn =
            <IconButton containerElement={<Link to={{
                    pathname: '/habit',
                    state: {
                        action: "ADD"
                    }
                }} />}  >
                    <ContentAdd />
            </IconButton>;

        const habitListCompo = <HabitList />

        return (
            <div>
                <Page className="commonPage"
                      body={habitListCompo}

                      headerTitle="Habits"
                      leftButton={addHabitBtn}

                      rightButton={<IconButton
                          onClick={() => {this.setState({drawerOpen: !this.state.drawerOpen})}}>
                          <EditorModeEdit />
                      </IconButton>}

                      showFooter={true}
                />

                <Drawer width={"80%"} openSecondary={true} open={this.state.drawerOpen} >

                    <AppBar title="History"
                            showMenuIconButton={false}
                            iconElementRight={<IconButton
                                onClick={() => {this.setState({drawerOpen: !this.state.drawerOpen})}}>
                                <NavigationClose />
                            </IconButton>}
                    />

                    <DoneDatesList lookbackDaysCount={25}/>


                </Drawer>

            </div>


        );
    }
}
/*


 */




