"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var React = require("react");
var react_1 = require("react");
var react_router_dom_1 = require("react-router-dom");
require("./CommonPage.css");
var Page_1 = require("../components/Page");
var HabitList_1 = require("../containers/HabitList");
var add_1 = require("material-ui/svg-icons/content/add");
var IconButton_1 = require("material-ui/IconButton");
var mode_edit_1 = require("material-ui/svg-icons/editor/mode-edit");
var AppBar_1 = require("material-ui/AppBar");
var Drawer_1 = require("material-ui/Drawer");
var svg_icons_1 = require("material-ui/svg-icons");
var DoneDatesList_1 = require("../containers/DoneDatesList");
var HabitListPage = /** @class */ (function (_super) {
    __extends(HabitListPage, _super);
    function HabitListPage(props) {
        var _this = _super.call(this, props) || this;
        console.log("in my habitListPage ctor props:", props);
        _this.state = { drawerOpen: false };
        return _this;
    }
    HabitListPage.prototype.render = function () {
        var _this = this;
        console.log("in HabitListPage render()");
        var addHabitBtn = React.createElement(IconButton_1["default"], { containerElement: React.createElement(react_router_dom_1.Link, { to: {
                    pathname: '/habit',
                    state: {
                        action: "ADD"
                    }
                } }) },
            React.createElement(add_1["default"], null));
        var habitListCompo = React.createElement(HabitList_1["default"], null);
        return (React.createElement("div", null,
            React.createElement(Page_1["default"], { className: "commonPage", body: habitListCompo, headerTitle: "Habits", leftButton: addHabitBtn, rightButton: React.createElement(IconButton_1["default"], { onClick: function () { _this.setState({ drawerOpen: !_this.state.drawerOpen }); } },
                    React.createElement(mode_edit_1["default"], null)), showFooter: true }),
            React.createElement(Drawer_1["default"], { width: "80%", openSecondary: true, open: this.state.drawerOpen },
                React.createElement(AppBar_1["default"], { title: "History", showMenuIconButton: false, iconElementRight: React.createElement(IconButton_1["default"], { onClick: function () { _this.setState({ drawerOpen: !_this.state.drawerOpen }); } },
                        React.createElement(svg_icons_1.NavigationClose, null)) }),
                React.createElement(DoneDatesList_1["default"], { lookbackDaysCount: 25 }))));
    };
    return HabitListPage;
}(react_1.Component));
exports["default"] = HabitListPage;
/*


 */
