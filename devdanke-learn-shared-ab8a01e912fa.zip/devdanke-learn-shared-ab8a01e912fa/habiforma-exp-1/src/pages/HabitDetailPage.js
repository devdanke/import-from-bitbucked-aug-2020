"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var React = require("react");
var react_1 = require("react");
var AddHabitForm_1 = require("../containers/AddHabitForm");
require("./CommonPage.css");
var Page_1 = require("../components/Page");
var IconButton_1 = require("material-ui/IconButton");
var arrow_back_1 = require("material-ui/svg-icons/navigation/arrow-back");
var react_router_dom_1 = require("react-router-dom");
var HabitDetailPage = /** @class */ (function (_super) {
    __extends(HabitDetailPage, _super);
    function HabitDetailPage(props) {
        var _this = _super.call(this, props) || this;
        console.log("habitDetailPage.ctor() location.state:", props.location.state);
        return _this;
    }
    HabitDetailPage.prototype.render = function () {
        var backBtn = React.createElement(IconButton_1["default"], { containerElement: React.createElement(react_router_dom_1.Link, { to: "/" }) },
            " ",
            React.createElement(arrow_back_1["default"], null),
            " ");
        //console.log("habitDetailPage.render(): about to render page.", new Date().toISOString());
        return (React.createElement(Page_1["default"], { className: "commonPage", body: React.createElement(AddHabitForm_1["default"], { habId: this.props.location.state.habId, action: this.props.location.state.action }), headerTitle: "Habit", leftButton: backBtn }));
    };
    return HabitDetailPage;
}(react_1.Component));
exports["default"] = HabitDetailPage;
