/* eslint-disable */
import * as React from 'react';
import { Component } from 'react';

import Page from '../components/Page'
import NavigationArrowBack from "material-ui/svg-icons/navigation/arrow-back";
import {Link} from "react-router-dom";
import IconButton from "material-ui/IconButton";

import './CommonPage.css';


class SettingsPage extends Component {

    render() {
        const backBtn = <IconButton containerElement={<Link to="/"/>}> <NavigationArrowBack /> </IconButton>;


        return (
            <Page
                className="commonPage"
                body={"no body yet"}

                headerTitle="Settings"
                leftButton={backBtn}

            />
        );
  }
}

export default SettingsPage;
