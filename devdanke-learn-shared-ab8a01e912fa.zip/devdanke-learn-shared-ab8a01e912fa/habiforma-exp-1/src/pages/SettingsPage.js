"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
/* eslint-disable */
var React = require("react");
var react_1 = require("react");
var Page_1 = require("../components/Page");
var arrow_back_1 = require("material-ui/svg-icons/navigation/arrow-back");
var react_router_dom_1 = require("react-router-dom");
var IconButton_1 = require("material-ui/IconButton");
require("./CommonPage.css");
var SettingsPage = /** @class */ (function (_super) {
    __extends(SettingsPage, _super);
    function SettingsPage() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SettingsPage.prototype.render = function () {
        var backBtn = React.createElement(IconButton_1["default"], { containerElement: React.createElement(react_router_dom_1.Link, { to: "/" }) },
            " ",
            React.createElement(arrow_back_1["default"], null),
            " ");
        return (React.createElement(Page_1["default"], { className: "commonPage", body: "no body yet", headerTitle: "Settings", leftButton: backBtn }));
    };
    return SettingsPage;
}(react_1.Component));
exports["default"] = SettingsPage;
