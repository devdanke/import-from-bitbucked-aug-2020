import React, { Component } from 'react';
import './HabitsPage.css';


class HabitsPage extends Component {
  render() {
    return (
      <div>


        <div className="HabitsPage-placeHolder">
        <HabitsPageHeader />

          habits page

          <HabitsPageFooter />
        </div>

      </div>
    );
  }
}

class HabitsPageHeader extends Component {
  render() {
    return (
      <div className="HabitsPageHeader-placeHolder">
        habits header
      </div>
    );
  }
}

class HabitsPageFooter extends Component {
  render() {
    return (
      <div className="HabitsPageFooter-placeHolder">
        habits footer
      </div>
    );
  }
}

export default HabitsPage;
