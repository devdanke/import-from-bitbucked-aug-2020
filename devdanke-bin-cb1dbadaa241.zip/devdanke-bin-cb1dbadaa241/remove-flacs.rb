
rootDir = "/media/SAMMY_640_A/_music"
destDir = "/media/SAMMY_640_A/__temp-flac"

# list all flac files under rootDir
Dir.glob("#{rootDir}/**/*.flac").each { |file|

    fileName = File.basename file
    File.rename(file, destDir + "/" + fileName)

}


