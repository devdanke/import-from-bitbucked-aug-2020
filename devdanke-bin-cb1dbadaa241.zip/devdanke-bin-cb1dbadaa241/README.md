# This is my README


A project full of dynamic and shell scripts.  Some are long-term helpers, like ideaClean.  Others are temporary, like some I have for 
converting my music collection from flac to ogg.

These few scripts are really part of the CMS workflows.