# list all flac files under a dir DONE
# know if file has illegal char DONE
# provide alt name if file contains illegal char DONE
# rename files DONE
# convert files from flac to ogg <<<
# convert files from flac to ogg <<<
# delete flac files

rootDir = "/media/SAMMY_640_A/_music"
goodCount = 0
badCount = 0

def makeSafeName(fileName)
    safeName = "#{fileName}"
    safeName.gsub!('.flac','_FLACK')
    safeName.gsub!('&','-')
    safeName.gsub!(',','-')
    safeName.gsub!(' ','-')
    safeName.gsub!('.','')
    safeName.gsub!("'",'')
    safeName.gsub!("(",'')
    safeName.gsub!(")",'')
    safeName.gsub!("---",'-')
    safeName.gsub!("--",'-')
    safeName.gsub!("_FLACK",'.flac')

    safeName
end

# list all flac files under rootDir
Dir.glob("#{rootDir}/**/*.flac").each { |file|

    fileName = File.basename file
    if fileName =~ / /
        badCount += 1
        safeName = makeSafeName(fileName)
        puts "FixMe: #{safeName}, orig: #{file}"

        File.rename(file, File.dirname(file) + "/" + safeName)
    else
        goodCount += 1
    end

}
puts "file total: #{goodCount+badCount}, good: #{goodCount}, bad: #{badCount}"

