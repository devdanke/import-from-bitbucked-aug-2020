
targDir = "/media/SAMMY_640_A/__temp-flac"

# list all flac files under rootDir

File.open("#{targDir}/aaaa_flac_file_problems.txt", 'w') { |outFile|

    Dir.glob("#{targDir}/**/*.flac").each { |file|

        result = `flac --test --silent --decode --no-decode-through-errors #{file}`
        if $? != 0
            outFile.write( "FLAC PROB: #{File.basename file}\n")
        end
    }
}



