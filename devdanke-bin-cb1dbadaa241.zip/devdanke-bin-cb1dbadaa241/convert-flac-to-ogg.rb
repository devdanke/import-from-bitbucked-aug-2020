
# convert files from flac to ogg <<<
# delete flac files

rootDir = "/media/SAMMY_640_A/_music"
count = 0


# list all flac files under rootDir
Dir.glob("#{rootDir}/**/*.flac").each { |file|
    count += 1
    flacFileName = File.basename file
    oggFileName = flacFileName.gsub!(".flac", ".ogg")
    outFilePath = File.dirname(file) + "/" + oggFileName
    cmd = "oggenc -q 7 -o #{outFilePath} #{file}"
    result = `#{cmd}`
    puts "result: #{result}"
}
puts "file count: #{count}."

